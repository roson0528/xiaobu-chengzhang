"""清除所有测试账号与测试数据，仅保留 admin 账号。"""
import asyncio
import sqlite3

from app.services.webdav_service import webdav_service

DB = "/app/data/app.db"


def clean_db():
    c = sqlite3.connect(DB)
    # 测试账号（保留 id=1 的 admin）
    c.execute("DELETE FROM children")
    c.execute("DELETE FROM users WHERE id IN (11, 12, 13)")
    c.execute("DELETE FROM audit_log")
    c.execute("DELETE FROM notifications")
    c.commit()
    print("=== users 剩余 ===")
    for r in c.execute("SELECT id, username, role, family_id FROM users ORDER BY id"):
        print(r)
    print("=== children 剩余 ===")
    for r in c.execute("SELECT id, name, user_id FROM children"):
        print(r)
    c.close()


async def _rm(path):
    try:
        items = await webdav_service.list_files(path)
    except Exception:
        items = []
    for it in items:
        await _rm(f"{path}/{it}".rstrip("/"))
    await webdav_service.delete(path)
    print("deleted", path)


async def clean_webdav():
    for p in ["child_22a28d48", "friends", "fam_main", "fam_admin/family_chat.json"]:
        try:
            await _rm(p)
        except Exception as e:
            print("err", p, repr(e))


if __name__ == "__main__":
    clean_db()
    asyncio.run(clean_webdav())
    print("=== 完成后 WebDAV 根目录 ===")
    print(asyncio.run(webdav_service.list_files("")))
