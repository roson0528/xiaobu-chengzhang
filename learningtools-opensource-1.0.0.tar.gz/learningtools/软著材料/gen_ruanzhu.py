#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
软著源程序材料生成器
======================
按「前 30 页 + 后 30 页、每页 50 行」生成源程序材料。
- 前 30 页：后端(Python) + 孩子端(Dart)
- 后 30 页：家长端(Dart) + 管理前端(Vue/TS)
共 60 页 × 50 行 = 3000 行（每个模块各取 750 行连续代码段）。

输出：
  - 源程序.txt   纯文本（每页带页眉标记，便于校对）
  - 源程序.html  打印就绪版（浏览器打开后「打印 → 另存为 PDF」即可）
"""
import os
import html

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

SOFT_NAME = "小步成长亲子学习管理平台软件"
SOFT_VERSION = "V3.0"
PAGE_LINES = 50
PAGES = 60
LINES_PER_MODULE = PAGE_LINES * PAGES // 4  # 750

MODULES = [
    # (名称, 目录, 扩展名集合, 优先排前的文件名)
    ("后端服务", os.path.join(ROOT, "backend", "app"), {".py"},
     ["main.py", "config.py", "database.py"]),
    ("孩子端APP", os.path.join(ROOT, "app", "child_app", "lib"), {".dart"},
     ["main.dart"]),
    ("家长端APP", os.path.join(ROOT, "app", "parent_app", "lib"), {".dart"},
     ["main.dart"]),
    ("管理前端", os.path.join(ROOT, "frontend", "src"), {".vue", ".ts"},
     ["main.ts"]),
]


def _comment_prefix(ext: str) -> str:
    return "#" if ext == ".py" else "//"


def _priority(fname: str, priorities: list) -> int:
    for i, p in enumerate(priorities):
        if fname == p:
            return i
    return len(priorities)


def collect_module(module_dir: str, exts: set, priorities: list) -> list:
    """返回该模块按规范顺序排列的源文件相对路径列表。"""
    files = []
    for dirpath, _dirs, names in os.walk(module_dir):
        for n in names:
            if os.path.splitext(n)[1].lower() in exts:
                files.append(os.path.join(dirpath, n))
    files.sort(key=lambda p: (
        _priority(os.path.basename(p), priorities),
        os.path.relpath(p, module_dir),
    ))
    return [os.path.relpath(p, module_dir) for p in files]


def module_lines(module_dir: str, relpaths: list, limit: int) -> list:
    """读取模块文件，去掉空行，返回前 limit 行（含文件分隔注释行）。"""
    lines = []
    for rel in relpaths:
        if len(lines) >= limit:
            break
        path = os.path.join(module_dir, rel)
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                raw = f.read().splitlines()
        except OSError:
            continue
        ext = os.path.splitext(rel)[1].lower()
        prefix = _comment_prefix(ext)
        lines.append(f"{prefix} ==================== 文件：{rel} ====================")
        for ln in raw:
            if len(lines) >= limit:
                break
            if ln.strip():  # 去掉空行
                lines.append(ln.rstrip())
    return lines[:limit]


def build_listing() -> list:
    """返回 3000 行（前30页=后端+孩子端，后30页=家长端+前端）。"""
    listing = []
    for name, module_dir, exts, priorities in MODULES:
        relpaths = collect_module(module_dir, exts, priorities)
        listing.extend(module_lines(module_dir, relpaths, LINES_PER_MODULE))
        print(f"[{name}] 选取 {min(len(listing), LINES_PER_MODULE)} 行 / 共 {len(relpaths)} 个文件")
    return listing[: PAGE_LINES * PAGES]


def paginate(lines: list) -> list:
    """切成 60 页，每页 50 行。"""
    pages = []
    for i in range(PAGES):
        pages.append(lines[i * PAGE_LINES:(i + 1) * PAGE_LINES])
    return pages


def header_text(page: int) -> str:
    return f"{SOFT_NAME} {SOFT_VERSION}                    第 {page} 页 / 共 {PAGES} 页"


def write_txt(pages: list, out: str):
    with open(out, "w", encoding="utf-8") as f:
        f.write(f"{SOFT_NAME} {SOFT_VERSION}\n")
        f.write("源程序（前30页 + 后30页，每页50行）\n")
        f.write("=" * 70 + "\n\n")
        for idx, page in enumerate(pages, 1):
            f.write(header_text(idx) + "\n")
            f.write("-" * 70 + "\n")
            for ln in page:
                f.write(ln + "\n")
            f.write("\n\n")
    print(f"已生成：{out}")


def write_html(pages: list, out: str):
    esc = lambda s: html.escape(s)  # noqa: E731
    parts = []
    parts.append(f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>{SOFT_NAME} {SOFT_VERSION} 源程序</title>
<style>
  @page {{ size: A4; margin: 16mm 14mm 14mm 14mm; }}
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; font-family: 'Courier New', Consolas, monospace; color: #000; }}
  .page {{
    width: 100%;
    page-break-after: always;
    padding: 0 2mm 4mm 2mm;
  }}
  .page:last-child {{ page-break-after: auto; }}
  .page-header {{
    display: flex;
    justify-content: space-between;
    font-size: 9.5pt;
    border-bottom: 1px solid #000;
    padding-bottom: 2px;
    margin-bottom: 6px;
  }}
  .page-header .page-no {{ font-weight: bold; }}
  pre.code {{
    margin: 0;
    font-size: 7.6pt;
    line-height: 1.38;
    white-space: pre-wrap;
    word-break: break-all;
  }}
</style>
</head>
<body>
""")
    for idx, page in enumerate(pages, 1):
        parts.append('<div class="page">')
        parts.append(
            f'<div class="page-header">'
            f'<span>{esc(SOFT_NAME)} {esc(SOFT_VERSION)}</span>'
            f'<span class="page-no">第 {idx} 页 / 共 {PAGES} 页</span>'
            f'</div>'
        )
        parts.append('<pre class="code">')
        for ln in page:
            parts.append(esc(ln) + "\n")
        parts.append('</pre>')
        parts.append('</div>\n')
    parts.append("</body>\n</html>\n")
    with open(out, "w", encoding="utf-8") as f:
        f.write("".join(parts))
    print(f"已生成：{out}")


def main():
    print("=" * 60)
    print(f"{SOFT_NAME} {SOFT_VERSION} 源程序材料生成")
    print("=" * 60)
    listing = build_listing()
    print(f"总行数：{len(listing)}（目标 {PAGE_LINES * PAGES}）")
    pages = paginate(listing)
    out_txt = os.path.join(BASE, "源程序.txt")
    out_html = os.path.join(BASE, "源程序.html")
    write_txt(pages, out_txt)
    write_html(pages, out_html)
    print("完成。打开 源程序.html → 打印 → 另存为 PDF 即可提交。")


if __name__ == "__main__":
    main()
