import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../config.dart';
import '../services/auth_service.dart';

/// 管理页：内嵌网页管理端，并自动注入登录态（localStorage）。
class AdminWebviewPage extends StatefulWidget {
  const AdminWebviewPage({super.key});

  @override
  State<AdminWebviewPage> createState() => _AdminWebviewPageState();
}

class _AdminWebviewPageState extends State<AdminWebviewPage> {
  WebViewController? _controller;
  bool _injected = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  Future<void> _initWebView() async {
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) {
            if (mounted) setState(() => _loading = false);
            _injectToken();
          },
        ),
      )
      ..loadRequest(Uri.parse(AppConfig.webAdminUrl));
    if (mounted) setState(() => _controller = c);
  }

  /// 把原生登录态写入网页 localStorage 后刷新，让网页端自动登录。
  Future<void> _injectToken() async {
    if (_injected) return;
    final auth = context.read<AuthService>();
    if (auth.accessToken.isEmpty) return;
    _injected = true;
    final token = jsonEncode(auth.accessToken);
    final refresh = jsonEncode(auth.refreshToken);
    final user = jsonEncode(auth.webUserJson);
    await _controller?.runJavaScript('''
      localStorage.setItem('lt_access_token', $token);
      localStorage.setItem('lt_refresh_token', $refresh);
      localStorage.setItem('lt_user', $user);
      location.reload();
    ''');
  }

  Future<void> _reload() async {
    _injected = false;
    await _controller?.reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('管理'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          if (_controller != null)
            IconButton(
              icon: const Icon(Icons.refresh),
              tooltip: '刷新并重新登录网页',
              onPressed: _reload,
            ),
        ],
      ),
      body: _controller == null
          ? const Center(child: CircularProgressIndicator())
          : Stack(
              children: [
                WebViewWidget(controller: _controller!),
                if (_loading)
                  const Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    child: LinearProgressIndicator(minHeight: 2),
                  ),
              ],
            ),
    );
  }
}
