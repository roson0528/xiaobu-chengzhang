import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';

/// 网络管控：对指定设备（默认 MRX-W09 平板）做上网限制。
///
/// * 默认状态为「限制上网」，只放行学习平台，保证孩子端 APP 永远可用；
/// * 专注模式开启、或兑换带「附赠上网时长」的奖励时，自动临时放行，到期自动收回；
/// * 这里提供家长的一键断网 / 一键联网硬开关。
class NetControlPage extends StatefulWidget {
  const NetControlPage({super.key});

  @override
  State<NetControlPage> createState() => _NetControlPageState();
}

class _NetControlPageState extends State<NetControlPage> {
  List<Map<String, dynamic>> _devices = [];
  String? _selectedId;
  Map<String, dynamic>? _device;
  Map<String, dynamic>? _effective;
  Map<String, dynamic>? _agent;
  List<ChildProfile> _children = [];
  bool _loading = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final auth = context.read<AuthService>();
    try {
      final data = await ApiClient.instance.getJson('/netcontrol/state');
      final children = await auth.loadChildren();
      if (!mounted) return;
      setState(() {
        _ingest(data);
        _children = children;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = '$e';
        _loading = false;
      });
    }
  }

  /// 解析 state：设备列表 + 当前选中设备的生效策略
  void _ingest(dynamic data) {
    if (data is! Map) return;
    _devices = ((data['devices'] as List?) ?? const [])
        .map((e) => (e as Map).cast<String, dynamic>())
        .toList();
    _agent = (data['agent'] as Map?)?.cast<String, dynamic>();
    if (!_devices.any((d) => d['id'] == _selectedId)) {
      _selectedId = _devices.isEmpty ? null : _devices.first['id'] as String?;
    }
    Map<String, dynamic>? cur;
    for (final d in _devices) {
      if (d['id'] == _selectedId) cur = d;
    }
    cur ??= (data['device'] as Map?)?.cast<String, dynamic>();
    _device = cur;
    _effective = (cur?['effective'] as Map?)?.cast<String, dynamic>() ??
        (data['effective'] as Map?)?.cast<String, dynamic>();
  }

  void _select(String? id) {
    if (id == _selectedId) return;
    setState(() {
      _selectedId = id;
      Map<String, dynamic>? cur;
      for (final d in _devices) {
        if (d['id'] == id) cur = d;
      }
      _device = cur;
      _effective = (cur?['effective'] as Map?)?.cast<String, dynamic>();
    });
  }

  /// 统一收口：写操作 → 用返回的 state 刷新 → 提示
  Future<void> _run(Future<dynamic> Function() action, String okMsg) async {
    setState(() => _busy = true);
    try {
      final data = await action();
      if (!mounted) return;
      setState(() {
        _ingest(data);
        _busy = false;
      });
      if (okMsg.isNotEmpty) _toast(okMsg);
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      _toast('操作失败：$e');
    }
  }

  Future<void> _setMode(String mode, {int? minutes}) async {
    setState(() => _busy = true);
    final body = <String, dynamic>{'mode': mode};
    if (minutes != null) body['minutes'] = minutes;
    final deviceId = _device?['id'];
    if (deviceId != null) body['device_id'] = deviceId;
    try {
      final data = await ApiClient.instance.postJson('/netcontrol/mode', body);
      if (!mounted) return;
      setState(() {
        _device = (data['device'] as Map?)?.cast<String, dynamic>();
        _effective = (data['effective'] as Map?)?.cast<String, dynamic>();
        _agent = (data['agent'] as Map?)?.cast<String, dynamic>();
        _busy = false;
      });
      _toast(_modeLabel(mode));
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      _toast('设置失败：$e');
    }
  }

  Future<void> _bindChild(String? childId) async {
    setState(() => _busy = true);
    try {
      final data = await ApiClient.instance.postJson('/netcontrol/device', {
        'device_id': _device?['id'],
        'child_id': childId,
      });
      if (!mounted) return;
      setState(() {
        _device = (data['device'] as Map?)?.cast<String, dynamic>();
        _effective = (data['effective'] as Map?)?.cast<String, dynamic>();
        _busy = false;
      });
      _toast(childId == null ? '已改为任意孩子的授权都生效' : '已绑定孩子');
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      _toast('绑定失败：$e');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  /// 修改设备识别信息。平板换网络后随机 MAC 可能变化，此时控制会失效，
  /// 家长可以在这里把路由器上看到的新 MAC 填回来。
  Future<void> _editDevice() async {
    final macCtl = TextEditingController(text: '${_device?['mac'] ?? ''}');
    final ipCtl = TextEditingController(text: '${_device?['ip'] ?? ''}');
    final nameCtl = TextEditingController(text: '${_device?['name'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改受管控设备'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: macCtl,
              decoration: const InputDecoration(
                labelText: '设备 MAC',
                helperText: '形如 22:0d:8d:f9:8d:05',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: ipCtl,
              decoration: const InputDecoration(labelText: '设备 IP（选填）'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: nameCtl,
              decoration: const InputDecoration(labelText: '名称'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('保存')),
        ],
      ),
    );
    if (ok != true) return;
    final mac = macCtl.text.trim();
    if (mac.isEmpty) {
      _toast('MAC 不能为空');
      return;
    }
    setState(() => _busy = true);
    try {
      final data = await ApiClient.instance.postJson('/netcontrol/device', {
        'device_id': _device?['id'],
        'mac': mac,
        'ip': ipCtl.text.trim(),
        'name': nameCtl.text.trim(),
      });
      if (!mounted) return;
      setState(() {
        _device = (data['device'] as Map?)?.cast<String, dynamic>();
        _effective = (data['effective'] as Map?)?.cast<String, dynamic>();
        _busy = false;
      });
      _toast('已更新设备信息');
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      _toast('保存失败：$e');
    }
  }

  Map<String, dynamic> get _schedule =>
      (_device?['schedule'] as Map?)?.cast<String, dynamic>() ?? const {};

  List<Map<String, dynamic>> get _windows =>
      ((_schedule['windows'] as List?) ?? const [])
          .map((e) => (e as Map).cast<String, dynamic>())
          .toList();

  Future<void> _setEnabled(bool enabled) => _run(
        () => ApiClient.instance.postJson('/netcontrol/device', {
          'device_id': _device?['id'],
          'enabled': enabled,
        }),
        enabled ? '已启用管控' : '已停用管控（不施加任何限制）',
      );

  /// 新增设备：填一个 IP 就能纳入管控（MAC 选填）
  Future<void> _addDevice() async {
    final ipCtl = TextEditingController();
    final nameCtl = TextEditingController();
    final macCtl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('添加受管控设备'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: ipCtl,
                decoration: const InputDecoration(
                  labelText: '设备 IP（必填）',
                  helperText: '例：YOUR_ROUTER_IP',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: nameCtl,
                decoration: const InputDecoration(
                  labelText: '名称（选填）',
                  helperText: '例：客厅电视',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: macCtl,
                decoration: const InputDecoration(
                  labelText: 'MAC（选填）',
                  helperText: '留空即按 IP 匹配，手机随机 MAC 也能管住',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('添加')),
        ],
      ),
    );
    if (ok != true) return;
    final ip = ipCtl.text.trim();
    if (ip.isEmpty) {
      _toast('请填写设备 IP');
      return;
    }
    await _run(
      () => ApiClient.instance.postJson('/netcontrol/devices', {
        'ip': ip,
        'name': nameCtl.text.trim(),
        'mac': macCtl.text.trim(),
      }),
      '已添加设备 $ip',
    );
  }

  Future<void> _deleteDevice() async {
    final d = _device;
    if (d == null) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('移除设备'),
        content: Text('不再管控「${d['name']}」（${d['ip']}）？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('移除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await _run(
      () => ApiClient.instance.deleteJson('/netcontrol/devices/${d['id']}'),
      '已移除设备',
    );
  }

  // ---------------- 时间段 ----------------

  Future<void> _saveSchedule(
          bool enabled, List<Map<String, dynamic>> windows, String outAction) =>
      _run(
        () => ApiClient.instance.postJson('/netcontrol/schedule', {
          'device_id': _device?['id'],
          'enabled': enabled,
          'windows': windows,
          'out_action': outAction,
        }),
        enabled ? '时段控制已保存' : '已关闭时段控制',
      );

  Future<void> _editSchedule() async {
    var enabled = _schedule['enabled'] == true;
    var outAction = '${_schedule['out_action'] ?? 'restricted'}';
    final windows = _windows.map((w) => Map<String, dynamic>.from(w)).toList();

    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setInner) => AlertDialog(
          title: const Text('时间段控制'),
          content: SizedBox(
            width: 380,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: enabled,
                    onChanged: (v) => setInner(() => enabled = v),
                    title: const Text('启用时段控制'),
                    subtitle: const Text('时段内可上网，时段外按下面的规则处理',
                        style: TextStyle(fontSize: 12)),
                  ),
                  const Divider(),
                  if (windows.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('还没有时间段，点下方按钮添加',
                          style: TextStyle(color: Colors.grey, fontSize: 13)),
                    ),
                  for (var i = 0; i < windows.length; i++)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.schedule, size: 20),
                      title: Text(
                        '${_daysText(windows[i]['days'])}  '
                        '${windows[i]['start']}-${windows[i]['end']}',
                        style: const TextStyle(fontSize: 14),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, size: 20),
                        onPressed: () => setInner(() => windows.removeAt(i)),
                      ),
                    ),
                  const SizedBox(height: 4),
                  OutlinedButton.icon(
                    onPressed: () async {
                      final w = await _pickWindow();
                      if (w != null) setInner(() => windows.add(w));
                    },
                    icon: const Icon(Icons.add),
                    label: const Text('添加时间段'),
                  ),
                  const Divider(),
                  const Text('时段外', style: TextStyle(fontSize: 13, color: Colors.grey)),
                  DropdownButton<String>(
                    isExpanded: true,
                    value: outAction,
                    onChanged: (v) => setInner(() => outAction = v ?? 'restricted'),
                    items: const [
                      DropdownMenuItem(value: 'restricted', child: Text('限制上网')),
                      DropdownMenuItem(value: 'block', child: Text('完全断网')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            TextButton(
              onPressed: () {
                if (enabled && windows.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('开启时段控制前，请至少添加一个时间段')),
                  );
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: const Text('保存'),
            ),
          ],
        ),
      ),
    );
    if (saved != true) return;
    await _saveSchedule(enabled, windows, outAction);
  }

  Future<Map<String, dynamic>?> _pickWindow() async {
    final picked = <int>{3, 4, 5};
    var start = const TimeOfDay(hour: 18, minute: 0);
    var end = const TimeOfDay(hour: 21, minute: 0);
    return showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setInner) => AlertDialog(
          title: const Text('添加时间段'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('适用星期', style: TextStyle(fontSize: 13, color: Colors.grey)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (var i = 1; i <= 7; i++)
                    FilterChip(
                      label: Text(_dayName(i)),
                      selected: picked.contains(i),
                      onSelected: (on) => setInner(() {
                        if (on) {
                          picked.add(i);
                        } else {
                          picked.remove(i);
                        }
                      }),
                    ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final t = await showTimePicker(context: ctx, initialTime: start);
                        if (t != null) setInner(() => start = t);
                      },
                      child: Text('开始 ${_fmt(start)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final t = await showTimePicker(context: ctx, initialTime: end);
                        if (t != null) setInner(() => end = t);
                      },
                      child: Text('结束 ${_fmt(end)}'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              const Text('结束早于开始表示跨夜（如 22:00-07:00）',
                  style: TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
            TextButton(
              onPressed: () {
                if (picked.isEmpty) return;
                if (_fmt(start) == _fmt(end)) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('开始与结束时间不能相同')),
                  );
                  return;
                }
                Navigator.pop(ctx, {
                  'days': picked.toList()..sort(),
                  'start': _fmt(start),
                  'end': _fmt(end),
                });
              },
              child: const Text('确定'),
            ),
          ],
        ),
      ),
    );
  }

  String _fmt(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  String _dayName(int d) =>
      const ['', '周一', '周二', '周三', '周四', '周五', '周六', '周日'][d];

  String _daysText(dynamic days) {
    final list = ((days as List?) ?? const []).map((e) => '$e').toList();
    if (list.length == 7) return '每天';
    if (list.join(',') == '1,2,3,4,5') return '工作日';
    if (list.join(',') == '6,7') return '周末';
    return list.map((e) => _dayName(int.tryParse(e) ?? 0)).join('、');
  }

  String _modeLabel(String mode) => switch (mode) {
        'allow_all' => '已开启联网（完全放开）',
        'block_all' => '已一键断网',
        _ => '已恢复正常管控',
      };

  String _statusText() {
    final eff = _effective;
    if (eff == null) return '读取中…';
    final action = eff['action'];
    final reason = eff['reason'] ?? '';
    return switch (action) {
      'allow' => '✅ 当前可上网（$reason）',
      'block' => '⛔ 当前完全断网（$reason）',
      _ => '🔒 当前限制上网，仅可访问学习平台（$reason）',
    };
  }

  /// 路由器代理是否正在同步（令牌不一致 / 路由器离线都表现为不同步）
  String _agentText() {
    final a = _agent;
    if (a == null) return '路由器同步状态：未知';
    if (a['online'] == true) {
      final sec = a['age_seconds'];
      return '路由器同步正常（${sec is int ? sec : '?'} 秒前刚拉取）';
    }
    if (a['token_error'] == true) {
      return '⚠️ 路由器令牌与服务器不一致，管控未生效';
    }
    final age = a['age_seconds'];
    if (age is int) {
      return '⚠️ 路由器已 ${(age / 60).floor()} 分钟没有同步，管控可能未生效';
    }
    return '⚠️ 路由器尚未同步（本次重启后还没拉到策略）';
  }

  /// 硬开关提示：一键断网/联网会盖过专注模式的联网放行，必须显眼说明
  List<Widget> _overrideWarnings() {
    final mode = _effective?['mode'] ?? 'enforce';
    final until = _device?['manual_until'];
    final forever = until == null;
    if (mode == 'block_all') {
      return [
        Card(
          color: const Color(0xFFFFEBEE),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.wifi_off, color: Colors.red),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '正在「一键断网」，孩子任何联网都会失败',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.red),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '这个开关${forever ? '没有到期时间（永久生效）' : '到期后自动恢复'}，'
                  '且优先于专注模式的联网放行——孩子做「需要联网」的任务时也会打不开网页。'
                  '如果孩子正卡在网上不去，先点下面这个按钮。',
                  style: const TextStyle(fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: _busy ? null : () => _setMode('enforce'),
                  icon: const Icon(Icons.restart_alt),
                  label: const Text('恢复正常管控'),
                  style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
      ];
    }
    if (mode == 'allow_all') {
      return [
        Card(
          color: const Color(0xFFFFF8E1),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.wifi, color: Color(0xFFF57C00)),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '正在「一键联网」，孩子可自由上网',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Color(0xFFF57C00)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '这个开关${forever ? '没有到期时间（永久生效）' : '到期后自动恢复'}，'
                  '孩子现在不受任何限制。排障/临时用完后记得点「恢复正常管控」。',
                  style: const TextStyle(fontSize: 13, height: 1.4),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
      ];
    }
    return const [];
  }

  /// 把 ISO 本地时间转成 HH:mm 展示
  String _hhmm(dynamic iso) {
    if (iso == null) return '';
    try {
      final dt = DateTime.parse('$iso');
      final now = DateTime.now();
      final sameDay = dt.year == now.year && dt.month == now.month && dt.day == now.day;
      final hm = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
      return sameDay ? hm : '${dt.month}-${dt.day} $hm';
    } catch (_) {
      return '';
    }
  }

  List<Widget> _grantChips() {
    final grants = (_effective?['grants'] as List?) ?? const [];
    if (grants.isEmpty) return const [];
    return [
      const SizedBox(height: 10),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final g in grants)
            Chip(
              avatar: const Icon(Icons.timer_outlined, size: 16, color: Color(0xFF1E88E5)),
              label: Text(
                '${(g as Map)['note'] ?? g['source']} · 至 ${_hhmm(g['until'])}',
                style: const TextStyle(fontSize: 12),
              ),
              backgroundColor: const Color(0xFFE3F2FD),
              side: BorderSide.none,
            ),
        ],
      ),
    ];
  }

  /// 设备切换条：任意 IP 设备都能在这里切换/新增
  Widget _deviceSelector() {
    return SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          for (final d in _devices)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                selected: d['id'] == _selectedId,
                onSelected: (_) => _select(d['id'] as String?),
                label: Text('${d['name']}', style: const TextStyle(fontSize: 13)),
              ),
            ),
          ActionChip(
            avatar: const Icon(Icons.add, size: 16),
            label: const Text('添加设备', style: TextStyle(fontSize: 13)),
            onPressed: _busy ? null : _addDevice,
          ),
        ],
      ),
    );
  }

  /// 时间段控制卡片
  Widget _scheduleCard() {
    final enabled = _schedule['enabled'] == true;
    final wins = _windows;
    final outBlock = '${_schedule['out_action'] ?? 'restricted'}' == 'block';
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.schedule, size: 20, color: Color(0xFF1E88E5)),
                const SizedBox(width: 8),
                const Text('时间段控制',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                const Spacer(),
                TextButton(
                  onPressed: _busy ? null : _editSchedule,
                  child: Text(enabled ? '修改' : '设置'),
                ),
              ],
            ),
            Text(
              enabled
                  ? '已开启：${wins.length} 个时段，时段外${outBlock ? '完全断网' : '限制上网'}'
                  : '未开启（设备始终按上面的模式判定）',
              style: TextStyle(
                fontSize: 13,
                color: enabled ? Colors.green.shade700 : Colors.grey,
              ),
            ),
            if (enabled && wins.isNotEmpty) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final w in wins)
                    Chip(
                      label: Text('${_daysText(w['days'])} ${w['start']}-${w['end']}',
                          style: const TextStyle(fontSize: 12)),
                      backgroundColor: const Color(0xFFE8F5E9),
                      side: BorderSide.none,
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final mode = _effective?['mode'] ?? 'enforce';
    return Scaffold(
      appBar: AppBar(
        title: const Text('网络管控'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: '刷新',
            onPressed: _busy ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (_error != null)
                    Card(
                      color: const Color(0xFFFFEBEE),
                      child: ListTile(
                        leading: const Icon(Icons.error_outline, color: Colors.red),
                        title: const Text('读取失败'),
                        subtitle: Text(_error!),
                        trailing: TextButton(onPressed: _load, child: const Text('重试')),
                      ),
                    ),
                  ..._overrideWarnings(),
                  _deviceSelector(),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.devices, color: Color(0xFF1E88E5)),
                              const SizedBox(width: 8),
                              Text(
                                '${_device?['name'] ?? '受管控设备'}',
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.bold),
                              ),
                              const Spacer(),
                              Switch(
                                value: _device?['enabled'] == true,
                                onChanged: _busy ? null : _setEnabled,
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit, size: 18),
                                tooltip: '修改名称 / IP / MAC',
                                onPressed: _busy ? null : _editDevice,
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 18),
                                tooltip: '从管控列表移除',
                                onPressed: (_busy || _devices.length <= 1)
                                    ? null
                                    : _deleteDevice,
                              ),
                              if (_busy)
                                const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(strokeWidth: 2)),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'IP ${_device?['ip'] ?? '-'}'
                            '${(_device?['mac'] ?? '') != '' ? '   ·   MAC ${_device?['mac']}' : '   ·   按 IP 匹配'}',
                            style: const TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _statusText(),
                            style: const TextStyle(fontSize: 15, height: 1.4),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Icon(
                                _agent?['online'] == true
                                    ? Icons.cloud_done_outlined
                                    : Icons.cloud_off_outlined,
                                size: 15,
                                color: _agent?['online'] == true
                                    ? Colors.green.shade600
                                    : Colors.orange.shade800,
                              ),
                              const SizedBox(width: 5),
                              Expanded(
                                child: Text(
                                  _agentText(),
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: _agent?['online'] == true
                                        ? Colors.grey.shade700
                                        : Colors.orange.shade900,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          ..._grantChips(),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  _scheduleCard(),
                  const SizedBox(height: 12),
                  const Text('一键硬开关',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _busy ? null : () => _setMode('block_all'),
                          icon: const Icon(Icons.wifi_off),
                          label: const Text('一键断网'),
                          style: FilledButton.styleFrom(
                            backgroundColor:
                                mode == 'block_all' ? Colors.red.shade700 : Colors.red,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _busy ? null : () => _setMode('allow_all'),
                          icon: const Icon(Icons.wifi),
                          label: const Text('一键联网'),
                          style: FilledButton.styleFrom(
                            backgroundColor: mode == 'allow_all'
                                ? Colors.green.shade700
                                : Colors.green,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: _busy ? null : () => _setMode('enforce'),
                    icon: const Icon(Icons.restore),
                    label: const Text('恢复正常管控（默认限制上网）'),
                    style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14)),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('授权范围',
                              style: TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 2),
                          const Text(
                            '选择哪个孩子的专注模式 / 奖励兑换可以放开这台设备的上网权限。',
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                          const SizedBox(height: 4),
                          DropdownButton<String?>(
                            isExpanded: true,
                            value: _device?['child_id'] as String?,
                            onChanged: _busy ? null : _bindChild,
                            items: [
                              const DropdownMenuItem<String?>(
                                value: null,
                                child: Text('任意孩子（默认）'),
                              ),
                              for (final c in _children)
                                DropdownMenuItem<String?>(
                                  value: c.id,
                                  child: Text('仅 ${c.name}'),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Card(
                    color: const Color(0xFFF5F5F5),
                    child: const Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('规则说明',
                              style: TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.bold)),
                          SizedBox(height: 6),
                          Text(
                            '· 默认：只能访问学习平台，其它上网行为被限制；\n'
                            '· 专注模式开启期间：自动放开，退出或超时自动收回；\n'
                            '· 兑换带「附赠上网时长」的奖励：按配置时长放开；\n'
                            '· 一键断网：完全断开（包括学习平台）；\n'
                            '· 可添加任意 IP 的设备：填 MAC 按 MAC 管，不填 MAC 就按 IP 管；\n'
                            '· 时间段：时段内可上网、时段外限制或断网，支持跨夜时段；\n'
                            '· 所有放行都有到期时间，路由器侧独立计时，不会因为网络故障而失效。',
                            style: TextStyle(fontSize: 12.5, height: 1.6),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
    );
  }
}
