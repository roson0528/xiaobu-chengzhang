import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import 'item_detail_page.dart';

/// 任务：审核孩子提交的打卡（打卡审核）与临时任务（任务审批），右下角可布置一次性任务。
class CheckinReviewPage extends StatefulWidget {
  const CheckinReviewPage({super.key});

  @override
  State<CheckinReviewPage> createState() => _CheckinReviewPageState();
}

/// 待审批条目：打卡或任务。
class _ReviewItem {
  _ReviewItem({required this.kind, required this.raw, this.childId = '', this.childName = ''});
  final String kind; // 'checkin' | 'task'
  final Map<String, dynamic> raw;
  final String childId;
  final String childName;

  String get id => raw['id']?.toString() ?? '';
  bool get isTask => kind == 'task';

  /// 显示用时间：提交时间 > 创建时间 > 计划开始时间（未提交任务）。
  String get time {
    final completed = (raw['completed_at'] ?? '').toString();
    if (completed.isNotEmpty) return completed;
    final created = (raw['created_at'] ?? '').toString();
    if (created.isNotEmpty) return created;
    return (raw['planned_start'] ?? '').toString();
  }

  /// 执行状态：todo=未进行 / reviewing=待审批 / approved=已通过 / rejected=已驳回 / skipped=已跳过
  String get execStatus {
    if (kind == 'task') {
      final st = (raw['status'] ?? '').toString();
      if (st == 'skipped') return 'skipped';
      final rs = (raw['review_status'] ?? '').toString();
      if (rs == 'rejected') return 'rejected';
      if (st == 'completed') {
        if (rs == 'approved') return 'approved';
        return 'reviewing';
      }
      return 'todo';
    }
    final st = (raw['status'] ?? '').toString();
    if (st == 'approved') return 'approved';
    if (st == 'rejected') return 'rejected';
    return 'reviewing';
  }

  String get badge => kind == 'task' ? (raw['task_type'] ?? '任务').toString() : (raw['checkin_type'] ?? '打卡').toString();

  /// 假期作业已经提交过的天数（假期里每天可以交一部分，审核通过才算写完）。
  int get submittedDays {
    final subs = raw['submissions'];
    if (subs is! List) return 0;
    return subs
        .whereType<Map>()
        .map((e) => (e['date'] ?? '').toString())
        .where((d) => d.isNotEmpty)
        .toSet()
        .length;
  }

  /// 假期作业/任务：返回「假期 7天 · 已交3天」这样的标签，非假期返回空串。
  String get holidayLabel {
    if (raw['holiday'] != true) return '';
    final n = raw['holiday_days'] is int ? raw['holiday_days'] as int : 0;
    final base = n > 0 ? '假期 $n天' : '假期作业';
    final days = submittedDays;
    return days > 0 ? '$base · 已交$days天' : base;
  }

  /// 假期区间文案（如 10月1日~10月7日），非假期返回空串。
  String get holidayRange {
    if (raw['holiday'] != true) return '';
    final start = (raw['planned_date'] ?? '').toString();
    final n = raw['holiday_days'] is int ? raw['holiday_days'] as int : 0;
    if (start.isEmpty || n <= 0) return '';
    final d = DateTime.tryParse(start);
    if (d == null) return '';
    final end = d.add(Duration(days: n - 1));
    String f(DateTime x) => '${x.month}月${x.day}日';
    return n == 1 ? f(d) : '${f(d)}~${f(end)}';
  }
  String get title => kind == 'task' ? (raw['title'] ?? '').toString() : (raw['subject'] ?? '').toString();
  String get content => (raw['content'] ?? '').toString();

  List<String> get photos {
    final list = raw['completed_photos'] ?? raw['photo_paths'];
    if (list is List) {
      return list.map((e) => e.toString()).where((e) => e.isNotEmpty).toList();
    }
    final s = (raw['completed_photo'] ?? raw['photo_path'])?.toString() ?? '';
    return s.isNotEmpty ? [s] : const [];
  }
}

const String _allChildren = '__all__'; // 查看全部孩子

class _CheckinReviewPageState extends State<CheckinReviewPage> {
  List<ChildProfile> _children = [];
  String? _childId;
  List<_ReviewItem> _items = [];
  bool _loading = true;
  bool _loadFailed = false; // 接口出错时区分「真的没有」和「加载失败」
  String? _selectedDate; // 默认今天

  // 布置任务表单
  final _taskTitle = TextEditingController();
  final _rewardPoints = TextEditingController();
  final _penaltyPoints = TextEditingController();
  String _subject = '家务';
  String _difficulty = 'medium';
  bool _photoRequired = true;
  // 是否需要联网：勾选后该任务开启专注模式期间可以上外网（默认不勾选）
  bool _needNetwork = false;
  // 假期任务：勾选后在「假期时长」天内持续存在，假期内任意一天提交都不扣分
  bool _isHoliday = false;
  final _holidayDays = TextEditingController(text: '7');
  // 临时任务类型（作业由「作业」页的「布置作业」负责，这里不再含作业）
  final _subjects = const ['家务', '背诵', '阅读', '运动', '其他'];
  final _difficulties = const [
    {'v': 'easy', 'l': '简单'},
    {'v': 'medium', 'l': '中等'},
    {'v': 'hard', 'l': '困难'},
  ];
  bool _posting = false;

  @override
  void initState() {
    super.initState();
    _selectedDate = _fmtDate(DateTime.now());
    _load();
  }

  @override
  void dispose() {
    _taskTitle.dispose();
    _rewardPoints.dispose();
    _penaltyPoints.dispose();
    _holidayDays.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await context.read<AuthService>().loadChildren();
    String? cid = _childId;
    if (cid == null && list.isNotEmpty) {
      // 多个孩子时默认「全部孩子」，避免新增孩子后只显示第一个孩子的任务
      cid = list.length > 1 ? _allChildren : list.first.id;
    }
    if (!mounted) return;
    setState(() {
      _children = list;
      _childId = cid;
    });
    await _loadRecords();
  }

  Future<void> _loadRecords() async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    final items = <_ReviewItem>[];
    var failed = false;

    // 目标孩子：全部孩子 或 当前选中的单个孩子
    final targets = <Map<String, String>>[];
    if (cid == _allChildren) {
      for (final c in _children) {
        targets.add({'id': c.id, 'name': c.name});
      }
    } else {
      String name = '';
      for (final c in _children) {
        if (c.id == cid) {
          name = c.name;
          break;
        }
      }
      targets.add({'id': cid, 'name': name});
    }

    for (final t in targets) {
      final tid = t['id']!;
      final tname = t['name'] ?? '';
      // 打卡（打卡审核）
      try {
        final url = _selectedDate == null ? '/checkins/$tid' : '/checkins/$tid?date=$_selectedDate';
        final data = await ApiClient.instance.getJson(url) as List;
        for (final r in data.whereType<Map>()) {
          items.add(_ReviewItem(
            kind: 'checkin',
            raw: r.cast<String, dynamic>(),
            childId: tid,
            childName: tname,
          ));
        }
      } catch (_) {
        failed = true;
      }
      // 任务（同步孩子端「今日任务」）：未提交也显示，区分未进行/待审批/已通过/已驳回
      try {
        final isToday = _selectedDate == null || _selectedDate == _fmtDate(DateTime.now());
        final data = isToday
            ? await ApiClient.instance.getJson('/tasks/$tid/today') as Map<String, dynamic>
            : await ApiClient.instance.getJson('/tasks/$tid/history?date=$_selectedDate') as Map<String, dynamic>;
        for (final e in ((data['tasks'] as List?) ?? const []).whereType<Map>()) {
          final raw = e.cast<String, dynamic>();
          // 当天视图里作业归「作业」页；但按历史日期查找时必须一并列出 ——
          // 否则「当天只有作业」会被误报成「该日期暂无打卡或任务」，
          // 已经过期还没审核的作业也没法在这里继续处理。
          if (isToday && (raw['task_type']?.toString() ?? '') == '作业') continue;
          items.add(_ReviewItem(
            kind: 'task',
            raw: raw,
            childId: tid,
            childName: tname,
          ));
        }
      } catch (_) {
        failed = true;
      }
    }

    items.sort((a, b) => b.time.compareTo(a.time));
    if (!mounted) return;
    setState(() {
      _items = items;
      _loading = false;
      _loadFailed = failed;
    });
  }

  String _fmtDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _showTime(String s) {
    final p = DateTime.tryParse(s);
    if (p == null) return s;
    final hh = p.hour.toString().padLeft(2, '0');
    final mm = p.minute.toString().padLeft(2, '0');
    return '${p.year}年${p.month}月${p.day}日 $hh:$mm';
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate != null ? DateTime.tryParse(_selectedDate!) ?? now : now,
      firstDate: DateTime(2020, 1, 1),
      lastDate: now,
      helpText: '按日期查找',
    );
    if (picked == null || !mounted) return;
    setState(() => _selectedDate = _fmtDate(picked));
    await _loadRecords();
  }

  /// 孩子选择图标（多孩子时显示在 AppBar，日历左侧）：全部孩子=group，单个孩子=person。
  Widget _buildChildSelector() {
    final isAll = _childId == _allChildren;
    return IconButton(
      icon: Icon(isAll ? Icons.group : Icons.person),
      tooltip: _childNameOf(_childId),
      onPressed: _pickChild,
    );
  }

  String _childNameOf(String? id) {
    if (id == _allChildren) return '全部孩子';
    for (final c in _children) {
      if (c.id == id) return c.name;
    }
    return '选择孩子';
  }

  Future<void> _pickChild() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.group, color: Color(0xFF1E88E5)),
              title: const Text('全部孩子', style: TextStyle(fontWeight: FontWeight.bold)),
              trailing: _childId == _allChildren ? const Icon(Icons.check, color: Color(0xFF1E88E5)) : null,
              onTap: () => Navigator.pop(ctx, _allChildren),
            ),
            for (final c in _children)
              ListTile(
                leading: const Icon(Icons.person, color: Color(0xFF1E88E5)),
                title: Text(c.name),
                trailing: _childId == c.id ? const Icon(Icons.check, color: Color(0xFF1E88E5)) : null,
                onTap: () => Navigator.pop(ctx, c.id),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    setState(() => _childId = selected);
    await _loadRecords();
  }

  Future<void> _openDetail(_ReviewItem it) async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ItemDetailPage(
          kind: it.kind,
          raw: it.raw,
          childId: it.childId,
          childName: it.childName,
        ),
      ),
    );
    if (changed == true && mounted) await _loadRecords();
  }

  Future<void> _review(_ReviewItem it) async {
    final cid = it.childId.isNotEmpty ? it.childId : (_childId ?? '');
    if (cid.isEmpty) return;
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => _ReviewDialog(item: it),
    );
    if (result == null || !mounted) return;
    final status = result['status'] as String;

    // 二次确认，防止误触通过/驳回
    final approved = status == 'approved';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(approved ? '确认通过？' : '确认驳回？'),
        content: Text(
          approved
              ? '通过后孩子将获得积分奖励，且该任务不能再提交修改。'
              : '驳回后孩子会收到通知，可查看原因并重新提交，直到通过为止。',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: approved ? const Color(0xFF43A047) : const Color(0xFFE53935),
            ),
            child: Text(approved ? '确认通过' : '确认驳回'),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;

    try {
      if (it.kind == 'checkin') {
        final endpoint = status == 'approved' ? 'review' : 'reject';
        await ApiClient.instance.postJson('/checkins/${it.id}/$endpoint?child_id=$cid', {
          'comment': result['comment'] ?? '',
          'grade': result['grade'],
        });
      } else {
        await ApiClient.instance.postJson('/tasks/${it.id}/review?child_id=$cid', {
          'status': status,
          'comment': result['comment'] ?? '',
          'grade': result['grade'],
        });
      }
      if (!mounted) return;
      _toast(status == 'approved' ? '已通过 ✅' : '已驳回');
      await _loadRecords();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _openPostTask() {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      _toast('请先在管理页添加孩子档案');
      return;
    }
    if (cid == _allChildren) {
      _toast('布置任务请先在上方选择具体孩子');
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: _buildTaskForm(),
      ),
    );
  }

  Future<void> _postTask() async {
    final title = _taskTitle.text.trim();
    if (title.isEmpty) {
      _toast('请输入任务标题');
      return;
    }
    final cid = _childId;
    if (cid == null || cid.isEmpty || cid == _allChildren) {
      _toast('布置任务请先在上方选择具体孩子');
      return;
    }
    setState(() => _posting = true);
    final rewardPoints = int.tryParse(_rewardPoints.text.trim()) ?? 0;
    final penaltyPoints = int.tryParse(_penaltyPoints.text.trim()) ?? 0;
    try {
      await ApiClient.instance.postJson('/tasks/$cid', {
        'title': title,
        'subject': _subject,
        'task_type': _subject,
        'difficulty': _difficulty,
        'planned_date': DateTime.now().toIso8601String().substring(0, 10),
        'repeat': {'type': 'none', 'days': []},
        'photo_required': _photoRequired,
        'reward_points': rewardPoints > 0 ? rewardPoints : null,
        'penalty_points': penaltyPoints,
        'need_network': _needNetwork,
        'holiday': _isHoliday,
        'holiday_days': _isHoliday ? (int.tryParse(_holidayDays.text.trim()) ?? 7) : 0,
      });
      if (!mounted) return;
      _taskTitle.clear();
      _rewardPoints.clear();
      _penaltyPoints.clear();
      _needNetwork = false;
      _isHoliday = false;
      _holidayDays.text = '7';
      setState(() => _posting = false);
      Navigator.of(context).pop();
      _toast('任务已布置，同步到孩子端今日任务 ✅');
      await _loadRecords();
    } on ApiException catch (e) {
      if (mounted) setState(() => _posting = false);
      _toast(e.message);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('任务'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          if (_children.length > 1) _buildChildSelector(),
          if (_selectedDate != null && _selectedDate != _fmtDate(DateTime.now()))
            IconButton(
              icon: const Icon(Icons.today),
              tooltip: '回到今天',
              onPressed: () {
                setState(() => _selectedDate = _fmtDate(DateTime.now()));
                _loadRecords();
              },
            ),
          IconButton(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), tooltip: '按日期查'),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _buildRecords()),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openPostTask,
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_task),
        label: const Text('布置任务'),
      ),
    );
  }

  Widget _buildRecords() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_children.isEmpty) {
      return const Center(child: Text('暂无孩子档案，请先在管理页添加孩子'));
    }
    if (_items.isEmpty) {
      final isToday = _selectedDate == null || _selectedDate == _fmtDate(DateTime.now());
      final hint = _loadFailed
          ? '加载失败，下拉重试'
          : (isToday ? '今天暂无打卡或任务' : '该日期没有打卡、任务或作业');
      // 空状态也套一层可下拉的列表，加载失败时能直接下拉重试
      return RefreshIndicator(
        onRefresh: _loadRecords,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            SizedBox(height: MediaQuery.of(context).size.height * 0.28),
            Center(
              child: Text(
                hint,
                style: TextStyle(
                  color: _loadFailed ? const Color(0xFFE53935) : Colors.grey,
                ),
              ),
            ),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadRecords,
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
        itemCount: _items.length,
        itemBuilder: (_, i) => _recordCard(_items[i]),
      ),
    );
  }

  Widget _recordCard(_ReviewItem it) {
    final status = it.execStatus;
    final isTask = it.isTask;
    final photos = it.photos;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => _openDetail(it),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: (isTask ? const Color(0xFF7E57C2) : const Color(0xFF1E88E5)).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      it.badge,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        color: isTask ? const Color(0xFF7E57C2) : const Color(0xFF1E88E5),
                      ),
                    ),
                  ),
                  if (it.childName.isNotEmpty && _childId == _allChildren) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF00897B).withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        it.childName,
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF00897B)),
                      ),
                    ),
                  ],
                  if (it.holidayLabel.isNotEmpty) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF7043).withValues(alpha: 0.14),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        '🏖️ ${it.holidayLabel}',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFFE64A19)),
                      ),
                    ),
                  ],
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      it.title.isEmpty ? it.badge : it.title,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  _statusChip(status),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      it.time.isEmpty ? '' : '🕐 ${_showTime(it.time)}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                  if (it.holidayRange.isNotEmpty)
                    Text('🏖️ ${it.holidayRange}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFFE64A19))),
                  const SizedBox(width: 6),
                  if (photos.isNotEmpty)
                    Text('📷 ${photos.length}张照片',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF1E88E5))),
                  const SizedBox(width: 4),
                  const Icon(Icons.chevron_right, size: 18, color: Colors.grey),
                ],
              ),
              if (status == 'reviewing')
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    FilledButton.tonalIcon(
                      onPressed: () => _review(it),
                      icon: const Icon(Icons.fact_check_outlined, size: 18),
                      label: const Text('审批'),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statusChip(String status) {
    final (label, color) = switch (status) {
      'approved' => ('已通过', const Color(0xFF43A047)),
      'rejected' => ('已驳回', const Color(0xFFE53935)),
      'reviewing' => ('待审批', const Color(0xFFFB8C00)),
      'skipped' => ('已跳过', const Color(0xFF9E9E9E)),
      _ => ('未进行', const Color(0xFF1E88E5)),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildTaskForm() {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('布置临时任务（一次性，同步到孩子端今日任务）',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(
            controller: _taskTitle,
            decoration: const InputDecoration(labelText: '任务标题 *', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _subject,
            decoration: const InputDecoration(labelText: '类型', border: OutlineInputBorder()),
            items: [for (final s in _subjects) DropdownMenuItem(value: s, child: Text(s))],
            onChanged: (v) => setState(() => _subject = v ?? '家务'),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: _difficulty,
            decoration: const InputDecoration(labelText: '难度', border: OutlineInputBorder()),
            items: [
              for (final d in _difficulties)
                DropdownMenuItem(value: d['v']!, child: Text(d['l']!)),
            ],
            onChanged: (v) => setState(() => _difficulty = v ?? 'medium'),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('需要拍照提交', style: TextStyle(fontSize: 15)),
            value: _photoRequired,
            activeTrackColor: const Color(0xFF1E88E5),
            onChanged: (v) => setState(() => _photoRequired = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('需要联网', style: TextStyle(fontSize: 15)),
            subtitle: const Text('勾选后，该任务专注期间平板可以上外网；不勾选则不能上网',
                style: TextStyle(fontSize: 12)),
            value: _needNetwork,
            activeTrackColor: const Color(0xFF1E88E5),
            onChanged: (v) => setState(() => _needNetwork = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('假期任务 🏖️', style: TextStyle(fontSize: 15)),
            subtitle: const Text('勾选后，这期间每天都能看到它；假期内任意一天提交都算按时完成，不扣分',
                style: TextStyle(fontSize: 12)),
            value: _isHoliday,
            activeTrackColor: const Color(0xFFFF7043),
            onChanged: (v) => setState(() => _isHoliday = v),
          ),
          if (_isHoliday)
            Padding(
              padding: const EdgeInsets.only(left: 4, right: 4, bottom: 4),
              child: Row(
                children: [
                  const Text('假期时长：', style: TextStyle(fontSize: 14)),
                  SizedBox(
                    width: 90,
                    child: TextField(
                      controller: _holidayDays,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        isDense: true,
                        border: OutlineInputBorder(),
                        suffixText: '天',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '例如国庆 7 天：从开始日期起连续 7 天有效',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 12),
          TextField(
            controller: _rewardPoints,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: '奖励积分（选填）',
              hintText: '完成审核通过后奖励的积分，留空按难度默认',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _penaltyPoints,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: '未完成扣分（选填）',
              hintText: '超时未完成或被驳回时扣除的积分，0 表示不扣',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _posting ? null : _postTask,
              icon: const Icon(Icons.send),
              label: const Text('发布任务'),
            ),
          ),
        ],
      ),
    );
  }
}

/// 审批弹窗：评语 + 优秀/良好打分（打卡与任务通用）。
class _ReviewDialog extends StatefulWidget {
  final _ReviewItem item;
  const _ReviewDialog({required this.item});

  @override
  State<_ReviewDialog> createState() => _ReviewDialogState();
}

class _ReviewDialogState extends State<_ReviewDialog> {
  final _comment = TextEditingController();
  String _grade = 'excellent'; // excellent 优秀 / good 良好

  @override
  void dispose() {
    _comment.dispose();
    super.dispose();
  }

  void _close(String status) {
    Navigator.of(context).pop({
      'status': status,
      'comment': _comment.text.trim(),
      'grade': status == 'approved' ? _grade : null,
    });
  }

  @override
  Widget build(BuildContext context) {
    final it = widget.item;
    final title = it.title.isEmpty ? it.badge : it.title;
    return AlertDialog(
      title: Text('审批${it.badge}'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('检查「$title」的完成情况：'),
            if (it.holidayRange.isNotEmpty || it.submittedDays > 0) ...[
              const SizedBox(height: 10),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF3E0),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '🏖️ 假期作业${it.holidayRange.isEmpty ? '' : '：${it.holidayRange}'}'
                  '${it.submittedDays > 0 ? '，孩子已分 ${it.submittedDays} 天提交' : ''}\n'
                  '通过 = 这份作业写完归档，之后不用再交；驳回 = 还可以继续提交。',
                  style: const TextStyle(fontSize: 13, color: Color(0xFFE65100), height: 1.4),
                ),
              ),
            ],
            const SizedBox(height: 12),
            const Text('打分', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('优秀（满分）'),
                  selected: _grade == 'excellent',
                  onSelected: (_) => setState(() => _grade = 'excellent'),
                ),
                ChoiceChip(
                  label: const Text('良好（一半）'),
                  selected: _grade == 'good',
                  onSelected: (_) => setState(() => _grade = 'good'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _comment,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '评语（选填）',
                hintText: '写下对这次完成的评价或鼓励……',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => _close('rejected'), child: const Text('驳回')),
        FilledButton(onPressed: () => _close('approved'), child: const Text('通过')),
      ],
    );
  }
}
