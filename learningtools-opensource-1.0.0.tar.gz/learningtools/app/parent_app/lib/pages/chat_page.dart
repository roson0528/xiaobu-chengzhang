import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/chat_notifier.dart';
import '../widgets/photo_view_page.dart';
import '../widgets/sticker_text.dart';
import 'family_chat_page.dart';

/// 聊天：与孩子一对一沟通，可发文字、照片、文件（作业）。
class ChatPage extends StatefulWidget {
  const ChatPage({super.key});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  List<ChildProfile> _children = [];
  List<Map<String, dynamic>> _familyMembers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await context.read<AuthService>().loadChildren();
    final members = await _loadFamilyMembers();
    if (mounted) {
      setState(() {
        _children = list;
        _familyMembers = members;
        _loading = false;
      });
    }
  }

  Future<List<Map<String, dynamic>>> _loadFamilyMembers() async {
    try {
      final data = await ApiClient.instance.getJson('/family/members') as Map<String, dynamic>;
      final members = (data['members'] as List?)?.whereType<Map>() ?? const [];
      final myId = context.read<AuthService>().user?.id;
      return members
          .map((e) => e.cast<String, dynamic>())
          .where((m) => m['id'] != myId && (m['role']?.toString() ?? '') != 'child')
          .toList();
    } catch (_) {
      return const [];
    }
  }

  Widget _trailing(bool unread) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (unread) Container(width: 10, height: 10, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
        const Icon(Icons.chevron_right),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('聊天'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ValueListenableBuilder<Set<String>>(
              valueListenable: ChatNotifier.instance.unreadKeys,
              builder: (context, unreadKeys, _) => RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  children: [
                    const _SectionHeader('家庭聊天'),
                    ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: Color(0xFFC8E6C9),
                        child: Text('👨‍👩‍👧', style: TextStyle(fontSize: 20)),
                      ),
                      title: const Text('家庭群聊'),
                      subtitle: const Text('全家人一起聊天'),
                      trailing: _trailing(unreadKeys.contains('family')),
                      onTap: () {
                        ChatNotifier.instance.markRead('family');
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const FamilyChatPage(isGroup: true, title: '家庭群聊'),
                          ),
                        );
                      },
                    ),
                    for (final m in _familyMembers)
                      ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFFBBDEFB),
                          child: Text('👤'),
                        ),
                        title: Text(m['display_name']?.toString() ?? m['username']?.toString() ?? ''),
                        subtitle: const Text('点击私聊'),
                        trailing: _trailing(unreadKeys.contains('p2p:${m['id']}')),
                        onTap: () {
                          ChatNotifier.instance.markRead('p2p:${m['id']}');
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => FamilyChatPage(
                                isGroup: false,
                                peerId: m['id'] as int,
                                title: m['display_name']?.toString() ?? m['username']?.toString() ?? '聊天',
                              ),
                            ),
                          );
                        },
                      ),
                    const Divider(height: 24),
                    const _SectionHeader('与孩子聊天'),
                    if (_children.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: Text('暂无孩子档案，请先在管理页添加孩子')),
                      )
                    else
                      for (final c in _children)
                        ListTile(
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFBBDEFB),
                            child: Text(c.avatar.isNotEmpty ? c.avatar : '👦'),
                          ),
                          title: Text(c.name),
                          subtitle: Text(c.grade > 0 ? '${c.grade} 年级' : '点击开始聊天'),
                          trailing: _trailing(c.userId != null && unreadKeys.contains('p2p:${c.userId}')),
                          onTap: () {
                            if (c.userId != null) ChatNotifier.instance.markRead('p2p:${c.userId}');
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => c.userId != null
                                    ? FamilyChatPage(isGroup: false, peerId: c.userId, title: c.name)
                                    : _ChatDetailPage(child: c),
                              ),
                            );
                          },
                        ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _ChatDetailPage extends StatefulWidget {
  final ChildProfile child;
  const _ChatDetailPage({required this.child});

  @override
  State<_ChatDetailPage> createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<_ChatDetailPage> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  final Map<String, Uint8List> _imageCache = {};
  final Map<String, Future<Uint8List?>> _futureCache = {};

  List<MessageItem> _messages = [];
  bool _loading = true;
  bool _sending = false;

  String get _childId => widget.child.id;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final data = await ApiClient.instance.getJson('/messages/$_childId') as List;
      final list = data
          .map((e) => MessageItem.fromJson((e as Map).cast<String, dynamic>()))
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      if (mounted) {
        setState(() {
          _messages = list;
          _loading = false;
        });
        _scrollToBottom();
        await ApiClient.instance.postForm('/messages/$_childId/read_all', const {});
      }
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  Future<Uint8List?> _loadImageBytes(MessageAttachment a) {
    final cached = _imageCache[a.path];
    if (cached != null) return Future.value(cached);
    final f = _futureCache[a.path];
    if (f != null) return f;
    final future = _fetchImageBytes(a);
    _futureCache[a.path] = future;
    return future;
  }

  Future<Uint8List?> _fetchImageBytes(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance
          .getBytes('/messages/$_childId/attachment?path=${Uri.encodeComponent(a.path)}');
      if (bytes.isEmpty) return null;
      _imageCache[a.path] = Uint8List.fromList(bytes);
      return _imageCache[a.path];
    } catch (_) {
      return null;
    }
  }

  Future<void> _sendText() async {
    final content = _input.text.trim();
    if (content.isEmpty) return;
    _input.clear();
    await _sendMessage(content: content);
  }

  Future<void> _sendSticker(String code) async {
    await _sendMessage(content: '[sticker:$code]');
  }

  Future<void> _pickSticker() async {
    final code = await showStickerPicker(context);
    if (code != null && code.isNotEmpty) {
      await _sendSticker(code);
    }
  }

  Future<void> _sendMessage({String content = '', List<MessageAttachment> attachments = const []}) async {
    setState(() => _sending = true);
    try {
      await ApiClient.instance.postJson('/messages/$_childId', {
        'content': content,
        'attachments': [
          for (final a in attachments) {'type': a.type, 'path': a.path, 'name': a.name, 'size': a.size},
        ],
      });
      await _load();
      _scrollToBottom();
    } on ApiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message), behavior: SnackBarBehavior.floating),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _pickAndSend(ImageSource source) async {
    try {
      final XFile? f = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      if (f == null) return;
      final a = await _uploadAttachment(File(f.path));
      if (a != null) await _sendMessage(attachments: [a]);
    } catch (e) {
      _toast('选择图片失败：$e');
    }
  }

  Future<void> _pickFileAndSend() async {
    try {
      final res = await FilePicker.platform.pickFiles();
      if (res == null || res.files.isEmpty) return;
      final f = res.files.single;
      final a = await _uploadAttachment(File(f.path!));
      if (a != null) await _sendMessage(attachments: [a]);
    } catch (e) {
      _toast('选择文件失败：$e');
    }
  }

  Future<MessageAttachment?> _uploadAttachment(File file) async {
    try {
      final res = await ApiClient.instance.uploadFile('/messages/$_childId/attachment', file, const {})
          as Map<String, dynamic>;
      return MessageAttachment(
        type: res['type']?.toString() ?? 'file',
        path: res['path']?.toString() ?? '',
        name: res['name']?.toString() ?? '',
        size: res['size'] is int ? res['size'] as int : 0,
      );
    } on ApiException catch (e) {
      _toast(e.message);
      return null;
    }
  }

  Future<void> _openFile(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance
          .getBytes('/messages/$_childId/attachment?path=${Uri.encodeComponent(a.path)}');
      final dir = await getTemporaryDirectory();
      final safe = a.name.replaceAll(RegExp(r'[/\\]'), '_');
      final file = File('${dir.path}/$safe');
      await file.writeAsBytes(bytes, flush: true);
      final result = await OpenFilex.open(file.path);
      if (result.type != ResultType.done && mounted) {
        _toast('无法打开该文件，请安装对应应用');
      }
    } catch (e) {
      _toast('下载失败：$e');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  void _showAttachSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Color(0xFF1E88E5)),
              title: const Text('拍照'),
              onTap: () {
                Navigator.pop(ctx);
                _pickAndSend(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF1E88E5)),
              title: const Text('从相册选择'),
              onTap: () {
                Navigator.pop(ctx);
                _pickAndSend(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.attach_file, color: Color(0xFF1E88E5)),
              title: const Text('发送文件（作业/文档）'),
              onTap: () {
                Navigator.pop(ctx);
                _pickFileAndSend();
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('与 ${widget.child.name} 聊天'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      body: Column(
        children: [
          Expanded(child: _buildList()),
          SafeArea(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: _sending ? null : _showAttachSheet,
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF1E88E5)),
                  ),
                  IconButton(
                    onPressed: _sending ? null : _pickSticker,
                    icon: const Icon(Icons.emoji_emotions_outlined, color: Color(0xFF1E88E5)),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      minLines: 1,
                      maxLines: 4,
                      decoration: InputDecoration(
                        hintText: '发消息…',
                        filled: true,
                        fillColor: const Color(0xFFF5F5F5),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  IconButton.filled(
                    onPressed: _sending ? null : _sendText,
                    icon: const Icon(Icons.send),
                    style: IconButton.styleFrom(backgroundColor: const Color(0xFF1E88E5)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_messages.isEmpty) {
      return const Center(child: Text('还没有消息，打个招呼吧 👋'));
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(12),
      itemCount: _messages.length,
      itemBuilder: (context, i) {
        final m = _messages[i];
        final isMine = m.senderRole != 'child';
        return Align(
          alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
            decoration: BoxDecoration(
              color: isMine ? const Color(0xFFBBDEFB) : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isMine ? 16 : 4),
                bottomRight: Radius.circular(isMine ? 4 : 16),
              ),
            ),
            child: Column(
              crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (m.content.isNotEmpty) ...[
                  StickerText(m.content),
                  const SizedBox(height: 4),
                ],
                if (m.attachments.isNotEmpty)
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [for (final a in m.attachments) _attachmentWidget(a)],
                  ),
                const SizedBox(height: 2),
                Text(
                  _shortTime(m.createdAt),
                  style: const TextStyle(fontSize: 10, color: Colors.grey),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _attachmentWidget(MessageAttachment a) {
    if (a.isImage) {
      return FutureBuilder<Uint8List?>(
        future: _loadImageBytes(a),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const SizedBox(
              width: 120,
              height: 120,
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            );
          }
          final bytes = snap.data;
          if (bytes == null) return const _AttachmentPlaceholder(emoji: '🖼️');
          return ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GestureDetector(
              onTap: () => _previewImage(bytes),
              child: Image.memory(bytes, width: 140, height: 140, fit: BoxFit.cover),
            ),
          );
        },
      );
    }
    return InkWell(
      onTap: () => _openFile(a),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFE3F2FD),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.attach_file, size: 18, color: Color(0xFF1E88E5)),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                a.name.isEmpty ? '附件' : a.name,
                style: const TextStyle(fontSize: 13),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (a.size > 0) ...[
              const SizedBox(width: 6),
              Text('${(a.size / 1024).toStringAsFixed(0)}KB',
                  style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ],
        ),
      ),
    );
  }

  void _previewImage(Uint8List bytes) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PhotoViewPage(photos: [bytes], title: '查看图片')),
    );
  }

  String _shortTime(String iso) {
    if (iso.isEmpty || iso.length < 16) return '';
    return iso.replaceFirst('T', ' ').substring(5, 16);
  }
}

class _AttachmentPlaceholder extends StatelessWidget {
  final String emoji;
  const _AttachmentPlaceholder({required this.emoji});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 120,
      height: 120,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(emoji, style: const TextStyle(fontSize: 32)),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String text;
  const _SectionHeader(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Text(
        text,
        style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.bold),
      ),
    );
  }
}
