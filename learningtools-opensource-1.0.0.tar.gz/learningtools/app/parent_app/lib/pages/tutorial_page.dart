import 'package:flutter/material.dart';

/// 使用教程：家长端、管理后台、孩子端的完整使用说明。
class TutorialPage extends StatelessWidget {
  const TutorialPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('使用教程'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 40),
        children: const [
          _Lead(),
          _Section(
            title: '这套工具是干什么的',
            children: [
              _P('小步成长是一套家长和孩子配合使用的学习与习惯养成工具。'
                  '家长在手机（「小步家长」App）或电脑上布置任务、查看情况，孩子在手机上看任务、打卡、完成任务，一家人还能在一个地方聊天。'),
              _P('它分成三个部分：家长端 App（小步家长）、管理后台（电脑浏览器）、孩子端 App。'
                  '下面按这三块分别说明怎么用。'),
            ],
          ),
          _Section(
            title: '一、家长端 App 怎么用',
            children: [
              _H('1. 登录'),
              _P('用管理员分配给你的账号密码登录。登录后底部有五个入口：管理、任务、作业、聊天、我的。'),
              _H('2. 管理（首页）'),
              _P('这里是孩子情况的汇总，能看到孩子的任务完成情况、专注时长、积分等信息，'
                  '也可以从这里快速进入常用的管理操作。'),
              _H('3. 任务'),
              _P('这里同步显示孩子的「今日任务」和打卡审核：孩子每天要做的任务都会显示在这里，'
                  '按执行状态区分「未进行 / 待审批 / 已通过 / 已驳回」。'
                  '点「审批」可以打分（优秀得全部积分、良好得一半积分）并写评语，也可以驳回。'
                  '点任意一条可以进入详情页查看完整内容和照片（左右滑动连续看图）。'
                  '右上角「日历」可按日期查找历史任务。'
                  '右下角的「布置任务」按钮可以临时布置一次性任务，布置后同步到孩子端「今日任务」。'),
              _H('4. 作业'),
              _P('这里默认显示「当天布置或当天提交」的作业：包括孩子自行提交的课堂作业，'
                  '以及通过右下角「布置作业」布置的内容。历史作业默认归档、不显示，'
                  '点右上角「日历」可按日期查找任意一天的历史作业。'
                  '点「审批」检查完成情况，支持优秀/良好打分和写评语；'
                  '课堂作业会标注「来自课堂作业」，普通作业也可以一键发送到家庭聊天。'),
              _H('5. 聊天'),
              _P('底部「聊天」里有家庭群聊，也可以单独找某个家庭成员或孩子私聊，'
                  '支持发文字、图片和视频。有新消息时聊天标签会显示红点，点开会话就自动消除。'),
              _H('6. 我的'),
              _P('我的里有几个常用功能：'),
              _Bullet('教育日记：记录孩子的成长状态、作业完成情况和需要改进的地方。'),
              _Bullet('我的家庭：查看家庭成员，添加爸爸、妈妈或孩子账号。'),
              _Bullet('检查升级：手动检查有没有新版本，有新版本会提醒下载安装。'),
              _Bullet('分享应用：把下载地址和介绍发给朋友。'),
              _Bullet('使用教程：也就是你现在看到的这个页面。'),
            ],
          ),
          _Section(
            title: '二、管理后台怎么用',
            children: [
              _P('管理后台在电脑浏览器里打开，适合做偏管理的事情。用管理员账号登录。'),
              _H('1. 仪表盘'),
              _P('看整体的孩子数量、任务完成、打卡、积分等汇总数据。'),
              _H('2. 孩子管理'),
              _P('点「新增孩子账号」创建孩子档案，填写姓名、年级等信息，并绑定到对应的家长账号。'),
              _H('3. 用户管理'),
              _P('管理家长、孩子等各类账号，包括创建账号、重置密码、分配角色。'),
              _H('4. 任务与计划'),
              _P('按周给孩子安排任务，可以一次排好一整周。'),
              _H('5. 聊天记录管理'),
              _P('查看每个孩子的聊天占用情况（图片、视频、文件各占多少），'
                  '可以按类型清理，也可以一次性清空全部聊天记录。'),
              _H('6. 奖励管理'),
              _P('设置孩子可以兑换的奖品（比如多少积分换多少分钟游戏时间），以及可以获得的徽章。'),
              _H('7. 导出'),
              _P('把孩子的成长报告、任务记录等数据导出成文件保存。'),
            ],
          ),
          _Section(
            title: '三、孩子端 App 怎么用',
            children: [
              _P('孩子用孩子账号登录，界面更简单、更活泼。底部有五个入口：今日任务、专注、打卡、聊天、我的。'),
              _H('1. 今日任务'),
              _P('看今天要做什么。点一个任务可以看说明，然后点开始去做，做完拍照提交。'
                  '也可以翻看以前的历史任务，看看过去都完成了什么。'),
              _H('2. 专注'),
              _P('学习类任务会进入专注模式：一个倒计时，期间摄像头会定时拍一下确认孩子在学习，'
                  '时间到了再拍照提交任务。劳动、运动这类任务不走专注模式。'),
              _H('3. 打卡'),
              _P('孩子每天的学习、运动、阅读、劳动、心情都可以在这里打卡，拍照提交给家长审核。'),
              _H('4. 聊天'),
              _P('有家庭群，也能单独找爸爸、妈妈或同学聊天，发文字、图片、视频。'
                  '有新消息会弹提醒，聊天标签也会显示红点。'),
              _H('5. 我的'),
              _P('孩子在这里看自己的奖励（积分、徽章、兑换奖品）、错题本、成长记录、好友，以及设置。'),
            ],
          ),
          _Section(
            title: '四、网络管控（限制平板上网）',
            children: [
              _P('「我的 → 网络管控」可以管住孩子的平板：平时上不了外网，'
                  '只有家长勾选了「需要联网」的任务在专注期间、'
                  '或者用积分兑换到带上网时长的奖励时，才临时放开。'),
              _H('1. 平时是「限制上网」'),
              _P('默认只放行学习平台本身，所以孩子端 App 永远能打开、能开始专注。'
                  '其它上网行为（刷视频、玩游戏、逛网页）都会被挡掉。'),
              _H('2. 什么时候会自动放开'),
              _P('发布任务或作业时勾选「需要联网」，孩子打开这个任务点「开始专注」，'
                  '平板在这个专注期间就可以上网；专注结束自动收回。\n'
                  '没有勾选「需要联网」的任务、以及自由专注，专注期间都不能上网。'),
              _H('3. 注意：默认是「不需要联网」'),
              _P('发布任务、布置作业时「需要联网」默认不勾选。'
                  '需要孩子上网查资料、看网课的任务，记得手动打开这个开关。'),
              _H('4. 家长的一键硬开关'),
              _P('「一键断网」：完全断开（连学习平台也断），适合需要立刻制止的时候。\n'
                  '「一键联网」：完全放开，适合临时把平板交给孩子查资料。\n'
                  '「恢复正常管控」：回到默认的限制状态。'),
              _H('5. 给奖励加「附赠上网时长」'),
              _P('在管理后台的奖励页，新增兑换项时可以填「附赠上网」分钟数。'
                  '孩子兑换成功后，平板就自动获得对应时长的上网时间。'),
              _Bullet('放行都是「临时」的：路由器自己计时，时间一到自动收紧，'
                  '不会因为网络故障而一直开着。'),
              _Bullet('平板本身没有独立的联网权，能不能上网完全由孩子端 App 的状态决定。'),
              _Bullet('如果换了路由器或平板换了网络导致 MAC 变了，'
                  '可以在「网络管控」右上角铅笔图标里把新 MAC 填回去。'),
            ],
          ),
          _Section(
            title: '五、假期作业（寒暑假、国庆等长假期）',
            children: [
              _P('遇到国庆、寒暑假这种一口气布置好几天量的作业时，'
                  '把它设成「假期作业」就不怕孩子被误扣分了。'),
              _H('1. 怎么布置'),
              _P('在「作业 → 布置作业」或「任务 → 发布任务」里勾选「假期作业 / 假期任务」，'
                  '再填「假期时长」天数（比如国庆填 7 天）。'
                  '已有的作业/任务也可以点开「修改」补上这个设置。'),
              _H('2. 假期里它一直都在'),
              _P('平时任务只在布置的那一天出现；设成假期作业后，'
                  '从开始日期起连续 N 天都会出现在孩子的「今日任务」里，想起来写就写。'),
              _H('3. 每天可以交一部分'),
              _P('孩子假期里可能一天只写一部分：可以每天提交一次，'
                  '照片会一天天累积起来，家长审核时能看到每一天交的内容。'),
              _H('4. 只有「通过」才算写完'),
              _P('家长审核通过，这份作业才算写完并归档，孩子端就不再出现、也不用再交；'
                  '如果驳回，孩子可以继续补交，直到通过为止。'),
              _Bullet('假期里什么时候交都不算超时，不会触发「未完成扣分」；'
                  '整段假期结束还是一个字没交，才会按设定扣一次分。'),
              _Bullet('一个假期可以布置多份假期作业，时长各填各的。'),
            ],
          ),
          _Section(
            title: '几个小提醒',
            children: [
              _Bullet('查看照片时左右滑动可以连续看上一张、下一张，右上角按钮可以横竖屏切换。'),
              _Bullet('家里有多个孩子时，打卡页可以选「全部孩子」一起看，每个孩子的提交都会标注名字。'),
              _Bullet('劳动、家务、运动这类体力任务不会启动专注模式，做完直接拍照提交就行。'),
              _Bullet('聊天有未读红点提醒，点开会话就自动消除，不需要手动清理。'),
              _Bullet('升级检查在「我的」里，有新版本会主动提醒，建议及时更新。'),
              _Bullet('孩子端的账号和设备是绑定的，同一时间一般只在一个设备上登录。'),
            ],
          ),
        ],
      ),
    );
  }
}

class _Lead extends StatelessWidget {
  const _Lead();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.only(bottom: 18),
      child: Text(
        '这份教程会带你一步步了解小步成长的所有功能。建议先从头看一遍，'
        '遇到具体功能时再回来翻对应的小节。',
        style: TextStyle(fontSize: 15, color: Colors.black87, height: 1.6),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _Section({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1565C0),
            ),
          ),
          const SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }
}

class _H extends StatelessWidget {
  final String text;

  const _H(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 4),
      child: Text(
        text,
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class _P extends StatelessWidget {
  final String text;

  const _P(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text(
        text,
        style: const TextStyle(fontSize: 15, color: Colors.black87, height: 1.6),
      ),
    );
  }
}

class _Bullet extends StatelessWidget {
  final String text;

  const _Bullet(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6, left: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 7, right: 8),
            child: Icon(Icons.circle, size: 6, color: Colors.grey),
          ),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 15, color: Colors.black87, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}
