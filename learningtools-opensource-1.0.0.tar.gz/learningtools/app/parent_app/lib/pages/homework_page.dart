import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/photo_thumbs.dart';
import '../widgets/review_homework_dialog.dart';
import 'item_detail_page.dart';

/// 作业：布置当日的作业内容（支持附件/照片），内容同步到孩子端「今日作业」，可一键转聊天发送。
class HomeworkPage extends StatefulWidget {
  const HomeworkPage({super.key});

  @override
  State<HomeworkPage> createState() => _HomeworkPageState();
}

const String _allChildren = '__all__'; // 查看全部孩子

class _HomeworkPageState extends State<HomeworkPage> {
  List<ChildProfile> _children = [];
  String? _childId;
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  bool _sending = false;
  String? _selectedDate; // 默认今天，可切换按日期查找

  @override
  void initState() {
    super.initState();
    _selectedDate = _fmtDate(DateTime.now());
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await context.read<AuthService>().loadChildren();
    String? cid = _childId;
    if (cid == null && list.isNotEmpty) {
      // 多个孩子时默认「全部孩子」，避免新增孩子后只显示第一个孩子的作业
      cid = list.length > 1 ? _allChildren : list.first.id;
    }
    if (!mounted) return;
    setState(() {
      _children = list;
      _childId = cid;
    });
    await _loadItems();
  }

  Future<void> _loadItems() async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      setState(() {
        _loading = false;
        _items = [];
      });
      return;
    }
    try {
      // 目标孩子：全部孩子 或 单个孩子
      final targets = <Map<String, String>>[];
      if (cid == _allChildren) {
        for (final c in _children) {
          targets.add({'id': c.id, 'name': c.name});
        }
      } else {
        String name = '';
        for (final c in _children) {
          if (c.id == cid) {
            name = c.name;
            break;
          }
        }
        targets.add({'id': cid, 'name': name});
      }

      final day = _selectedDate ?? _fmtDate(DateTime.now());
      final all = <Map<String, dynamic>>[];
      for (final t in targets) {
        final tid = t['id']!;
        final data = await ApiClient.instance.getJson('/homework/$tid') as List;
        for (final e in data.whereType<Map>()) {
          final raw = e.cast<String, dynamic>();
          raw['_child_id'] = tid;
          raw['_child_name'] = t['name'] ?? '';
          all.add(raw);
        }
      }
      // 默认只显示当天布置/提交；切换日期后按所选日期查找（历史作业即归档后仍可按日期查看）
      final items = all.where((e) {
        final planned = (e['planned_date'] ?? e['date'] ?? '').toString();
        final completed = (e['completed_at'] ?? '').toString();
        // 假期作业在假期区间内每天都能看到（可能只写了一部分，还没审核通过）
        if (e['holiday'] == true) {
          final d = DateTime.tryParse(planned);
          final n = e['holiday_days'] is int ? e['holiday_days'] as int : 0;
          if (d != null && n > 0) {
            final end = d.add(Duration(days: n - 1));
            final day0 = DateTime.tryParse(day);
            if (day0 != null && !day0.isBefore(DateTime(d.year, d.month, d.day)) && !day0.isAfter(end)) {
              return true;
            }
          }
        }
        return planned == day || completed.startsWith(day);
      }).toList();
      items.sort((a, b) {
        final da = (a['planned_date'] ?? a['date'] ?? '').toString();
        final db = (b['planned_date'] ?? b['date'] ?? '').toString();
        return db.compareTo(da);
      });
      setState(() {
        _items = items;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _fmtDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  /// 中文日期：2026年9月15日
  String _fmtCn(String s) {
    final p = DateTime.tryParse(s);
    if (p == null) return s;
    return '${p.year}年${p.month}月${p.day}日';
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate != null ? DateTime.tryParse(_selectedDate!) ?? now : now,
      firstDate: DateTime(2020, 1, 1),
      lastDate: now,
      helpText: '按日期查找',
    );
    if (picked == null || !mounted) return;
    setState(() => _selectedDate = _fmtDate(picked));
    await _loadItems();
  }

  /// 孩子选择图标（多孩子时显示在 AppBar，日历左侧）：全部孩子=group，单个孩子=person。
  Widget _buildChildSelector() {
    final isAll = _childId == _allChildren;
    return IconButton(
      icon: Icon(isAll ? Icons.group : Icons.person),
      tooltip: _childNameOf(_childId),
      onPressed: _pickChild,
    );
  }

  String _childNameOf(String? id) {
    if (id == _allChildren) return '全部孩子';
    for (final c in _children) {
      if (c.id == id) return c.name;
    }
    return '选择孩子';
  }

  Future<void> _pickChild() async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.group, color: Color(0xFF1E88E5)),
              title: const Text('全部孩子', style: TextStyle(fontWeight: FontWeight.bold)),
              trailing: _childId == _allChildren ? const Icon(Icons.check, color: Color(0xFF1E88E5)) : null,
              onTap: () => Navigator.pop(ctx, _allChildren),
            ),
            for (final c in _children)
              ListTile(
                leading: const Icon(Icons.person, color: Color(0xFF1E88E5)),
                title: Text(c.name),
                trailing: _childId == c.id ? const Icon(Icons.check, color: Color(0xFF1E88E5)) : null,
                onTap: () => Navigator.pop(ctx, c.id),
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    setState(() => _childId = selected);
    await _loadItems();
  }

  Future<void> _addHomework() async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      _toast('请先在管理页添加孩子档案');
      return;
    }
    if (cid == _allChildren) {
      _toast('布置作业请先点击左上角图标选择具体孩子');
      return;
    }
    final draft = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _HomeworkForm(childId: cid),
    );
    if (draft == null || !mounted) return;
    try {
      await ApiClient.instance.postJson('/homework/$cid', {
        'title': draft['title'],
        'content': draft['content'] ?? '',
        'date': draft['date'],
        'need_network': draft['need_network'] ?? false,
        'holiday': draft['holiday'] ?? false,
        'holiday_days': draft['holiday_days'] ?? 0,
        'attachments': draft['attachments'] ?? [],
      });
      if (!mounted) return;
      _toast('作业已布置，已同步到孩子端 ✅');
      await _loadItems();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _sendToChat(Map<String, dynamic> item) async {
    final cid = (item['_child_id'] ?? _childId ?? '').toString();
    if (cid.isEmpty) return;
    setState(() => _sending = true);
    try {
      await ApiClient.instance.postJson('/homework/$cid/${item['id']}/send-to-chat', const {});
      if (!mounted) return;
      _toast('已通过聊天发送给孩子 💬');
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _delete(Map<String, dynamic> item) async {
    final cid = (item['_child_id'] ?? _childId ?? '').toString();
    if (cid.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除作业？'),
        content: Text('确定删除「${item['title']}」吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await ApiClient.instance.delete('/homework/$cid/${item['id']}');
      await _loadItems();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('作业'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          if (_children.length > 1) _buildChildSelector(),
          if (_selectedDate != null && _selectedDate != _fmtDate(DateTime.now()))
            IconButton(
              icon: const Icon(Icons.today),
              tooltip: '回到今天',
              onPressed: () {
                setState(() => _selectedDate = _fmtDate(DateTime.now()));
                _loadItems();
              },
            ),
          IconButton(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), tooltip: '按日期查'),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addHomework,
        icon: const Icon(Icons.add),
        label: const Text('布置作业'),
        backgroundColor: const Color(0xFF1E88E5),
      ),
      body: Column(
        children: [
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_children.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text('暂无孩子档案，请先在管理页添加孩子'),
        ),
      );
    }
    if (_items.isEmpty) {
      final isToday = _selectedDate == null || _selectedDate == _fmtDate(DateTime.now());
      return RefreshIndicator(
        onRefresh: _loadItems,
        child: ListView(
          children: [
            const SizedBox(height: 100),
            Center(child: Text(isToday ? '今天暂无作业，点击右下角「布置作业」' : '该日期暂无作业')),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadItems,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: _items.length,
        itemBuilder: (_, i) => _homeworkCard(_items[i]),
      ),
    );
  }

  Future<void> _openDetail(Map<String, dynamic> item) async {
    final changed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => ItemDetailPage(
          kind: 'task',
          raw: item,
          childId: (item['_child_id'] ?? _childId ?? '').toString(),
          showClassChip: (item['source']?.toString() ?? '') == 'classroom',
        ),
      ),
    );
    if (changed == true && mounted) await _loadItems();
  }

  Widget _homeworkCard(Map<String, dynamic> item) {
    final title = item['title']?.toString() ?? '';
    final content = item['content']?.toString() ?? '';
    final date = _fmtCn((item['planned_date'] ?? item['date'] ?? '').toString());
    final attachments = (item['attachments'] as List?) ?? const [];
    final status = item['status']?.toString() ?? 'pending';
    final reviewStatus = item['review_status']?.toString() ?? '';
    final donePhotos = (item['completed_photos'] as List?)
            ?.map((e) => e.toString())
            .where((e) => e.isNotEmpty)
            .toList() ??
        const <String>[];
    final isCompleted = status == 'completed';
    final fromClass = (item['source']?.toString() ?? '') == 'classroom';
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openDetail(item),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (_childId == _allChildren && (item['_child_name'] ?? '').toString().isNotEmpty) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00897B).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      (item['_child_name'] ?? '').toString(),
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF00897B)),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                ),
                _statusChip(status, reviewStatus),
                const SizedBox(width: 6),
                Text(date, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
            if (content.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(content, style: const TextStyle(fontSize: 14, color: Colors.black87)),
            ],
            if (attachments.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final a in attachments)
                    _attachmentWidget(
                      MessageAttachment.fromJson((a as Map).cast<String, dynamic>()),
                      (item['_child_id'] ?? _childId ?? '').toString(),
                    ),
                ],
              ),
            ],
            if ((isCompleted || reviewStatus == 'rejected') && donePhotos.isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(reviewStatus == 'rejected' ? '被驳回的提交照片' : '孩子提交的照片',
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 6),
              PhotoThumbs(paths: donePhotos, childId: (item['_child_id'] ?? _childId ?? '').toString()),
            ],
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (isCompleted && reviewStatus == 'pending')
                  FilledButton.tonalIcon(
                    onPressed: () => _review(item),
                    icon: const Icon(Icons.fact_check_outlined, size: 18),
                    label: const Text('审批'),
                  ),
                if (fromClass)
                  _chip('来自课堂作业', const Color(0xFF8E24AA))
                else
                  TextButton.icon(
                    onPressed: _sending ? null : () => _sendToChat(item),
                    icon: const Icon(Icons.chat_bubble_outline, size: 18),
                    label: const Text('发送到聊天'),
                  ),
                IconButton(
                  onPressed: () => _delete(item),
                  icon: const Icon(Icons.delete_outline, color: Colors.red),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
  }

  Widget _statusChip(String status, String reviewStatus) {
    if (reviewStatus == 'rejected') return _chip('已驳回', const Color(0xFFE53935));
    if (status == 'completed') {
      final (label, color) = switch (reviewStatus) {
        'approved' => ('已通过', const Color(0xFF43A047)),
        _ => ('待审批', const Color(0xFFFB8C00)),
      };
      return _chip(label, color);
    }
    if (status == 'skipped') return _chip('已跳过', const Color(0xFF9E9E9E));
    return _chip('待完成', const Color(0xFF1E88E5));
  }

  Widget _chip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.bold)),
    );
  }

  Future<void> _review(Map<String, dynamic> item) async {
    final cid = (item['_child_id'] ?? _childId ?? '').toString();
    if (cid.isEmpty) return;
    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => ReviewHomeworkDialog(
        dialogTitle: '审批作业',
        itemTitle: item['title']?.toString() ?? '',
      ),
    );
    if (result == null || !mounted) return;
    final status = result['status'] as String;

    // 二次确认，防止误触通过/驳回
    final approved = status == 'approved';
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(approved ? '确认通过？' : '确认驳回？'),
        content: Text(
          approved
              ? '通过后该作业不能再提交修改。'
              : '驳回后孩子会收到通知，可查看原因并重新提交，直到通过为止。',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: approved ? const Color(0xFF43A047) : const Color(0xFFE53935),
            ),
            child: Text(approved ? '确认通过' : '确认驳回'),
          ),
        ],
      ),
    );
    if (confirm != true || !mounted) return;

    try {
      await ApiClient.instance.postJson('/tasks/${item['id']}/review?child_id=$cid', {
        'status': status,
        'comment': result['comment'] ?? '',
        'grade': result['grade'],
      });
      if (!mounted) return;
      _toast(status == 'approved' ? '已通过 ✅' : '已驳回');
      await _loadItems();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Widget _attachmentWidget(MessageAttachment a, String childId) {
    if (a.isImage) {
      return _HomeworkImage(attachment: a, childId: childId);
    }
    return InkWell(
      onTap: () => _openFile(a, childId),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFE3F2FD),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.attach_file, size: 18, color: Color(0xFF1E88E5)),
            const SizedBox(width: 4),
            Flexible(child: Text(a.name.isEmpty ? '附件' : a.name, style: const TextStyle(fontSize: 13))),
          ],
        ),
      ),
    );
  }

  Future<void> _openFile(MessageAttachment a, String childId) async {
    try {
      final bytes = await ApiClient.instance.getBytes(
        '/messages/$childId/attachment?path=${Uri.encodeComponent(a.path)}',
      );
      final dir = await getTemporaryDirectory();
      final name = (a.name.isEmpty ? 'attachment' : a.name).split(RegExp(r'[\\/]')).last;
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes, flush: true);
      await OpenFilex.open(file.path);
    } catch (e) {
      _toast('打开失败：$e');
    }
  }
}

class _HomeworkImage extends StatefulWidget {
  final MessageAttachment attachment;
  final String childId;
  const _HomeworkImage({required this.attachment, required this.childId});

  @override
  State<_HomeworkImage> createState() => _HomeworkImageState();
}

class _HomeworkImageState extends State<_HomeworkImage> {
  Uint8List? _bytes;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await ApiClient.instance.getBytes(
        '/messages/${widget.childId}/attachment?path=${Uri.encodeComponent(widget.attachment.path)}',
      );
      if (mounted) setState(() => _bytes = Uint8List.fromList(bytes));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final b = _bytes;
    if (b == null) {
      return Container(
        width: 90,
        height: 90,
        color: const Color(0xFFF5F5F5),
        child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image.memory(b, width: 90, height: 90, fit: BoxFit.cover),
    );
  }
}

/// 布置作业表单（底部弹层）：标题、内容、日期、附件/照片。
class _HomeworkForm extends StatefulWidget {
  final String childId;
  const _HomeworkForm({required this.childId});

  @override
  State<_HomeworkForm> createState() => _HomeworkFormState();
}

class _HomeworkFormState extends State<_HomeworkForm> {
  final _title = TextEditingController();
  final _content = TextEditingController();
  DateTime _date = DateTime.now();
  final List<MessageAttachment> _attachments = [];
  bool _uploading = false;
  // 是否需要联网：勾选后该作业开启专注模式期间可以上外网（默认不勾选）
  bool _needNetwork = false;
  // 假期作业：勾选后在「假期时长」天内持续存在，每天可交一部分，审核通过才算写完
  bool _isHoliday = false;
  final _holidayDays = TextEditingController(text: '7');

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    _holidayDays.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto(ImageSource source) async {
    try {
      final f = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      if (f == null) return;
      await _upload(File(f.path));
    } catch (e) {
      _toast('选择图片失败：$e');
    }
  }

  Future<void> _pickFile() async {
    try {
      final res = await FilePicker.platform.pickFiles();
      if (res == null || res.files.isEmpty) return;
      await _upload(File(res.files.single.path!));
    } catch (e) {
      _toast('选择文件失败：$e');
    }
  }

  Future<void> _upload(File file) async {
    setState(() => _uploading = true);
    try {
      final res = await ApiClient.instance.uploadFile(
        '/messages/${widget.childId}/attachment',
        file,
        const {},
      ) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _attachments.add(MessageAttachment(
          type: res['type']?.toString() ?? 'file',
          path: res['path']?.toString() ?? '',
          name: res['name']?.toString() ?? '',
          size: res['size'] is int ? res['size'] as int : 0,
        ));
      });
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _submit() {
    final title = _title.text.trim();
    if (title.isEmpty) {
      _toast('请输入作业标题');
      return;
    }
    Navigator.pop(context, {
      'title': title,
      'content': _content.text.trim(),
      'date': _date.toIso8601String().substring(0, 10),
      'need_network': _needNetwork,
      'holiday': _isHoliday,
      'holiday_days': _isHoliday ? (int.tryParse(_holidayDays.text.trim()) ?? 7) : 0,
      'attachments': [
        for (final a in _attachments) {'type': a.type, 'path': a.path, 'name': a.name, 'size': a.size},
      ],
    });
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (d != null) setState(() => _date = d);
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('布置作业', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(
                controller: _title,
                decoration: const InputDecoration(
                  labelText: '作业标题 *',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _content,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: '作业内容',
                  hintText: '例如：语文课本第5课朗读、数学练习册P10-12…',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('日期：', style: TextStyle(fontWeight: FontWeight.bold)),
                  TextButton(
                    onPressed: _pickDate,
                    child: Text('${_date.year}年${_date.month}月${_date.day}日 📅'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Text('附件/照片：', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  IconButton(onPressed: _uploading ? null : () => _pickPhoto(ImageSource.camera), icon: const Icon(Icons.photo_camera)),
                  IconButton(onPressed: _uploading ? null : () => _pickPhoto(ImageSource.gallery), icon: const Icon(Icons.photo_library)),
                  IconButton(onPressed: _uploading ? null : _pickFile, icon: const Icon(Icons.attach_file)),
                ],
              ),
              if (_uploading) const LinearProgressIndicator(),
              if (_attachments.isNotEmpty)
                Wrap(
                  spacing: 8,
                  children: [
                    for (final a in _attachments)
                      Chip(
                        label: Text(a.name.isEmpty ? '附件' : a.name),
                        onDeleted: () => setState(() => _attachments.remove(a)),
                      ),
                  ],
                ),
              const SizedBox(height: 4),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('需要联网', style: TextStyle(fontSize: 15)),
                subtitle: const Text('勾选后，该作业专注期间平板可以上外网；不勾选则不能上网',
                    style: TextStyle(fontSize: 12)),
                value: _needNetwork,
                activeTrackColor: const Color(0xFF1E88E5),
                onChanged: (v) => setState(() => _needNetwork = v),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('假期作业 🏖️', style: TextStyle(fontSize: 15)),
                subtitle: const Text('勾选后，这期间每天都能看到它；每天可以交一部分，家长审核通过才算写完',
                    style: TextStyle(fontSize: 12)),
                value: _isHoliday,
                activeTrackColor: const Color(0xFFFF7043),
                onChanged: (v) => setState(() => _isHoliday = v),
              ),
              if (_isHoliday)
                Padding(
                  padding: const EdgeInsets.only(left: 4, right: 4, bottom: 6),
                  child: Row(
                    children: [
                      const Text('假期时长：', style: TextStyle(fontSize: 14)),
                      SizedBox(
                        width: 90,
                        child: TextField(
                          controller: _holidayDays,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(
                            isDense: true,
                            border: OutlineInputBorder(),
                            suffixText: '天',
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '例如国庆 7 天：从上面选的日期起连续 7 天有效',
                          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _submit,
                  child: const Text('布置并同步到孩子端'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
