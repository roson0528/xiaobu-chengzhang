import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/chat_notifier.dart';
import '../services/event_notifier.dart';
import 'admin_webview_page.dart';
import 'chat_page.dart';
import 'checkin_review_page.dart';
import 'homework_page.dart';
import 'mine_page.dart';

/// 家长端主页：底部五页（管理 / 任务 / 作业 / 聊天 / 我的）。
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  bool _hasUpdate = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkUpdate();
      _startChatNotifier();
    });
  }

  void _startChatNotifier() {
    final uid = context.read<AuthService>().user?.id ?? 0;
    if (uid > 0) ChatNotifier.instance.start(uid);
    EventNotifier.instance.start();
  }

  Widget _chatTabIcon(IconData icon) {
    return ValueListenableBuilder<int>(
      valueListenable: ChatNotifier.instance.unread,
      builder: (_, n, __) => Badge(
        isLabelVisible: n > 0,
        label: Text('$n'),
        child: Icon(icon),
      ),
    );
  }

  /// 检查家长端新版本：有新版则「我的」标签显示红点。
  Future<void> _checkUpdate() async {
    try {
      final data = await ApiClient.instance.getJson('/app/parent/latest') as Map<String, dynamic>;
      final latest = data['version']?.toString() ?? '';
      if (latest.isEmpty || !mounted) return;
      if (_compareVersion(latest, AppConfig.appVersion) > 0) {
        setState(() => _hasUpdate = true);
      }
    } catch (_) {}
  }

  int _compareVersion(String a, String b) {
    final pa = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final pb = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final len = pa.length > pb.length ? pa.length : pb.length;
    for (var i = 0; i < len; i++) {
      final va = i < pa.length ? pa[i] : 0;
      final vb = i < pb.length ? pb[i] : 0;
      if (va != vb) return va.compareTo(vb);
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [
          AdminWebviewPage(),
          CheckinReviewPage(),
          HomeworkPage(),
          ChatPage(),
          MinePage(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: '管理'),
          const NavigationDestination(icon: Icon(Icons.checklist_outlined), selectedIcon: Icon(Icons.checklist), label: '任务'),
          const NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: '作业'),
          NavigationDestination(
            icon: _chatTabIcon(Icons.chat_bubble_outline),
            selectedIcon: _chatTabIcon(Icons.chat_bubble),
            label: '聊天',
          ),
          NavigationDestination(
            icon: Badge(isLabelVisible: _hasUpdate, smallSize: 8, child: const Icon(Icons.person_outline)),
            selectedIcon: Badge(isLabelVisible: _hasUpdate, smallSize: 8, child: const Icon(Icons.person)),
            label: '我的',
          ),
        ],
      ),
    );
  }
}
