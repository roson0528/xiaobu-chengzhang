import 'package:flutter/material.dart';

import '../services/api_client.dart';

/// 我的家庭：查看家庭成员，添加成员（绑定账号到本家庭）。
class FamilyPage extends StatefulWidget {
  const FamilyPage({super.key});

  @override
  State<FamilyPage> createState() => _FamilyPageState();
}

class _FamilyPageState extends State<FamilyPage> {
  List<Map<String, dynamic>> _members = [];
  List<Map<String, dynamic>> _children = [];
  String _familyId = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiClient.instance.getJson('/family/members') as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _familyId = data['family_id']?.toString() ?? '';
        _members = ((data['members'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => e.cast<String, dynamic>())
            .toList();
        _children = ((data['children'] as List?) ?? const [])
            .whereType<Map>()
            .map((e) => e.cast<String, dynamic>())
            .toList();
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _bindMember() async {
    final controller = TextEditingController();
    final username = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('添加家庭成员'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: '对方账号（用户名）',
            hintText: '输入爸爸/妈妈/孩子的登录账号',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('添加'),
          ),
        ],
      ),
    );
    if (username == null || username.isEmpty || !mounted) return;
    try {
      await ApiClient.instance.postJson('/family/bind', {'username': username});
      if (!mounted) return;
      _toast('已添加 $username ✅');
      await _load();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('我的家庭'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_alt),
            tooltip: '添加成员',
            onPressed: _bindMember,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (_familyId.isNotEmpty)
                    Card(
                      color: const Color(0xFFE3F2FD),
                      child: ListTile(
                        leading: const Icon(Icons.family_restroom, color: Color(0xFF1E88E5)),
                        title: const Text('家庭编号'),
                        subtitle: Text(_familyId, style: const TextStyle(fontSize: 12)),
                      ),
                    ),
                  const SizedBox(height: 12),
                  const Text('家庭成员', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (_members.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: Text('暂无成员', style: TextStyle(color: Colors.grey))),
                      ),
                    )
                  else
                    for (final m in _members)
                      Card(
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: const Color(0xFFBBDEFB),
                            child: Text(m['role'] == 'child' ? '👦' : '👤'),
                          ),
                          title: Text(m['display_name']?.toString() ?? m['username']?.toString() ?? ''),
                          subtitle: Text(m['username']?.toString() ?? ''),
                          trailing: _roleChip(m['role']?.toString() ?? ''),
                        ),
                      ),
                  const SizedBox(height: 16),
                  const Text('孩子档案', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (_children.isEmpty)
                    const Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: Text('暂无孩子档案', style: TextStyle(color: Colors.grey))),
                      ),
                    )
                  else
                    for (final c in _children)
                      Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: Color(0xFFC8E6C9),
                            child: Text('👦'),
                          ),
                          title: Text(c['name']?.toString() ?? ''),
                          subtitle: Text('${c['grade'] ?? 0} 年级'),
                        ),
                      ),
                  const SizedBox(height: 16),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.person_add_alt, color: Color(0xFF1E88E5)),
                      title: const Text('添加成员'),
                      subtitle: const Text('输入对方账号，加入本家庭后可聊天与数据同步'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: _bindMember,
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _roleChip(String role) {
    final (label, color) = switch (role) {
      'super_admin' || 'family_admin' => ('管理员', const Color(0xFF1E88E5)),
      'parent' => ('家长', const Color(0xFF43A047)),
      'child' => ('孩子', const Color(0xFFFF8F00)),
      _ => (role, const Color(0xFF9E9E9E)),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.bold)),
    );
  }
}
