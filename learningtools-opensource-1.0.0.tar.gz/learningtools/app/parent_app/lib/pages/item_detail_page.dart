import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../widgets/photo_thumbs.dart';
import '../widgets/photo_view_page.dart';

/// 任务 / 打卡 / 作业 详情页：完整信息 + 提交照片（可左右连续看图）。
/// 任务 / 作业支持「修改」「删除」；循环任务修改仅对今天有效。
class ItemDetailPage extends StatefulWidget {
  final String kind; // 'checkin' | 'task'
  final Map<String, dynamic> raw;
  final String childId;
  final String childName; // 「全部孩子」模式下标注名字
  final bool showClassChip; // 是否显示「来自课堂作业」

  const ItemDetailPage({
    super.key,
    required this.kind,
    required this.raw,
    required this.childId,
    this.childName = '',
    this.showClassChip = false,
  });

  @override
  State<ItemDetailPage> createState() => _ItemDetailPageState();
}

class _ItemDetailPageState extends State<ItemDetailPage> {
  bool _busy = false;

  Map<String, dynamic> get raw => widget.raw;
  String get _id => raw['id']?.toString() ?? '';
  String get _childId => widget.childId;

  bool get _isTask => widget.kind == 'task';
  bool get _isHomework =>
      _isTask &&
      ((raw['task_type']?.toString() ?? '') == '作业' || raw['homework'] == true);
  bool get _isRecurring {
    final r = raw['repeat'];
    if (r is Map) return (r['type']?.toString() ?? 'none') != 'none';
    return false;
  }

  String get _time {
    final completed = (raw['completed_at'] ?? '').toString();
    if (completed.isNotEmpty) return completed;
    final created = (raw['created_at'] ?? '').toString();
    if (created.isNotEmpty) return created;
    final planned = (raw['planned_date'] ?? '').toString();
    final start = (raw['planned_start'] ?? '').toString();
    return start.isNotEmpty ? '$planned $start' : planned;
  }

  String get _status => _isTask
      ? (raw['review_status'] ?? '').toString()
      : (raw['status'] ?? '').toString();

  String get _badge => _isTask
      ? (raw['task_type'] ?? raw['subject'] ?? '任务').toString()
      : (raw['checkin_type'] ?? '打卡').toString();

  String get _title => _isTask
      ? (raw['title'] ?? '').toString()
      : (raw['subject'] ?? '').toString();

  String get _content => (raw['content'] ?? '').toString();
  String get _comment => (raw['review_comment'] ?? '').toString();
  String get _grade => (raw['grade'] ?? '').toString();

  List<String> get _photos {
    final list = raw['completed_photos'] ?? raw['photo_paths'];
    if (list is List) {
      return list.map((e) => e.toString()).where((e) => e.isNotEmpty).toList();
    }
    final s = (raw['completed_photo'] ?? raw['photo_path'])?.toString() ?? '';
    return s.isNotEmpty ? [s] : const [];
  }

  /// 布置作业时家长上传的附件（图片/文件）。
  List<MessageAttachment> get _attachments {
    final list = raw['attachments'];
    if (list is List) {
      return list
          .whereType<Map>()
          .map((e) => MessageAttachment.fromJson(e.cast<String, dynamic>()))
          .where((a) => a.path.isNotEmpty)
          .toList();
    }
    return const [];
  }

  Future<Uint8List?> _loadAttachmentBytes(String path) async {
    try {
      final b = await ApiClient.instance.getBytes(
        '/messages/$_childId/attachment?path=${Uri.encodeComponent(path)}',
      );
      return Uint8List.fromList(b);
    } catch (_) {
      return null;
    }
  }

  Future<void> _openAttachment(MessageAttachment a) async {
    try {
      final bytes = await _loadAttachmentBytes(a.path);
      if (bytes == null || bytes.isEmpty) {
        _toast('附件加载失败');
        return;
      }
      final dir = await getTemporaryDirectory();
      final safe = a.name.isEmpty ? 'attachment' : a.name.replaceAll(RegExp(r'[/\\]'), '_');
      final file = File('${dir.path}/$safe');
      await file.writeAsBytes(bytes, flush: true);
      final result = await OpenFilex.open(file.path);
      if (result.type != ResultType.done && mounted) {
        _toast('无法打开该文件，请安装对应应用');
      }
    } catch (e) {
      _toast('下载附件失败：$e');
    }
  }

  Widget _attachmentThumb(MessageAttachment a) {
    if (a.isImage) {
      return FutureBuilder<Uint8List?>(
        future: _loadAttachmentBytes(a.path),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const SizedBox(
              width: 92,
              height: 92,
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
            );
          }
          final bytes = snap.data;
          if (bytes == null || bytes.isEmpty) {
            return const SizedBox(
              width: 92,
              height: 92,
              child: Center(child: Text('🖼️', style: TextStyle(fontSize: 30))),
            );
          }
          return ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GestureDetector(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => PhotoViewPage(
                    photos: [bytes],
                    title: a.name.isEmpty ? '查看图片' : a.name,
                  ),
                ),
              ),
              child: Image.memory(bytes, width: 92, height: 92, fit: BoxFit.cover),
            ),
          );
        },
      );
    }
    return InkWell(
      onTap: () => _openAttachment(a),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFE3F2FD),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.attach_file, size: 18, color: Color(0xFF1E88E5)),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                a.name.isEmpty ? '附件' : a.name,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _fmtTime(String s) {
    final p = DateTime.tryParse(s);
    if (p == null) return s;
    final hh = p.hour.toString().padLeft(2, '0');
    final mm = p.minute.toString().padLeft(2, '0');
    return '${p.year}年${p.month}月${p.day}日 $hh:$mm';
  }

  (String, Color) get _statusChip {
    if (_isTask) {
      final st = (raw['status'] ?? '').toString();
      if (st == 'skipped') return ('已跳过', const Color(0xFF9E9E9E));
      if (st == 'completed') {
        final rs = (raw['review_status'] ?? '').toString();
        if (rs == 'approved') return ('已通过', const Color(0xFF43A047));
        if (rs == 'rejected') return ('已驳回', const Color(0xFFE53935));
        return ('待审批', const Color(0xFFFB8C00));
      }
      return ('未进行', const Color(0xFF1E88E5));
    }
    return switch (_status) {
      'approved' => ('已通过', const Color(0xFF43A047)),
      'rejected' => ('已驳回', const Color(0xFFE53935)),
      _ => ('待审批', const Color(0xFFFB8C00)),
    };
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  // ---- 修改 ----
  Future<void> _openEdit() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: _TaskEditForm(raw: raw, isHomework: _isHomework),
      ),
    );
    if (result == null || !mounted) return;
    setState(() => _busy = true);
    try {
      if (_isHomework) {
        await ApiClient.instance.putJson('/homework/$_childId/$_id', {
          'title': result['title'],
          'content': result['content'] ?? '',
          'date': result['planned_date'],
          'need_network': result['need_network'] ?? false,
          'holiday': result['holiday'] ?? false,
          'holiday_days': result['holiday_days'] ?? 0,
        });
      } else {
        await ApiClient.instance.putJson(
          '/tasks/$_id?child_id=$_childId&today_only=${_isRecurring ? 'true' : 'false'}',
          {
            'title': result['title'],
            'content': result['content'] ?? '',
            'difficulty': result['difficulty'] ?? 'medium',
            'reward_points': result['reward_points'],
            'penalty_points': result['penalty_points'] ?? 0,
            'photo_required': result['photo_required'] ?? true,
            'need_network': result['need_network'] ?? false,
            'holiday': result['holiday'] ?? false,
            'holiday_days': result['holiday_days'] ?? 0,
            'planned_date': result['planned_date'],
          },
        );
      }
      if (!mounted) return;
      _toast(_isRecurring && !_isHomework ? '已修改（仅今天生效）✅' : '已修改 ✅');
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (mounted) setState(() => _busy = false);
      _toast(e.message);
    }
  }

  // ---- 删除 ----
  Future<void> _delete() async {
    final tip = _isRecurring && !_isHomework
        ? '这是循环任务，删除仅对今天生效，明天仍会照常出现。'
        : '删除后不可恢复。';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除确认'),
        content: Text('确定删除「$_title」吗？\n$tip'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('删除', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      if (_isHomework) {
        await ApiClient.instance.delete('/homework/$_childId/$_id');
      } else {
        await ApiClient.instance.delete(
          '/tasks/$_id?child_id=$_childId&today_only=${_isRecurring ? 'true' : 'false'}',
        );
      }
      if (!mounted) return;
      _toast(_isRecurring && !_isHomework ? '已删除（仅今天）✅' : '已删除 ✅');
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      if (mounted) setState(() => _busy = false);
      _toast(e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final (statusLabel, statusColor) = _statusChip;
    final gradeLabel = _grade == 'good'
        ? '良好（一半）'
        : _grade == 'excellent'
            ? '优秀（满分）'
            : '';
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      appBar: AppBar(
        title: Text('$_badge详情'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [
          if (_isTask && !_busy) ...[
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              tooltip: '修改',
              onPressed: _openEdit,
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: '删除',
              onPressed: _delete,
            ),
          ] else if (_busy)
            const Padding(
              padding: EdgeInsets.all(14),
              child: SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
              ),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _title.isEmpty ? _badge : _title,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          statusLabel,
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: statusColor),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _chip(_badge, const Color(0xFF1E88E5)),
                      if (widget.childName.isNotEmpty) _chip(widget.childName, const Color(0xFF00897B)),
                      if (widget.showClassChip) _chip('来自课堂作业', const Color(0xFF8E24AA)),
                      if (_isRecurring && !_isHomework) _chip('循环任务', const Color(0xFF7E57C2)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_time.isNotEmpty)
                    Text('🕐 ${_fmtTime(_time)}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                  if (_content.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    const Text('内容', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text(_content, style: const TextStyle(fontSize: 15, height: 1.5, color: Colors.black87)),
                  ],
                  if (_attachments.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    const Text('布置内容附件', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [for (final a in _attachments) _attachmentThumb(a)],
                    ),
                  ],
                  if (_comment.isNotEmpty || gradeLabel.isNotEmpty) ...[
                    const SizedBox(height: 14),
                    const Divider(height: 1),
                    const SizedBox(height: 10),
                    if (gradeLabel.isNotEmpty)
                      Text('打分：$gradeLabel',
                          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: Color(0xFFF57C00))),
                    if (_comment.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text('评语：$_comment',
                          style: const TextStyle(fontSize: 14, color: Colors.black54, height: 1.5)),
                    ],
                  ],
                ],
              ),
            ),
          ),
          if (_photos.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('提交的照片（左右滑动连续看图）',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            PhotoThumbs(paths: _photos, childId: _childId, size: 100),
          ],
        ],
      ),
    );
  }

  Widget _chip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.bold)),
    );
  }
}

/// 修改任务/作业表单（底部弹层）。
class _TaskEditForm extends StatefulWidget {
  final Map<String, dynamic> raw;
  final bool isHomework;
  const _TaskEditForm({required this.raw, required this.isHomework});

  @override
  State<_TaskEditForm> createState() => _TaskEditFormState();
}

class _TaskEditFormState extends State<_TaskEditForm> {
  late final TextEditingController _title;
  late final TextEditingController _content;
  late final TextEditingController _reward;
  late final TextEditingController _penalty;
  late String _difficulty;
  late bool _photoRequired;
  // 是否需要联网：勾选后专注期间放开平板外网（默认不勾选）
  late bool _needNetwork;
  // 假期作业/任务：勾选后在「假期时长」天内持续存在，假期内每天可交一部分，审核通过才算写完
  late bool _isHoliday;
  late final TextEditingController _holidayDays;
  // 假期从哪天开始（就是这份作业/任务的计划日期）
  late DateTime _startDate;

  @override
  void initState() {
    super.initState();
    final r = widget.raw;
    _title = TextEditingController(text: (r['title'] ?? '').toString());
    _content = TextEditingController(text: (r['content'] ?? '').toString());
    _reward = TextEditingController(
      text: r['reward_points'] is int ? '${r['reward_points']}' : '',
    );
    _penalty = TextEditingController(
      text: r['penalty_points'] is int ? '${r['penalty_points']}' : '0',
    );
    _difficulty = (r['difficulty'] ?? 'medium').toString();
    _photoRequired = r['photo_required'] != false;
    _needNetwork = r['need_network'] == true;
    _isHoliday = r['holiday'] == true;
    _startDate = DateTime.tryParse((r['planned_date'] ?? '').toString()) ?? DateTime.now();
    _holidayDays = TextEditingController(
      text: r['holiday_days'] is int && (r['holiday_days'] as int) > 0 ? '${r['holiday_days']}' : '7',
    );
  }

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    _reward.dispose();
    _penalty.dispose();
    _holidayDays.dispose();
    super.dispose();
  }

  static String _iso(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  static String _pretty(DateTime d) => '${d.month}月${d.day}日';

  /// 假期区间预览：开始日期 + 时长 → 结束日期（含）
  String get _holidayRangeText {
    final n0 = int.tryParse(_holidayDays.text.trim()) ?? 7;
    final n = n0 < 1 ? 1 : (n0 > 60 ? 60 : n0);
    final start = DateTime(_startDate.year, _startDate.month, _startDate.day);
    final end = start.add(Duration(days: n - 1));
    return n <= 1 ? _pretty(start) : '${_pretty(start)}~${_pretty(end)}';
  }

  Future<void> _pickStartDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (d != null && mounted) setState(() => _startDate = d);
  }

  void _save() {
    final title = _title.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入标题'), behavior: SnackBarBehavior.floating),
      );
      return;
    }
    final reward = int.tryParse(_reward.text.trim());
    final penalty = int.tryParse(_penalty.text.trim()) ?? 0;
    Navigator.of(context).pop({
      'title': title,
      'content': _content.text.trim(),
      'difficulty': _difficulty,
      'reward_points': (reward != null && reward > 0) ? reward : null,
      'penalty_points': penalty,
      'photo_required': _photoRequired,
      'need_network': _needNetwork,
      'holiday': _isHoliday,
      'holiday_days': _isHoliday ? (int.tryParse(_holidayDays.text.trim()) ?? 7) : 0,
      'planned_date': _iso(_startDate),
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.isHomework ? '修改作业' : '修改任务',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          if (!widget.isHomework)
            const Padding(
              padding: EdgeInsets.only(top: 4),
              child: Text('循环任务修改仅对今天有效，不影响原任务',
                  style: TextStyle(fontSize: 12, color: Colors.orange)),
            ),
          const SizedBox(height: 12),
          TextField(
            controller: _title,
            decoration: const InputDecoration(labelText: '标题 *', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _content,
            maxLines: 3,
            decoration: const InputDecoration(labelText: '内容', border: OutlineInputBorder()),
          ),
          if (!widget.isHomework) ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: _difficulty,
              decoration: const InputDecoration(labelText: '难度', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'easy', child: Text('简单')),
                DropdownMenuItem(value: 'medium', child: Text('中等')),
                DropdownMenuItem(value: 'hard', child: Text('困难')),
              ],
              onChanged: (v) => setState(() => _difficulty = v ?? 'medium'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _reward,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '奖励积分（选填）',
                hintText: '留空按难度默认',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _penalty,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '未完成扣分（0 不扣）',
                border: OutlineInputBorder(),
              ),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('需要拍照提交', style: TextStyle(fontSize: 15)),
              value: _photoRequired,
              activeTrackColor: const Color(0xFF1E88E5),
              onChanged: (v) => setState(() => _photoRequired = v),
            ),
          ],
          // 下面这几项作业和任务都支持：已经布置过的作业也能改成假期作业/需要联网
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('需要联网', style: TextStyle(fontSize: 15)),
            subtitle: const Text('勾选后，专注期间平板可以上外网；不勾选则不能上网',
                style: TextStyle(fontSize: 12)),
            value: _needNetwork,
            activeTrackColor: const Color(0xFF1E88E5),
            onChanged: (v) => setState(() => _needNetwork = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(widget.isHomework ? '假期作业 🏖️' : '假期任务 🏖️',
                style: const TextStyle(fontSize: 15)),
            subtitle: const Text('勾选后，这期间每天都能看到它；每天可交一部分，审核通过才算写完',
                style: TextStyle(fontSize: 12)),
            value: _isHoliday,
            activeTrackColor: const Color(0xFFFF7043),
            onChanged: (v) => setState(() => _isHoliday = v),
          ),
          if (_isHoliday) ...[
            Padding(
              padding: const EdgeInsets.only(left: 4, right: 4, bottom: 4),
              child: Row(
                children: [
                  const Text('假期开始：', style: TextStyle(fontSize: 14)),
                  OutlinedButton.icon(
                    onPressed: _pickStartDate,
                    icon: const Icon(Icons.calendar_today, size: 16),
                    label: Text(_pretty(_startDate)),
                  ),
                  const SizedBox(width: 12),
                  const Text('时长：', style: TextStyle(fontSize: 14)),
                  SizedBox(
                    width: 84,
                    child: TextField(
                      controller: _holidayDays,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        isDense: true,
                        border: OutlineInputBorder(),
                        suffixText: '天',
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 4, right: 4, bottom: 6),
              child: Text(
                '假期区间：$_holidayRangeText（这段时间内每天都能看到它，随时可以交一部分）',
                style: const TextStyle(fontSize: 12, color: Color(0xFFE64A19)),
              ),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _save,
              icon: const Icon(Icons.save),
              label: const Text('保存'),
            ),
          ),
        ],
      ),
    );
  }
}
