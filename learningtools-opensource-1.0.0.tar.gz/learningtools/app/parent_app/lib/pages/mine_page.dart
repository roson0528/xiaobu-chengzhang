import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import 'diary_page.dart';
import 'family_page.dart';
import 'login_page.dart';
import 'net_control_page.dart';
import 'tutorial_page.dart';

/// 我的：账号、版本、检查升级、孩子端下载、退出登录。
class MinePage extends StatefulWidget {
  const MinePage({super.key});

  @override
  State<MinePage> createState() => _MinePageState();
}

class _MinePageState extends State<MinePage> {
  bool _checking = false;
  bool _downloading = false;
  double _progress = 0;
  String _downloadingLabel = '';

  @override
  void initState() {
    super.initState();
    // 打开即静默检查新版本（有新版本弹提示）
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkUpdate(silent: true));
  }

  String get _serverOrigin {
    final base = AppConfig.apiBaseUrl;
    final idx = base.indexOf('/api/v1');
    return idx > 0 ? base.substring(0, idx) : base;
  }

  int _compareVersion(String a, String b) {
    final pa = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final pb = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final len = pa.length > pb.length ? pa.length : pb.length;
    for (var i = 0; i < len; i++) {
      final va = i < pa.length ? pa[i] : 0;
      final vb = i < pb.length ? pb[i] : 0;
      if (va != vb) return va.compareTo(vb);
    }
    return 0;
  }

  Future<Map<String, dynamic>> _fetchLatest() async {
    return await ApiClient.instance.getJson('/app/parent/latest') as Map<String, dynamic>;
  }

  Future<void> _checkUpdate({bool silent = false}) async {
    setState(() => _checking = true);
    try {
      final data = await _fetchLatest();
      final latest = data['version']?.toString() ?? '';
      final url = data['download_url']?.toString() ?? '';
      if (!mounted) return;
      if (latest.isEmpty || _compareVersion(latest, AppConfig.appVersion) <= 0) {
        if (!silent) {
          _toast('已是最新版本 V${AppConfig.appVersion} ✅');
        }
        return;
      }
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('发现新版本 V$latest'),
          content: Text('当前版本 V${AppConfig.appVersion}，是否下载并安装最新版？'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('稍后')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('立即更新')),
          ],
        ),
      );
      if (ok == true && mounted) await _downloadAndInstall(url, '家长端升级包');
    } on ApiException catch (e) {
      if (!silent) _toast(e.message);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  /// 分享应用：把下载地址 + 介绍通过微信/QQ等发给朋友。
  Future<void> _shareApp() async {
    final text = '我正在使用「小步成长」：孩子打卡、专注学习、家长布置作业、家庭聊天，'
        '家长端和孩子端配套使用。\n家长端下载：$_serverOrigin/apk/parent-app-release.apk\n'
        '孩子端下载：$_serverOrigin/apk/app-release.apk';
    try {
      await SharePlus.instance.share(ShareParams(text: text, subject: '小步成长 App'));
    } catch (e) {
      _toast('分享失败：$e');
    }
  }

  Future<void> _downloadAndInstall(String downloadUrl, String label) async {
    String fullUrl = downloadUrl;
    if (downloadUrl.startsWith('/')) fullUrl = '$_serverOrigin$downloadUrl';

    setState(() {
      _downloading = true;
      _downloadingLabel = label;
      _progress = 0;
    });
    try {
      // 存到应用私有 files 目录（FileProvider 已授权），供系统安装器读取
      final dir = await getApplicationSupportDirectory();
      final updateDir = Directory('${dir.path}/update');
      if (!await updateDir.exists()) await updateDir.create(recursive: true);
      final apkPath = '${updateDir.path}/app-release.apk';

      await Dio().download(
        fullUrl,
        apkPath,
        onReceiveProgress: (received, total) {
          if (total > 0 && mounted) setState(() => _progress = received / total);
        },
      );
      if (!mounted) return;
      // 原生 FileProvider + ACTION_VIEW 唤起系统安装器
      try {
        await const MethodChannel('app_update/install')
            .invokeMethod('installApk', {'path': apkPath});
        if (mounted) _toast('$label已开始安装，请在系统弹窗中确认');
      } catch (e) {
        final result = await OpenFilex.open(apkPath);
        if (result.type != ResultType.done) {
          if (mounted) _toast('自动安装失败（${e is PlatformException ? e.message : e}），请手动打开安装包');
        }
      }
    } on DioException catch (e) {
      if (mounted) _toast('下载失败：${e.message}');
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  /// 修改昵称（聊天中显示的名字）。
  Future<void> _editNickname() async {
    final auth = context.read<AuthService>();
    final controller = TextEditingController(text: auth.user?.nickname ?? '');
    final nickname = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改名字'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: '名字（聊天中显示）',
            hintText: '例如：爸爸、妈妈、李爸爸',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    if (nickname == null || !mounted) return;
    try {
      await ApiClient.instance.putJson('/auth/me', {'nickname': nickname});
      await auth.refreshMe();
      if (!mounted) return;
      _toast(nickname.isEmpty ? '已清除名字' : '名字已更新 ✅');
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('退出登录'),
        content: const Text('确定要退出当前账号吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('退出')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await context.read<AuthService>().logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final user = auth.user;
    return Scaffold(
      appBar: AppBar(
        title: const Text('我的'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                radius: 26,
                backgroundColor: Color(0xFFBBDEFB),
                child: Text('👤', style: TextStyle(fontSize: 26)),
              ),
              title: Text(user?.displayName ?? '未登录',
                  style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              subtitle: Text(user?.roleLabel ?? ''),
              trailing: const Icon(Icons.edit, size: 20, color: Colors.grey),
              onTap: _editNickname,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.menu_book, color: Color(0xFF1E88E5)),
              title: const Text('教育日记'),
              subtitle: const Text('记录孩子成长状态、作业完成、问题不足'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const DiaryPage()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.family_restroom, color: Color(0xFF1E88E5)),
              title: const Text('我的家庭'),
              subtitle: const Text('查看家庭成员、添加爸爸/妈妈/孩子账号'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const FamilyPage()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.wifi_lock, color: Color(0xFF1E88E5)),
              title: const Text('网络管控'),
              subtitle: const Text('一键断网/联网，专注模式与奖励自动放行上网'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const NetControlPage()),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.system_update, color: Color(0xFF1E88E5)),
              title: const Text('检查升级'),
              subtitle: Text('当前版本 正式版 V${AppConfig.appVersion}'),
              trailing: _checking
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.chevron_right),
              onTap: _checking ? null : () => _checkUpdate(),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.share, color: Color(0xFF1E88E5)),
              title: const Text('分享应用'),
              subtitle: const Text('把下载地址和介绍发给朋友（微信/QQ等）'),
              trailing: const Icon(Icons.chevron_right),
              onTap: _shareApp,
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.help_outline, color: Color(0xFF1E88E5)),
              title: const Text('使用教程'),
              subtitle: const Text('家长端、管理后台、孩子端的完整使用说明'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const TutorialPage()),
              ),
            ),
          ),
          if (_downloading) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('正在下载 $_downloadingLabel…'),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: _progress, minHeight: 6),
                    const SizedBox(height: 4),
                    Text('${(_progress * 100).toStringAsFixed(0)}%', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('退出登录', style: TextStyle(color: Colors.red)),
              onTap: _logout,
            ),
          ),
          const SizedBox(height: 20),
          Center(
            child: Text('小步成长 正式版 V${AppConfig.appVersion} · 家长端',
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ),
        ],
      ),
    );
  }
}
