import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';

/// 教育日记：记录孩子成长状态、作业完成情况、学习问题不足等。
class DiaryPage extends StatefulWidget {
  const DiaryPage({super.key});

  @override
  State<DiaryPage> createState() => _DiaryPageState();
}

class _DiaryPageState extends State<DiaryPage> {
  List<ChildProfile> _children = [];
  String? _childId;
  List<Map<String, dynamic>> _entries = [];
  bool _loading = true;

  static const _moods = [
    {'value': 'happy', 'label': '😄 开心'},
    {'value': 'ok', 'label': '😐 一般'},
    {'value': 'tired', 'label': '😩 疲惫'},
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await context.read<AuthService>().loadChildren();
    String? cid = _childId;
    if (cid == null && list.isNotEmpty) cid = list.first.id;
    if (!mounted) return;
    setState(() {
      _children = list;
      _childId = cid;
    });
    await _loadEntries();
  }

  Future<void> _loadEntries() async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      setState(() {
        _loading = false;
        _entries = [];
      });
      return;
    }
    try {
      final month = DateTime.now().toIso8601String().substring(0, 7);
      final data = await ApiClient.instance.getJson('/diary/$cid', query: {'month': month}) as List;
      if (!mounted) return;
      setState(() {
        _entries = data.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _add() async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) {
      _toast('请先在管理页添加孩子档案');
      return;
    }
    final draft = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _DiaryForm(),
    );
    if (draft == null || !mounted) return;
    try {
      await ApiClient.instance.postJson('/diary/$cid', draft);
      if (!mounted) return;
      _toast('教育日记已保存 ✅');
      await _loadEntries();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  Future<void> _delete(Map<String, dynamic> e) async {
    final cid = _childId;
    if (cid == null || cid.isEmpty) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除这条日记？'),
        content: Text('确定删除 ${e['date'] ?? ''} 的日记吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await ApiClient.instance.delete('/diary/$cid/${e['id']}');
      await _loadEntries();
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  String _moodLabel(String mood) {
    for (final m in _moods) {
      if (m['value'] == mood) return m['label']!;
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('教育日记'),
        backgroundColor: const Color(0xFF1E88E5),
        foregroundColor: Colors.white,
        actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('写日记'),
        backgroundColor: const Color(0xFF1E88E5),
      ),
      body: Column(
        children: [
          if (_children.length > 1)
            Container(
              color: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  const Text('孩子：', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(width: 8),
                  DropdownButton<String>(
                    value: _childId,
                    items: [
                      for (final c in _children)
                        DropdownMenuItem(value: c.id, child: Text(c.name)),
                    ],
                    onChanged: (v) {
                      setState(() => _childId = v);
                      _loadEntries();
                    },
                  ),
                ],
              ),
            ),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_children.isEmpty) {
      return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('暂无孩子档案')));
    }
    if (_entries.isEmpty) {
      return RefreshIndicator(
        onRefresh: _loadEntries,
        child: ListView(
          children: const [
            SizedBox(height: 100),
            Center(child: Text('本月还没有日记，点击右下角「写日记」记录成长点滴')),
          ],
        ),
      );
    }
    return RefreshIndicator(
      onRefresh: _loadEntries,
      child: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: _entries.length,
        itemBuilder: (_, i) => _entryCard(_entries[i]),
      ),
    );
  }

  Widget _entryCard(Map<String, dynamic> e) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('📅 ${e['date'] ?? ''}',
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                ),
                if ((e['mood']?.toString() ?? '').isNotEmpty)
                  Text(_moodLabel(e['mood']!.toString()),
                      style: const TextStyle(fontSize: 13, color: Colors.orange)),
                IconButton(
                  onPressed: () => _delete(e),
                  icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                ),
              ],
            ),
            _field('🌱 成长状态', e['growth']),
            _field('📝 作业完成', e['homework']),
            _field('⚠️ 问题不足', e['problems']),
            _field('📌 备注', e['note']),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, dynamic value) {
    final v = value?.toString() ?? '';
    if (v.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 14, color: Colors.black87),
          children: [
            TextSpan(text: '$label：', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: v),
          ],
        ),
      ),
    );
  }
}

/// 写日记表单（底部弹层）。
class _DiaryForm extends StatefulWidget {
  @override
  State<_DiaryForm> createState() => _DiaryFormState();
}

class _DiaryFormState extends State<_DiaryForm> {
  final _growth = TextEditingController();
  final _homework = TextEditingController();
  final _problems = TextEditingController();
  final _note = TextEditingController();
  DateTime _date = DateTime.now();
  String _mood = 'ok';

  @override
  void dispose() {
    _growth.dispose();
    _homework.dispose();
    _problems.dispose();
    _note.dispose();
    super.dispose();
  }

  void _submit() {
    Navigator.pop(context, {
      'date': _date.toIso8601String().substring(0, 10),
      'growth': _growth.text.trim(),
      'homework': _homework.text.trim(),
      'problems': _problems.text.trim(),
      'mood': _mood,
      'note': _note.text.trim(),
    });
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (d != null) setState(() => _date = d);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('写教育日记', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Text('日期：', style: TextStyle(fontWeight: FontWeight.bold)),
                  TextButton(
                    onPressed: _pickDate,
                    child: Text('${_date.year}年${_date.month}月${_date.day}日 📅'),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              const Text('今天心情：', style: TextStyle(fontWeight: FontWeight.bold)),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment(value: 'happy', label: Text('😄 开心')),
                  ButtonSegment(value: 'ok', label: Text('😐 一般')),
                  ButtonSegment(value: 'tired', label: Text('😩 疲惫')),
                ],
                selected: {_mood},
                onSelectionChanged: (s) => setState(() => _mood = s.first),
              ),
              const SizedBox(height: 12),
              _tf(_growth, '成长状态（表现、进步等）', 3),
              const SizedBox(height: 12),
              _tf(_homework, '作业完成情况', 3),
              const SizedBox(height: 12),
              _tf(_problems, '学习问题/不足', 3),
              const SizedBox(height: 12),
              _tf(_note, '其他备注', 3),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(onPressed: _submit, child: const Text('保存日记')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tf(TextEditingController c, String label, int lines) {
    return TextField(
      controller: c,
      maxLines: lines,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
    );
  }
}
