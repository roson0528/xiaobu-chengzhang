/// 家长/管理端数据模型。
class UserInfo {
  final int id;
  final String username;
  final String role;
  final String status;
  final String nickname;

  const UserInfo({
    required this.id,
    required this.username,
    required this.role,
    this.status = 'active',
    this.nickname = '',
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
        id: json['id'] is int ? json['id'] as int : int.tryParse('${json['id'] ?? ''}') ?? 0,
        username: json['username']?.toString() ?? '',
        role: json['role']?.toString() ?? '',
        status: json['status']?.toString() ?? 'active',
        nickname: json['nickname']?.toString() ?? '',
      );

  String get displayName => nickname.isNotEmpty ? nickname : username;

  String get roleLabel {
    switch (role) {
      case 'super_admin':
        return '超级管理员';
      case 'family_admin':
        return '家庭管理员';
      case 'parent':
        return '家长';
      default:
        return role;
    }
  }
}

class ChildProfile {
  final String id;
  final String name;
  final int grade;
  final String avatar;
  final int? userId;

  const ChildProfile({
    required this.id,
    required this.name,
    this.grade = 0,
    this.avatar = '',
    this.userId,
  });

  factory ChildProfile.fromJson(Map<String, dynamic> json) => ChildProfile(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        grade: json['grade'] is int
            ? json['grade'] as int
            : int.tryParse('${json['grade'] ?? ''}') ?? 0,
        avatar: json['avatar']?.toString() ?? '',
        userId: json['user_id'] is int
            ? json['user_id'] as int
            : int.tryParse('${json['user_id'] ?? ''}'),
      );
}

class MessageAttachment {
  final String type; // image / audio / video / file
  final String path;
  final String name;
  final int size;

  const MessageAttachment({
    required this.type,
    required this.path,
    this.name = '',
    this.size = 0,
  });

  factory MessageAttachment.fromJson(Map<String, dynamic> json) => MessageAttachment(
        type: json['type']?.toString() ?? 'file',
        path: json['path']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        size: json['size'] is int
            ? json['size'] as int
            : int.tryParse('${json['size'] ?? ''}') ?? 0,
      );

  bool get isImage => type == 'image';
}

class MessageItem {
  final String id;
  final String senderRole;
  final String senderName;
  final String content;
  final List<MessageAttachment> attachments;
  final String readAt;
  final String createdAt;

  const MessageItem({
    required this.id,
    required this.senderRole,
    required this.senderName,
    required this.content,
    this.attachments = const [],
    required this.readAt,
    required this.createdAt,
  });

  factory MessageItem.fromJson(Map<String, dynamic> json) {
    final atts = <MessageAttachment>[];
    final a = json['attachments'];
    if (a is List) {
      for (final e in a) {
        if (e is Map) {
          atts.add(MessageAttachment.fromJson(e.cast<String, dynamic>()));
        }
      }
    }
    return MessageItem(
      id: json['id']?.toString() ?? '',
      senderRole: json['sender_role']?.toString() ?? '',
      senderName: json['sender_name']?.toString() ?? '',
      content: json['content']?.toString() ?? '',
      attachments: atts,
      readAt: json['read_at']?.toString() ?? '',
      createdAt: json['created_at']?.toString() ?? '',
    );
  }

  bool get isRead => readAt.isNotEmpty && readAt != 'null';
}
