import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// 全屏查看照片：左右滑动连续翻页、双指放大（放大后可拖动查看局部）、
/// 横竖屏切换、长按保存到相册 / 分享。
///
/// 滑动流畅性要点（解决「左右滑动生硬、不跟手」）：
/// 1. **非当前页不挂 InteractiveViewer**：`PageView` 会预构建相邻页，若每页都挂
///    `InteractiveViewer`，它的 `ScaleGestureRecognizer` 会与 `PageView` 的横向拖动
///    在手势竞技场里抢手势，导致翻页发涩。相邻页只渲染静态图片即可。
/// 2. **未放大时 `panEnabled: false`**：当前页在未放大时不接管拖动，横向滑动完全交给
///    `PageView`；只有放大后才允许拖动图片。
/// 3. **`allowImplicitScrolling: true`**：预构建前后各一页，翻页时图片已解码，
///    不会出现「滑到一半才开始加载」的顿挫。
/// 4. **未放大时 `physics: null`**：使用平台原生滚动物理（跟手 + 翻页吸附），
///    避免手写 `PageScrollPhysics` 覆盖掉原生手感。
class PhotoViewPage extends StatefulWidget {
  final List<Uint8List> photos;
  final int initialIndex;
  final String title;
  const PhotoViewPage({
    super.key,
    required this.photos,
    this.initialIndex = 0,
    this.title = '查看照片',
  });

  @override
  State<PhotoViewPage> createState() => _PhotoViewPageState();
}

class _PhotoViewPageState extends State<PhotoViewPage> {
  late final PageController _controller;
  late int _index;
  int _quarterTurns = 0;
  bool _zoomed = false;

  @override
  void initState() {
    super.initState();
    _index = widget.photos.isEmpty
        ? 0
        : widget.initialIndex.clamp(0, widget.photos.length - 1);
    _controller = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// 放大时禁用左右翻页，让单指拖动在图片内移动位置；恢复原大小后恢复翻页。
  void _onZoomChanged(bool zoomed) {
    if (_zoomed == zoomed) return;
    setState(() => _zoomed = zoomed);
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  String _imageExtension(Uint8List b) {
    if (b.length >= 8 &&
        b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) {
      return '.png';
    }
    if (b.length >= 3 && b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) {
      return '.jpg';
    }
    if (b.length >= 3 && b[0] == 0x47 && b[1] == 0x49 && b[2] == 0x46) {
      return '.gif';
    }
    if (b.length >= 4 &&
        b[0] == 0x52 && b[1] == 0x49 && b[2] == 0x46 && b[3] == 0x46) {
      return '.webp';
    }
    return '.jpg';
  }

  Future<void> _shareCurrent() async {
    if (widget.photos.isEmpty || _index >= widget.photos.length) return;
    try {
      final dir = await getTemporaryDirectory();
      final name = 'learning_${DateTime.now().millisecondsSinceEpoch}'
          '${_imageExtension(widget.photos[_index])}';
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(widget.photos[_index], flush: true);
      await SharePlus.instance.share(ShareParams(
        files: [XFile(file.path)],
        text: '小步成长 · 分享图片',
      ));
    } catch (_) {
      _toast('分享失败，请稍后重试');
    }
  }

  Future<void> _saveCurrent() async {
    if (widget.photos.isEmpty || _index >= widget.photos.length) return;
    try {
      final name = 'learning_${DateTime.now().millisecondsSinceEpoch}';
      await Gal.putImageBytes(widget.photos[_index], name: name);
      _toast('已保存到相册 ✅');
    } on GalException catch (e) {
      final msg = switch (e.type) {
        GalExceptionType.accessDenied => '保存失败：请在系统设置中允许相册权限',
        GalExceptionType.notEnoughSpace => '保存失败：存储空间不足',
        GalExceptionType.notSupportedFormat => '保存失败：图片格式不支持',
        GalExceptionType.unexpected => '保存失败，请稍后重试',
      };
      _toast(msg);
    } catch (_) {
      _toast('保存失败，请稍后重试');
    }
  }

  void _showSaveSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.download, color: Color(0xFF1E88E5)),
              title: const Text('保存到相册'),
              onTap: () {
                Navigator.pop(ctx);
                _saveCurrent();
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Color(0xFF43A047)),
              title: const Text('分享'),
              onTap: () {
                Navigator.pop(ctx);
                _shareCurrent();
              },
            ),
            ListTile(
              leading: const Icon(Icons.close, color: Colors.grey),
              title: const Text('取消'),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.photos.length;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(
          total > 1 ? '${widget.title} ${_index + 1}/$total' : widget.title,
          style: const TextStyle(fontSize: 16),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            tooltip: '分享',
            onPressed: _shareCurrent,
          ),
          IconButton(
            icon: const Icon(Icons.screen_rotation),
            tooltip: '横竖屏切换',
            onPressed: () =>
                setState(() => _quarterTurns = (_quarterTurns + 1) % 4),
          ),
        ],
      ),
      body: total == 0
          ? const Center(child: CircularProgressIndicator())
          : PageView.builder(
              controller: _controller,
              // 未放大：physics 传 null，交给 PageView 使用「平台原生物理 + 翻页吸附」；
              // 放大后锁定翻页，改为在图片内拖动。
              physics: _zoomed
                  ? const NeverScrollableScrollPhysics()
                  : null,
              // 预构建前后各一页：翻页时图片已解码，滑动更顺滑
              allowImplicitScrolling: true,
              itemCount: total,
              onPageChanged: (i) => setState(() {
                _index = i;
                _zoomed = false;
              }),
              itemBuilder: (_, i) => _PhotoViewItem(
                key: ValueKey<int>(i),
                bytes: widget.photos[i],
                quarterTurns: _quarterTurns,
                active: i == _index,
                onLongPress: _showSaveSheet,
                onZoomChanged: _onZoomChanged,
              ),
            ),
    );
  }
}

/// 单张照片：仅当前页挂 [InteractiveViewer]（可缩放），其余页只渲染静态图片。
class _PhotoViewItem extends StatefulWidget {
  final Uint8List bytes;
  final int quarterTurns;
  final bool active;
  final VoidCallback onLongPress;
  final ValueChanged<bool> onZoomChanged;

  const _PhotoViewItem({
    super.key,
    required this.bytes,
    required this.quarterTurns,
    required this.active,
    required this.onLongPress,
    required this.onZoomChanged,
  });

  @override
  State<_PhotoViewItem> createState() => _PhotoViewItemState();
}

class _PhotoViewItemState extends State<_PhotoViewItem> {
  final TransformationController _transform = TransformationController();
  bool _zoomed = false;

  @override
  void initState() {
    super.initState();
    _transform.addListener(_onTransform);
  }

  @override
  void didUpdateWidget(covariant _PhotoViewItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    // 翻走时复位缩放：避免下次滑回来仍是放大状态，与 PageView 手势互相打架
    if (oldWidget.active && !widget.active && _zoomed) {
      _zoomed = false;
      _transform.value = Matrix4.identity();
    }
  }

  void _onTransform() {
    final zoomed = _transform.value.getMaxScaleOnAxis() > 1.01;
    if (zoomed != _zoomed) {
      setState(() => _zoomed = zoomed);
    }
    widget.onZoomChanged(zoomed);
  }

  @override
  void dispose() {
    _transform.removeListener(_onTransform);
    _transform.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final image = Image.memory(
      widget.bytes,
      fit: BoxFit.contain,
      gaplessPlayback: true,
    );

    // 非当前页：只画静态图片，不参与任何手势，彻底避免与 PageView 争抢左右滑动
    if (!widget.active) {
      return Center(
        child: RotatedBox(quarterTurns: widget.quarterTurns, child: image),
      );
    }

    return GestureDetector(
      onLongPress: widget.onLongPress,
      child: Center(
        child: RotatedBox(
          quarterTurns: widget.quarterTurns,
          child: InteractiveViewer(
            transformationController: _transform,
            // 未放大时不接管拖动 → 左右滑动完全跟手；放大后才允许拖动查看局部
            panEnabled: _zoomed,
            scaleEnabled: true,
            minScale: 1,
            maxScale: 5,
            child: image,
          ),
        ),
      ),
    );
  }
}
