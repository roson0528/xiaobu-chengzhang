import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../services/api_client.dart';
import 'photo_view_page.dart';

/// 一组照片：显示缩略图，点击后进入可左右滑动的全屏查看（连续看图）。
///
/// 性能要点：多张照片**并行**下载，避免一张张排队导致整块区域迟迟不出现。
class PhotoThumbs extends StatefulWidget {
  final List<String> paths;
  final String childId;
  final double size;
  const PhotoThumbs({
    super.key,
    required this.paths,
    required this.childId,
    this.size = 80,
  });

  @override
  State<PhotoThumbs> createState() => _PhotoThumbsState();
}

class _PhotoThumbsState extends State<PhotoThumbs> {
  final List<Uint8List> _bytes = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant PhotoThumbs oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.childId != widget.childId ||
        !listEquals(oldWidget.paths, widget.paths)) {
      _bytes.clear();
      _loading = true;
      _load();
    }
  }

  Future<void> _load() async {
    final loaded = await Future.wait(widget.paths.map((p) async {
      try {
        final b = await ApiClient.instance.getBytes(
          '/submissions/${widget.childId}/photo?path=${Uri.encodeComponent(p)}',
        );
        return Uint8List.fromList(b);
      } catch (_) {
        return null;
      }
    }));
    if (!mounted) return;
    setState(() {
      _bytes
        ..clear()
        ..addAll(loaded.whereType<Uint8List>());
      _loading = false;
    });
  }

  void _open(int index) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PhotoViewPage(
          photos: List.of(_bytes),
          initialIndex: index,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Container(
        width: widget.size,
        height: widget.size,
        color: const Color(0xFFF5F5F5),
        child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    if (_bytes.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (var i = 0; i < _bytes.length; i++)
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GestureDetector(
              onTap: () => _open(i),
              child: Image.memory(
                _bytes[i],
                width: widget.size,
                height: widget.size,
                fit: BoxFit.cover,
                gaplessPlayback: true,
              ),
            ),
          ),
      ],
    );
  }
}
