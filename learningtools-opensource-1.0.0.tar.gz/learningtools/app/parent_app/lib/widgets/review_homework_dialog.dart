import 'package:flutter/material.dart';

/// 审批作业/任务弹窗：评语 + 优秀/良好打分。
/// 通过 Navigator.pop 返回 {status: 'approved'|'rejected', comment, grade}。
class ReviewHomeworkDialog extends StatefulWidget {
  final String dialogTitle;
  final String itemTitle;
  const ReviewHomeworkDialog({
    super.key,
    this.dialogTitle = '审批作业',
    this.itemTitle = '',
  });

  @override
  State<ReviewHomeworkDialog> createState() => _ReviewHomeworkDialogState();
}

class _ReviewHomeworkDialogState extends State<ReviewHomeworkDialog> {
  final _comment = TextEditingController();
  String _grade = 'excellent'; // excellent 优秀 / good 良好

  @override
  void dispose() {
    _comment.dispose();
    super.dispose();
  }

  void _close(String status) {
    Navigator.of(context).pop({
      'status': status,
      'comment': _comment.text.trim(),
      'grade': status == 'approved' ? _grade : null,
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.dialogTitle),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('检查「${widget.itemTitle}」的完成情况：'),
            const SizedBox(height: 12),
            const Text('打分', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('优秀（满分）'),
                  selected: _grade == 'excellent',
                  onSelected: (_) => setState(() => _grade = 'excellent'),
                ),
                ChoiceChip(
                  label: const Text('良好（一半）'),
                  selected: _grade == 'good',
                  onSelected: (_) => setState(() => _grade = 'good'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _comment,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '评语（选填）',
                hintText: '写下对这次作业的评价或鼓励……',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => _close('rejected'), child: const Text('驳回')),
        FilledButton(onPressed: () => _close('approved'), child: const Text('通过')),
      ],
    );
  }
}
