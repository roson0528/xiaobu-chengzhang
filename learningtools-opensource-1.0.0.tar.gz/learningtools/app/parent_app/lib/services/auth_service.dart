import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';
import 'api_client.dart';

/// 家长/管理端认证与账号状态。
class AuthService extends ChangeNotifier {
  AuthService._();

  static final AuthService instance = AuthService._();

  static const _kAccessToken = 'access_token';
  static const _kRefreshToken = 'refresh_token';
  static const _kUser = 'user_json';

  UserInfo? _user;
  String _accessToken = '';
  String _refreshToken = '';
  bool _initialized = false;

  UserInfo? get user => _user;
  String get accessToken => _accessToken;
  String get refreshToken => _refreshToken;
  bool get isLoggedIn => _user != null && _accessToken.isNotEmpty;
  bool get initialized => _initialized;
  bool get isAdmin =>
      _user?.role == 'super_admin' || _user?.role == 'family_admin';

  /// 供 WebView 注入到网页 localStorage 的用户 JSON。
  String get webUserJson => jsonEncode({
        'id': _user?.id,
        'username': _user?.username,
        'role': _user?.role,
        'status': _user?.status,
      });

  Future<void> init() async {
    ApiClient.instance.onAuthFailed = logoutSilently;
    // 自动刷新后同步内存态 access_token，确保 WebView 注入的是最新 token
    ApiClient.instance.onTokenRefreshed = (token) {
      _accessToken = token;
    };
    final prefs = await SharedPreferences.getInstance();
    _accessToken = prefs.getString(_kAccessToken) ?? '';
    _refreshToken = prefs.getString(_kRefreshToken) ?? '';
    final userJson = prefs.getString(_kUser);
    if (userJson != null && userJson.isNotEmpty) {
      try {
        _user = UserInfo.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
      } catch (_) {
        _user = null;
      }
    }
    _initialized = true;
    notifyListeners();
  }

  Future<UserInfo> login(String username, String password) async {
    final data = await ApiClient.instance.postJson('/auth/login', {
      'username': username,
      'password': password,
    }) as Map<String, dynamic>;

    _accessToken = data['access_token']?.toString() ?? '';
    _refreshToken = data['refresh_token']?.toString() ?? '';
    _user = UserInfo.fromJson((data['user'] as Map?)?.cast<String, dynamic>() ?? const {});

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAccessToken, _accessToken);
    await prefs.setString(_kRefreshToken, _refreshToken);
    await prefs.setString(_kUser, jsonEncode({
          'id': _user!.id,
          'username': _user!.username,
          'nickname': _user!.nickname,
          'role': _user!.role,
          'status': _user!.status,
        }));
    ApiClient.instance.updateAuthHeader(_accessToken);
    notifyListeners();
    return _user!;
  }

  /// 从服务端刷新当前账号信息（昵称等）。
  Future<void> refreshMe() async {
    try {
      final data = await ApiClient.instance.getJson('/auth/me') as Map<String, dynamic>;
      _user = UserInfo.fromJson(data);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kUser, jsonEncode({
            'id': _user!.id,
            'username': _user!.username,
            'nickname': _user!.nickname,
            'role': _user!.role,
            'status': _user!.status,
          }));
      notifyListeners();
    } catch (_) {}
  }

  /// 拉取当前账号可访问的孩子列表（聊天用）。
  Future<List<ChildProfile>> loadChildren() async {
    try {
      final data = await ApiClient.instance.getJson('/children') as List?;
      if (data == null) return const [];
      return data
          .map((e) => ChildProfile.fromJson((e as Map).cast<String, dynamic>()))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  bool autoLogin() => isLoggedIn;

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kAccessToken);
    await prefs.remove(_kRefreshToken);
    await prefs.remove(_kUser);
    _accessToken = '';
    _refreshToken = '';
    _user = null;
    ApiClient.instance.updateAuthHeader(null);
    notifyListeners();
  }

  Future<void> logoutSilently() async => logout();
}
