import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';

class ApiException implements Exception {
  final int? statusCode;
  final String message;

  const ApiException(this.statusCode, this.message);

  bool get isNetworkError => statusCode == null;

  @override
  String toString() => message;
}

/// Dio 封装：自动带 token、401 时刷新并重试一次、网络失败抛 ApiException。
class ApiClient {
  ApiClient._();

  static final ApiClient instance = ApiClient._();

  late final Dio _dio;
  final _lock = <String, Completer<String?>>{};

  void Function()? onAuthFailed;

  /// 401 自动刷新出新 access_token 后回调，供 AuthService 同步内存态（供 WebView 注入使用）。
  void Function(String newToken)? onTokenRefreshed;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    _dio = Dio(
      BaseOptions(
        baseUrl: AppConfig.apiBaseUrl,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 30),
        sendTimeout: const Duration(seconds: 60),
        headers: {
          if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
        },
      ),
    );
    _dio.interceptors.add(InterceptorsWrapper(
      onError: (e, handler) async {
        if (e.response?.statusCode == 401 && e.requestOptions.extra['retried'] != true) {
          final refreshed = await _tryRefreshToken();
          if (refreshed != null) {
            e.requestOptions.headers['Authorization'] = 'Bearer $refreshed';
            e.requestOptions.extra['retried'] = true;
            try {
              final res = await _dio.fetch(e.requestOptions);
              return handler.resolve(res);
            } catch (err) {
              return handler.next(err as DioException);
            }
          }
          onAuthFailed?.call();
        }
        handler.next(e);
      },
    ));
  }

  Future<String?> _tryRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    final refreshToken = prefs.getString('refresh_token');
    if (refreshToken == null || refreshToken.isEmpty) return null;

    final inflight = _lock[refreshToken];
    if (inflight != null) return inflight.future;

    final completer = Completer<String?>();
    _lock[refreshToken] = completer;
    try {
      final res = await Dio(
        BaseOptions(baseUrl: AppConfig.apiBaseUrl, connectTimeout: const Duration(seconds: 15)),
      ).post('/auth/refresh', data: {'refresh_token': refreshToken});
      final token = res.data?['access_token']?.toString();
      if (token != null && token.isNotEmpty) {
        await prefs.setString('access_token', token);
        _dio.options.headers['Authorization'] = 'Bearer $token';
        onTokenRefreshed?.call(token);
        completer.complete(token);
      } else {
        completer.complete(null);
      }
    } catch (_) {
      completer.complete(null);
    } finally {
      _lock.remove(refreshToken);
    }
    return completer.future;
  }

  String? get _token =>
      (_dio.options.headers['Authorization'] as String?)?.replaceFirst('Bearer ', '');

  void updateAuthHeader(String? token) {
    if (token == null || token.isEmpty) {
      _dio.options.headers.remove('Authorization');
    } else {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    }
  }

  Options _authOptions() => Options(
        headers: {'Authorization': 'Bearer $_token'},
        extra: {'retried': false},
      );

  Future<dynamic> getJson(String path, {Map<String, dynamic>? query}) async {
    try {
      final res = await _dio.get(path, queryParameters: query, options: _authOptions());
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> postJson(String path, Map<String, dynamic> body) async {
    try {
      final res = await _dio.post(
        path,
        data: body,
        options: _authOptions()..contentType = Headers.jsonContentType,
      );
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> deleteJson(String path) async {
    try {
      final res = await _dio.delete(path, options: _authOptions());
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> postForm(String path, Map<String, dynamic> fields) async {
    try {
      final form = FormData.fromMap(fields);
      final res = await _dio.post(path, data: form, options: _authOptions());
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> putJson(String path, Map<String, dynamic> body) async {
    try {
      final res = await _dio.put(
        path,
        data: body,
        options: _authOptions()..contentType = Headers.jsonContentType,
      );
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> delete(String path) async {
    try {
      final res = await _dio.delete(path, options: _authOptions());
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<List<int>> getBytes(String path) async {
    try {
      final res = await _dio.get<List<int>>(
        path,
        options: _authOptions()..responseType = ResponseType.bytes,
      );
      return res.data ?? const [];
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  Future<dynamic> uploadFile(String path, File file, Map<String, dynamic> fields) async {
    try {
      final form = FormData.fromMap({
        ...fields,
        'file': await MultipartFile.fromFile(file.path, filename: file.uri.pathSegments.last),
      });
      final res = await _dio.post(path, data: form, options: _authOptions());
      return res.data;
    } on DioException catch (e) {
      throw _wrap(e);
    }
  }

  ApiException _wrap(DioException e) {
    if (e.type == DioExceptionType.connectionError ||
        e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      return const ApiException(null, '网络连接失败，请检查网络后重试');
    }
    final data = e.response?.data;
    String msg = '请求失败';
    if (data is Map && data['detail'] != null) {
      final d = data['detail'];
      msg = d is String ? d : d.toString();
    } else if (data is String && data.isNotEmpty) {
      msg = data;
    } else {
      msg = e.message ?? '请求失败';
    }
    return ApiException(e.response?.statusCode, msg);
  }
}
