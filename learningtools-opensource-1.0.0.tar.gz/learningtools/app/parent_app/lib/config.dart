/// 家长/管理端全局配置。
class AppConfig {
  AppConfig._();

  /// 固定后端地址（HTTPS）。
  static const String apiBaseUrl = 'https://YOUR_DOMAIN:51666/api/v1';

  /// 网页管理端地址（WebView 内嵌，直接进入 dashboard，不经首页展示页）。
  static const String webAdminUrl = 'https://YOUR_DOMAIN:51666/dashboard';

  /// 家长端 App 版本号（正式版 V3.4）。
  static const String appVersion = '3.11';

  static Future<void> load() async {}
}
