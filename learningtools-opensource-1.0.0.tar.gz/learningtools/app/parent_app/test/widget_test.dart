import 'package:flutter_test/flutter_test.dart';

import 'package:learning_parent/config.dart';

void main() {
  test('版本号与后端地址固定', () {
    expect(AppConfig.appVersion, '0.91');
    expect(AppConfig.apiBaseUrl, 'http://localhost/api/v1');
  });
}
