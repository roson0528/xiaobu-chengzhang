import 'dart:io';

import 'api_client.dart';
import 'sync_service.dart';

/// 提交辅助：统一处理「先传照片 → 再提交记录 → 失败入队」的流程。
///
/// 返回提交结果描述，供页面提示：
/// - 'ok'：已提交到服务器
/// - 'queued'：离线，已进入本地队列，联网后自动同步
class SubmitHelper {
  SubmitHelper._();

  /// 尝试上传照片（/submissions/{childId}/photo，打卡/任务提交照片专用，不进入专注监控）。
  /// 成功返回服务器路径；离线入队并返回 'local://<本地路径>'；失败抛异常。
  static Future<String?> uploadPhoto(
    File file, {
    required String childId,
  }) async {
    final timestamp = DateTime.now().toIso8601String();
    try {
      final res = await ApiClient.instance.uploadFile('/submissions/$childId/photo', file, {
        'timestamp': timestamp,
      });
      return res['path']?.toString();
    } on ApiException catch (e) {
      if (e.isNetworkError) {
        await SyncService.instance.enqueuePhotoUpload(
          filePath: file.path,
          fields: {'child_id': childId},
        );
        return 'local://${file.path}';
      }
      rethrow;
    }
  }

  /// 提交打卡/运动/阅读/错题记录：
  /// 在线直接 POST；离线入队为 /sync/push 记录，联网后重放。
  static Future<String> submitRecord({
    required String url,
    required String entityType,
    required Map<String, dynamic> body,
  }) async {
    try {
      await ApiClient.instance.postJson(url, body);
      return 'ok';
    } on ApiException catch (e) {
      if (e.isNetworkError) {
        await SyncService.instance.enqueuePushRecord(
          entityType: entityType,
          payload: body,
        );
        return 'queued';
      }
      rethrow;
    }
  }
}
