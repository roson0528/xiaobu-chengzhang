import 'dart:async';

import 'package:shared_preferences/shared_preferences.dart';

import 'api_client.dart';
import 'notification_service.dart';

/// 任务/作业事件通知轮询：定时拉取未读通知，发现新通知时弹系统本地通知。
/// 后端在孩子提交任务/作业、家长布置作业、家长驳回时写入 notifications 表，
/// 两端 App 各轮询属于自己的通知（家长收提交提醒、孩子收布置/驳回提醒）。
class EventNotifier {
  EventNotifier._();

  static final EventNotifier instance = EventNotifier._();

  static const _prefsKey = 'event_seen_max_id_v1';

  Timer? _timer;
  int _lastSeenId = 0;
  bool _bootstrapped = false;

  void start() {
    if (_timer != null) return;
    NotificationService.instance.requestPermission();
    _bootstrap();
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _bootstrap() async {
    await _loadSeen();
    await _poll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _poll());
  }

  Future<void> _loadSeen() async {
    try {
      final sp = await SharedPreferences.getInstance();
      _lastSeenId = sp.getInt(_prefsKey) ?? 0;
      _bootstrapped = _lastSeenId > 0;
    } catch (_) {
      _bootstrapped = false;
    }
  }

  Future<void> _saveSeen() async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setInt(_prefsKey, _lastSeenId);
    } catch (_) {}
  }

  Future<void> _poll() async {
    try {
      final data = await ApiClient.instance.getJson('/notifications?unread_only=true');
      final items = (data as List)
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList();
      if (items.isEmpty) return;

      int maxId = 0;
      for (final it in items) {
        final id = _idOf(it);
        if (id > maxId) maxId = id;
      }

      if (!_bootstrapped) {
        // 首次安装：只记录基线，不弹历史通知
        _lastSeenId = maxId;
        _bootstrapped = true;
        await _saveSeen();
        return;
      }

      for (final it in items) {
        final id = _idOf(it);
        if (id <= _lastSeenId) continue;
        final title = it['title']?.toString() ?? '新通知';
        final content = it['content']?.toString() ?? '';
        await NotificationService.instance.show(
          id: id & 0x7fffffff,
          title: title,
          body: content,
        );
      }
      _lastSeenId = maxId;
      await _saveSeen();
    } catch (_) {
      // 网络异常忽略，下轮再试
    }
  }

  int _idOf(Map<String, dynamic> it) {
    final raw = it['id'];
    if (raw is int) return raw;
    return int.tryParse('$raw') ?? 0;
  }
}
