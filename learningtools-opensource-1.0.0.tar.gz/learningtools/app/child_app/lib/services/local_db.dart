import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// 本地 SQLite 数据库：
/// - sync_queue：离线提交队列（网络失败时入队，联网后重放，重试上限见 AppConfig.maxSyncRetries）
/// - cache：GET 快照缓存（/sync/pull 拉取后落盘，离线可读）
class LocalDb {
  LocalDb._();

  static final LocalDb instance = LocalDb._();

  static const _dbName = 'learning_app.db';
  static const _dbVersion = 1;
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(
      p.join(dir, _dbName),
      version: _dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE sync_queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            kind TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            url TEXT,
            payload TEXT,
            attempts INTEGER DEFAULT 0,
            created_at TEXT,
            status TEXT DEFAULT 'pending'
          )
        ''');
        await db.execute('''
          CREATE TABLE cache (
            key TEXT PRIMARY KEY,
            value TEXT,
            updated_at TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  // ---------------- 离线队列 ----------------

  Future<int> enqueue({
    required String kind,
    required String entityType,
    String? entityId,
    String? url,
    Map<String, dynamic>? payload,
  }) async {
    final db = await database;
    return db.insert('sync_queue', {
      'kind': kind,
      'entity_type': entityType,
      'entity_id': entityId,
      'url': url,
      'payload': payload == null ? null : jsonEncode(payload),
      'attempts': 0,
      'created_at': DateTime.now().toIso8601String(),
      'status': 'pending',
    });
  }

  Future<List<Map<String, dynamic>>> pendingItems() async {
    final db = await database;
    return db.query('sync_queue', where: "status = 'pending'", orderBy: 'id ASC');
  }

  Future<List<Map<String, dynamic>>> allItems() async {
    final db = await database;
    return db.query('sync_queue', orderBy: 'id DESC', limit: 50);
  }

  Future<void> markDone(int id) async {
    final db = await database;
    await db.update('sync_queue', {'status': 'done'}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> markFailed(int id) async {
    final db = await database;
    await db.update('sync_queue', {'status': 'failed'}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> bumpAttempts(int id, int attempts) async {
    final db = await database;
    await db.update('sync_queue', {'attempts': attempts}, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> pendingCount() async {
    final db = await database;
    final rows = await db.rawQuery("SELECT COUNT(*) AS c FROM sync_queue WHERE status = 'pending'");
    return (rows.first['c'] as num?)?.toInt() ?? 0;
  }

  // ---------------- 快照缓存 ----------------

  Future<void> putCache(String key, dynamic value) async {
    final db = await database;
    await db.insert(
      'cache',
      {
        'key': key,
        'value': jsonEncode(value),
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<Map<String, dynamic>?> getCache(String key) async {
    final db = await database;
    final rows = await db.query('cache', where: 'key = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    try {
      return jsonDecode(rows.first['value'] as String) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}