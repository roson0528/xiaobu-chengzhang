import 'dart:convert';
import 'dart:io';

import '../config.dart';
import '../models/models.dart';
import 'api_client.dart';
import 'auth_service.dart';
import 'local_db.dart';

/// 离线优先同步：
/// - 提交类操作（打卡/运动/阅读/错题）入队为 /sync/push 记录；
/// - 其他 POST（任务完成/跳过、发消息、专注事件）入队为直接端点重放；
/// - 照片入队为 multipart 上传重放；
/// - 网络失败时全部入队，联网后按序重放，单条重试 ≤ [AppConfig.maxSyncRetries] 次。
class SyncService {
  SyncService._();

  static final SyncService instance = SyncService._();

  bool _processing = false;

  // ---------- 入队 ----------

  /// 提交类操作（后端 /sync/push 支持 checkin/fitness/reading/mistake）。
  Future<int> enqueuePushRecord({
    required String entityType,
    required Map<String, dynamic> payload,
    String? entityId,
  }) {
    final id = entityId ?? 'local_${DateTime.now().millisecondsSinceEpoch}';
    return LocalDb.instance.enqueue(
      kind: 'push_record',
      entityType: entityType,
      entityId: id,
      payload: {
        'entity_type': entityType,
        'entity_id': id,
        'payload': payload,
      },
    );
  }

  /// 直接端点重放（task complete/skip、message send、focus event 等）。
  Future<int> enqueueJsonPost({
    required String url,
    required Map<String, dynamic> body,
    required String entityType,
    String? entityId,
  }) {
    return LocalDb.instance.enqueue(
      kind: 'json_post',
      entityType: entityType,
      entityId: entityId,
      url: url,
      payload: body,
    );
  }

  /// multipart 照片上传重放。
  Future<int> enqueuePhotoUpload({
    required String filePath,
    required Map<String, dynamic> fields,
  }) {
    return LocalDb.instance.enqueue(
      kind: 'photo_upload',
      entityType: 'photo',
      entityId: 'photo_${DateTime.now().millisecondsSinceEpoch}',
      payload: {'file_path': filePath, 'fields': fields},
    );
  }

  // ---------- 重放 ----------

  Future<void> processQueue() async {
    if (_processing) return;
    _processing = true;
    try {
      final items = await LocalDb.instance.pendingItems();
      for (final item in items) {
        final id = item['id'] as int;
        final attempts = (item['attempts'] as num?)?.toInt() ?? 0;
        final ok = await _replay(item);
        if (ok) {
          await LocalDb.instance.markDone(id);
        } else {
          final next = attempts + 1;
          if (next >= AppConfig.maxSyncRetries) {
            await LocalDb.instance.markFailed(id);
          } else {
            await LocalDb.instance.bumpAttempts(id, next);
          }
        }
      }
    } finally {
      _processing = false;
    }
  }

  Future<bool> _replay(Map<String, dynamic> item) async {
    final kind = item['kind'] as String? ?? '';
    try {
      switch (kind) {
        case 'push_record':
          await _replayPushRecord(item);
          return true;
        case 'json_post':
          await _replayJsonPost(item);
          return true;
        case 'photo_upload':
          await _replayPhotoUpload(item);
          return true;
        default:
          return false;
      }
    } catch (_) {
      return false;
    }
  }

  Future<void> _replayPushRecord(Map<String, dynamic> item) async {
    final childId = AuthService.instance.child?.id ?? '';
    if (childId.isEmpty) throw const ApiException(null, '未关联孩子档案');
    final payload = jsonDecode(item['payload'] as String? ?? '{}') as Map<String, dynamic>;
    await ApiClient.instance.postJson('/sync/push?child_id=$childId', {
      'records': [payload],
    });
  }

  Future<void> _replayJsonPost(Map<String, dynamic> item) async {
    final url = item['url'] as String? ?? '';
    final payload = jsonDecode(item['payload'] as String? ?? '{}') as Map<String, dynamic>;
    if (payload.containsKey('_form')) {
      final fields = Map<String, dynamic>.from(payload['_form'] as Map);
      await ApiClient.instance.postForm(url, fields);
    } else {
      await ApiClient.instance.postJson(url, payload);
    }
  }

  Future<void> _replayPhotoUpload(Map<String, dynamic> item) async {
    final payload = jsonDecode(item['payload'] as String? ?? '{}') as Map<String, dynamic>;
    final filePath = payload['file_path'] as String? ?? '';
    final fields = Map<String, dynamic>.from(payload['fields'] as Map? ?? {});
    final childId = fields['child_id']?.toString() ?? AuthService.instance.child?.id ?? '';
    if (childId.isEmpty) throw const ApiException(null, '未关联孩子档案');
    final file = File(filePath);
    if (!await file.exists()) throw const ApiException(null, '本地照片不存在');
    await ApiClient.instance.uploadFile('/submissions/$childId/photo', file, fields);
  }

  // ---------- 快照 ----------

  /// 拉取 /sync/pull 快照并缓存到本地。
  Future<SyncSnapshot> pullSnapshot({bool force = false}) async {
    final childId = AuthService.instance.child?.id ?? '';
    if (childId.isEmpty) throw const ApiException(null, '未关联孩子档案');
    try {
      final data = await ApiClient.instance
          .getJson('/sync/pull', query: {'child_id': childId}) as Map<String, dynamic>;
      await LocalDb.instance.putCache('snapshot', data);
      return SyncSnapshot.fromJson(data);
    } catch (_) {
      final cached = await LocalDb.instance.getCache('snapshot');
      if (cached != null) return SyncSnapshot.fromJson(cached);
      rethrow;
    }
  }

  /// 读取本地快照缓存（离线可用）。
  Future<SyncSnapshot?> cachedSnapshot() async {
    final cached = await LocalDb.instance.getCache('snapshot');
    if (cached == null) return null;
    return SyncSnapshot.fromJson(cached);
  }

  Future<int> pendingCount() => LocalDb.instance.pendingCount();
}
