import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';
import 'api_client.dart';

/// 认证与账号状态：登录、记住登录态、自动登录、退出。
class AuthService extends ChangeNotifier {
  AuthService._();

  static final AuthService instance = AuthService._();

  static const _kAccessToken = 'access_token';
  static const _kRefreshToken = 'refresh_token';
  static const _kUser = 'user_json';
  static const _kChild = 'child_json';

  UserInfo? _user;
  ChildProfile? _child;
  bool _initialized = false;

  UserInfo? get user => _user;
  ChildProfile? get child => _child;
  bool get isLoggedIn => _user != null && (_accessToken?.isNotEmpty ?? false);
  bool get initialized => _initialized;

  String? get _accessToken => _user == null ? null : _storedAccessToken;

  String? _storedAccessToken = '';

  Future<void> init() async {
    ApiClient.instance.onAuthFailed = logoutSilently;
    final prefs = await SharedPreferences.getInstance();
    _storedAccessToken = prefs.getString(_kAccessToken) ?? '';
    final userJson = prefs.getString(_kUser);
    if (userJson != null && userJson.isNotEmpty) {
      try {
        _user = UserInfo.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
      } catch (_) {
        _user = null;
      }
    }
    final childJson = prefs.getString(_kChild);
    if (childJson != null && childJson.isNotEmpty) {
      try {
        _child = ChildProfile.fromJson(jsonDecode(childJson) as Map<String, dynamic>);
      } catch (_) {
        _child = null;
      }
    }
    _initialized = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAccessToken, _storedAccessToken ?? '');
    if (_user != null) {
      await prefs.setString(_kUser, jsonEncode({
            'id': _user!.id,
            'username': _user!.username,
            'role': _user!.role,
            'status': _user!.status,
          }));
    }
    if (_child != null) {
      await prefs.setString(_kChild, jsonEncode({
            'id': _child!.id,
            'name': _child!.name,
            'grade': _child!.grade,
            'avatar': _child!.avatar,
          }));
    }
  }

  /// 登录并保存登录态。
  Future<UserInfo> login(String username, String password) async {
    final data = await ApiClient.instance.postJson('/auth/login', {
      'username': username,
      'password': password,
    }) as Map<String, dynamic>;

    _storedAccessToken = data['access_token']?.toString() ?? '';
    final refreshToken = data['refresh_token']?.toString() ?? '';
    _user = UserInfo.fromJson((data['user'] as Map?)?.cast<String, dynamic>() ?? const {});

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kAccessToken, _storedAccessToken ?? '');
    await prefs.setString(_kRefreshToken, refreshToken);
    await prefs.setString(_kUser, jsonEncode({
          'id': _user!.id,
          'username': _user!.username,
          'role': _user!.role,
          'status': _user!.status,
        }));
    ApiClient.instance.updateAuthHeader(_storedAccessToken);

    // 孩子账号：获取自己的档案作为 child_id（登录后必需）
    await loadChildProfile();
    notifyListeners();
    return _user!;
  }

  /// 拉取当前账号的孩子档案（孩子账号取第一条）。
  Future<ChildProfile?> loadChildProfile() async {
    try {
      final data = await ApiClient.instance.getJson('/children') as List?;
      if (data == null || data.isEmpty) return null;
      final first = (data.first as Map).cast<String, dynamic>();
      _child = ChildProfile.fromJson(first);
      await _persist();
      notifyListeners();
      return _child;
    } catch (_) {
      // 网络失败时使用本地缓存的档案
      return _child;
    }
  }

  /// 自动登录：本地有登录态即视为已登录（真正的鉴权由请求时 401 刷新兜底）。
  bool autoLogin() => isLoggedIn;

  /// 退出登录：清空本地登录态。
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kAccessToken);
    await prefs.remove(_kRefreshToken);
    await prefs.remove(_kUser);
    await prefs.remove(_kChild);
    _storedAccessToken = '';
    _user = null;
    _child = null;
    notifyListeners();
  }

  /// 401 刷新失败时的静默登出。
  Future<void> logoutSilently() async {
    await logout();
  }
}
