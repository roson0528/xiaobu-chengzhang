import 'package:flutter_foreground_task/flutter_foreground_task.dart';

/// 专注模式前台服务任务：负责在后台持续显示「专注中」通知。
///
/// 主界面通过 `FlutterForegroundTask.sendDataToTask('tick:<剩余秒数>')`
/// 更新通知内容；倒计时结束由主界面处理（发通知提醒并上报结束）。
@pragma('vm:entry-point')
void focusStartCallback() {
  FlutterForegroundTask.setTaskHandler(FocusTaskHandler());
}

class FocusTaskHandler extends TaskHandler {
  int _remaining = 0;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    await _updateNotification();
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    if (_remaining > 0) _remaining--;
    _updateNotification();
  }

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}

  @override
  void onReceiveData(Object data) {
    if (data is String && data.startsWith('tick:')) {
      final v = int.tryParse(data.substring(5));
      if (v != null && v >= 0) {
        _remaining = v;
        _updateNotification();
      }
    }
  }

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {}

  @override
  void onNotificationDismissed() {}

  Future<void> _updateNotification() async {
    final mm = (_remaining ~/ 60).toString().padLeft(2, '0');
    final ss = (_remaining % 60).toString().padLeft(2, '0');
    await FlutterForegroundTask.updateService(
      notificationTitle: '专注中 · $mm:$ss',
      notificationText: '屏幕已保持常亮，好好写作业吧！',
    );
  }
}
