import 'package:flutter/foundation.dart';

/// 专注模式的全局运行状态，供 MainShell 拦截底部导航切换。
/// FocusSessionView 在开始/结束时更新 [running]，并注册 [onStopRequested] 供外部触发停止。
class FocusState {
  FocusState._();

  static final ValueNotifier<bool> running = ValueNotifier<bool>(false);

  /// 由 FocusSessionView 注册：调用即结束当前专注。
  static void Function()? onStopRequested;

  static void requestStop() => onStopRequested?.call();
}
