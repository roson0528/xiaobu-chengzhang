import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api_client.dart';
import 'notification_service.dart';

/// 聊天消息轮询：定时拉取每个会话的最新消息，发现「非本人」新消息时：
/// 1) 弹系统本地通知；2) 累加未读数，供底部标签显示红点角标。
class ChatNotifier {
  ChatNotifier._();

  static final ChatNotifier instance = ChatNotifier._();

  static const _prefsKey = 'chat_seen_ids_v1';

  Timer? _timer;
  int _myUserId = 0;
  bool _hadSavedSeen = false;
  final Map<String, String> _seenByKey = {}; // 会话 key -> 已见的最新消息 id
  final Set<String> _unreadKeys = {}; // 有未读的会话 key

  /// 总未读数（绑定到底部「聊天」标签角标）。
  final ValueNotifier<int> unread = ValueNotifier<int>(0);

  /// 未读会话 key 集合（用于会话列表里显示未读小红点）。
  final ValueNotifier<Set<String>> unreadKeys = ValueNotifier<Set<String>>({});

  void start(int myUserId) {
    _myUserId = myUserId;
    if (_timer != null) return;
    NotificationService.instance.requestPermission();
    _bootstrap();
  }

  Future<void> _bootstrap() async {
    await _loadSeen();
    await _poll();
    _timer = Timer.periodic(const Duration(seconds: 20), (_) => _poll());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _loadSeen() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_prefsKey);
      if (raw != null && raw.isNotEmpty) {
        final map = jsonDecode(raw) as Map<String, dynamic>;
        _seenByKey
          ..clear()
          ..addAll(map.map((k, v) => MapEntry(k, v.toString())));
        _hadSavedSeen = true;
      }
    } catch (_) {
      _hadSavedSeen = false;
    }
  }

  Future<void> _saveSeen() async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_prefsKey, jsonEncode(_seenByKey));
    } catch (_) {}
  }

  Future<void> _poll() async {
    try {
      final data = await ApiClient.instance.getJson('/notifications/chat-unread') as Map<String, dynamic>;
      final items = ((data['items'] as List?) ?? const [])
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList();

      if (!_hadSavedSeen) {
        // 首次安装：只记录基线，不弹历史通知、不计未读
        for (final it in items) {
          final key = it['key']?.toString() ?? '';
          final id = it['latest_id']?.toString() ?? '';
          if (key.isNotEmpty) _seenByKey[key] = id;
        }
        _hadSavedSeen = true;
        await _saveSeen();
        return;
      }

      for (final it in items) {
        final key = it['key']?.toString() ?? '';
        final latestId = it['latest_id']?.toString() ?? '';
        if (key.isEmpty || latestId.isEmpty) continue;
        final seen = _seenByKey[key];
        if (seen != null && seen != latestId) {
          final raw = it['sender_id'];
          final senderId = raw is int ? raw : int.tryParse('$raw');
          if (senderId != _myUserId) {
            _unreadKeys.add(key);
            final title = it['title']?.toString() ?? '新消息';
            final name = it['sender_name']?.toString() ?? '';
            final preview = it['preview']?.toString() ?? '';
            final body = name.isEmpty ? preview : '$name：$preview';
            if (body.isNotEmpty) {
              await NotificationService.instance.show(
                id: (latestId.hashCode & 0x7fffffff),
                title: '💬 $title',
                body: body,
              );
            }
          }
        }
        _seenByKey[key] = latestId;
      }
      _recomputeUnread();
      await _saveSeen();
    } catch (_) {
      // 网络异常忽略，下轮再试
    }
  }

  void _recomputeUnread() {
    unread.value = _unreadKeys.length;
    unreadKeys.value = Set.of(_unreadKeys);
  }

  /// 打开某个会话后调用，清除该会话未读。
  void markRead(String key) {
    if (_unreadKeys.remove(key)) _recomputeUnread();
  }

  /// 清除全部未读。
  void markAllRead() {
    if (_unreadKeys.isEmpty) return;
    _unreadKeys.clear();
    _recomputeUnread();
  }
}
