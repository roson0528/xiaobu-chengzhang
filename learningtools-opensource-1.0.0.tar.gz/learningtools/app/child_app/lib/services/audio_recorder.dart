import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

/// 朗读打卡录音服务（record 包封装，Android 输出 m4a/AAC）。
class AudioRecorderService {
  AudioRecorderService._();

  static final AudioRecorderService instance = AudioRecorderService._();

  final AudioRecorder _recorder = AudioRecorder();
  String? _currentPath;

  bool get isRecording => _currentPath != null;

  Future<bool> ensurePermission() => _recorder.hasPermission();

  /// 开始录音，返回录音文件路径。
  Future<String> start() async {
    if (_currentPath != null) return _currentPath!;
    final dir = await getApplicationDocumentsDirectory();
    final audioDir = Directory(p.join(dir.path, 'audio'));
    if (!await audioDir.exists()) await audioDir.create(recursive: true);
    final path = p.join(audioDir.path, 'rec_${DateTime.now().millisecondsSinceEpoch}.m4a');
    await _recorder.start(const RecordConfig(), path: path);
    _currentPath = path;
    return path;
  }

  /// 停止录音，返回文件路径（失败返回 null）。
  Future<String?> stop() async {
    if (_currentPath == null) return null;
    final path = await _recorder.stop();
    _currentPath = null;
    return path;
  }

  /// 取消录音并删除文件。
  Future<void> cancel() async {
    if (_currentPath == null) return;
    await _recorder.cancel();
    final f = File(_currentPath!);
    _currentPath = null;
    try {
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }
}
