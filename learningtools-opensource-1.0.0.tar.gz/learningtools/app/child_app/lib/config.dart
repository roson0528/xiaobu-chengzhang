/// 全局配置。
///
/// 后端地址固定为公网地址，不提供用户可改的入口。
class AppConfig {
  AppConfig._();

  /// 固定后端地址（不可修改，HTTPS）。
  static const String apiBaseUrl = 'https://YOUR_DOMAIN:51666/api/v1';

  /// App 版本号（正式版 V3.5）。「检查升级」时与后端 /app/latest 返回的版本比较。
  static const String appVersion = '3.6';

  /// 是否为「学习专用版」（平板变体）。
  ///
  /// 构建时通过 `--dart-define=LT_TABLET=true` 打开；
  /// 打开后 App 一启动就自动进入专注模式（专注模式 = 放开该平板上网权限）。
  static const bool tabletMode =
      bool.fromEnvironment('LT_TABLET', defaultValue: false);

  /// 学习专用版自动进入专注模式时的默认时长（分钟）。
  static const int tabletFocusMinutes =
      int.fromEnvironment('LT_FOCUS_MINUTES', defaultValue: 45);

  /// 专注模式期间向后端续期心跳的间隔（分钟）。
  ///
  /// 后端每次心跳会把上网放行窗口顺延 [netHeartbeatGraceMinutes] 分钟，
  /// 因此即使 App 被强杀，最迟也会在该宽限期后自动收回上网权限。
  static const int focusHeartbeatMinutes = 5;

  /// 专注模式：定时拍照间隔（秒）。
  static const int focusPhotoIntervalSeconds = 60;

  /// 专注模式默认时长（分钟）。
  static const int defaultFocusMinutes = 25;

  /// 离线队列重试上限。
  static const int maxSyncRetries = 5;

  /// 兼容旧调用：地址固定，无需从本地读取。
  static Future<void> load() async {}
}
