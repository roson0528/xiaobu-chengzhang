import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:provider/provider.dart';

import 'config.dart';
import 'pages/login_page.dart';
import 'pages/main_shell.dart';
import 'services/api_client.dart';
import 'services/auth_service.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 前台服务与 UI 通信端口
  FlutterForegroundTask.initCommunicationPort();

  // 加载配置与初始化服务
  await AppConfig.load();
  await ApiClient.instance.init();
  await AuthService.instance.init();
  await NotificationService.instance.init();

  runApp(const LearningApp());
}

class LearningApp extends StatelessWidget {
  const LearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: AuthService.instance,
      child: MaterialApp(
        title: '小步成长',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFFF7043),
            brightness: Brightness.light,
          ),
          scaffoldBackgroundColor: const Color(0xFFFFF8F0),
        ),
        home: const _Root(),
      ),
    );
  }
}

/// 根据登录态决定首页（记住登录态，自动登录）。
class _Root extends StatelessWidget {
  const _Root();

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    if (!auth.initialized) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return auth.autoLogin() ? const MainShell() : const LoginPage();
  }
}
