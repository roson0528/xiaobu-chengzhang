/// 简单数据模型（与后端 /api/v1 返回结构对应，均为宽松解析）。
library;

class UserInfo {
  final int id;
  final String username;
  final String role;
  final String status;

  const UserInfo({
    required this.id,
    required this.username,
    required this.role,
    required this.status,
  });

  factory UserInfo.fromJson(Map<String, dynamic> json) => UserInfo(
        id: json['id'] is int ? json['id'] as int : int.tryParse('${json['id']}') ?? 0,
        username: json['username']?.toString() ?? '',
        role: json['role']?.toString() ?? '',
        status: json['status']?.toString() ?? '',
      );
}

/// 孩子档案（GET /children 返回的第一条，或 /sync/pull 中的 child）。
class ChildProfile {
  final String id;
  final String name;
  final int grade;
  final String avatar;

  const ChildProfile({
    required this.id,
    required this.name,
    required this.grade,
    required this.avatar,
  });

  factory ChildProfile.fromJson(Map<String, dynamic> json) => ChildProfile(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        grade: json['grade'] is int ? json['grade'] as int : int.tryParse('${json['grade'] ?? ''}') ?? 0,
        avatar: json['avatar']?.toString() ?? '',
      );
}

/// 今日任务卡片。
/// 假期作业已提交的日期（升序去重）。服务端按天记录，每天只保留一条。
List<String> _submissionDays(Object? raw) {
  if (raw is! List) return const [];
  final days = <String>{
    for (final e in raw.whereType<Map>())
      if ((e['date'] ?? '').toString().isNotEmpty) e['date'].toString(),
  }.toList();
  days.sort();
  return days;
}

class TaskItem {
  final String id;
  final String title;
  final String subject;
  final String taskType;
  final String plannedDate;
  final String plannedStart;
  final int plannedDuration;
  final int priority;
  final String difficulty;
  final String status;
  final String completedAt;
  final Map<String, dynamic> repeat;
  final List<String> skipDates;
  final List<String> deferDates;
  final String content;
  final List<MessageAttachment> attachments;
  final String reviewStatus;
  final String reviewComment;
  final List<String> completedPhotos;
  final bool photoRequired;
  final int penaltyPoints;

  /// 该任务/作业是否需要联网：勾选后专注期间放开受管控设备（平板）的外网权限。
  final bool needNetwork;

  /// 假期作业/任务：在「假期时长」天内持续存在，假期里每天可以交一部分，
  /// 家长审核通过才算写完（归档后不再提交）。
  final bool holiday;
  final int holidayDays;

  /// 假期里已经提交过的日期（升序，每天只保留一条）。
  final List<String> submittedDays;

  const TaskItem({
    required this.id,
    required this.title,
    required this.subject,
    required this.taskType,
    required this.plannedDate,
    required this.plannedStart,
    required this.plannedDuration,
    required this.priority,
    this.difficulty = 'medium',
    required this.status,
    required this.completedAt,
    this.repeat = const {},
    this.skipDates = const [],
    this.deferDates = const [],
    this.content = '',
    this.attachments = const [],
    this.reviewStatus = '',
    this.reviewComment = '',
    this.completedPhotos = const [],
    this.photoRequired = true,
    this.penaltyPoints = 0,
    this.needNetwork = false,
    this.holiday = false,
    this.holidayDays = 0,
    this.submittedDays = const [],
  });

  factory TaskItem.fromJson(Map<String, dynamic> json) => TaskItem(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? '未命名任务',
        subject: json['subject']?.toString() ?? '',
        taskType: json['task_type']?.toString() ?? '',
        plannedDate: json['planned_date']?.toString() ?? '',
        plannedStart: json['planned_start']?.toString() ?? '',
        plannedDuration: json['planned_duration'] is int
            ? json['planned_duration'] as int
            : int.tryParse('${json['planned_duration'] ?? ''}') ?? 0,
        priority: json['priority'] is int
            ? json['priority'] as int
            : int.tryParse('${json['priority'] ?? ''}') ?? 0,
        difficulty: json['difficulty']?.toString() ?? 'medium',
        status: json['status']?.toString() ?? 'pending',
        completedAt: json['completed_at']?.toString() ?? '',
        repeat: json['repeat'] is Map
            ? (json['repeat'] as Map).cast<String, dynamic>()
            : const {},
        skipDates: json['skip_dates'] is List
            ? (json['skip_dates'] as List).map((e) => e.toString()).toList()
            : const [],
        deferDates: json['defer_dates'] is List
            ? (json['defer_dates'] as List).map((e) => e.toString()).toList()
            : const [],
        content: json['content']?.toString() ?? '',
        attachments: json['attachments'] is List
            ? (json['attachments'] as List)
                .whereType<Map>()
                .map((e) => MessageAttachment.fromJson(e.cast<String, dynamic>()))
                .toList()
            : const [],
        reviewStatus: json['review_status']?.toString() ?? '',
        reviewComment: json['review_comment']?.toString() ?? '',
        completedPhotos: json['completed_photos'] is List
            ? (json['completed_photos'] as List).map((e) => e.toString()).toList()
            : const [],
        photoRequired: json['photo_required'] != false,
        needNetwork: json['need_network'] == true,
        holiday: json['holiday'] == true,
        holidayDays: json['holiday_days'] is int
            ? json['holiday_days'] as int
            : int.tryParse('${json['holiday_days'] ?? ''}') ?? 0,
        submittedDays: _submissionDays(json['submissions']),
        penaltyPoints: json['penalty_points'] is int
            ? json['penalty_points'] as int
            : int.tryParse('${json['penalty_points'] ?? ''}') ?? 0,
      );

  bool get isDone => status == 'completed' || status == 'skipped';

  /// 假期最后一天（含）；非假期或日期非法返回 null。
  DateTime? get holidayEnd {
    if (!holiday || holidayDays <= 0) return null;
    final start = DateTime.tryParse(plannedDate);
    if (start == null) return null;
    return DateTime(start.year, start.month, start.day).add(Duration(days: holidayDays - 1));
  }

  /// 今天是否还在假期区间内。
  bool get holidayToday {
    final end = holidayEnd;
    final start = DateTime.tryParse(plannedDate);
    if (end == null || start == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return !today.isBefore(DateTime(start.year, start.month, start.day)) && !today.isAfter(end);
  }

  /// 假期作业还能不能继续交：假期内且家长还没审核通过。
  bool get holidayOpen => holiday && holidayToday && reviewStatus != 'approved';

  /// 假期作业「已经交了一部分、但家长还没通过」：不能算已完成，通过才算写完。
  bool get holidayPartlyDone =>
      holiday && status == 'completed' && reviewStatus != 'approved';

  bool get isRecurring => (repeat['type']?.toString() ?? 'none') != 'none';

  bool get isHomework => taskType == '作业';

  /// 劳动 / 家务 / 运动 / 体育类任务：无需专注模式，直接拍照提交。
  bool get isPhysical {
    final s = '$subject$taskType$title';
    return s.contains('劳动') ||
        s.contains('家务') ||
        s.contains('运动') ||
        s.contains('体育');
  }

  String get difficultyLabel => switch (difficulty) {
        'easy' => '简单',
        'hard' => '困难',
        _ => '中等',
      };
}

/// 专注会话（start 接口返回值）。
class FocusSession {
  final String id;
  final String startedAt;
  final int duration;
  final String status;

  const FocusSession({
    required this.id,
    required this.startedAt,
    required this.duration,
    required this.status,
  });

  factory FocusSession.fromJson(Map<String, dynamic> json) => FocusSession(
        id: json['id']?.toString() ?? '',
        startedAt: json['started_at']?.toString() ?? '',
        duration: json['duration'] is int
            ? json['duration'] as int
            : int.tryParse('${json['duration'] ?? ''}') ?? 0,
        status: json['status']?.toString() ?? 'active',
      );
}

/// 积分数据（GET /rewards/{child_id}/points → {records, total}）。
class PointsData {
  final int total;
  final List<Map<String, dynamic>> records;

  const PointsData({required this.total, required this.records});

  factory PointsData.fromJson(Map<String, dynamic> json) => PointsData(
        total: json['total'] is int
            ? json['total'] as int
            : int.tryParse('${json['total'] ?? ''}') ?? 0,
        records: (json['records'] as List?)?.cast<Map<String, dynamic>>() ?? const [],
      );
}

/// 徽章（GET /rewards/{child_id}/badges → {earned: [...]}）。
class BadgeData {
  final List<Map<String, dynamic>> earned;

  const BadgeData({required this.earned});

  factory BadgeData.fromJson(Map<String, dynamic> json) => BadgeData(
        earned: (json['earned'] as List?)?.cast<Map<String, dynamic>>() ?? const [],
      );
}

/// 消息附件（type: image/audio/video/file）。
class MessageAttachment {
  final String type;
  final String name;
  final String path;
  final int size;

  const MessageAttachment({
    this.type = '',
    this.name = '',
    this.path = '',
    this.size = 0,
  });

  factory MessageAttachment.fromJson(Map<String, dynamic> json) => MessageAttachment(
        type: json['type']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        path: json['path']?.toString() ?? '',
        size: json['size'] is int
            ? json['size'] as int
            : int.tryParse('${json['size'] ?? ''}') ?? 0,
      );
}

/// 消息。
class MessageItem {
  final String id;
  final String senderRole;
  final String senderName;
  final String content;
  final String readAt;
  final String createdAt;
  final List<MessageAttachment> attachments;

  const MessageItem({
    required this.id,
    required this.senderRole,
    required this.senderName,
    required this.content,
    required this.readAt,
    required this.createdAt,
    this.attachments = const [],
  });

  factory MessageItem.fromJson(Map<String, dynamic> json) => MessageItem(
        id: json['id']?.toString() ?? '',
        senderRole: json['sender_role']?.toString() ?? '',
        senderName: json['sender_name']?.toString() ?? '',
        content: json['content']?.toString() ?? '',
        readAt: json['read_at']?.toString() ?? '',
        createdAt: json['created_at']?.toString() ?? '',
        attachments: json['attachments'] is List
            ? (json['attachments'] as List)
                .whereType<Map>()
                .map((e) => MessageAttachment.fromJson(e.cast<String, dynamic>()))
                .toList()
            : const [],
      );

  bool get isRead => readAt.isNotEmpty && readAt != 'null';
}

/// /sync/pull 快照。
class SyncSnapshot {
  final String serverTime;
  final ChildProfile child;
  final String week;
  final String today;
  final List<TaskItem> planTasks;
  final List<TaskItem> todayTasks;
  final PointsData points;
  final BadgeData badges;
  final List<MessageItem> messages;
  final List<Map<String, dynamic>> checkins;

  const SyncSnapshot({
    required this.serverTime,
    required this.child,
    required this.week,
    required this.today,
    required this.planTasks,
    required this.todayTasks,
    required this.points,
    required this.badges,
    required this.messages,
    required this.checkins,
  });

  factory SyncSnapshot.fromJson(Map<String, dynamic> json) {
    Iterable<Map<String, dynamic>> maps(dynamic v) =>
        (v as List?)?.map((e) => (e as Map).cast<String, dynamic>()) ?? const [];
    return SyncSnapshot(
      serverTime: json['server_time']?.toString() ?? '',
      child: json['child'] is Map
          ? ChildProfile.fromJson((json['child'] as Map).cast<String, dynamic>())
          : const ChildProfile(id: '', name: '', grade: 0, avatar: ''),
      week: json['week']?.toString() ?? '',
      today: json['today']?.toString() ?? '',
      planTasks: maps(json['plan_tasks']).map(TaskItem.fromJson).toList(),
      todayTasks: maps(json['today_tasks']).map(TaskItem.fromJson).toList(),
      points: PointsData.fromJson((json['points'] as Map?)?.cast<String, dynamic>() ?? const {}),
      badges: BadgeData.fromJson((json['badges'] as Map?)?.cast<String, dynamic>() ?? const {}),
      messages: maps(json['messages']).map(MessageItem.fromJson).toList(),
      checkins: maps(json['checkins']).toList(),
    );
  }
}

/// 打卡任务预设（家长配置，孩子端选择）。
class CheckinPreset {
  final String id;
  final String title;
  final String checkinType;
  final String subject;
  final String content;
  final int duration;
  final bool enabled;
  final Map<String, dynamic> repeat;
  final bool photoRequired;
  final int penaltyPoints;

  const CheckinPreset({
    required this.id,
    required this.title,
    required this.checkinType,
    required this.subject,
    required this.content,
    required this.duration,
    required this.enabled,
    this.repeat = const {},
    this.photoRequired = true,
    this.penaltyPoints = 0,
  });

  factory CheckinPreset.fromJson(Map<String, dynamic> json) => CheckinPreset(
        id: json['id']?.toString() ?? '',
        title: json['title']?.toString() ?? '',
        checkinType: json['checkin_type']?.toString() ?? '作业',
        subject: json['subject']?.toString() ?? '',
        content: json['content']?.toString() ?? '',
        duration: json['duration'] is int
            ? json['duration'] as int
            : int.tryParse('${json['duration'] ?? ''}') ?? 0,
        enabled: json['enabled'] != false,
        repeat: json['repeat'] is Map
            ? (json['repeat'] as Map).cast<String, dynamic>()
            : const {},
        photoRequired: json['photo_required'] != false,
        penaltyPoints: json['penalty_points'] is int
            ? json['penalty_points'] as int
            : int.tryParse('${json['penalty_points'] ?? ''}') ?? 0,
      );
}

/// 成长记录（获奖/犯错/成长瞬间/其它）。
class GrowthRecord {
  final String id;
  final String type;
  final String title;
  final String content;
  final String photoPath;
  final List<String> photoPaths;
  final String createdAt;

  const GrowthRecord({
    required this.id,
    required this.type,
    required this.title,
    required this.content,
    this.photoPath = '',
    this.photoPaths = const [],
    required this.createdAt,
  });

  factory GrowthRecord.fromJson(Map<String, dynamic> json) {
    final paths = <String>[];
    final pp = json['photo_paths'];
    if (pp is List) {
      paths.addAll(pp.map((e) => e.toString()));
    } else if (json['photo_path']?.toString().isNotEmpty == true) {
      paths.add(json['photo_path'].toString());
    }
    return GrowthRecord(
      id: json['id']?.toString() ?? '',
      type: json['type']?.toString() ?? 'other',
      title: json['title']?.toString() ?? '',
      content: json['content']?.toString() ?? '',
      photoPath: json['photo_path']?.toString() ?? '',
      photoPaths: paths,
      createdAt: json['created_at']?.toString() ?? '',
    );
  }
}

/// 好友（其它孩子档案）。
class FriendChild {
  final String childId;
  final String name;
  final String avatar;
  final int grade;

  const FriendChild({
    required this.childId,
    required this.name,
    this.avatar = '',
    this.grade = 0,
  });

  factory FriendChild.fromJson(Map<String, dynamic> json) => FriendChild(
        childId: json['child_id']?.toString() ?? json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        avatar: json['avatar']?.toString() ?? '',
        grade: json['grade'] is int
            ? json['grade'] as int
            : int.tryParse('${json['grade'] ?? ''}') ?? 0,
      );
}

/// 好友申请。
class FriendRequest {
  final String id;
  final String fromChild;
  final String toChild;
  final String status;
  final String fromName;
  final String toName;
  final String createdAt;

  const FriendRequest({
    required this.id,
    required this.fromChild,
    required this.toChild,
    required this.status,
    this.fromName = '',
    this.toName = '',
    this.createdAt = '',
  });

  factory FriendRequest.fromJson(Map<String, dynamic> json) => FriendRequest(
        id: json['id']?.toString() ?? '',
        fromChild: json['from_child']?.toString() ?? '',
        toChild: json['to_child']?.toString() ?? '',
        status: json['status']?.toString() ?? 'pending',
        fromName: json['from_name']?.toString() ?? '',
        toName: json['to_name']?.toString() ?? '',
        createdAt: json['created_at']?.toString() ?? '',
      );
}

/// 好友消息。
class FriendMessage {
  final String id;
  final String fromChild;
  final String content;
  final String createdAt;
  final List<MessageAttachment> attachments;

  const FriendMessage({
    required this.id,
    required this.fromChild,
    required this.content,
    this.createdAt = '',
    this.attachments = const [],
  });

  factory FriendMessage.fromJson(Map<String, dynamic> json) => FriendMessage(
        id: json['id']?.toString() ?? '',
        fromChild: json['from_child']?.toString() ?? '',
        content: json['content']?.toString() ?? '',
        createdAt: json['created_at']?.toString() ?? '',
        attachments: (json['attachments'] as List?)
                ?.map((e) => MessageAttachment.fromJson((e as Map).cast<String, dynamic>()))
                .toList() ??
            const [],
      );
}

/// 徽章类型（目录）。
class BadgeItem {
  final String id;
  final String name;
  final String emoji;
  final String description;

  const BadgeItem({
    required this.id,
    required this.name,
    this.emoji = '🏆',
    this.description = '',
  });

  factory BadgeItem.fromJson(Map<String, dynamic> json) => BadgeItem(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        emoji: json['emoji']?.toString() ?? '🏆',
        description: json['description']?.toString() ?? '',
      );
}

/// 积分兑换内容。
class RedeemItem {
  final String id;
  final String name;
  final String emoji;
  final int cost;

  const RedeemItem({
    required this.id,
    required this.name,
    this.emoji = '🎁',
    required this.cost,
  });

  factory RedeemItem.fromJson(Map<String, dynamic> json) => RedeemItem(
        id: json['id']?.toString() ?? '',
        name: json['name']?.toString() ?? '',
        emoji: json['emoji']?.toString() ?? '🎁',
        cost: json['cost'] is int
            ? json['cost'] as int
            : int.tryParse('${json['cost'] ?? ''}') ?? 0,
      );
}

/// 情绪打卡记录（GET /mood/{child_id}）。
class MoodRecord {
  final String id;
  final String mood;
  final String note;
  final String date;
  final String createdAt;

  const MoodRecord({
    required this.id,
    required this.mood,
    this.note = '',
    this.date = '',
    this.createdAt = '',
  });

  factory MoodRecord.fromJson(Map<String, dynamic> json) => MoodRecord(
        id: json['id']?.toString() ?? '',
        mood: json['mood']?.toString() ?? 'ok',
        note: json['note']?.toString() ?? '',
        date: json['date']?.toString() ?? '',
        createdAt: json['created_at']?.toString() ?? '',
      );

  String get label => switch (mood) {
        'happy' => '开心',
        'tired' => '疲惫',
        _ => '一般',
      };

  String get emoji => switch (mood) {
        'happy' => '😄',
        'tired' => '😩',
        _ => '😐',
      };
}

/// 专注成就树（GET /growth/{child_id}/tree）。
class GrowthTree {
  final int growth;
  final int points;
  final int focusMinutes;
  final String stageCode;
  final String stageName;
  final String stageEmoji;
  final String? nextStage;
  final int? nextThreshold;
  final double progress;

  const GrowthTree({
    required this.growth,
    required this.points,
    required this.focusMinutes,
    required this.stageCode,
    required this.stageName,
    required this.stageEmoji,
    this.nextStage,
    this.nextThreshold,
    this.progress = 1.0,
  });

  factory GrowthTree.fromJson(Map<String, dynamic> json) => GrowthTree(
        growth: json['growth'] is int
            ? json['growth'] as int
            : int.tryParse('${json['growth'] ?? ''}') ?? 0,
        points: json['points'] is int
            ? json['points'] as int
            : int.tryParse('${json['points'] ?? ''}') ?? 0,
        focusMinutes: json['focus_minutes'] is int
            ? json['focus_minutes'] as int
            : int.tryParse('${json['focus_minutes'] ?? ''}') ?? 0,
        stageCode: json['stage_code']?.toString() ?? 'seed',
        stageName: json['stage_name']?.toString() ?? '种子',
        stageEmoji: json['stage_emoji']?.toString() ?? '🌰',
        nextStage: json['next_stage']?.toString(),
        nextThreshold: json['next_threshold'] is int
            ? json['next_threshold'] as int
            : int.tryParse('${json['next_threshold'] ?? ''}'),
        progress: json['progress'] is num
            ? (json['progress'] as num).toDouble()
            : 1.0,
      );
}