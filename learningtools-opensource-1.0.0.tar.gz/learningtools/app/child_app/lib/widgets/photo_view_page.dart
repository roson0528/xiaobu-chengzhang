import 'dart:typed_data';

import 'package:flutter/material.dart';

/// 全屏查看照片，支持横竖屏切换（每次点击旋转 90°）。
class PhotoViewPage extends StatefulWidget {
  final Uint8List bytes;
  final String title;
  const PhotoViewPage({super.key, required this.bytes, this.title = '查看照片'});

  @override
  State<PhotoViewPage> createState() => _PhotoViewPageState();
}

class _PhotoViewPageState extends State<PhotoViewPage> {
  int _quarterTurns = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text(widget.title, style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            icon: const Icon(Icons.screen_rotation),
            tooltip: '横竖屏切换',
            onPressed: () => setState(() => _quarterTurns = (_quarterTurns + 1) % 4),
          ),
        ],
      ),
      body: Center(
        child: RotatedBox(
          quarterTurns: _quarterTurns,
          child: InteractiveViewer(
            maxScale: 5,
            child: Image.memory(widget.bytes, fit: BoxFit.contain, gaplessPlayback: true),
          ),
        ),
      ),
    );
  }
}
