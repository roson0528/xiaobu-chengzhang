import 'dart:io';

import 'package:flutter/material.dart';

import 'kid_widgets.dart';

/// 拍照字段：显示缩略图与按钮，返回选中的本地文件。
/// [cameraOnly] 为 true 时只能拍照，不允许从相册选择。
class PhotoPickerField extends StatefulWidget {
  final void Function(File?) onChanged;
  final bool cameraOnly;

  const PhotoPickerField({super.key, required this.onChanged, this.cameraOnly = false});

  @override
  State<PhotoPickerField> createState() => _PhotoPickerFieldState();
}

class _PhotoPickerFieldState extends State<PhotoPickerField> {
  File? _file;

  Future<void> _pickCamera() async {
    final file = await PhotoHelper.pick(camera: true, gallery: false);
    if (file != null) {
      setState(() => _file = file);
      widget.onChanged(file);
    }
  }

  Future<void> _pickGallery() async {
    final file = await PhotoHelper.pick(camera: false, gallery: true);
    if (file != null) {
      setState(() => _file = file);
      widget.onChanged(file);
    }
  }

  Future<void> _choose() async {
    if (widget.cameraOnly) {
      await _pickCamera();
      return;
    }
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Text('📷', style: TextStyle(fontSize: 24)),
              title: const Text('拍一张照片', style: TextStyle(fontSize: 17)),
              onTap: () => Navigator.pop(ctx, 'camera'),
            ),
            ListTile(
              leading: const Text('🖼️', style: TextStyle(fontSize: 24)),
              title: const Text('从相册选择', style: TextStyle(fontSize: 17)),
              onTap: () => Navigator.pop(ctx, 'gallery'),
            ),
          ],
        ),
      ),
    );
    if (action == 'camera') await _pickCamera();
    if (action == 'gallery') await _pickGallery();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: _file == null
                ? Container(
                    width: 72,
                    height: 72,
                    color: const Color(0xFFF5F5F5),
                    child: const Center(child: Text('📷', style: TextStyle(fontSize: 30))),
                  )
                : Image.file(_file!, width: 72, height: 72, fit: BoxFit.cover),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('打卡照片', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(
                  _file == null
                      ? (widget.cameraOnly ? '请拍摄一张照片（只能拍摄）' : '拍照或从相册选一张')
                      : '已拍摄，点击可重新拍摄',
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ),
          TextButton.icon(
            onPressed: _choose,
            icon: const Icon(Icons.add_a_photo),
            label: Text(widget.cameraOnly ? '拍照' : '拍照/选图'),
          ),
        ],
      ),
    );
  }
}
