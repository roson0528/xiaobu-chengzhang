import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// 孩子友好的大按钮。
class KidButton extends StatelessWidget {
  final String label;
  final String emoji;
  final Color color;
  final VoidCallback? onTap;
  final bool loading;
  final bool compact;

  const KidButton({
    super.key,
    required this.label,
    required this.emoji,
    required this.color,
    this.onTap,
    this.loading = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: loading ? null : onTap,
        child: Container(
          padding: EdgeInsets.symmetric(
            vertical: compact ? 12 : 22,
            horizontal: 16,
          ),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 3),
          ),
          child: loading
              ? Center(
                  child: SizedBox(
                    width: compact ? 22 : 28,
                    height: compact ? 22 : 28,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(emoji, style: TextStyle(fontSize: compact ? 22 : 30)),
                    const SizedBox(width: 10),
                    Flexible(
                      child: Text(
                        label,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: compact ? 16 : 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

/// 圆形图标按钮（用于「我的」页入口）。
class KidTile extends StatelessWidget {
  final String emoji;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const KidTile({
    super.key,
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      color: Colors.white,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          radius: 24,
          backgroundColor: color.withValues(alpha: 0.15),
          child: Text(emoji, style: const TextStyle(fontSize: 26)),
        ),
        title: Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 13, color: Colors.grey)),
        trailing: const Icon(Icons.chevron_right, color: Colors.grey, size: 28),
        onTap: onTap,
      ),
    );
  }
}

/// 照片选择器：拍照或从相册选图，复制到应用目录，返回本地文件。
class PhotoHelper {
  static Future<File?> pick({bool camera = true, bool gallery = true}) async {
    final picker = ImagePicker();
    final source = await _chooseSource(camera, gallery);
    if (source == null) return null;
    final xfile = await picker.pickImage(
      source: source,
      maxWidth: 1600,
      maxHeight: 1600,
      imageQuality: 80,
    );
    if (xfile == null) return null;
    return _copyToAppDir(xfile);
  }

  static Future<ImageSource?> _chooseSource(bool camera, bool gallery) async {
    if (camera && !gallery) return ImageSource.camera;
    if (!camera && gallery) return ImageSource.gallery;
    // 由调用方弹窗选择
    return ImageSource.camera;
  }

  static Future<File> _copyToAppDir(XFile xfile) async {
    final dir = await getApplicationDocumentsDirectory();
    final photosDir = Directory(p.join(dir.path, 'photos'));
    if (!await photosDir.exists()) await photosDir.create(recursive: true);
    final name = 'photo_${DateTime.now().millisecondsSinceEpoch}${p.extension(xfile.path)}';
    final dest = File(p.join(photosDir.path, name));
    await File(xfile.path).copy(dest.path);
    return dest;
  }
}

/// 空状态。
class KidEmpty extends StatelessWidget {
  final String emoji;
  final String text;

  const KidEmpty({super.key, this.emoji = '🌱', required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 56)),
          const SizedBox(height: 12),
          Text(text, style: const TextStyle(fontSize: 16, color: Colors.grey)),
        ],
      ),
    );
  }
}

/// 带 emoji 的标题栏。
class KidAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String emoji;
  final Color color;
  final List<Widget>? actions;

  const KidAppBar({
    super.key,
    required this.title,
    required this.emoji,
    required this.color,
    this.actions,
  });

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: color,
      foregroundColor: Colors.white,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
      actions: actions,
    );
  }
}

/// 简单的输入卡片。
class KidTextField extends StatelessWidget {
  final String label;
  final String? hint;
  final TextEditingController? controller;
  final bool obscure;
  final TextInputType keyboardType;
  final int maxLines;

  const KidTextField({
    super.key,
    required this.label,
    this.hint,
    this.controller,
    this.obscure = false,
    this.keyboardType = TextInputType.text,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      maxLines: maxLines,
      style: const TextStyle(fontSize: 18),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}
