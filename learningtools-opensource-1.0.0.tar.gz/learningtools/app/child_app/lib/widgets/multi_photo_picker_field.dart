import 'dart:io';

import 'package:flutter/material.dart';

import 'kid_widgets.dart';

/// 多张照片选择：支持拍照/相册，返回文件列表。cameraOnly 时只能拍照。
class MultiPhotoPickerField extends StatefulWidget {
  final void Function(List<File>) onChanged;
  final bool cameraOnly;
  final int maxPhotos;

  const MultiPhotoPickerField({
    super.key,
    required this.onChanged,
    this.cameraOnly = false,
    this.maxPhotos = 6,
  });

  @override
  State<MultiPhotoPickerField> createState() => _MultiPhotoPickerFieldState();
}

class _MultiPhotoPickerFieldState extends State<MultiPhotoPickerField> {
  final List<File> _files = [];

  Future<void> _addOne() async {
    if (_files.length >= widget.maxPhotos) {
      _toast('最多 ${widget.maxPhotos} 张照片哦');
      return;
    }
    File? file;
    if (widget.cameraOnly) {
      file = await PhotoHelper.pick(camera: true, gallery: false);
    } else {
      final action = await showModalBottomSheet<String>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Text('📷', style: TextStyle(fontSize: 24)),
                title: const Text('拍一张照片', style: TextStyle(fontSize: 17)),
                onTap: () => Navigator.pop(ctx, 'camera'),
              ),
              ListTile(
                leading: const Text('🖼️', style: TextStyle(fontSize: 24)),
                title: const Text('从相册选择', style: TextStyle(fontSize: 17)),
                onTap: () => Navigator.pop(ctx, 'gallery'),
              ),
            ],
          ),
        ),
      );
      if (action == 'camera') {
        file = await PhotoHelper.pick(camera: true, gallery: false);
      } else if (action == 'gallery') {
        file = await PhotoHelper.pick(camera: false, gallery: true);
      }
    }
    if (file == null || !mounted) return;
    final picked = file;
    setState(() => _files.add(picked));
    widget.onChanged(List.unmodifiable(_files));
  }

  void _remove(int i) {
    setState(() => _files.removeAt(i));
    widget.onChanged(List.unmodifiable(_files));
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    const size = 84.0;
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        for (var i = 0; i < _files.length; i++)
          Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: size,
                  height: size,
                  child: Image.file(_files[i], fit: BoxFit.cover),
                ),
              ),
              Positioned(
                top: 2,
                right: 2,
                child: GestureDetector(
                  onTap: () => _remove(i),
                  child: Container(
                    decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                    padding: const EdgeInsets.all(3),
                    child: const Icon(Icons.close, size: 14, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        if (_files.length < widget.maxPhotos)
          GestureDetector(
            onTap: _addOne,
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFFFB74D), width: 2),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(widget.cameraOnly ? Icons.photo_camera : Icons.add_a_photo,
                        color: const Color(0xFFFB8C00), size: 28),
                    const SizedBox(height: 2),
                    Text(
                      widget.cameraOnly ? '拍照' : '添加',
                      style: const TextStyle(fontSize: 12, color: Color(0xFFFB8C00)),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
