import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../services/api_client.dart';
import 'photo_view_page.dart';

/// 一组提交照片的缩略图，点击进入全屏查看（孩子端）。
class SubmittedPhotoGrid extends StatelessWidget {
  final List<String> paths;
  final String childId;
  final double size;
  const SubmittedPhotoGrid({
    super.key,
    required this.paths,
    required this.childId,
    this.size = 84,
  });

  @override
  Widget build(BuildContext context) {
    if (paths.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [for (final p in paths) _Thumb(path: p, childId: childId, size: size)],
    );
  }
}

class _Thumb extends StatefulWidget {
  final String path;
  final String childId;
  final double size;
  const _Thumb({required this.path, required this.childId, required this.size});

  @override
  State<_Thumb> createState() => _ThumbState();
}

class _ThumbState extends State<_Thumb> {
  Uint8List? _bytes;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final b = await ApiClient.instance.getBytes(
        '/submissions/${widget.childId}/photo?path=${Uri.encodeComponent(widget.path)}',
      );
      if (mounted) setState(() => _bytes = Uint8List.fromList(b));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final b = _bytes;
    if (b == null) {
      return Container(
        width: widget.size,
        height: widget.size,
        color: const Color(0xFFF5F5F5),
        child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: GestureDetector(
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => PhotoViewPage(bytes: b, title: '查看照片')),
        ),
        child: Image.memory(b, width: widget.size, height: widget.size, fit: BoxFit.cover),
      ),
    );
  }
}
