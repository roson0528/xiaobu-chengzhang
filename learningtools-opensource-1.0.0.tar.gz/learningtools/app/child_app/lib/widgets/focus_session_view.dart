import 'dart:async';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:provider/provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../config.dart';
import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/focus_state.dart';
import '../services/focus_task.dart';
import '../services/notification_service.dart';
import '../services/sync_service.dart';
import 'kid_widgets.dart';
import 'video_play_page.dart';

/// 可复用的专注会话视图：进入即自动开始，倒计时结束/手动结束触发 [onFinished]。
/// 用于：专注 tab、学习打卡、今日文武任务。
class FocusSessionView extends StatefulWidget {
  final int durationMinutes;
  final String taskId;
  final bool freeMode;
  final VoidCallback? onFinished;

  const FocusSessionView({
    super.key,
    required this.durationMinutes,
    this.taskId = '',
    this.freeMode = false,
    this.onFinished,
  });

  @override
  State<FocusSessionView> createState() => _FocusSessionViewState();
}

enum _SessionStatus { running, finished }

class _FocusSessionViewState extends State<FocusSessionView> with WidgetsBindingObserver {
  _SessionStatus _status = _SessionStatus.running;
  FocusSession? _session;
  late int _remaining;
  late int _totalSeconds;
  int _elapsed = 0;
  Timer? _ticker;
  Timer? _photoTimer;
  Timer? _heartbeatTimer;
  CameraController? _camera;
  bool _cameraTrying = false;
  bool _stopping = false;
  late String _childId;

  // 录像
  bool _recording = false;
  bool _recordingBusy = false;
  bool _uploading = false;
  final List<File> _videoSegments = [];
  final Set<String> _uploadedSegments = {};

  bool get _isFree => widget.freeMode;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _childId = context.read<AuthService>().child?.id ?? '';
    _totalSeconds = widget.durationMinutes * 60;
    _remaining = _totalSeconds;
    _elapsed = 0;
    FocusState.running.value = true;
    FocusState.onStopRequested = _stop;
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void dispose() {
    if (FocusState.onStopRequested == _stop) {
      FocusState.onStopRequested = null;
    }
    FocusState.running.value = false;
    WidgetsBinding.instance.removeObserver(this);
    _ticker?.cancel();
    _photoTimer?.cancel();
    _heartbeatTimer?.cancel();
    _camera?.dispose();
    _camera = null;
    _cleanupVideos();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_status == _SessionStatus.running && state == AppLifecycleState.paused) {
      _reportEvent('background_switch');
    }
  }

  Future<void> _reportEvent(String type) async {
    final sessionId = _session?.id ?? '';
    if (sessionId.isEmpty) return;
    final timestamp = DateTime.now().toIso8601String();
    final fields = {'type': type, 'timestamp': timestamp, 'session_id': sessionId};
    try {
      await ApiClient.instance.postForm('/focus/$_childId/event', fields);
    } on ApiException catch (e) {
      if (e.isNetworkError) {
        await SyncService.instance.enqueueJsonPost(
          url: '/focus/$_childId/event',
          body: {'_form': fields},
          entityType: 'focus_event',
          entityId: 'evt_${DateTime.now().millisecondsSinceEpoch}',
        );
      }
    }
  }

  Future<void> _start() async {
    // 通知权限 + 忽略电池优化
    await NotificationService.instance.requestPermission();
    try {
      if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }
    } catch (_) {}

    try {
      final data = await ApiClient.instance.postForm('/focus/$_childId/start', {
        'task_id': widget.taskId,
        'duration_minutes': _isFree ? 0 : widget.durationMinutes,
      }) as Map<String, dynamic>;
      _session = FocusSession.fromJson(data);
    } on ApiException catch (e) {
      if (!mounted) return;
      if (e.isNetworkError) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('需要联网才能开始专注哦'), behavior: SnackBarBehavior.floating),
        );
        widget.onFinished?.call();
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), behavior: SnackBarBehavior.floating),
      );
      widget.onFinished?.call();
      return;
    }

    await WakelockPlus.enable();
    try {
      if (!await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.startService(
          serviceId: 256,
          notificationTitle: '专注中',
          notificationText: '屏幕已保持常亮，好好加油吧！',
          notificationIcon: null,
          callback: focusStartCallback,
          serviceTypes: [ForegroundServiceTypes.dataSync],
        );
      }
    } catch (_) {}

    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _onTick());
    _startHeartbeat();
    _photoTimer?.cancel();
    _photoTimer = Timer.periodic(
      Duration(seconds: AppConfig.focusPhotoIntervalSeconds),
      (_) => _captureAndUpload(),
    );
    _initCamera();
    FlutterForegroundTask.sendDataToTask('tick:$_remaining');
  }

  /// 心跳续期：专注进行中每隔 [_heartbeatInterval] 通知后端顺延上网放行窗口。
  ///
  /// 这是「双重兜底」的第二层——只要专注还在跑，即使路由器长时间拉不到策略，
  /// 上网放行也不会被误判过期；而 App 被强杀后不再有心跳，最迟在宽限期后收回。
  static const Duration _heartbeatInterval =
      Duration(minutes: AppConfig.focusHeartbeatMinutes);

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(_heartbeatInterval, (_) => _heartbeat());
  }

  Future<void> _heartbeat() async {
    final sessionId = _session?.id ?? '';
    if (sessionId.isEmpty) return;
    try {
      await ApiClient.instance
          .postForm('/focus/$_childId/heartbeat', {'session_id': sessionId});
    } catch (_) {
      // 心跳失败不打扰孩子：下一轮会补上；后端本身也有会话时长兜底
    }
  }

  void _onTick() {
    if (_isFree) {
      setState(() => _elapsed++);
      FlutterForegroundTask.sendDataToTask('elapsed:$_elapsed');
      return;
    }
    if (_remaining <= 0) {
      _finish();
      return;
    }
    setState(() => _remaining--);
    FlutterForegroundTask.sendDataToTask('tick:$_remaining');
  }

  Future<void> _stop() async {
    if (_stopping) return;
    _stopping = true;
    _ticker?.cancel();
    _photoTimer?.cancel();
    _heartbeatTimer?.cancel();
    // 结束前若仍在录像，先停止录像
    if (_recording) {
      try {
        final cam = _camera;
        if (cam != null && cam.value.isRecordingVideo) {
          final xfile = await cam.stopVideoRecording();
          _videoSegments.add(File(xfile.path));
        }
      } catch (_) {}
      _recording = false;
    }
    await _teardownCamera();
    await WakelockPlus.disable();
    try {
      await FlutterForegroundTask.stopService();
    } catch (_) {}
    final sessionId = _session?.id ?? '';
    if (sessionId.isNotEmpty) {
      try {
        await ApiClient.instance.postForm('/focus/$_childId/stop', {'session_id': sessionId});
      } on ApiException catch (e) {
        if (e.isNetworkError) {
          await SyncService.instance.enqueueJsonPost(
            url: '/focus/$_childId/stop',
            body: {'_form': {'session_id': sessionId}},
            entityType: 'focus_stop',
            entityId: 'stop_${DateTime.now().millisecondsSinceEpoch}',
          );
        }
      }
    }
    _session = null;
    _stopping = false;
    FocusState.running.value = false;
    if (mounted) setState(() => _status = _SessionStatus.finished);
    _cleanupVideos();
    widget.onFinished?.call();
  }

  Future<void> _finish() async {
    if (_status != _SessionStatus.running) return;
    setState(() {
      _remaining = 0;
      _status = _SessionStatus.finished;
    });
    await NotificationService.instance.show(
      id: 1001,
      title: '专注结束 🎉',
      body: _isFree ? '自由专注结束，记得提交本次打卡任务！' : '太棒了，请及时提交本次打卡任务！',
    );
    await _stop();
  }

  Future<void> _confirmEnd() async {
    if (_status != _SessionStatus.running || _stopping) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('结束专注模式？'),
        content: const Text('是否结束本次专注模式？结束后才能进行其它操作。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('继续专注')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('结束专注')),
        ],
      ),
    );
    if (ok == true) await _stop();
  }

  // ---------- 相机与照片 ----------

  Future<void> _initCamera() async {
    if (_cameraTrying) return;
    _cameraTrying = true;
    try {
      final cameras = await availableCameras();
      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );
      final controller = CameraController(front, ResolutionPreset.low, enableAudio: true);
      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() => _camera = controller);
    } catch (_) {
      await _reportEvent('photo_missing');
    } finally {
      _cameraTrying = false;
    }
  }

  Future<void> _teardownCamera() async {
    final c = _camera;
    _camera = null;
    if (c != null) {
      try {
        await c.dispose();
      } catch (_) {}
    }
  }

  Future<void> _captureAndUpload() async {
    if (_recording) return; // 录像期间暂停定时拍照，避免相机占用冲突
    final sessionId = _session?.id ?? '';
    if (sessionId.isEmpty) return;
    final timestamp = DateTime.now().toIso8601String();
    final cam = _camera;
    if (cam == null || !cam.value.isInitialized) {
      await _reportEvent('photo_missing');
      return;
    }
    try {
      final xfile = await cam.takePicture();
      final file = File(xfile.path);
      try {
        await ApiClient.instance.uploadFile('/focus/upload', file, {
          'child_id': _childId,
          'timestamp': timestamp,
          'session_id': sessionId,
        });
        if (await file.exists()) await file.delete();
      } on ApiException catch (e) {
        if (e.isNetworkError) {
          await SyncService.instance.enqueuePhotoUpload(
            filePath: file.path,
            fields: {'child_id': _childId, 'timestamp': timestamp, 'session_id': sessionId},
          );
        } else {
          if (await file.exists()) await file.delete();
        }
      }
    } catch (_) {
      await _reportEvent('photo_missing');
    }
  }

  String get _timeText {
    final total = _isFree ? _elapsed : _remaining;
    final mm = (total ~/ 60).toString().padLeft(2, '0');
    final ss = (total % 60).toString().padLeft(2, '0');
    return '$mm:$ss';
  }

  // ---------- 录像 ----------

  Future<void> _toggleRecording() async {
    if (_recording) {
      await _stopVideoRecording();
    } else {
      await _startVideoRecording();
    }
  }

  Future<void> _startVideoRecording() async {
    final cam = _camera;
    if (cam == null || !cam.value.isInitialized) {
      _toast('相机未就绪，稍后再试');
      return;
    }
    if (cam.value.isRecordingVideo || _recordingBusy) return;
    setState(() => _recordingBusy = true);
    try {
      await cam.startVideoRecording();
      if (mounted) setState(() => _recording = true);
    } catch (_) {
      _toast('开始录像失败，请重试');
    } finally {
      if (mounted) setState(() => _recordingBusy = false);
    }
  }

  Future<void> _stopVideoRecording() async {
    final cam = _camera;
    if (cam == null || !cam.value.isRecordingVideo || _recordingBusy) return;
    setState(() => _recordingBusy = true);
    try {
      final xfile = await cam.stopVideoRecording();
      if (mounted) {
        setState(() {
          _recording = false;
          _videoSegments.add(File(xfile.path));
        });
      } else {
        _recording = false;
      }
    } catch (_) {
      if (mounted) setState(() => _recording = false);
      _toast('停止录像失败，请重试');
    } finally {
      if (mounted) setState(() => _recordingBusy = false);
    }
  }

  Future<void> _uploadVideo(File segment) async {
    if (_uploading) return;
    final sessionId = _session?.id ?? '';
    setState(() => _uploading = true);
    try {
      await ApiClient.instance.uploadFile('/focus/video/upload', segment, {
        'child_id': _childId,
        'timestamp': DateTime.now().toIso8601String(),
        'session_id': sessionId,
      });
      if (!mounted) return;
      setState(() => _uploadedSegments.add(segment.path));
      _toast('录像已上传到服务器 ✅');
    } on ApiException catch (e) {
      _toast(e.isNetworkError ? '上传失败，请检查网络后重试' : e.message);
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _playVideo(File segment) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => VideoPlayPage(file: segment)),
    );
  }

  Future<void> _deleteVideo(File segment) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除这段录像？'),
        content: const Text('删除后无法恢复。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() {
      _videoSegments.remove(segment);
      _uploadedSegments.remove(segment.path);
    });
    try {
      if (await segment.exists()) await segment.delete();
    } catch (_) {}
  }

  Future<void> _cleanupVideos() async {
    // 退出专注模式后自动清除本地录像文件
    for (final f in List<File>.from(_videoSegments)) {
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    _videoSegments.clear();
    _uploadedSegments.clear();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _status != _SessionStatus.running,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && _status == _SessionStatus.running) _confirmEnd();
      },
      child: _buildRunning(),
    );
  }

  Widget _buildRunning() {
    final running = _status == _SessionStatus.running;
    final statusText = !running
        ? '本次专注已结束'
        : (_isFree ? '自由专注进行中…' : '专注进行中…');
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 8),
          // 缩小的摄像头画面（置于顶部，避免分散注意力）
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: _camera != null && _camera!.value.isInitialized
                    ? SizedBox(
                        height: 80,
                        width: 100,
                        child: FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _camera!.value.previewSize!.height,
                            height: _camera!.value.previewSize!.width,
                            child: CameraPreview(_camera!),
                          ),
                        ),
                      )
                    : Container(
                        height: 80,
                        width: 100,
                        color: const Color(0xFFBBDEFB),
                        child: const Center(child: Text('📷', style: TextStyle(fontSize: 30))),
                      ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            _timeText,
            style: const TextStyle(
              fontSize: 64,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1565C0),
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(height: 6),
          Text(
            statusText,
            style: const TextStyle(fontSize: 14, color: Colors.grey),
          ),
          if (_recording) ...[
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                ),
                const SizedBox(width: 6),
                const Text('录像中…', style: TextStyle(fontSize: 13, color: Colors.red)),
              ],
            ),
          ],
          const SizedBox(height: 16),
          if (running)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                KidButton(
                  label: _recording ? '停止录像' : '开始录像',
                  emoji: _recording ? '⏹️' : '🎥',
                  color: _recording ? const Color(0xFFEF5350) : const Color(0xFF26A69A),
                  onTap: _recordingBusy ? null : _toggleRecording,
                ),
              ],
            ),
          Expanded(
            child: _videoSegments.isEmpty
                ? const SizedBox.shrink()
                : ListView.builder(
                    shrinkWrap: true,
                    itemCount: _videoSegments.length,
                    itemBuilder: (_, i) => _videoSegmentTile(i),
                  ),
          ),
          if (running)
            Row(
              children: [
                Expanded(
                  child: KidButton(
                    label: '结束专注',
                    emoji: '🛑',
                    color: const Color(0xFFEF5350),
                    onTap: _stop,
                  ),
                ),
              ],
            ),
          const SizedBox(height: 12),
          Text(
            running ? '专注期间切换其它操作需先结束本次专注' : '请及时提交本次打卡任务',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _videoSegmentTile(int index) {
    final seg = _videoSegments[index];
    final uploaded = _uploadedSegments.contains(seg.path);
    return Card(
      margin: const EdgeInsets.only(top: 8),
      color: const Color(0xFFF1F8E9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(
          children: [
            const Icon(Icons.videocam, color: Color(0xFF26A69A)),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '录像 ${index + 1}${uploaded ? '（已上传）' : ''}',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
              ),
            ),
            IconButton(
              tooltip: '回放',
              icon: const Icon(Icons.play_circle_outline, color: Color(0xFF1E88E5)),
              onPressed: () => _playVideo(seg),
            ),
            IconButton(
              tooltip: uploaded ? '已上传' : '上传到服务器',
              icon: uploaded
                  ? const Icon(Icons.cloud_done, color: Colors.green)
                  : const Icon(Icons.cloud_upload_outlined, color: Color(0xFF26A69A)),
              onPressed: uploaded ? null : (_uploading ? null : () => _uploadVideo(seg)),
            ),
            IconButton(
              tooltip: '删除',
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              onPressed: () => _deleteVideo(seg),
            ),
          ],
        ),
      ),
    );
  }
}
