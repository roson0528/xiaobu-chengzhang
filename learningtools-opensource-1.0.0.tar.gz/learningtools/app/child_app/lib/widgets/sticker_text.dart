import 'package:flutter/material.dart';

/// 小步成长聊天表情包（32 个 GIF 动图）。
/// code 对应资源 assets/stickers/<code>.gif，两端命名一致即可互显。
const List<Map<String, String>> stickers = [
  {'code': 's01', 'name': 's01'},
  {'code': 's02', 'name': 's02'},
  {'code': 's03', 'name': 's03'},
  {'code': 's04', 'name': 's04'},
  {'code': 's05', 'name': 's05'},
  {'code': 's06', 'name': 's06'},
  {'code': 's07', 'name': 's07'},
  {'code': 's08', 'name': 's08'},
  {'code': 's09', 'name': 's09'},
  {'code': 's10', 'name': 's10'},
  {'code': 's11', 'name': 's11'},
  {'code': 's12', 'name': 's12'},
  {'code': 's13', 'name': 's13'},
  {'code': 's14', 'name': 's14'},
  {'code': 's15', 'name': 's15'},
  {'code': 's16', 'name': 's16'},
  {'code': 's17', 'name': 's17'},
  {'code': 's18', 'name': 's18'},
  {'code': 's19', 'name': 's19'},
  {'code': 's20', 'name': 's20'},
  {'code': 's21', 'name': 's21'},
  {'code': 's22', 'name': 's22'},
  {'code': 's23', 'name': 's23'},
  {'code': 's24', 'name': 's24'},
  {'code': 's25', 'name': 's25'},
  {'code': 's26', 'name': 's26'},
  {'code': 's27', 'name': 's27'},
  {'code': 's28', 'name': 's28'},
  {'code': 's29', 'name': 's29'},
  {'code': 's30', 'name': 's30'},
  {'code': 's31', 'name': 's31'},
  {'code': 's32', 'name': 's32'},
];

String stickerAsset(String code) => 'assets/stickers/$code.gif';

String stickerName(String code) {
  for (final s in stickers) {
    if (s['code'] == code) return s['name']!;
  }
  return '';
}

final RegExp _stickerRe = RegExp(r'\[sticker:([A-Za-z0-9_]+)\]');

class _Seg {
  final String type;
  final String value;
  _Seg.text(this.value) : type = 'text';
  _Seg.sticker(this.value) : type = 'sticker';
  bool get isSticker => type == 'sticker';
}

List<_Seg> _parse(String text) {
  final segs = <_Seg>[];
  var last = 0;
  for (final m in _stickerRe.allMatches(text)) {
    if (m.start > last) segs.add(_Seg.text(text.substring(last, m.start)));
    segs.add(_Seg.sticker(m.group(1)!));
    last = m.end;
  }
  if (last < text.length) segs.add(_Seg.text(text.substring(last)));
  return segs;
}

/// 渲染消息正文：文本中 [sticker:code] 替换为 GIF 动图；纯表情则放大显示。
class StickerText extends StatelessWidget {
  final String text;
  final double inlineSize;
  const StickerText(this.text, {super.key, this.inlineSize = 88});

  @override
  Widget build(BuildContext context) {
    final segs = _parse(text);
    if (segs.length == 1 && segs.first.isSticker) {
      return Image.asset(
        stickerAsset(segs.first.value),
        width: 140,
        height: 140,
        gaplessPlayback: true,
        fit: BoxFit.contain,
      );
    }
    return Text.rich(
      TextSpan(
        children: [
          for (final s in segs)
            if (s.isSticker)
              WidgetSpan(
                alignment: PlaceholderAlignment.middle,
                child: Image.asset(
                  stickerAsset(s.value),
                  width: inlineSize,
                  height: inlineSize,
                  gaplessPlayback: true,
                  fit: BoxFit.contain,
                ),
              )
            else
              TextSpan(text: s.value, style: const TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}

/// 弹出表情选择面板，选中返回 code（null 表示取消）。
Future<String?> showStickerPicker(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (ctx) => SafeArea(
      child: SizedBox(
        height: 340,
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('选择表情', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
            ),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 4,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: stickers.length,
                itemBuilder: (_, i) {
                  final s = stickers[i];
                  return GestureDetector(
                    onTap: () => Navigator.pop(ctx, s['code']),
                    child: Image.asset(
                      stickerAsset(s['code']!),
                      gaplessPlayback: true,
                      fit: BoxFit.contain,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
