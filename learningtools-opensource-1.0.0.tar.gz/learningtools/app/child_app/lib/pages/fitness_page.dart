import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/multi_photo_picker_field.dart';

/// 运动打卡：POST /api/v1/fitness/{child_id}。
class FitnessPage extends StatefulWidget {
  const FitnessPage({super.key});

  @override
  State<FitnessPage> createState() => _FitnessPageState();
}

class _FitnessPageState extends State<FitnessPage> {
  String _type = '跳绳';
  final _duration = TextEditingController();
  final _count = TextEditingController();
  final _calories = TextEditingController();
  final List<File> _photos = [];
  bool _submitting = false;

  static const _types = ['跳绳', '跑步', '游泳', '篮球', '足球', '羽毛球', '其他'];

  @override
  void dispose() {
    _duration.dispose();
    _count.dispose();
    _calories.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final childId = context.read<AuthService>().child?.id ?? '';
    if (childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    setState(() => _submitting = true);
    try {
      final photoPaths = <String>[];
      for (final f in _photos) {
        final p = await SubmitHelper.uploadPhoto(f, childId: childId);
        if (p != null && p.isNotEmpty) photoPaths.add(p);
      }
      final duration = int.tryParse(_duration.text.trim()) ?? 0;
      final count = int.tryParse(_count.text.trim()) ?? 0;
      final calories = int.tryParse(_calories.text.trim()) ?? 0;
      final detailParts = <String>[];
      if (duration > 0) detailParts.add('时长 $duration 分钟');
      if (count > 0) detailParts.add('数量 $count');
      if (calories > 0) detailParts.add('消耗 $calories 千卡');
      final result = await SubmitHelper.submitRecord(
        url: '/checkins/$childId',
        entityType: 'checkin',
        body: {
          'checkin_type': '运动',
          'subject': _type,
          'content': detailParts.isEmpty ? '完成${_type}运动' : detailParts.join(' · '),
          'duration': duration,
          'photo_path': photoPaths.isNotEmpty ? photoPaths.first : '',
          'photo_paths': photoPaths,
          'created_at': DateTime.now().toIso8601String(),
        },
      );
      if (!mounted) return;
      _toast(result == 'ok' ? '运动打卡成功，等待家长审核 ⏳' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop();
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      appBar: KidAppBar(title: '运动打卡', emoji: '⚽', color: const Color(0xFF43A047)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('今天做了什么运动？', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _types
                  .map((t) => ChoiceChip(
                        label: Text(t, style: const TextStyle(fontSize: 15)),
                        selected: _type == t,
                        selectedColor: const Color(0xFF81C784),
                        onSelected: (_) => setState(() => _type = t),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 18),
            KidTextField(label: '运动时长（分钟）', hint: '例如 30', controller: _duration, keyboardType: TextInputType.number),
            const SizedBox(height: 14),
            KidTextField(label: '数量（个/圈）', hint: '例如跳绳 200 个', controller: _count, keyboardType: TextInputType.number),
            const SizedBox(height: 14),
            KidTextField(label: '消耗（千卡，可选）', hint: '例如 100', controller: _calories, keyboardType: TextInputType.number),
            const SizedBox(height: 14),
            const Text('拍几张照片记录一下吧（可拍多张、也可从相册选）', style: TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            MultiPhotoPickerField(
              onChanged: (files) {
                _photos
                  ..clear()
                  ..addAll(files);
              },
            ),
            const SizedBox(height: 22),
            KidButton(
              label: '提交打卡',
              emoji: '🏅',
              color: const Color(0xFF43A047),
              loading: _submitting,
              onTap: _submit,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}