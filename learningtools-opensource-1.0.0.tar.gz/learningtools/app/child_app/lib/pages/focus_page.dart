import 'package:flutter/material.dart';

import '../config.dart';
import '../widgets/focus_session_view.dart';
import '../widgets/kid_widgets.dart';

/// 专注模式 tab：空闲时选时长，开始后复用 FocusSessionView。
///
/// [autoStart] 为真时（学习专用版），进入页面即自动开始专注模式，
/// 这样平板一打开 App 就会自动放开该设备的上网权限。
class FocusPage extends StatefulWidget {
  final bool autoStart;

  const FocusPage({super.key, this.autoStart = false});

  @override
  State<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends State<FocusPage> {
  late int _minutes;
  bool _freeMode = false;
  late bool _active;

  @override
  void initState() {
    super.initState();
    // 学习专用版：一启动就直接进入专注（默认 45 分钟，可用 --dart-define 调整）
    _minutes = widget.autoStart
        ? AppConfig.tabletFocusMinutes
        : AppConfig.defaultFocusMinutes;
    _active = widget.autoStart;
  }

  void _onSessionFinished() {
    if (!mounted) return;
    setState(() {
      _active = false;
      _freeMode = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('专注结束，请及时提交本次打卡任务'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE3F2FD),
      appBar: KidAppBar(
        title: widget.autoStart ? '专注模式 · 学习专用版' : '专注模式',
        emoji: '🧘',
        color: const Color(0xFF42A5F5),
      ),
      body: SafeArea(
        child: _active
            ? FocusSessionView(
                durationMinutes: _minutes,
                freeMode: _freeMode,
                onFinished: _onSessionFinished,
              )
            : _buildIdle(),
      ),
    );
  }

  Widget _buildIdle() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const Spacer(),
          const Text('🧘', style: TextStyle(fontSize: 90)),
          const SizedBox(height: 12),
          const Text(
            '专心做一件事，\n坚持到时间结束！',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 8,
            runSpacing: 8,
            children: [
              _durationChip(15),
              _durationChip(25),
              _durationChip(45),
              _freeChip(),
            ],
          ),
          const SizedBox(height: 24),
          KidButton(
            label: _freeMode ? '开始自由专注' : '开始专注',
            emoji: '▶️',
            color: const Color(0xFF42A5F5),
            onTap: () => setState(() => _active = true),
          ),
          const SizedBox(height: 12),
          const Text(
            '开始后屏幕保持常亮，切到别的应用会提醒家长哦',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          if (widget.autoStart) ...[
            const SizedBox(height: 6),
            const Text(
              '这台平板的联网由家长设置：只有家长勾选了「需要联网」的任务，\n'
              '在它的专注模式里才可以上网',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12, color: Color(0xFF1565C0)),
            ),
          ],
          const Spacer(),
        ],
      ),
    );
  }

  Widget _durationChip(int minutes) {
    final selected = !_freeMode && _minutes == minutes;
    return GestureDetector(
      onTap: () => setState(() {
        _freeMode = false;
        _minutes = minutes;
      }),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF42A5F5) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFF42A5F5), width: 2),
        ),
        child: Text(
          '$minutes 分钟',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: selected ? Colors.white : const Color(0xFF42A5F5),
          ),
        ),
      ),
    );
  }

  Widget _freeChip() {
    final selected = _freeMode;
    return GestureDetector(
      onTap: () => setState(() => _freeMode = true),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF42A5F5) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFF42A5F5), width: 2),
        ),
        child: Text(
          '自由时间',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: selected ? Colors.white : const Color(0xFF42A5F5),
          ),
        ),
      ),
    );
  }
}
