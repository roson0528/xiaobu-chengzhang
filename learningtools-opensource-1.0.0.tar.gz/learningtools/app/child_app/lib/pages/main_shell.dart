import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/chat_notifier.dart';
import '../services/event_notifier.dart';
import '../services/focus_state.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import 'checkin_records_page.dart';
import 'morning_checkin_page.dart';
import 'conversations_page.dart';
import 'fitness_page.dart';
import 'focus_page.dart';
import 'friends_page.dart';
import 'growth_page.dart';
import 'labor_checkin_page.dart';
import 'mistakes_page.dart';
import 'mood_page.dart';
import 'reading_page.dart';
import 'rewards_page.dart';
import 'settings_page.dart';
import 'tasks_page.dart';

/// 主框架：底部 5 个标签（今日任务 / 专注 / 打卡 / 成长 / 我的）。
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  static const int _focusTabIndex = 1;
  // 学习专用版：启动就停在专注 tab，并自动开始一次专注
  int _index = AppConfig.tabletMode ? _focusTabIndex : 0;
  bool _hasUpdate = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    await SyncService.instance.processQueue();
    try {
      await SyncService.instance.pullSnapshot();
    } catch (_) {}
    await _checkCelebration();
    await _checkUpdate();
    _startChatNotifier();
  }

  void _startChatNotifier() {
    final uid = context.read<AuthService>().user?.id ?? 0;
    if (uid > 0) ChatNotifier.instance.start(uid);
    EventNotifier.instance.start();
  }

  Widget _chatTabIcon(IconData icon) {
    return ValueListenableBuilder<int>(
      valueListenable: ChatNotifier.instance.unread,
      builder: (_, n, __) => Badge(
        isLabelVisible: n > 0,
        label: Text('$n'),
        child: Icon(icon),
      ),
    );
  }

  /// 检查新版本：有新版则「我的」标签显示红点。
  Future<void> _checkUpdate() async {
    try {
      final data = await ApiClient.instance.getJson('/app/latest') as Map<String, dynamic>;
      final latest = data['version']?.toString() ?? '';
      if (latest.isEmpty || !mounted) return;
      if (_compareVersion(latest, AppConfig.appVersion) > 0) {
        setState(() => _hasUpdate = true);
      }
    } catch (_) {}
  }

  int _compareVersion(String a, String b) {
    final pa = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final pb = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final len = pa.length > pb.length ? pa.length : pb.length;
    for (var i = 0; i < len; i++) {
      final va = i < pa.length ? pa[i] : 0;
      final vb = i < pb.length ? pb[i] : 0;
      if (va != vb) return va.compareTo(vb);
    }
    return 0;
  }

  /// 每周成长回顾：周报生成后，孩子端首次打开弹出庆祝动画。
  Future<void> _checkCelebration() async {
    final childId = AuthService.instance.child?.id ?? '';
    if (childId.isEmpty) return;
    try {
      final data = await ApiClient.instance
          .getJson('/reports/$childId/celebration') as Map<String, dynamic>;
      if (data['has_report'] != true) return;
      final week = data['week']?.toString() ?? '';
      final prefs = await SharedPreferences.getInstance();
      final seen = prefs.getString('celebration_week');
      if (seen == week) return;
      await prefs.setString('celebration_week', week);
      if (!mounted) return;
      final summary = (data['summary'] as Map?)?.cast<String, dynamic>() ?? const {};
      _showCelebration(week, summary);
    } catch (_) {
      // 静默失败，不打扰孩子
    }
  }

  void _showCelebration(String week, Map<String, dynamic> summary) {
    final totalTasks = _asInt(summary['total_tasks']);
    final completed = _asInt(summary['completed']);
    final studyMinutes = _asInt(summary['total_study_minutes']);
    final focus = _asInt(summary['focus_sessions']);
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'close',
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (ctx, _, _) => Center(
        child: TweenAnimationBuilder<double>(
          tween: Tween(begin: 0.0, end: 1.0),
          duration: const Duration(milliseconds: 600),
          builder: (context, scale, child) =>
              Transform.scale(scale: scale, child: child),
          child: Material(
            color: Colors.transparent,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 28),
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFF9C4), Color(0xFFFFE082)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('🎉', style: TextStyle(fontSize: 64)),
                  const SizedBox(height: 8),
                  const Text(
                    '本周成长回顾',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text('$week · 你这一周很棒！', style: const TextStyle(color: Colors.black54)),
                  const SizedBox(height: 16),
                  _celebrationStat('📋', '完成任务', '$completed / $totalTasks'),
                  _celebrationStat('📚', '学习时长', '$studyMinutes 分钟'),
                  _celebrationStat('🧘', '专注次数', '$focus 次'),
                  const SizedBox(height: 20),
                  const Text('继续加油，下周更棒！🌟',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFE65100))),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: () => Navigator.of(ctx).pop(),
                    child: const Text('太棒了！'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _celebrationStat(String emoji, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 20)),
          const SizedBox(width: 8),
          Text(label, style: const TextStyle(fontSize: 15, color: Colors.black54)),
          const SizedBox(width: 12),
          Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  int _asInt(dynamic v) => v is int ? v : int.tryParse('$v') ?? 0;

  Future<void> _onDestinationSelected(int i) async {
    // 专注期间切换到其它标签：先确认结束本次专注
    if (i != _focusTabIndex && FocusState.running.value) {
      final end = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('结束专注模式？'),
          content: const Text('是否结束本次专注模式？选择结束后才可以进行其它操作。'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('继续专注')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('结束专注')),
          ],
        ),
      );
      if (end != true) return;
      FocusState.requestStop();
    }
    setState(() => _index = i);
  }

  @override
  Widget build(BuildContext context) {
    final child = context.watch<AuthService>().child;
    final name = child?.name;
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [
          TasksPage(),
          FocusPage(autoStart: AppConfig.tabletMode),
          _CheckinHub(),
          ConversationsPage(),
          _MineHub(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _onDestinationSelected,
        destinations: [
          const NavigationDestination(icon: Icon(Icons.checklist), label: '今日任务'),
          const NavigationDestination(icon: Icon(Icons.timer), label: '专注'),
          const NavigationDestination(icon: Icon(Icons.edit_note), label: '打卡'),
          NavigationDestination(
            icon: _chatTabIcon(Icons.chat_bubble_outline),
            selectedIcon: _chatTabIcon(Icons.chat_bubble),
            label: '聊天',
          ),
          NavigationDestination(
            icon: Badge(isLabelVisible: _hasUpdate, smallSize: 8, child: const Icon(Icons.person)),
            label: name == null || name.isEmpty ? '我的' : '$name的',
          ),
        ],
      ),
    );
  }
}

/// 打卡聚合页：学习 / 运动 / 阅读。
class _CheckinHub extends StatelessWidget {
  const _CheckinHub();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F8E9),
      appBar: KidAppBar(title: '今天打卡了吗', emoji: '🗓️', color: const Color(0xFF7CB342)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          const Text(
            '完成打卡可以获得积分哦！',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 15, color: Colors.grey),
          ),
          const SizedBox(height: 18),
          KidButton(
            label: '晨起打卡',
            emoji: '🌅',
            color: const Color(0xFFFB8C00),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MorningCheckinPage()),
            ),
          ),
          const SizedBox(height: 12),
          KidButton(
            label: '家务打卡',
            emoji: '🧹',
            color: const Color(0xFF66BB6A),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const LaborCheckinPage()),
            ),
          ),
          const SizedBox(height: 12),
          KidButton(
            label: '运动打卡',
            emoji: '⚽',
            color: const Color(0xFF43A047),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const FitnessPage()),
            ),
          ),
          const SizedBox(height: 12),
          KidButton(
            label: '阅读打卡',
            emoji: '📚',
            color: const Color(0xFF8E24AA),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ReadingPage()),
            ),
          ),
          const SizedBox(height: 12),
          KidButton(
            label: '心情打卡',
            emoji: '🌈',
            color: const Color(0xFF00BFA5),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MoodPage()),
            ),
          ),
          const SizedBox(height: 12),
          KidButton(
            label: '我的打卡记录',
            emoji: '🗒️',
            color: const Color(0xFF546E7A),
            compact: true,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CheckinRecordsPage()),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            '🌱 每天进步一点点',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}

/// 「我的」聚合页：错题本 / 奖励 / 消息 / 设置。
class _MineHub extends StatelessWidget {
  const _MineHub();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCE4EC),
      appBar: KidAppBar(title: '我的', emoji: '👦', color: const Color(0xFFEC407A)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          KidTile(
            emoji: '📕',
            title: '错题本',
            subtitle: '把不会的题记下来，下次就会了',
            color: const Color(0xFFE53935),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const MistakesPage()),
            ),
          ),
          const SizedBox(height: 10),
          KidTile(
            emoji: '🎁',
            title: '我的奖励',
            subtitle: '看看攒了多少积分和徽章',
            color: const Color(0xFFFFB300),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const RewardsPage()),
            ),
          ),
          const SizedBox(height: 10),
          KidTile(
            emoji: '🌱',
            title: '成长记录',
            subtitle: '记录获奖、成长瞬间和点滴',
            color: const Color(0xFF8E24AA),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const GrowthPage()),
            ),
          ),
          const SizedBox(height: 10),
          KidTile(
            emoji: '👫',
            title: '我的好友',
            subtitle: '添加好友、一起成长、互相鼓励',
            color: const Color(0xFFFF7043),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const FriendsPage()),
            ),
          ),
          const SizedBox(height: 10),
          KidTile(
            emoji: '⚙️',
            title: '设置',
            subtitle: '后端地址、离线同步、退出登录',
            color: const Color(0xFF546E7A),
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
        ],
      ),
    );
  }
}
