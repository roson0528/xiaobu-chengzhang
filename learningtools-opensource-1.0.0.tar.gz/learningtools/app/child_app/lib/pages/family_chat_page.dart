import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/photo_view_page.dart';
import '../widgets/sticker_text.dart';

/// 家庭聊天：群聊（isGroup=true）或与某位家人一对一（peerId）。
class FamilyChatPage extends StatefulWidget {
  final bool isGroup;
  final int? peerId;
  final String title;

  const FamilyChatPage({super.key, required this.isGroup, this.peerId, required this.title});

  @override
  State<FamilyChatPage> createState() => _FamilyChatPageState();
}

class _FamilyChatPageState extends State<FamilyChatPage> {
  List<Map<String, dynamic>> _messages = [];
  final _input = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = true;
  bool _sending = false;
  int _myId = 0;

  final Map<String, Uint8List> _imgCache = {};
  final Map<String, Future<Uint8List?>> _imgFutures = {};

  @override
  void initState() {
    super.initState();
    _myId = context.read<AuthService>().user?.id ?? 0;
    _load();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  String get _listPath => widget.isGroup ? '/family/chat' : '/family/p2p/${widget.peerId}';
  String get _attachPath =>
      widget.isGroup ? '/family/chat/attachment' : '/family/p2p/${widget.peerId}/attachment';

  Future<void> _load() async {
    try {
      final data = await ApiClient.instance.getJson(_listPath) as List;
      final list = data
          .whereType<Map>()
          .map((e) => e.cast<String, dynamic>())
          .toList()
        ..sort((a, b) => (a['created_at']?.toString() ?? '').compareTo(b['created_at']?.toString() ?? ''));
      if (!mounted) return;
      setState(() {
        _messages = list;
        _loading = false;
      });
      _scrollToBottom();
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  Future<void> _send({String content = '', List<MessageAttachment> attachments = const []}) async {
    if (_sending) return;
    setState(() => _sending = true);
    try {
      await ApiClient.instance.postJson(_listPath, {
        'content': content,
        'attachments': [
          for (final a in attachments) {'type': a.type, 'path': a.path, 'name': a.name, 'size': a.size},
        ],
      });
      if (!mounted) return;
      await _load();
    } on ApiException catch (e) {
      if (mounted) _toast(e.message);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _sendText() async {
    final c = _input.text.trim();
    if (c.isEmpty) return;
    _input.clear();
    await _send(content: c);
  }

  Future<void> _pickSticker() async {
    final code = await showStickerPicker(context);
    if (code != null && code.isNotEmpty) await _send(content: '[sticker:$code]');
  }

  Future<MessageAttachment?> _upload(File f) async {
    try {
      final res = await ApiClient.instance.uploadFile(_attachPath, f, const {}) as Map<String, dynamic>;
      return MessageAttachment(
        type: res['type']?.toString() ?? 'file',
        path: res['path']?.toString() ?? '',
        name: res['name']?.toString() ?? '',
        size: res['size'] is int ? res['size'] as int : 0,
      );
    } on ApiException catch (e) {
      if (mounted) _toast(e.message);
      return null;
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? f = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      if (f == null) return;
      final a = await _upload(File(f.path));
      if (a != null) await _send(attachments: [a]);
    } catch (e) {
      if (mounted) _toast('选择图片失败：$e');
    }
  }

  Future<void> _pickVideo(ImageSource source) async {
    try {
      final XFile? f = await ImagePicker().pickVideo(source: source, maxDuration: const Duration(minutes: 3));
      if (f == null) return;
      final a = await _upload(File(f.path));
      if (a != null) await _send(attachments: [a]);
    } catch (e) {
      if (mounted) _toast('选择视频失败：$e');
    }
  }

  void _showAttachSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Color(0xFF00ACC1)),
              title: const Text('拍照'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF00ACC1)),
              title: const Text('从相册选照片'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: Color(0xFF00ACC1)),
              title: const Text('拍视频 / 选视频'),
              onTap: () {
                Navigator.pop(ctx);
                _pickVideo(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<Uint8List?> _imgBytes(MessageAttachment a) {
    final cached = _imgCache[a.path];
    if (cached != null) return Future.value(cached);
    final f = _imgFutures[a.path];
    if (f != null) return f;
    final fut = _fetchImg(a);
    _imgFutures[a.path] = fut;
    return fut;
  }

  Future<Uint8List?> _fetchImg(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance.getBytes('$_attachPath?path=${Uri.encodeComponent(a.path)}');
      if (bytes.isEmpty) return null;
      _imgCache[a.path] = Uint8List.fromList(bytes);
      return _imgCache[a.path];
    } catch (_) {
      return null;
    }
  }

  Future<void> _openFile(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance.getBytes('$_attachPath?path=${Uri.encodeComponent(a.path)}');
      final dir = await getTemporaryDirectory();
      final safe = a.name.replaceAll(RegExp(r'[/\\]'), '_');
      final file = File('${dir.path}/$safe');
      await file.writeAsBytes(bytes, flush: true);
      await OpenFilex.open(file.path);
    } catch (_) {
      if (mounted) _toast('打开失败');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0F7FA),
      appBar: KidAppBar(
        title: widget.title,
        emoji: widget.isGroup ? '👨‍👩‍👧' : '💬',
        color: const Color(0xFF00ACC1),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _buildList()),
          SafeArea(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _sending ? null : _showAttachSheet,
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF00ACC1)),
                  ),
                  IconButton(
                    onPressed: _sending ? null : _pickSticker,
                    icon: const Icon(Icons.emoji_emotions_outlined, color: Color(0xFF00ACC1)),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      maxLines: 1,
                      decoration: InputDecoration(
                        hintText: widget.isGroup ? '给家人发个消息…' : '发个消息…',
                        filled: true,
                        fillColor: const Color(0xFFF5F5F5),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      onSubmitted: (_) => _sendText(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _sendText,
                    icon: const Icon(Icons.send),
                    color: Colors.white,
                    style: IconButton.styleFrom(backgroundColor: const Color(0xFF00ACC1)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_messages.isEmpty) {
      return KidEmpty(emoji: widget.isGroup ? '👨‍👩‍👧' : '💬', text: '还没有消息，打个招呼吧！');
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(12),
      itemCount: _messages.length,
      itemBuilder: (context, i) => _bubble(_messages[i]),
    );
  }

  Widget _bubble(Map<String, dynamic> m) {
    final role = m['sender_role']?.toString() ?? '';
    final rawId = m['sender_id'];
    final senderId = rawId is int ? rawId : int.tryParse('$rawId');
    final isMine = (senderId != null && _myId > 0) ? senderId == _myId : role == 'child';
    final content = m['content']?.toString() ?? '';
    final name = m['sender_name']?.toString() ?? '';
    final atts = (m['attachments'] as List?)
            ?.map((e) => MessageAttachment.fromJson((e as Map).cast<String, dynamic>()))
            .toList() ??
        const <MessageAttachment>[];
    final raw = (m['created_at']?.toString() ?? '').replaceFirst('T', ' ');
    final time = raw.length > 16 ? raw.substring(5, 16) : '';

    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.8),
        decoration: BoxDecoration(
          color: isMine ? const Color(0xFFB2EBF2) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isMine ? 14 : 4),
            bottomRight: Radius.circular(isMine ? 4 : 14),
          ),
        ),
        child: Column(
          crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMine && name.isNotEmpty)
              Text(name, style: const TextStyle(fontSize: 11, color: Colors.grey, fontWeight: FontWeight.bold)),
            if (content.isNotEmpty) StickerText(content),
            for (final a in atts) _attachment(a),
            const SizedBox(height: 2),
            Text(time, style: const TextStyle(fontSize: 10, color: Colors.grey)),
          ],
        ),
      ),
    );
  }

  Widget _attachment(MessageAttachment a) {
    if (a.type == 'image') {
      return Padding(
        padding: const EdgeInsets.only(top: 6),
        child: FutureBuilder<Uint8List?>(
          future: _imgBytes(a),
          builder: (ctx, snap) {
            final b = snap.data;
            if (b == null) {
              return Container(
                width: 140,
                height: 100,
                color: const Color(0xFFF1F1F1),
                child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
              );
            }
            return GestureDetector(
              onTap: () => Navigator.of(ctx).push(
                MaterialPageRoute(builder: (_) => PhotoViewPage(bytes: b, title: '查看图片')),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(b, width: 160, height: 120, fit: BoxFit.cover),
              ),
            );
          },
        ),
      );
    }
    // 视频/文件：显示一个可点击卡片
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: InkWell(
        onTap: () => _openFile(a),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(color: const Color(0xFFF5F5F5), borderRadius: BorderRadius.circular(8)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(a.type == 'video' ? Icons.play_circle_fill : Icons.insert_drive_file,
                  color: const Color(0xFF00ACC1)),
              const SizedBox(width: 6),
              Flexible(
                child: Text(a.name.isEmpty ? (a.type == 'video' ? '视频' : '文件') : a.name,
                    style: const TextStyle(fontSize: 13)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
