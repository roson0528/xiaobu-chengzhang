import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/chat_notifier.dart';
import '../widgets/kid_widgets.dart';
import 'family_chat_page.dart';
import 'friend_chat_page.dart';

/// 会话列表：家庭群聊、爸爸/妈妈（私聊）、同学（好友），带未读小红点。
class ConversationsPage extends StatefulWidget {
  const ConversationsPage({super.key});

  @override
  State<ConversationsPage> createState() => _ConversationsPageState();
}

class _ConversationsPageState extends State<ConversationsPage> {
  List<Map<String, dynamic>> _parents = [];
  List<FriendChild> _friends = [];
  bool _loading = true;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await Future.wait([_loadParents(), _loadFriends()]);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadParents() async {
    try {
      final data = await ApiClient.instance.getJson('/family/members') as Map<String, dynamic>;
      final members = (data['members'] as List?)?.whereType<Map>() ?? const [];
      final parents = members
          .map((e) => e.cast<String, dynamic>())
          .where((m) => (m['role']?.toString() ?? '') != 'child')
          .toList();
      if (mounted) setState(() => _parents = parents);
    } catch (_) {
      if (mounted) setState(() => _parents = const []);
    }
  }

  Future<void> _loadFriends() async {
    try {
      final data = await ApiClient.instance.getJson('/friends/$_childId') as List;
      final list = data
          .map((e) => FriendChild.fromJson((e as Map).cast<String, dynamic>()))
          .toList();
      if (mounted) setState(() => _friends = list);
    } catch (_) {
      if (mounted) setState(() => _friends = const []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0F7FA),
      appBar: KidAppBar(
        title: '聊天',
        emoji: '💬',
        color: const Color(0xFF00ACC1),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ValueListenableBuilder<Set<String>>(
              valueListenable: ChatNotifier.instance.unreadKeys,
              builder: (context, unreadKeys, _) => RefreshIndicator(
                onRefresh: _load,
                child: ListView(
                  children: [
                    const _Header('👨‍👩‍👧 家庭'),
                    _conversationTile(
                      emoji: '👨‍👩‍👧',
                      name: '家庭群聊',
                      subtitle: '全家人一起聊天',
                      unread: unreadKeys.contains('family'),
                      onTap: () {
                        ChatNotifier.instance.markRead('family');
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => const FamilyChatPage(isGroup: true, title: '家庭群聊'),
                          ),
                        );
                      },
                    ),
                    for (final p in _parents)
                      _conversationTile(
                        emoji: '👤',
                        name: p['display_name']?.toString() ?? p['username']?.toString() ?? '家人',
                        subtitle: '私聊',
                        unread: unreadKeys.contains('p2p:${p['id']}'),
                        onTap: () {
                          ChatNotifier.instance.markRead('p2p:${p['id']}');
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => FamilyChatPage(
                                isGroup: false,
                                peerId: p['id'] as int,
                                title: p['display_name']?.toString() ?? p['username']?.toString() ?? '聊天',
                              ),
                            ),
                          );
                        },
                      ),
                    const _Header('👫 同学'),
                    if (_friends.isEmpty)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Center(child: Text('还没有同学，去「我的好友」添加吧', style: TextStyle(color: Colors.grey))),
                      )
                    else
                      for (final f in _friends)
                        _conversationTile(
                          emoji: f.avatar.isNotEmpty ? f.avatar : '🧒',
                          name: f.name,
                          subtitle: '私聊',
                          unread: unreadKeys.contains('friend:${f.childId}'),
                          onTap: () {
                            ChatNotifier.instance.markRead('friend:${f.childId}');
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => FriendChatPage(friend: f)),
                            );
                          },
                        ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _conversationTile({
    required String emoji,
    required String name,
    required String subtitle,
    required bool unread,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: const Color(0xFFB2EBF2),
        child: Text(emoji, style: const TextStyle(fontSize: 22)),
      ),
      title: Text(name, style: TextStyle(fontSize: 16, fontWeight: unread ? FontWeight.bold : FontWeight.w500)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (unread) Container(width: 10, height: 10, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
          const Icon(Icons.chevron_right),
        ],
      ),
      onTap: onTap,
    );
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
      child: Text(
        text,
        style: const TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.bold),
      ),
    );
  }
}
