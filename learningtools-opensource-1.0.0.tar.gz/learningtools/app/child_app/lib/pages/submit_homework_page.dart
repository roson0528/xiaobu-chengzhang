import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/multi_photo_picker_field.dart';

/// 提交作业：孩子提交老师在学校布置的作业，拍照上传后到家长端「作业」审核。
class SubmitHomeworkPage extends StatefulWidget {
  const SubmitHomeworkPage({super.key});

  @override
  State<SubmitHomeworkPage> createState() => _SubmitHomeworkPageState();
}

class _SubmitHomeworkPageState extends State<SubmitHomeworkPage> {
  static const _subjects = ['语文', '数学', '英语', '科学', '其他'];

  final _title = TextEditingController();
  final _content = TextEditingController();
  String _subject = '';
  final List<File> _photos = [];
  bool _submitting = false;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    if (_title.text.trim().isEmpty) {
      _toast('请先填写作业标题');
      return;
    }
    setState(() => _submitting = true);
    try {
      final photoPaths = <String>[];
      for (final f in _photos) {
        final p = await SubmitHelper.uploadPhoto(f, childId: _childId);
        if (p != null && p.isNotEmpty) photoPaths.add(p);
      }
      final body = <String, dynamic>{
        'title': _title.text.trim(),
        'subject': _subject.isEmpty ? '作业' : _subject,
        'content': _content.text.trim(),
        'photo_paths': photoPaths,
        'completed_at': DateTime.now().toIso8601String(),
      };

      String result;
      try {
        await ApiClient.instance.postJson('/homework/$_childId/submit', body);
        result = 'ok';
      } on ApiException catch (e) {
        if (e.isNetworkError) {
          await SyncService.instance.enqueueJsonPost(
            url: '/homework/$_childId/submit',
            body: body,
            entityType: 'homework',
          );
          result = 'queued';
        } else {
          rethrow;
        }
      }

      if (!mounted) return;
      _toast(result == 'ok' ? '作业已提交，等待家长审核 ⏳' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop(true);
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF3E0),
      appBar: KidAppBar(title: '提交作业', emoji: '📚', color: const Color(0xFFFFB300)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '把老师在学校布置的作业提交给家长审核',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _title,
              decoration: const InputDecoration(
                labelText: '作业标题 *',
                hintText: '比如：数学练习册第10页、背课文《春》',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            const Text('科目', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                for (final s in _subjects)
                  ChoiceChip(
                    label: Text(s),
                    selected: _subject == s,
                    onSelected: (_) => setState(() => _subject = s),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _content,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '作业说明（选填）',
                hintText: '可以写一写作业内容或注意事项',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            const Text('拍照给家长看看', style: TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            MultiPhotoPickerField(
              cameraOnly: false,
              onChanged: (files) {
                _photos
                  ..clear()
                  ..addAll(files);
              },
            ),
            const SizedBox(height: 22),
            KidButton(
              label: '提交作业',
              emoji: '📤',
              color: const Color(0xFFFFB300),
              loading: _submitting,
              onTap: _submit,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
