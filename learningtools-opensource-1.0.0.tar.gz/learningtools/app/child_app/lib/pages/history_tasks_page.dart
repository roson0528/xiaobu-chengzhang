import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/kid_widgets.dart';

/// 历史任务：按日期查看已经归档（过去）的任务。
class HistoryTasksPage extends StatefulWidget {
  const HistoryTasksPage({super.key});

  @override
  State<HistoryTasksPage> createState() => _HistoryTasksPageState();
}

class _HistoryTasksPageState extends State<HistoryTasksPage> {
  List<TaskItem> _tasks = [];
  List<String> _dates = [];
  String? _selectedDate;
  bool _loading = true;
  String? _error;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void initState() {
    super.initState();
    _loadDates();
  }

  Future<void> _loadDates() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await ApiClient.instance
          .getJson('/tasks/$_childId/history/dates') as Map<String, dynamic>;
      final dates = ((data['dates'] as List?) ?? const [])
          .map((e) => e.toString())
          .toList();
      if (!mounted) return;
      if (dates.isEmpty) {
        setState(() {
          _dates = [];
          _tasks = [];
          _selectedDate = null;
          _loading = false;
        });
        return;
      }
      setState(() => _dates = dates);
      await _loadTasks(dates.first);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '加载失败，请检查网络';
      });
    }
  }

  Future<void> _loadTasks(String date) async {
    setState(() {
      _loading = true;
      _error = null;
      _selectedDate = date;
    });
    try {
      final data = await ApiClient.instance
          .getJson('/tasks/$_childId/history?date=$date') as Map<String, dynamic>;
      final list = (data['tasks'] as List?)
              ?.map((e) => TaskItem.fromJson((e as Map).cast<String, dynamic>()))
              .toList() ??
          <TaskItem>[];
      if (!mounted) return;
      setState(() {
        _tasks = list;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '加载失败，请检查网络';
      });
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final yesterday = DateTime(now.year, now.month, now.day).subtract(const Duration(days: 1));
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate != null ? _parse(_selectedDate!) : yesterday,
      firstDate: DateTime(2020, 1, 1),
      lastDate: yesterday,
      helpText: '选择要查看的日期',
    );
    if (picked == null || !mounted) return;
    await _loadTasks(_fmt(picked));
  }

  DateTime _parse(String s) {
    final parts = s.split('-');
    if (parts.length != 3) return DateTime.now();
    return DateTime(
      int.tryParse(parts[0]) ?? 2000,
      int.tryParse(parts[1]) ?? 1,
      int.tryParse(parts[2]) ?? 1,
    );
  }

  String _fmt(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _showDate(String s) {
    final d = _parse(s);
    return '${d.year}年${d.month}月${d.day}日';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      appBar: KidAppBar(
        title: '历史任务',
        emoji: '🗂️',
        color: const Color(0xFF8D6E63),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Card(
              color: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              child: ListTile(
                leading: const Icon(Icons.calendar_today, color: Color(0xFF8D6E63)),
                title: Text(_selectedDate == null ? '选择日期' : _showDate(_selectedDate!),
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(_dates.isEmpty ? '还没有历史任务' : '共 ${_dates.length} 天有记录'),
                trailing: const Icon(Icons.chevron_right),
                onTap: _pickDate,
              ),
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ListView(
        children: [
          const SizedBox(height: 60),
          KidEmpty(emoji: '📡', text: _error!),
        ],
      );
    }
    if (_tasks.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 60),
          KidEmpty(emoji: '📭', text: '这一天没有任务记录'),
        ],
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: _tasks.map(_buildCard).toList(),
    );
  }

  Widget _buildCard(TaskItem t) {
    final rejected = t.reviewStatus == 'rejected' && t.status != 'completed' && t.status != 'skipped';
    final (statusText, statusColor) = rejected
        ? ('已驳回', const Color(0xFFEF5350))
        : switch (t.status) {
            'completed' => ('已完成', const Color(0xFF66BB6A)),
            'skipped' => ('已跳过', const Color(0xFF9E9E9E)),
            _ => ('未完成', const Color(0xFFFF9800)),
          };
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: rejected ? const Color(0xFFFFF5F5) : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            const Icon(Icons.task_alt, color: Color(0xFFFF7043)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(t.title,
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  if (t.subject.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text('科目：${t.subject}',
                          style: const TextStyle(fontSize: 13, color: Colors.grey)),
                    ),
                  if (rejected && t.reviewComment.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text('驳回原因：${t.reviewComment}',
                          style: const TextStyle(fontSize: 13, color: Color(0xFFC62828))),
                    ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: statusColor.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(statusText,
                  style: TextStyle(fontSize: 12, color: statusColor, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }
}
