import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/local_db.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/photo_view_page.dart';
import '../widgets/sticker_text.dart';

/// 与好友聊天：加载历史消息，气泡展示（自己右侧青色，好友左侧白色），底部发送。
class FriendChatPage extends StatefulWidget {
  final FriendChild friend;

  const FriendChatPage({super.key, required this.friend});

  @override
  State<FriendChatPage> createState() => _FriendChatPageState();
}

class _FriendChatPageState extends State<FriendChatPage> {
  List<FriendMessage> _messages = [];
  final _input = TextEditingController();
  final _scroll = ScrollController();
  bool _loading = true;
  bool _sending = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load({bool silent = false}) async {
    if (!silent) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final data = await ApiClient.instance
          .getJson('/friends/$_childId/messages/${widget.friend.childId}') as List;
      // 本地缓存最近消息，离线可读
      await LocalDb.instance.putCache('friend_msgs_${widget.friend.childId}', {'items': data});
      final msgs = data
          .map((e) => FriendMessage.fromJson((e as Map).cast<String, dynamic>()))
          .toList()
        ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
      setState(() {
        _messages = msgs;
        _loading = false;
      });
      _scrollToBottom();
    } on ApiException catch (e) {
      // 离线降级：读最近消息缓存
      final cached = await LocalDb.instance.getCache('friend_msgs_${widget.friend.childId}');
      final items = (cached?['items'] as List?) ?? const [];
      if (items.isNotEmpty) {
        final msgs = items
            .map((e) => FriendMessage.fromJson((e as Map).cast<String, dynamic>()))
            .toList()
          ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
        setState(() {
          _messages = msgs;
          _loading = false;
        });
        _scrollToBottom();
        _toast('离线模式，显示最近消息');
      } else {
        setState(() {
          _loading = false;
          _error = e.message;
        });
      }
    }
  }

  final Map<String, Uint8List> _imgCache = {};
  final Map<String, Future<Uint8List?>> _imgFutures = {};

  Future<void> _send() async {
    final content = _input.text.trim();
    if (content.isEmpty || _sending) return;
    _input.clear();
    await _postMessage(content);
  }

  Future<void> _sendSticker(String code) async {
    await _postMessage('[sticker:$code]');
  }

  Future<void> _pickSticker() async {
    final code = await showStickerPicker(context);
    if (code != null && code.isNotEmpty) {
      await _sendSticker(code);
    }
  }

  Future<MessageAttachment?> _upload(File f) async {
    try {
      final res = await ApiClient.instance
          .uploadFile('/friends/$_childId/attachment', f, const {}) as Map<String, dynamic>;
      return MessageAttachment(
        type: res['type']?.toString() ?? 'file',
        path: res['path']?.toString() ?? '',
        name: res['name']?.toString() ?? '',
        size: res['size'] is int ? res['size'] as int : 0,
      );
    } on ApiException catch (e) {
      if (mounted) _toast(e.message);
      return null;
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? f = await ImagePicker().pickImage(source: source, imageQuality: 85, maxWidth: 1600);
      if (f == null) return;
      final a = await _upload(File(f.path));
      if (a != null) await _postMessage('', attachments: [a]);
    } catch (e) {
      if (mounted) _toast('选择图片失败：$e');
    }
  }

  Future<void> _pickVideo(ImageSource source) async {
    try {
      final XFile? f = await ImagePicker().pickVideo(source: source, maxDuration: const Duration(minutes: 3));
      if (f == null) return;
      final a = await _upload(File(f.path));
      if (a != null) await _postMessage('', attachments: [a]);
    } catch (e) {
      if (mounted) _toast('选择视频失败：$e');
    }
  }

  void _showAttachSheet() {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera, color: Color(0xFF00ACC1)),
              title: const Text('拍照'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library, color: Color(0xFF00ACC1)),
              title: const Text('从相册选照片'),
              onTap: () {
                Navigator.pop(ctx);
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.videocam, color: Color(0xFF00ACC1)),
              title: const Text('拍视频 / 选视频'),
              onTap: () {
                Navigator.pop(ctx);
                _pickVideo(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _postMessage(String content, {List<MessageAttachment> attachments = const []}) async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    setState(() {
      _sending = true;
      // 先本地追加，发送成功后再以服务器为准刷新
      _messages.add(FriendMessage(
        id: 'local_${DateTime.now().millisecondsSinceEpoch}',
        fromChild: _childId,
        content: content,
        createdAt: DateTime.now().toIso8601String(),
        attachments: attachments,
      ));
    });
    _scrollToBottom();
    try {
      await ApiClient.instance.postJson('/friends/$_childId/message', {
        'to_child': widget.friend.childId,
        'content': content,
        'attachments': [
          for (final a in attachments) {'type': a.type, 'path': a.path, 'name': a.name, 'size': a.size},
        ],
      });
      if (!mounted) return;
      await _load(silent: true);
    } on ApiException catch (e) {
      _toast(e.message);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<Uint8List?> _imgBytes(MessageAttachment a) {
    final cached = _imgCache[a.path];
    if (cached != null) return Future.value(cached);
    final f = _imgFutures[a.path];
    if (f != null) return f;
    final fut = _fetchImg(a);
    _imgFutures[a.path] = fut;
    return fut;
  }

  Future<Uint8List?> _fetchImg(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance
          .getBytes('/friends/$_childId/attachment?path=${Uri.encodeComponent(a.path)}');
      if (bytes.isEmpty) return null;
      _imgCache[a.path] = Uint8List.fromList(bytes);
      return _imgCache[a.path];
    } catch (_) {
      return null;
    }
  }

  Future<void> _openFile(MessageAttachment a) async {
    try {
      final bytes = await ApiClient.instance
          .getBytes('/friends/$_childId/attachment?path=${Uri.encodeComponent(a.path)}');
      final dir = await getTemporaryDirectory();
      final safe = a.name.replaceAll(RegExp(r'[/\\]'), '_');
      final file = File('${dir.path}/$safe');
      await file.writeAsBytes(bytes, flush: true);
      await OpenFilex.open(file.path);
    } catch (_) {
      if (mounted) _toast('打开失败');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE0F7FA),
      appBar: KidAppBar(
        title: widget.friend.name,
        emoji: '💬',
        color: const Color(0xFF00ACC1),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: Column(
        children: [
          Expanded(child: _buildList()),
          SafeArea(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: _sending ? null : _showAttachSheet,
                    icon: const Icon(Icons.add_circle_outline, color: Color(0xFF00ACC1)),
                  ),
                  IconButton(
                    onPressed: _sending ? null : _pickSticker,
                    icon: const Icon(Icons.emoji_emotions_outlined, color: Color(0xFF00ACC1)),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _input,
                      maxLines: 1,
                      decoration: InputDecoration(
                        hintText: '给${widget.friend.name}发个消息…',
                        filled: true,
                        fillColor: const Color(0xFFF5F5F5),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(22),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: const Icon(Icons.send),
                    color: Colors.white,
                    style: IconButton.styleFrom(backgroundColor: const Color(0xFF00ACC1)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildList() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _messages.isEmpty) {
      return KidEmpty(emoji: '📡', text: _error!);
    }
    if (_messages.isEmpty) {
      return const KidEmpty(emoji: '💬', text: '还没有消息，打个招呼吧！');
    }
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.all(12),
      itemCount: _messages.length,
      itemBuilder: (context, i) {
        final m = _messages[i];
        final isMine = m.fromChild == _childId;
        return Align(
          alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
            decoration: BoxDecoration(
              color: isMine ? const Color(0xFFB2EBF2) : Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: const Radius.circular(16),
                topRight: const Radius.circular(16),
                bottomLeft: Radius.circular(isMine ? 16 : 4),
                bottomRight: Radius.circular(isMine ? 4 : 16),
              ),
            ),
            child: Column(
              crossAxisAlignment: isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Text(
                  isMine ? '我' : widget.friend.name,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 2),
                if (m.content.isNotEmpty) StickerText(m.content),
                for (final a in m.attachments) _attachment(a),
                const SizedBox(height: 2),
                Text(
                  _shortTime(m.createdAt),
                  style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _shortTime(String iso) {
    if (iso.isEmpty || iso.length < 16) return '';
    return iso.replaceFirst('T', ' ').substring(5, 16);
  }

  Widget _attachment(MessageAttachment a) {
    if (a.type == 'image') {
      return Padding(
        padding: const EdgeInsets.only(top: 6),
        child: FutureBuilder<Uint8List?>(
          future: _imgBytes(a),
          builder: (ctx, snap) {
            final b = snap.data;
            if (b == null) {
              return Container(
                width: 140,
                height: 100,
                color: const Color(0xFFF1F1F1),
                child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
              );
            }
            return GestureDetector(
              onTap: () => Navigator.of(ctx).push(
                MaterialPageRoute(builder: (_) => PhotoViewPage(bytes: b, title: '查看图片')),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(b, width: 160, height: 120, fit: BoxFit.cover),
              ),
            );
          },
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: InkWell(
        onTap: () => _openFile(a),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(color: const Color(0xFFF5F5F5), borderRadius: BorderRadius.circular(8)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(a.type == 'video' ? Icons.play_circle_fill : Icons.insert_drive_file,
                  color: const Color(0xFF00ACC1)),
              const SizedBox(width: 6),
              Flexible(
                child: Text(a.name.isEmpty ? (a.type == 'video' ? '视频' : '文件') : a.name,
                    style: const TextStyle(fontSize: 13)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
