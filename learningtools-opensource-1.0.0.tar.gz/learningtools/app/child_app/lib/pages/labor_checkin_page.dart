import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/multi_photo_picker_field.dart';

/// 家务打卡：孩子主动打卡，填写做了什么家务并拍照提交（只能拍摄，不可选相册）。
class LaborCheckinPage extends StatefulWidget {
  const LaborCheckinPage({super.key});

  @override
  State<LaborCheckinPage> createState() => _LaborCheckinPageState();
}

class _LaborCheckinPageState extends State<LaborCheckinPage> {
  final _content = TextEditingController();
  final List<File> _photos = [];
  bool _submitting = false;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void dispose() {
    _content.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    if (_content.text.trim().isEmpty) {
      _toast('请先写一写你做了什么家务');
      return;
    }
    setState(() => _submitting = true);
    try {
      final photoPaths = <String>[];
      for (final f in _photos) {
        final p = await SubmitHelper.uploadPhoto(f, childId: _childId);
        if (p != null && p.isNotEmpty) photoPaths.add(p);
      }
      final result = await SubmitHelper.submitRecord(
        url: '/checkins/$_childId',
        entityType: 'checkin',
        body: {
          'checkin_type': '家务',
          'subject': '家务',
          'content': _content.text.trim(),
          'duration': 0,
          'photo_path': photoPaths.isNotEmpty ? photoPaths.first : '',
          'photo_paths': photoPaths,
          'created_at': DateTime.now().toIso8601String(),
        },
      );
      if (!mounted) return;
      _toast(result == 'ok' ? '家务打卡成功，等待家长审核 ⏳' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop();
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      appBar: KidAppBar(title: '家务打卡', emoji: '🧹', color: const Color(0xFF66BB6A)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('今天做了什么家务？', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            TextField(
              controller: _content,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '做了什么家务 *',
                hintText: '比如：扫地、洗碗、整理房间……',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            const Text('拍照给家长看看（只能拍摄）', style: TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            MultiPhotoPickerField(
              cameraOnly: true,
              onChanged: (files) {
                _photos
                  ..clear()
                  ..addAll(files);
              },
            ),
            const SizedBox(height: 22),
            KidButton(
              label: '提交打卡',
              emoji: '✅',
              color: const Color(0xFF66BB6A),
              loading: _submitting,
              onTap: _submit,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
