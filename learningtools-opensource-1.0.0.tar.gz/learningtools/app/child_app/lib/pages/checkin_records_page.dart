import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/submitted_photo_grid.dart';

/// 我的打卡记录：展示每条打卡的审核状态（待家长审核 / 已通过 / 未通过）。
class CheckinRecordsPage extends StatefulWidget {
  const CheckinRecordsPage({super.key});

  @override
  State<CheckinRecordsPage> createState() => _CheckinRecordsPageState();
}

class _CheckinRecordsPageState extends State<CheckinRecordsPage> {
  List<Map<String, dynamic>> _records = [];
  bool _loading = true;
  String? _error;
  String? _selectedDate; // null = 本月全部

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final url = _selectedDate == null ? '/checkins/$_childId' : '/checkins/$_childId?date=$_selectedDate';
      final data = await ApiClient.instance.getJson(url) as List;
      if (!mounted) return;
      setState(() {
        _records = data.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e is ApiException ? e.message : '加载失败，请检查网络';
      });
    }
  }

  String _fmtDate(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  String _showDate(String s) {
    final p = DateTime.tryParse(s);
    if (p == null) return s;
    return '${p.year}年${p.month}月${p.day}日';
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate != null ? DateTime.tryParse(_selectedDate!) ?? now : now,
      firstDate: DateTime(2020, 1, 1),
      lastDate: now,
      helpText: '按日期查看打卡记录',
    );
    if (picked == null || !mounted) return;
    setState(() => _selectedDate = _fmtDate(picked));
    await _load();
  }

  String _statusLabel(String status) => switch (status) {
        'approved' => '已通过',
        'rejected' => '未通过',
        _ => '待家长审核',
      };

  String _statusEmoji(String status) => switch (status) {
        'approved' => '✅',
        'rejected' => '❌',
        _ => '⏳',
      };

  Color _statusColor(String status) => switch (status) {
        'approved' => const Color(0xFF2E7D32),
        'rejected' => const Color(0xFFC62828),
        _ => const Color(0xFFF57C00),
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF3E0),
      appBar: KidAppBar(
        title: '我的打卡记录',
        emoji: '🗓️',
        color: const Color(0xFFFB8C00),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            tooltip: '按日期查看',
            onPressed: _pickDate,
          ),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                const Text('📅', style: TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    _selectedDate == null ? '本月打卡记录' : '${_showDate(_selectedDate!)} 的打卡',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                ),
                if (_selectedDate != null)
                  GestureDetector(
                    onTap: () {
                      setState(() => _selectedDate = null);
                      _load();
                    },
                    child: const Text('清除', style: TextStyle(fontSize: 13, color: Color(0xFFFB8C00))),
                  ),
              ],
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _records.isEmpty) {
      return ListView(
        children: [const SizedBox(height: 80), KidEmpty(emoji: '📡', text: _error!)],
      );
    }
    if (_records.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 80),
          KidEmpty(emoji: '🗒️', text: '还没有打卡记录，去打卡吧！'),
        ],
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: _records.map((r) {
          final status = r['status']?.toString() ?? 'pending';
          final type = r['checkin_type']?.toString() ?? '打卡';
          final subject = r['subject']?.toString() ?? '';
          final content = r['content']?.toString() ?? '';
          final score = r['score'];
          final createdAt = r['created_at']?.toString() ?? '';
          final comment = r['review_comment']?.toString() ?? '';
          final photoPaths = (r['photo_paths'] as List?)
                  ?.map((e) => e.toString())
                  .where((e) => e.isNotEmpty)
                  .toList() ??
              const <String>[];
          final color = _statusColor(status);
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          content.isNotEmpty ? content : '$type · $subject',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${_statusEmoji(status)} ${_statusLabel(status)}',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: color),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '$type${subject.isNotEmpty ? ' · $subject' : ''}'
                    '${_shortTime(createdAt).isNotEmpty ? ' · ${_shortTime(createdAt)}' : ''}',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  if (status == 'approved' && score != null) ...[
                    const SizedBox(height: 6),
                    Text('家长评分：$score 分',
                        style: const TextStyle(fontSize: 13, color: Color(0xFF2E7D32))),
                  ],
                  if (comment.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text('家长评语：$comment', style: const TextStyle(fontSize: 13, color: Colors.black54)),
                  ],
                  if (photoPaths.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    SubmittedPhotoGrid(paths: photoPaths, childId: _childId),
                  ],
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  String _shortTime(String raw) {
    if (raw.isEmpty) return '';
    final s = raw.replaceFirst('T', ' ');
    return s.length > 16 ? s.substring(0, 16) : s;
  }
}
