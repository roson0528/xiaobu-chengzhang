import 'package:flutter/material.dart';

import '../widgets/kid_widgets.dart';

/// 积分记录页：按需查看，支持「全部 / 最近一周 / 最近一个月 / 按日期」筛选。
class PointsRecordsPage extends StatefulWidget {
  final List<Map<String, dynamic>> records;
  const PointsRecordsPage({super.key, required this.records});

  @override
  State<PointsRecordsPage> createState() => _PointsRecordsPageState();
}

class _PointsRecordsPageState extends State<PointsRecordsPage> {
  String _filter = 'all'; // all | week | month | date
  String? _date;

  DateTime _ts(Map<String, dynamic> r) =>
      DateTime.tryParse(r['timestamp']?.toString() ?? '') ?? DateTime(1970);

  String _dateStr(Map<String, dynamic> r) {
    final t = r['timestamp']?.toString() ?? '';
    return t.length >= 10 ? t.substring(0, 10) : '';
  }

  List<Map<String, dynamic>> get _filtered {
    final now = DateTime.now();
    switch (_filter) {
      case 'week':
        final cutoff = now.subtract(const Duration(days: 7));
        return widget.records.where((r) => _ts(r).isAfter(cutoff)).toList();
      case 'month':
        final cutoff = now.subtract(const Duration(days: 30));
        return widget.records.where((r) => _ts(r).isAfter(cutoff)).toList();
      case 'date':
        if (_date == null) return widget.records;
        return widget.records.where((r) => _dateStr(r) == _date).toList();
      default:
        return widget.records;
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _date != null ? (DateTime.tryParse(_date!) ?? now) : now,
      firstDate: DateTime(2020),
      lastDate: now,
      helpText: '按日期查看积分记录',
    );
    if (picked == null || !mounted) return;
    setState(() {
      _date =
          '${picked.year.toString().padLeft(4, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.day.toString().padLeft(2, '0')}';
      _filter = 'date';
    });
  }

  String _filterLabel() {
    switch (_filter) {
      case 'week':
        return '最近一周';
      case 'month':
        return '最近一个月';
      case 'date':
        return _date ?? '按日期';
      default:
        return '全部';
    }
  }

  @override
  Widget build(BuildContext context) {
    final records = _filtered.reversed.toList();
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: KidAppBar(
        title: '积分记录',
        emoji: '📜',
        color: const Color(0xFFFFB300),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('全部'),
                  selected: _filter == 'all',
                  onSelected: (_) => setState(() => _filter = 'all'),
                ),
                ChoiceChip(
                  label: const Text('最近一周'),
                  selected: _filter == 'week',
                  onSelected: (_) => setState(() => _filter = 'week'),
                ),
                ChoiceChip(
                  label: const Text('最近一个月'),
                  selected: _filter == 'month',
                  onSelected: (_) => setState(() => _filter = 'month'),
                ),
                ActionChip(
                  avatar: const Icon(Icons.calendar_month, size: 18),
                  label: Text(_date == null && _filter == 'date' ? '按日期' : (_filter == 'date' ? _date! : '按日期')),
                  onPressed: _pickDate,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Row(
              children: [
                Text('当前：${_filterLabel()} · ${records.length} 条',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
          Expanded(
            child: records.isEmpty
                ? const KidEmpty(emoji: '🗒️', text: '该筛选条件下暂无积分记录')
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                    itemCount: records.length,
                    itemBuilder: (_, i) {
                      final r = records[i];
                      final pts = r['points'] is int
                          ? r['points'] as int
                          : int.tryParse('${r['points']}') ?? 0;
                      final reason = r['reason']?.toString() ?? '';
                      final ts = r['timestamp']?.toString() ?? '';
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          leading: Text(pts >= 0 ? '➕' : '➖', style: const TextStyle(fontSize: 22)),
                          title: Text(reason, style: const TextStyle(fontSize: 15)),
                          subtitle: Text(
                            ts.replaceFirst('T', ' ').substring(0, ts.length >= 16 ? 16 : ts.length),
                            style: const TextStyle(fontSize: 11, color: Colors.grey),
                          ),
                          trailing: Text(
                            pts >= 0 ? '+$pts' : '$pts',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: pts >= 0 ? const Color(0xFF2E7D32) : const Color(0xFFC62828),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
