import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import 'points_records_page.dart';

/// 我的奖励：积分、徽章与积分兑换。
class RewardsPage extends StatefulWidget {
  const RewardsPage({super.key});

  @override
  State<RewardsPage> createState() => _RewardsPageState();
}

class _RewardsPageState extends State<RewardsPage> {
  PointsData? _points;
  BadgeData? _badges;
  GrowthTree? _tree;
  List<BadgeItem> _catalogBadges = const [];
  List<RedeemItem> _redeemItems = const [];
  String? _redeemingId;
  bool _loading = true;
  String? _error;
  final ScrollController _scroll = ScrollController();
  final GlobalKey _redeemKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final pointsData = await ApiClient.instance
          .getJson('/rewards/$_childId/points') as Map<String, dynamic>;
      final badgesData = await ApiClient.instance
          .getJson('/rewards/$_childId/badges') as Map<String, dynamic>;
      final treeData = await ApiClient.instance
          .getJson('/growth/$_childId/tree') as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _points = PointsData.fromJson(pointsData);
        _badges = BadgeData.fromJson(badgesData);
        _tree = GrowthTree.fromJson(treeData);
        _loading = false;
      });
    } catch (_) {
      // 离线降级：读快照缓存
      final snap = await SyncService.instance.cachedSnapshot();
      if (!mounted) return;
      if (snap != null) {
        setState(() {
          _points = snap.points;
          _badges = snap.badges;
          _loading = false;
        });
      } else {
        setState(() {
          _loading = false;
          _error = '加载失败，请检查网络';
        });
      }
    }
    // 目录独立拉取：失败时降级为空列表，不阻塞页面主体。
    await _loadCatalog();
  }

  /// 拉取徽章类型 + 兑换目录（GET /rewards/{childId}/catalog）。
  Future<void> _loadCatalog() async {
    try {
      final data = await ApiClient.instance
          .getJson('/rewards/$_childId/catalog') as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _catalogBadges = (data['badges'] as List?)
                ?.map((e) => BadgeItem.fromJson((e as Map).cast<String, dynamic>()))
                .toList() ??
            const [];
        _redeemItems = (data['redeem_items'] as List?)
                ?.map((e) => RedeemItem.fromJson((e as Map).cast<String, dynamic>()))
                .toList() ??
            const [];
      });
    } catch (_) {
      // 离线降级：目录为空，不崩溃。
    }
  }

  String _badgeEmoji(String name) {
    switch (name) {
      case '早起鸟':
        return '🐦';
      case '阅读之星':
        return '⭐';
      case '运动达人':
        return '🏅';
      case '坚持打卡':
        return '🔥';
      case '专注小达人':
        return '🧘';
      default:
        return '🏆';
    }
  }

  /// 专注成就树卡片：成长值 = 积分 + 专注总分钟数，随积累长成大树。
  Widget _buildTreeCard() {
    final tree = _tree;
    if (tree == null) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(child: Text('成长树加载中…', style: TextStyle(color: Colors.grey))),
        ),
      );
    }
    final progress = (tree.progress * 100).clamp(0, 100).toInt();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFE8F5E9), Color(0xFFC8E6C9)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Text(tree.stageEmoji, style: const TextStyle(fontSize: 60)),
          const SizedBox(height: 6),
          Text(
            '${tree.stageName} · 成长值 ${tree.growth}',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Color(0xFF2E7D32)),
          ),
          const SizedBox(height: 4),
          Text(
            '积分 ${tree.points} · 专注 ${tree.focusMinutes} 分钟',
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: tree.progress.clamp(0.0, 1.0),
              minHeight: 10,
              backgroundColor: Colors.white,
              color: const Color(0xFF66BB6A),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            tree.nextStage != null
                ? '还差 ${(tree.nextThreshold! - tree.growth)} 成长值长成「${tree.nextStage}」（$progress%）'
                : '已长成最高形态，太棒了！🎉',
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  /// 兑换奖品：确认对话框 → POST redeem → 刷新积分/徽章/目录。
  Future<void> _redeem(RedeemItem item) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('确认兑换？'),
        content: Text('确定用 ${item.cost} 积分兑换「${item.emoji} ${item.name}」吗？'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('再想想'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('兑换'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _redeemingId = item.id);
    try {
      await ApiClient.instance.postJson('/rewards/$_childId/redeem', {
        'reward_name': item.name,
        'cost': item.cost,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('兑换成功！🎉'), behavior: SnackBarBehavior.floating),
      );
      await _load();
    } catch (e) {
      if (!mounted) return;
      final msg = e is ApiException ? e.message : '兑换失败，请重试';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
      );
    } finally {
      if (mounted) setState(() => _redeemingId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: KidAppBar(
        title: '我的奖励',
        emoji: '🎁',
        color: const Color(0xFFFFB300),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _points == null) {
      return KidEmpty(emoji: '📡', text: _error!);
    }
    final points = _points ?? const PointsData(total: 0, records: []);

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 积分大卡片
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFFFB300), Color(0xFFFF8F00)],
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: [
                const Text('🌟', style: TextStyle(fontSize: 46)),
                const SizedBox(height: 6),
                const Text('我的积分', style: TextStyle(color: Colors.white, fontSize: 16)),
                Text(
                  '${points.total}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 52,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                const Text(
                  '坚持打卡、完成任务都可以获得积分哦！',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(height: 12),
                Material(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      final ctx = _redeemKey.currentContext;
                      if (ctx != null) {
                        Scrollable.ensureVisible(ctx, duration: const Duration(milliseconds: 400));
                      }
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('🎁', style: TextStyle(fontSize: 20)),
                          SizedBox(width: 8),
                          Text(
                            '我要兑换',
                            style: TextStyle(
                              color: Color(0xFFFF8F00),
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Text('🎁 积分兑换', key: _redeemKey, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _buildRedeemSection(points.total),
          const SizedBox(height: 20),
          const Text('🌳 专注成就树', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _buildTreeCard(),
          const SizedBox(height: 20),
          const Text('🏅 我的徽章', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _buildBadgesSection(),
          const SizedBox(height: 20),
          const Text('📜 积分记录', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Text('📜', style: TextStyle(fontSize: 26)),
              title: const Text('查看积分记录', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              subtitle: Text(
                '共 ${points.records.length} 条 · 支持按日期 / 最近一周 / 最近一个月查看',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => PointsRecordsPage(records: points.records),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  /// 徽章区块：目录徽章全展示，已获得彩色 / 未获得置灰。
  /// 目录为空但 earned 非空时直接展示 earned（复用 _badgeEmoji）。
  Widget _buildBadgesSection() {
    final earned = _badges?.earned ?? <Map<String, dynamic>>[];
    final earnedNames = <String>{};
    final emojiByName = <String, String>{};
    for (final b in earned) {
      final name = b['name']?.toString() ?? b['badge']?.toString() ?? '';
      if (name.isEmpty) continue;
      earnedNames.add(name);
      final emoji = b['emoji']?.toString();
      if (emoji != null && emoji.isNotEmpty) emojiByName[name] = emoji;
    }

    final items = <_BadgeView>[];
    if (_catalogBadges.isNotEmpty) {
      // 展示所有徽章类型
      for (final cb in _catalogBadges) {
        final name = cb.name.isNotEmpty ? cb.name : '徽章';
        final earnedEmoji = emojiByName[name];
        items.add(_BadgeView(
          name: name,
          emoji: cb.emoji.isNotEmpty
              ? cb.emoji
              : (earnedEmoji != null && earnedEmoji.isNotEmpty
                  ? earnedEmoji
                  : _badgeEmoji(name)),
          earned: earnedNames.contains(name),
        ));
      }
    } else if (earned.isNotEmpty) {
      // catalog 为空但已获得徽章非空：直接展示 earned
      for (final b in earned) {
        final name = b['name']?.toString() ?? b['badge']?.toString() ?? '徽章';
        final emoji = b['emoji']?.toString();
        items.add(_BadgeView(
          name: name,
          emoji: (emoji != null && emoji.isNotEmpty) ? emoji : _badgeEmoji(name),
          earned: true,
        ));
      }
    }

    if (items.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(child: Text('还没有徽章，继续加油！', style: TextStyle(color: Colors.grey))),
        ),
      );
    }

    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: items.map((b) {
        return Container(
          width: 96,
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
          decoration: BoxDecoration(
            color: b.earned ? Colors.white : const Color(0xFFF1F1F1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: b.earned ? const Color(0xFFFFE082) : const Color(0xFFE0E0E0),
            ),
          ),
          child: Column(
            children: [
              Opacity(
                opacity: b.earned ? 1.0 : 0.35,
                child: Text(b.emoji, style: const TextStyle(fontSize: 32)),
              ),
              const SizedBox(height: 4),
              Text(
                b.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: b.earned ? FontWeight.bold : FontWeight.normal,
                  color: b.earned ? Colors.black87 : Colors.grey,
                ),
              ),
              const SizedBox(height: 2),
              if (!b.earned)
                const Text('未获得', style: TextStyle(fontSize: 10, color: Colors.grey)),
            ],
          ),
        );
      }).toList(),
    );
  }

  /// 积分兑换区块：展示目录兑换项，积分足够才能点「兑换」。
  Widget _buildRedeemSection(int points) {
    if (_redeemItems.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Center(child: Text('暂无兑换内容', style: TextStyle(color: Colors.grey))),
        ),
      );
    }
    return Column(
      children: _redeemItems.map((item) {
        final affordable = points >= item.cost;
        final redeeming = _redeemingId == item.id;
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: Text(item.emoji, style: const TextStyle(fontSize: 30)),
            title: Text(
              item.name,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              affordable ? '${item.cost} 积分' : '${item.cost} 积分 · 还差 ${item.cost - points} 积分',
              style: TextStyle(
                fontSize: 12,
                color: affordable ? const Color(0xFFFF8F00) : Colors.grey,
              ),
            ),
            trailing: SizedBox(
              width: 74,
              height: 36,
              child: ElevatedButton(
                onPressed: (affordable && !redeeming) ? () => _redeem(item) : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFB300),
                  disabledBackgroundColor: const Color(0xFFE0E0E0),
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.zero,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                ),
                child: redeeming
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Text('兑换', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

/// 徽章展示视图模型。
class _BadgeView {
  final String name;
  final String emoji;
  final bool earned;

  const _BadgeView({required this.name, required this.emoji, required this.earned});
}