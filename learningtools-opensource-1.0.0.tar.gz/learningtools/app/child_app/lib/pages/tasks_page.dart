import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import 'history_tasks_page.dart';
import 'submit_homework_page.dart';
import 'task_detail_page.dart';

/// 今日任务：展示任务卡片，支持完成。
class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  List<TaskItem> _tasks = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final childId = context.read<AuthService>().child?.id ?? '';
    try {
      final data = await ApiClient.instance
          .getJson('/tasks/$childId/today') as Map<String, dynamic>;
      final list = (data['tasks'] as List?)
              ?.map((e) => TaskItem.fromJson((e as Map).cast<String, dynamic>()))
              .toList() ??
          <TaskItem>[];
      setState(() {
        _tasks = list;
        _loading = false;
      });
    } catch (_) {
      // 离线降级：读本地快照缓存
      final snap = await SyncService.instance.cachedSnapshot();
      if (snap != null && snap.todayTasks.isNotEmpty) {
        setState(() {
          _tasks = snap.todayTasks;
          _loading = false;
        });
      } else {
        setState(() {
          _loading = false;
          _error = '加载失败，请检查网络';
        });
      }
    }
  }

  Future<void> _openDetail(TaskItem task) async {
    final done = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => TaskDetailPage(task: task)),
    );
    if (done == true) {
      _toast('太棒了，任务完成！🎉');
      await _load();
    }
  }

  Future<void> _submitHomework() async {
    final submitted = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => const SubmitHomeworkPage()),
    );
    if (submitted == true) {
      _toast('作业已提交，等待家长审核 ⏳');
      await _load();
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  String _subjectEmoji(String subject) {
    switch (subject) {
      case '语文':
        return '📖';
      case '数学':
        return '🔢';
      case '英语':
        return '🔤';
      case '科学':
        return '🔬';
      default:
        return '📝';
    }
  }

  @override
  Widget build(BuildContext context) {
    final doneCount =
        _tasks.where((t) => t.isDone && !t.holidayPartlyDone).length;
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      appBar: KidAppBar(
        title: '今日任务',
        emoji: '📋',
        color: const Color(0xFFFF7043),
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: '历史任务',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const HistoryTasksPage()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _buildBody(doneCount),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _submitHomework,
        icon: const Icon(Icons.school),
        label: const Text('提交作业'),
        backgroundColor: const Color(0xFFFFB300),
        foregroundColor: Colors.white,
      ),
    );
  }

  Widget _buildBody(int doneCount) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null && _tasks.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 80),
          KidEmpty(emoji: '📡', text: _error!),
        ],
      );
    }
    if (_tasks.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 80),
          const KidEmpty(emoji: '🎉', text: '今天没有任务，去玩一会儿吧！'),
        ],
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // 进度条
        Card(
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Text('✅', style: const TextStyle(fontSize: 22)),
                const SizedBox(width: 10),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: _tasks.isEmpty ? 0 : doneCount / _tasks.length,
                      minHeight: 14,
                      backgroundColor: const Color(0xFFFFE0B2),
                      color: const Color(0xFF66BB6A),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Text(
                  '$doneCount/${_tasks.length}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        ..._tasks.map((t) => _TaskCard(
              task: t,
              emoji: _subjectEmoji(t.subject),
              onTap: () => _openDetail(t),
            )),
      ],
    );
  }
}

String _difficultyEmoji(String difficulty) {
  switch (difficulty) {
    case 'easy':
      return '🟢';
    case 'hard':
      return '🔴';
    default:
      return '🟡';
  }
}

class _TaskCard extends StatelessWidget {
  final TaskItem task;
  final String emoji;
  final VoidCallback onTap;

  const _TaskCard({
    required this.task,
    required this.emoji,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // 假期作业分次提交：交了一部分但家长还没通过时，不能显示成「已完成」
    final holidayOpen = task.holidayPartlyDone;
    final done = task.isDone && !holidayOpen;
    final rejected = !done && task.reviewStatus == 'rejected';
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      color: rejected
          ? const Color(0xFFFFEBEE)
          : (holidayOpen
              ? const Color(0xFFFFF3E0)
              : (done ? const Color(0xFFE8F5E9) : Colors.white)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(emoji, style: const TextStyle(fontSize: 30)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      task.title,
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        decoration: done ? TextDecoration.lineThrough : null,
                        color: done ? Colors.grey : Colors.black87,
                      ),
                    ),
                  ),
                  if (holidayOpen)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFF7043),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '假期已交${task.submittedDays.length}天',
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    )
                  else if (done)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF66BB6A),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        task.status == 'completed' ? '已完成' : '已跳过',
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    )
                  else if (rejected)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEF5350),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        '已驳回',
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    )
                  else
                    const Icon(Icons.chevron_right, color: Colors.grey),
                ],
              ),
              if (task.plannedStart.isNotEmpty ||
                  task.plannedDuration > 0 ||
                  task.isRecurring ||
                  task.difficulty != 'medium') ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 4,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    if (task.plannedStart.isNotEmpty)
                      Text('🕐 ${task.plannedStart}',
                          style: const TextStyle(fontSize: 13, color: Colors.grey)),
                    if (task.plannedDuration > 0)
                      Text('⏱ ${task.plannedDuration} 分钟',
                          style: const TextStyle(fontSize: 13, color: Colors.grey)),
                    Text(_difficultyEmoji(task.difficulty) + task.difficultyLabel,
                        style: TextStyle(
                          fontSize: 12,
                          color: task.difficulty == 'hard'
                              ? Colors.red
                              : (task.difficulty == 'easy' ? Colors.green : Colors.grey),
                        )),
                    if (task.isRecurring)
                      const Text('🔁 循环',
                          style: TextStyle(fontSize: 12, color: Colors.blueGrey)),
                  ],
                ),
              ],
              if (!done) ...[
                const SizedBox(height: 10),
                Text(
                  rejected
                      ? '家长已驳回，点开查看原因并重新提交'
                      : '点开查看说明，开始任务 → 专注 → 拍照提交',
                  style: TextStyle(fontSize: 12, color: rejected ? Colors.red : Colors.orange),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
