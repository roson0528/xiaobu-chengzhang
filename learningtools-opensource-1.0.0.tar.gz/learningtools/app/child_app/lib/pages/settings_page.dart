import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import 'login_page.dart';

/// 设置：当前账号、检查升级、离线同步、退出登录。
class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _syncing = false;
  bool _checking = false;
  bool _downloading = false;
  double _progress = 0;
  int _pending = 0;

  @override
  void initState() {
    super.initState();
    _refreshPending();
  }

  Future<void> _refreshPending() async {
    final c = await SyncService.instance.pendingCount();
    if (mounted) setState(() => _pending = c);
  }

  Future<void> _syncNow() async {
    setState(() => _syncing = true);
    await SyncService.instance.processQueue();
    await _refreshPending();
    setState(() => _syncing = false);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_pending == 0 ? '同步完成，全部已上传 ✅' : '还有 $_pending 条等待联网重试'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ---------- 检查升级 ----------

  String get _serverOrigin {
    final base = AppConfig.apiBaseUrl;
    final idx = base.indexOf('/api/v1');
    return idx > 0 ? base.substring(0, idx) : base;
  }

  int _compareVersion(String a, String b) {
    final pa = a.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final pb = b.split('.').map((e) => int.tryParse(e) ?? 0).toList();
    final len = pa.length > pb.length ? pa.length : pb.length;
    for (var i = 0; i < len; i++) {
      final va = i < pa.length ? pa[i] : 0;
      final vb = i < pb.length ? pb[i] : 0;
      if (va != vb) return va.compareTo(vb);
    }
    return 0;
  }

  Future<void> _checkUpdate() async {
    setState(() => _checking = true);
    try {
      final data = await ApiClient.instance.getJson('/app/latest') as Map<String, dynamic>;
      final latest = data['version']?.toString() ?? '';
      final downloadUrl = data['download_url']?.toString() ?? '';
      if (!mounted) return;
      if (latest.isEmpty || _compareVersion(latest, AppConfig.appVersion) <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已是最新版本 V${AppConfig.appVersion} ✅'), behavior: SnackBarBehavior.floating),
        );
        return;
      }
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('发现新版本 V$latest'),
          content: Text('当前版本 V${AppConfig.appVersion}，是否下载并安装最新版？'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('下载安装')),
          ],
        ),
      );
      if (ok == true && mounted) {
        await _downloadAndInstall(downloadUrl);
      }
    } on ApiException catch (e) {
      if (mounted) _toast(e.message);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  Future<void> _downloadAndInstall(String downloadUrl) async {
    if (downloadUrl.isEmpty) {
      _toast('未获取到下载地址');
      return;
    }
    String fullUrl = downloadUrl;
    if (downloadUrl.startsWith('/')) fullUrl = '$_serverOrigin$downloadUrl';

    setState(() {
      _downloading = true;
      _progress = 0;
    });
    try {
      // 存到应用私有 files 目录（FileProvider 已授权），供系统安装器读取
      final dir = await getApplicationSupportDirectory();
      final updateDir = Directory('${dir.path}/update');
      if (!await updateDir.exists()) await updateDir.create(recursive: true);
      final apkPath = '${updateDir.path}/app-release.apk';

      await Dio().download(
        fullUrl,
        apkPath,
        onReceiveProgress: (received, total) {
          if (total > 0 && mounted) {
            setState(() => _progress = received / total);
          }
        },
      );
      if (!mounted) return;
      // 原生 FileProvider + ACTION_VIEW 唤起系统安装器
      try {
        await const MethodChannel('app_update/install')
            .invokeMethod('installApk', {'path': apkPath});
        if (mounted) _toast('已开始安装，请在系统弹窗中确认');
      } catch (e) {
        final result = await OpenFilex.open(apkPath);
        if (result.type != ResultType.done) {
          if (mounted) _toast('自动安装失败（${e is PlatformException ? e.message : e}），请手动打开安装包');
        }
      }
    } on DioException catch (e) {
      if (mounted) _toast('下载失败：${e.message}');
    } finally {
      if (mounted) setState(() => _downloading = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _logout() async {
    final auth = context.read<AuthService>();
    await auth.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final user = auth.user;
    final child = auth.child;
    return Scaffold(
      backgroundColor: const Color(0xFFECEFF1),
      appBar: KidAppBar(title: '设置', emoji: '⚙️', color: const Color(0xFF546E7A)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 账号信息
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 26,
                    backgroundColor: Color(0xFFB0BEC5),
                    child: Text('👦', style: TextStyle(fontSize: 28)),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        child?.name ?? user?.username ?? '未登录',
                        style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '账号：${user?.username ?? '-'}（${user?.role ?? '-'}）',
                        style: const TextStyle(fontSize: 13, color: Colors.grey),
                      ),
                      if (child != null && child.grade > 0)
                        Text('${child.grade} 年级', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          // 检查升级
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('🔧 检查升级', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text('当前版本 V${AppConfig.appVersion}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                  if (_downloading) ...[
                    const SizedBox(height: 10),
                    LinearProgressIndicator(value: _progress, minHeight: 6),
                    const SizedBox(height: 4),
                    Text('下载中 ${(_progress * 100).toStringAsFixed(0)}%',
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                  const SizedBox(height: 10),
                  KidButton(
                    label: '检查升级',
                    emoji: '⬆️',
                    color: const Color(0xFF42A5F5),
                    loading: _checking || _downloading,
                    onTap: _checkUpdate,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          // 离线同步
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('📡 离线同步：待上传 $_pending 条',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text(
                    '网络不好时，打卡会自动保存到本地，联网后重试（最多 5 次）。',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 8),
                  KidButton(
                    label: '立即同步',
                    emoji: '🔄',
                    color: const Color(0xFF42A5F5),
                    loading: _syncing,
                    onTap: _syncNow,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          // 退出登录
          KidButton(
            label: '退出登录',
            emoji: '🚪',
            color: const Color(0xFFEF5350),
            onTap: _logout,
          ),
          const SizedBox(height: 20),
          Center(
            child: Text('小步成长 正式版 V${AppConfig.appVersion} · 孩子端',
                style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ),
        ],
      ),
    );
  }
}
