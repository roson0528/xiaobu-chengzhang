import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/kid_widgets.dart';

/// 情绪打卡：每天可选记录心情（开心 / 一般 / 疲惫），帮助家长了解状态。
class MoodPage extends StatefulWidget {
  const MoodPage({super.key});

  @override
  State<MoodPage> createState() => _MoodPageState();
}

class _MoodPageState extends State<MoodPage> {
  final TextEditingController _noteCtrl = TextEditingController();
  String? _selected;
  bool _submitting = false;

  static const _moods = [
    {'value': 'happy', 'label': '开心', 'emoji': '😄'},
    {'value': 'ok', 'label': '一般', 'emoji': '😐'},
    {'value': 'tired', 'label': '疲惫', 'emoji': '😩'},
  ];

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void dispose() {
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final mood = _selected;
    if (mood == null) {
      _toast('先选一个今天的心情吧');
      return;
    }
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    setState(() => _submitting = true);
    final label = _moods.firstWhere((m) => m['value'] == mood)['label'] as String;
    final note = _noteCtrl.text.trim();
    final result = await SubmitHelper.submitRecord(
      url: '/checkins/$_childId',
      entityType: 'checkin',
      body: {
        'checkin_type': '心情',
        'subject': label,
        'content': note.isEmpty ? '今天心情：$label' : '今天心情：$label · $note',
        'duration': 0,
        'photo_path': '',
        'photo_paths': const <String>[],
        'created_at': DateTime.now().toIso8601String(),
      },
    );
    if (!mounted) return;
    _toast(result == 'ok' ? '今天的心情已记录，等待家长审核 ⏳' : '已保存，联网后自动同步');
    if (result == 'ok') {
      Navigator.of(context).pop();
    } else {
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE8F5E9),
      appBar: KidAppBar(title: '心情打卡', emoji: '🌈', color: const Color(0xFF43A047)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 8),
            const Text(
              '今天的心情怎么样？',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            const Text(
              '记录一下，让爸爸妈妈更了解你。',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _moods.map((m) {
                final selected = _selected == m['value'];
                return GestureDetector(
                  onTap: () => setState(() => _selected = m['value']),
                  child: AnimatedScale(
                    scale: selected ? 1.12 : 1.0,
                    duration: const Duration(milliseconds: 150),
                    child: Column(
                      children: [
                        Text(m['emoji'] as String, style: const TextStyle(fontSize: 52)),
                        const SizedBox(height: 6),
                        Text(
                          m['label'] as String,
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                            color: selected ? const Color(0xFF2E7D32) : Colors.black54,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 28),
            TextField(
              controller: _noteCtrl,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '想说的话（可选）',
                hintText: '今天发生了什么事呢？',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 24),
            KidButton(
              label: '记录心情',
              emoji: '💾',
              color: const Color(0xFF43A047),
              loading: _submitting,
              onTap: _submit,
            ),
          ],
        ),
      ),
    );
  }
}
