import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/kid_widgets.dart';

/// 阅读打卡：POST /api/v1/reading/{child_id}。
class ReadingPage extends StatefulWidget {
  const ReadingPage({super.key});

  @override
  State<ReadingPage> createState() => _ReadingPageState();
}

class _ReadingPageState extends State<ReadingPage> {
  final _bookName = TextEditingController();
  final _pages = TextEditingController();
  final _duration = TextEditingController();
  final _note = TextEditingController();
  bool _submitting = false;

  @override
  void dispose() {
    _bookName.dispose();
    _pages.dispose();
    _duration.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final childId = context.read<AuthService>().child?.id ?? '';
    if (childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    if (_bookName.text.trim().isEmpty) {
      _toast('请填写书名');
      return;
    }
    setState(() => _submitting = true);
    try {
      final pages = int.tryParse(_pages.text.trim()) ?? 0;
      final duration = int.tryParse(_duration.text.trim()) ?? 0;
      final note = _note.text.trim();
      final contentParts = <String>[];
      if (pages > 0) contentParts.add('读了 $pages 页');
      if (duration > 0) contentParts.add('时长 $duration 分钟');
      if (note.isNotEmpty) contentParts.add(note);
      final result = await SubmitHelper.submitRecord(
        url: '/checkins/$childId',
        entityType: 'checkin',
        body: {
          'checkin_type': '阅读',
          'subject': _bookName.text.trim(),
          'content': contentParts.isEmpty ? '阅读《${_bookName.text.trim()}》' : contentParts.join(' · '),
          'duration': duration,
          'photo_path': '',
          'photo_paths': const <String>[],
          'created_at': DateTime.now().toIso8601String(),
        },
      );
      if (!mounted) return;
      _toast(result == 'ok' ? '阅读打卡成功，等待家长审核 ⏳' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop();
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3E5F5),
      appBar: KidAppBar(title: '阅读打卡', emoji: '📚', color: const Color(0xFF8E24AA)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            KidTextField(label: '书名 *', hint: '今天读了哪本书？', controller: _bookName),
            const SizedBox(height: 14),
            KidTextField(label: '阅读页数', hint: '例如 20', controller: _pages, keyboardType: TextInputType.number),
            const SizedBox(height: 14),
            KidTextField(label: '阅读时长（分钟）', hint: '例如 30', controller: _duration, keyboardType: TextInputType.number),
            const SizedBox(height: 14),
            KidTextField(label: '读书笔记（可选）', hint: '写一句读后感吧', controller: _note, maxLines: 3),
            const SizedBox(height: 22),
            KidButton(
              label: '提交打卡',
              emoji: '📖',
              color: const Color(0xFF8E24AA),
              loading: _submitting,
              onTap: _submit,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}