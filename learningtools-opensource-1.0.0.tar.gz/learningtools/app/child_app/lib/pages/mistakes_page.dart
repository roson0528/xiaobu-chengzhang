import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../services/sync_service.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/photo_picker_field.dart';

/// 错题本：查看 / 拍照记录错题，支持「我又会了」复习 +1。
class MistakesPage extends StatefulWidget {
  const MistakesPage({super.key});

  @override
  State<MistakesPage> createState() => _MistakesPageState();
}

class _MistakesPageState extends State<MistakesPage> {
  List<Map<String, dynamic>> _records = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final childId = context.read<AuthService>().child?.id ?? '';
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final data = await ApiClient.instance.getJson('/mistakes/$childId') as List;
      setState(() {
        _records = data.cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _loading = false;
        _error = '加载失败，请检查网络';
      });
    }
  }

  Future<void> _review(Map<String, dynamic> record) async {
    final childId = context.read<AuthService>().child?.id ?? '';
    final id = record['id']?.toString() ?? '';
    // 乐观更新 mastery
    setState(() {
      _records = _records.map((r) {
        if (r['id'] == id) {
          r['mastery'] = ((r['mastery'] as num?)?.toInt() ?? 0) + 1;
          r['last_reviewed'] = DateTime.now().toIso8601String();
        }
        return r;
      }).toList();
    });
    try {
      await ApiClient.instance.postForm('/mistakes/$id/review?child_id=$childId', const {});
    } on ApiException catch (e) {
      if (e.isNetworkError) {
        await SyncService.instance.enqueueJsonPost(
          url: '/mistakes/$id/review?child_id=$childId',
          body: const {'_form': <String, dynamic>{}},
          entityType: 'mistake_review',
          entityId: id,
        );
        _toast('已记录，联网后自动同步');
      } else {
        _toast(e.message);
      }
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBE9E7),
      appBar: KidAppBar(
        title: '错题本',
        emoji: '📕',
        color: const Color(0xFFE53935),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFFE53935),
        foregroundColor: Colors.white,
        onPressed: () async {
          final added = await Navigator.of(context).push<bool>(
            MaterialPageRoute(builder: (_) => const _AddMistakeSheet()),
          );
          if (added == true) _load();
        },
        icon: const Icon(Icons.add_a_photo),
        label: const Text('记一道错题'),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return KidEmpty(emoji: '📡', text: _error!);
    }
    if (_records.isEmpty) {
      return const KidEmpty(emoji: '📕', text: '还没有错题，点右下角拍一道吧！');
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _records.length,
      itemBuilder: (context, i) {
        final r = _records[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEF9A9A),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        r['subject']?.toString() ?? '其他',
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    ),
                    const Spacer(),
                    Text(
                      '掌握度 ${r['mastery'] ?? 0}',
                      style: const TextStyle(fontSize: 13, color: Colors.grey),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  r['content']?.toString() ?? '',
                  style: const TextStyle(fontSize: 16, height: 1.4),
                ),
                if ((r['answer']?.toString() ?? '').isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text(
                    '✅ 答案：${r['answer']}',
                    style: const TextStyle(fontSize: 14, color: Color(0xFF2E7D32)),
                  ),
                ],
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: KidButton(
                        label: '我又会了',
                        emoji: '💪',
                        color: const Color(0xFF66BB6A),
                        onTap: () => _review(r),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _AddMistakeSheet extends StatefulWidget {
  const _AddMistakeSheet();

  @override
  State<_AddMistakeSheet> createState() => _AddMistakeSheetState();
}

class _AddMistakeSheetState extends State<_AddMistakeSheet> {
  String _subject = '数学';
  final _content = TextEditingController();
  final _answer = TextEditingController();
  File? _photo;
  bool _submitting = false;

  static const _subjects = ['语文', '数学', '英语', '科学', '其他'];

  @override
  void dispose() {
    _content.dispose();
    _answer.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final childId = context.read<AuthService>().child?.id ?? '';
    if (_content.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请填写错题内容'), behavior: SnackBarBehavior.floating),
      );
      return;
    }
    setState(() => _submitting = true);
    try {
      String? photoPath;
      if (_photo != null) {
        photoPath = await SubmitHelper.uploadPhoto(_photo!, childId: childId);
      }
      final result = await SubmitHelper.submitRecord(
        url: '/mistakes/$childId',
        entityType: 'mistake',
        body: {
          'subject': _subject,
          'content': _content.text.trim(),
          'answer': _answer.text.trim(),
          'photo_path': photoPath,
          'mastery': 0,
        },
      );
      if (!mounted) return;
      if (result == 'ok') {
        Navigator.of(context).pop(true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已保存，联网后自动同步'), behavior: SnackBarBehavior.floating),
        );
        Navigator.of(context).pop(true);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(e.message), behavior: SnackBarBehavior.floating),
      );
      setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBE9E7),
      appBar: KidAppBar(title: '记错题', emoji: '📝', color: const Color(0xFFE53935)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('科目', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: _subjects
                  .map((s) => ChoiceChip(
                        label: Text(s, style: const TextStyle(fontSize: 15)),
                        selected: _subject == s,
                        selectedColor: const Color(0xFFEF9A9A),
                        onSelected: (_) => setState(() => _subject = s),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 14),
            KidTextField(label: '错题内容 *', hint: '把题目或错误写下来', controller: _content, maxLines: 3),
            const SizedBox(height: 14),
            KidTextField(label: '正确答案（可选）', hint: '正确答案是什么？', controller: _answer, maxLines: 2),
            const SizedBox(height: 14),
            PhotoPickerField(onChanged: (f) => _photo = f),
            const SizedBox(height: 22),
            KidButton(
              label: '保存错题',
              emoji: '💾',
              color: const Color(0xFFE53935),
              loading: _submitting,
              onTap: _save,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}