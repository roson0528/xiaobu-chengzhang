import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/multi_photo_picker_field.dart';

/// 晨起打卡：说明起床后做了什么（阅读/晨练/练字等）并拍照提交，审核通过后奖励积分。
class MorningCheckinPage extends StatefulWidget {
  const MorningCheckinPage({super.key});

  @override
  State<MorningCheckinPage> createState() => _MorningCheckinPageState();
}

class _MorningCheckinPageState extends State<MorningCheckinPage> {
  final _content = TextEditingController();
  final List<File> _photos = [];
  bool _submitting = false;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  @override
  void dispose() {
    _content.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    if (_content.text.trim().isEmpty) {
      _toast('请先写一写起床后做了什么');
      return;
    }
    if (_photos.isEmpty) {
      _toast('请拍一张晨起的照片');
      return;
    }
    setState(() => _submitting = true);
    try {
      final photoPaths = <String>[];
      for (final f in _photos) {
        final p = await SubmitHelper.uploadPhoto(f, childId: _childId);
        if (p != null && p.isNotEmpty) photoPaths.add(p);
      }
      final result = await SubmitHelper.submitRecord(
        url: '/checkins/$_childId',
        entityType: 'checkin',
        body: {
          'checkin_type': '晨起',
          'subject': '晨起',
          'content': _content.text.trim(),
          'duration': 0,
          'photo_path': photoPaths.isNotEmpty ? photoPaths.first : '',
          'photo_paths': photoPaths,
          'created_at': DateTime.now().toIso8601String(),
        },
      );
      if (!mounted) return;
      _toast(result == 'ok' ? '晨起打卡成功，等待家长审核 ⏳' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop();
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final hour = now.hour;
    final greet = hour < 6 ? '天还没亮呢，真早呀！' : (hour < 10 ? '早上好！' : (hour < 13 ? '中午好！' : '今天也要加油哦！'));
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8E1),
      appBar: KidAppBar(title: '晨起打卡', emoji: '🌅', color: const Color(0xFFFB8C00)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text('🌅 $greet', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('写一写起床后做了什么，再拍张照片提交，审核通过后可获得积分。',
                style: TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 16),
            TextField(
              controller: _content,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: '起床后做了什么 *',
                hintText: '比如：起来阅读了 20 分钟 / 晨练跑步 / 练字……',
                border: OutlineInputBorder(),
                filled: true,
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 16),
            const Text('拍张照片（只能拍摄）', style: TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 8),
            MultiPhotoPickerField(
              cameraOnly: true,
              onChanged: (files) {
                _photos
                  ..clear()
                  ..addAll(files);
              },
            ),
            const SizedBox(height: 22),
            KidButton(
              label: '提交晨起打卡',
              emoji: '🌞',
              color: const Color(0xFFFB8C00),
              loading: _submitting,
              onTap: _submit,
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
