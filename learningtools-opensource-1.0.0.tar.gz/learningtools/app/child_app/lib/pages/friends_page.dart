import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/kid_widgets.dart';
import 'friend_chat_page.dart';
import 'friend_growth_page.dart';

/// 我的好友：好友列表 / 加好友 / 申请记录。
class FriendsPage extends StatefulWidget {
  const FriendsPage({super.key});

  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: const Color(0xFFFFF3E0),
        appBar: AppBar(
          backgroundColor: const Color(0xFFFF7043),
          foregroundColor: Colors.white,
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('👫', style: TextStyle(fontSize: 24)),
              SizedBox(width: 8),
              Text('我的好友', style: TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            tabs: [
              Tab(text: '👫 好友'),
              Tab(text: '🔍 加好友'),
              Tab(text: '📋 申请记录'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _FriendsListTab(),
            _AddFriendTab(),
            _RequestsTab(),
          ],
        ),
      ),
    );
  }
}

/// 好友列表 Tab。
class _FriendsListTab extends StatefulWidget {
  const _FriendsListTab();

  @override
  State<_FriendsListTab> createState() => _FriendsListTabState();
}

class _FriendsListTabState extends State<_FriendsListTab> {
  List<FriendChild> _friends = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final data = await ApiClient.instance.getJson('/friends/$_childId') as List;
      setState(() {
        _friends = data
            .map((e) => FriendChild.fromJson((e as Map).cast<String, dynamic>()))
            .toList();
        _loading = false;
      });
    } on ApiException catch (e) {
      setState(() {
        _loading = false;
        _error = e.message;
      });
    }
  }

  void _openChat(FriendChild f) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => FriendChatPage(friend: f)),
    );
  }

  void _openGrowth(FriendChild f) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => FriendGrowthPage(friend: f)),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _friends.isEmpty) {
      return ListView(
        children: [const SizedBox(height: 60), KidEmpty(emoji: '📡', text: _error!)],
      );
    }
    if (_friends.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 60),
          KidEmpty(emoji: '👫', text: '还没有好友，去「加好友」认识新朋友吧！'),
        ],
      );
    }
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
          child: Text(
            '👆 点一下聊天 · 长按或点 ✨ 看TA的成长',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _friends.length,
            itemBuilder: (_, i) {
              final f = _friends[i];
              return Card(
                margin: const EdgeInsets.only(bottom: 12),
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                child: ListTile(
                  onTap: () => _openChat(f),
                  onLongPress: () => _openGrowth(f),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: const CircleAvatar(
                    radius: 24,
                    backgroundColor: Color(0xFFFFF3E0),
                    child: Text('👦', style: TextStyle(fontSize: 26)),
                  ),
                  title: Text(
                    f.name,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    f.grade > 0 ? '${f.grade}年级' : '我的小伙伴',
                    style: const TextStyle(fontSize: 13, color: Colors.grey),
                  ),
                  trailing: IconButton(
                    tooltip: '看TA的成长',
                    icon: const Icon(Icons.auto_awesome, color: Color(0xFFFF7043)),
                    onPressed: () => _openGrowth(f),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// 加好友 Tab。
class _AddFriendTab extends StatefulWidget {
  const _AddFriendTab();

  @override
  State<_AddFriendTab> createState() => _AddFriendTabState();
}

class _AddFriendTabState extends State<_AddFriendTab> {
  final _input = TextEditingController();
  List<FriendChild> _results = [];
  final Set<String> _requested = {};
  bool _searching = false;
  bool _searched = false;

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _search() async {
    final kw = _input.text.trim();
    if (kw.isEmpty) {
      _toast('先输入小伙伴的姓名哦');
      return;
    }
    setState(() => _searching = true);
    try {
      final data = await ApiClient.instance
          .getJson('/friends/search', query: {'name': kw}) as List;
      setState(() {
        _results = data
            .map((e) => FriendChild.fromJson((e as Map).cast<String, dynamic>()))
            .where((f) => f.childId.isNotEmpty && f.childId != _childId) // 不能加自己
            .toList();
        _searched = true;
        _searching = false;
      });
    } on ApiException catch (e) {
      setState(() {
        _results = [];
        _searched = true;
        _searching = false;
      });
      _toast(e.message);
    }
  }

  Future<void> _sendRequest(FriendChild f) async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    try {
      await ApiClient.instance
          .postJson('/friends/$_childId/request', {'to_child': f.childId});
      if (!mounted) return;
      setState(() => _requested.add(f.childId));
      _toast('已发送申请，等对方家长同意');
    } on ApiException catch (e) {
      _toast(e.message);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '输入姓名找到小伙伴，点「加好友」发出申请，等TA的家长同意后就能一起玩啦！',
          style: TextStyle(fontSize: 13, color: Colors.grey),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                decoration: InputDecoration(
                  hintText: '输入姓名，比如：小明',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                onSubmitted: (_) => _search(),
              ),
            ),
            const SizedBox(width: 10),
            FilledButton.icon(
              onPressed: _searching ? null : _search,
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF7043)),
              icon: _searching
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.search),
              label: const Text('搜索'),
            ),
          ],
        ),
        const SizedBox(height: 20),
        if (_searched && !_searching && _results.isEmpty)
          const KidEmpty(emoji: '🔍', text: '没有找到这个名字的小伙伴'),
        ..._results.map((f) => _buildResultCard(f)),
      ],
    );
  }

  Widget _buildResultCard(FriendChild f) {
    final sent = _requested.contains(f.childId);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: const CircleAvatar(
          radius: 24,
          backgroundColor: Color(0xFFFFF3E0),
          child: Text('👦', style: TextStyle(fontSize: 26)),
        ),
        title: Text(f.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        subtitle: Text(
          f.grade > 0 ? '${f.grade}年级' : '小伙伴',
          style: const TextStyle(fontSize: 13, color: Colors.grey),
        ),
        trailing: sent
            ? const Text(
                '已申请 ✅',
                style: TextStyle(fontSize: 13, color: Colors.green, fontWeight: FontWeight.bold),
              )
            : FilledButton(
                onPressed: () => _sendRequest(f),
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF7043)),
                child: const Text('加好友'),
              ),
      ),
    );
  }
}

/// 申请记录 Tab。
class _RequestsTab extends StatefulWidget {
  const _RequestsTab();

  @override
  State<_RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<_RequestsTab> {
  List<FriendRequest> _outgoing = [];
  List<FriendRequest> _incoming = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final data = await ApiClient.instance.getJson('/friends/$_childId/requests') as Map;
      List<FriendRequest> parse(dynamic v) =>
          (v as List?)
                  ?.map((e) => FriendRequest.fromJson((e as Map).cast<String, dynamic>()))
                  .toList() ??
              [];
      setState(() {
        _outgoing = parse(data['outgoing']);
        _incoming = parse(data['incoming']);
        _loading = false;
      });
    } on ApiException catch (e) {
      setState(() {
        _loading = false;
        _error = e.message;
      });
    }
  }

  /// 状态中文标签；incoming 的 pending 孩子端不能审批，只展示状态。
  String _statusLabel(FriendRequest r, {required bool isIncoming}) {
    switch (r.status) {
      case 'accepted':
        return '✅ 已通过';
      case 'rejected':
        return '❌ 已拒绝';
      case 'pending':
        return isIncoming ? '⏳ 等待对方家长审批' : '⏳ 待处理';
      default:
        return '⏳ 待处理';
    }
  }

  Widget _requestCard(FriendRequest r, {required String name, required bool isIncoming}) {
    final label = _statusLabel(r, isIncoming: isIncoming);
    final emoji = switch (r.status) {
      'accepted' => '✅',
      'rejected' => '❌',
      _ => '⏳',
    };
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: ListTile(
        leading: Text(emoji, style: const TextStyle(fontSize: 26)),
        title: Text(
          name.isEmpty ? '小伙伴' : name,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${label}${_shortTime(r.createdAt).isEmpty ? '' : ' · ${_shortTime(r.createdAt)}'}',
          style: const TextStyle(fontSize: 13, color: Colors.grey),
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 14, 4, 8),
        child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
      );

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _outgoing.isEmpty && _incoming.isEmpty) {
      return ListView(
        children: [const SizedBox(height: 60), KidEmpty(emoji: '📡', text: _error!)],
      );
    }
    if (_outgoing.isEmpty && _incoming.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 60),
          KidEmpty(emoji: '📋', text: '还没有申请记录'),
        ],
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_incoming.isNotEmpty) ...[
          _sectionTitle('📥 收到的申请'),
          ..._incoming.map((r) => _requestCard(r, name: r.fromName, isIncoming: true)),
        ],
        if (_outgoing.isNotEmpty) ...[
          _sectionTitle('📤 我发出的申请'),
          ..._outgoing.map((r) => _requestCard(r, name: r.toName, isIncoming: false)),
        ],
      ],
    );
  }

  String _shortTime(String iso) {
    if (iso.isEmpty || iso.length < 16) return '';
    return iso.replaceFirst('T', ' ').substring(5, 16);
  }
}
