import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../widgets/kid_widgets.dart';

/// 成长类型（顺序：获奖 / 成长瞬间 / 其它）。
const _growthTypes = [
  {'value': 'award', 'label': '🏆 获奖'},
  {'value': 'milestone', 'label': '🌱 成长瞬间'},
  {'value': 'other', 'label': '📝 其它'},
];

const _maxPhotos = 9;

String _typeEmoji(String type) {
  for (final t in _growthTypes) {
    if (t['value'] == type) return (t['label'] as String).split(' ').first;
  }
  return '📝';
}

String _typeLabel(String type) {
  for (final t in _growthTypes) {
    if (t['value'] == type) return t['label'] as String;
  }
  return '📝 其它';
}

/// 照片字节缓存：path -> 字节，避免每次重建都重新请求。
final Map<String, Uint8List> _photoCache = {};

/// 时间显示：2025-01-01T12:00:00 → 2025-01-01 12:00
String _formatTime(String raw) {
  final s = raw.replaceFirst('T', ' ');
  return s.length > 16 ? s.substring(0, 16) : s;
}

/// 成长页：朋友圈式时间线，可发照片、删除记录。
class GrowthPage extends StatefulWidget {
  const GrowthPage({super.key});

  @override
  State<GrowthPage> createState() => _GrowthPageState();
}

class _GrowthPageState extends State<GrowthPage> {
  List<GrowthRecord> _records = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final data = await ApiClient.instance.getJson('/growth/$_childId') as List;
      if (!mounted) return;
      setState(() {
        _records = data
            .map((e) => GrowthRecord.fromJson((e as Map).cast<String, dynamic>()))
            .toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e is ApiException ? e.message : '加载失败，请检查网络';
      });
    }
  }

  Future<void> _add() async {
    if (_childId.isEmpty) {
      _toast('还没有绑定孩子账号');
      return;
    }
    final result = await showModalBottomSheet<_GrowthDraft>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF3E5F5),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _GrowthComposer(childId: _childId),
    );
    if (result == null || !mounted) return;
    try {
      await ApiClient.instance.postJson('/growth/$_childId', {
        'type': result.type,
        'title': result.title,
        'content': result.content,
        'photo_paths': result.photoPaths,
      });
      if (!mounted) return;
      _toast(result.photoPaths.isEmpty ? '已记录成长点滴 🌱' : '发布成功！📸');
      await _load();
    } catch (e) {
      if (!mounted) return;
      _toast(e is ApiException ? e.message : '发布失败，请重试');
    }
  }

  Future<void> _delete(GrowthRecord r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除记录？'),
        content: Text('确定删除「${r.title}」吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await ApiClient.instance.delete('/growth/$_childId/${r.id}');
      if (!mounted) return;
      _toast('已删除');
      await _load();
    } catch (e) {
      if (!mounted) return;
      _toast(e is ApiException ? e.message : '删除失败，请重试');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3E5F5),
      appBar: KidAppBar(
        title: '成长记录',
        emoji: '🌱',
        color: const Color(0xFFAB47BC),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: RefreshIndicator(onRefresh: _load, child: _buildBody()),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: const Color(0xFFAB47BC),
        foregroundColor: Colors.white,
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('发布', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _records.isEmpty) {
      return ListView(
        children: [const SizedBox(height: 80), KidEmpty(emoji: '📡', text: _error!)],
      );
    }
    if (_records.isEmpty) {
      return ListView(
        children: const [
          SizedBox(height: 60),
          KidEmpty(emoji: '🌱', text: '还没有成长记录，点右下角「发布」记录一条吧！'),
        ],
      );
    }
    final items = List<Widget>.generate(_records.length, (i) {
      final r = _records[i];
      return _RecordCard(
        record: r,
        childId: _childId,
        onDelete: () => _delete(r),
      );
    });
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 88),
      children: items,
    );
  }
}

/// 朋友圈卡片：头部 emoji + 标题 + 时间，正文，照片区。
class _RecordCard extends StatelessWidget {
  final GrowthRecord record;
  final String childId;
  final VoidCallback onDelete;

  const _RecordCard({
    required this.record,
    required this.childId,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final photos = record.photoPaths.where((p) => p.trim().isNotEmpty).toList();
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      color: Colors.white,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onLongPress: onDelete,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: const Color(0xFFF3E5F5),
                    child: Text(_typeEmoji(record.type), style: const TextStyle(fontSize: 24)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          record.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '${_typeLabel(record.type).split(' ').last} · ${_formatTime(record.createdAt)}',
                          style: const TextStyle(fontSize: 12, color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.grey),
                    tooltip: '删除',
                    onPressed: onDelete,
                  ),
                ],
              ),
              if (record.content.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  record.content,
                  style: const TextStyle(fontSize: 15, height: 1.4, color: Colors.black87),
                ),
              ],
              if (photos.isNotEmpty) ...[
                const SizedBox(height: 10),
                _PhotoGrid(paths: photos, childId: childId),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// 照片九宫格（最多显示 _maxPhotos 张，超出显示 +N）。
class _PhotoGrid extends StatelessWidget {
  final List<String> paths;
  final String childId;

  const _PhotoGrid({required this.paths, required this.childId});

  static const double _size = 92;

  @override
  Widget build(BuildContext context) {
    final shown = paths.take(_maxPhotos).toList();
    final extra = paths.length - shown.length;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final p in shown)
          GestureDetector(
            onTap: () => _viewPhoto(context, p),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: SizedBox(
                width: _size,
                height: _size,
                child: _RecordPhoto(path: p, childId: childId),
              ),
            ),
          ),
        if (extra > 0)
          Container(
            width: _size,
            height: _size,
            decoration: BoxDecoration(
              color: const Color(0xFFF3E5F5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                '+$extra',
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF8E24AA),
                ),
              ),
            ),
          ),
      ],
    );
  }

  void _viewPhoto(BuildContext context, String path) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => _RecordPhoto(path: path, childId: childId, fullscreen: true),
      ),
    );
  }
}

/// 单张照片：带缓存加载，加载失败显示 🖼️ 占位。
class _RecordPhoto extends StatefulWidget {
  final String path;
  final String childId;
  final bool fullscreen;

  const _RecordPhoto({
    required this.path,
    required this.childId,
    this.fullscreen = false,
  });

  @override
  State<_RecordPhoto> createState() => _RecordPhotoState();
}

class _RecordPhotoState extends State<_RecordPhoto> {
  Uint8List? _bytes;
  bool _loading = true;
  bool _failed = false;
  int _quarterTurns = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cached = _photoCache[widget.path];
    if (cached != null) {
      if (mounted) {
        setState(() {
          _bytes = cached;
          _loading = false;
        });
      }
      return;
    }
    try {
      final raw = await ApiClient.instance.getBytes(
        '/growth/${widget.childId}/photo?path=${Uri.encodeComponent(widget.path)}',
      );
      if (!mounted) return;
      if (raw.isEmpty) {
        // 空响应视为加载失败，避免 Image.memory 解码报错
        setState(() {
          _failed = true;
          _loading = false;
        });
        return;
      }
      final bytes = Uint8List.fromList(raw);
      _photoCache[widget.path] = bytes;
      setState(() {
        _bytes = bytes;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _failed = true;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final bytes = _bytes;
    if (widget.fullscreen) {
      return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black,
          foregroundColor: Colors.white,
          title: const Text('查看照片', style: TextStyle(fontSize: 16)),
          actions: [
            IconButton(
              icon: const Icon(Icons.screen_rotation),
              tooltip: '横竖屏切换',
              onPressed: () => setState(() => _quarterTurns = (_quarterTurns + 1) % 4),
            ),
          ],
        ),
        body: Center(
          child: bytes == null
              ? (_failed
                  ? const Text('🖼️ 图片加载失败', style: TextStyle(color: Colors.white70, fontSize: 16))
                  : const CircularProgressIndicator())
              : RotatedBox(
                  quarterTurns: _quarterTurns,
                  child: InteractiveViewer(
                    minScale: 0.5,
                    maxScale: 4,
                    child: Center(
                      child: Image.memory(bytes, fit: BoxFit.contain, gaplessPlayback: true),
                    ),
                  ),
                ),
        ),
      );
    }
    if (bytes != null) {
      final placeholder = Container(
        color: const Color(0xFFF5F5F5),
        alignment: Alignment.center,
        child: const Text('🖼️', style: TextStyle(fontSize: 30)),
      );
      return Image.memory(
        bytes,
        fit: BoxFit.cover,
        gaplessPlayback: true,
        errorBuilder: (_, __, ___) => placeholder,
      );
    }
    if (_loading && !_failed) {
      return Container(
        color: const Color(0xFFF5F5F5),
        child: const Center(
          child: SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(strokeWidth: 2.5),
          ),
        ),
      );
    }
    // 加载失败占位
    return Container(
      color: const Color(0xFFF5F5F5),
      alignment: Alignment.center,
      child: const Text('🖼️', style: TextStyle(fontSize: 30)),
    );
  }
}

/// 发布草稿。
class _GrowthDraft {
  final String type;
  final String title;
  final String content;
  final List<String> photoPaths;

  const _GrowthDraft(this.type, this.title, this.content, this.photoPaths);
}

/// 发布底部弹窗：类型 / 标题 / 详情 / 选照片（最多 9 张）。
class _GrowthComposer extends StatefulWidget {
  final String childId;

  const _GrowthComposer({required this.childId});

  @override
  State<_GrowthComposer> createState() => _GrowthComposerState();
}

class _GrowthComposerState extends State<_GrowthComposer> {
  String _type = 'award';
  final _title = TextEditingController();
  final _content = TextEditingController();
  final List<File> _photos = [];
  bool _uploading = false;

  @override
  void dispose() {
    _title.dispose();
    _content.dispose();
    super.dispose();
  }

  /// 选择来源（拍照 / 相册），再调用 PhotoHelper 选一张。
  Future<void> _addPhoto() async {
    if (_photos.length >= _maxPhotos) {
      _toast('最多选择 $_maxPhotos 张照片哦');
      return;
    }
    final source = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Text('📷', style: TextStyle(fontSize: 26)),
              title: const Text('拍照'),
              onTap: () => Navigator.pop(ctx, 'camera'),
            ),
            ListTile(
              leading: const Text('🖼️', style: TextStyle(fontSize: 26)),
              title: const Text('从相册选择'),
              onTap: () => Navigator.pop(ctx, 'gallery'),
            ),
          ],
        ),
      ),
    );
    if (source == null || !mounted) return;
    final file = await PhotoHelper.pick(
      camera: source == 'camera',
      gallery: source == 'gallery',
    );
    if (file == null || !mounted) return;
    setState(() {
      if (_photos.length < _maxPhotos) _photos.add(file);
    });
  }

  void _removePhoto(int index) {
    if (_uploading) return;
    setState(() => _photos.removeAt(index));
  }

  /// 发布：逐张上传照片 → 返回草稿（含 photo_paths），由页面创建记录。
  Future<void> _publish() async {
    final title = _title.text.trim();
    if (title.isEmpty) {
      _toast('请填写标题');
      return;
    }
    if (_uploading) return;
    setState(() => _uploading = true);
    try {
      final paths = <String>[];
      for (final f in _photos) {
        final resp = await ApiClient.instance
            .uploadFile('/growth/${widget.childId}/photo', f, const {});
        final p = resp is Map ? resp['path']?.toString() : null;
        if (p != null && p.isNotEmpty) paths.add(p);
      }
      if (!mounted) return;
      Navigator.of(context).pop(
        _GrowthDraft(_type, title, _content.text.trim(), paths),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _uploading = false);
      _toast(e is ApiException ? e.message : '发布失败，请重试');
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('📝 发布成长', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: _uploading ? null : () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _growthTypes.map((t) {
                return ChoiceChip(
                  label: Text(t['label'] as String),
                  selected: _type == t['value'],
                  selectedColor: const Color(0xFFCE93D8),
                  onSelected: _uploading
                      ? null
                      : (_) => setState(() => _type = t['value'] as String),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
            KidTextField(label: '标题', hint: '比如：数学竞赛一等奖', controller: _title),
            const SizedBox(height: 14),
            KidTextField(label: '详情（可选）', hint: '写几句吧', controller: _content, maxLines: 3),
            const SizedBox(height: 16),
            Text(
              '📷 照片（最多 $_maxPhotos 张）',
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            _buildPhotoPicker(),
            const SizedBox(height: 18),
            KidButton(
              label: '发布',
              emoji: '🚀',
              color: const Color(0xFFAB47BC),
              loading: _uploading,
              onTap: _uploading ? null : _publish,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotoPicker() {
    const size = 80.0;
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (var i = 0; i < _photos.length; i++)
          Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: SizedBox(
                  width: size,
                  height: size,
                  child: Image.file(_photos[i], fit: BoxFit.cover),
                ),
              ),
              Positioned(
                top: 2,
                right: 2,
                child: GestureDetector(
                  onTap: () => _removePhoto(i),
                  child: Container(
                    decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                    padding: const EdgeInsets.all(3),
                    child: const Icon(Icons.close, size: 14, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        if (_photos.length < _maxPhotos)
          GestureDetector(
            onTap: _uploading ? null : _addPhoto,
            child: Container(
              width: size,
              height: size,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFCE93D8), width: 2),
              ),
              child: const Center(child: Text('➕', style: TextStyle(fontSize: 28))),
            ),
          ),
      ],
    );
  }
}