import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../config.dart';
import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/submit_helper.dart';
import '../widgets/focus_session_view.dart';
import '../widgets/photo_view_page.dart';
import '../widgets/submitted_photo_grid.dart';
import '../widgets/kid_widgets.dart';
import '../widgets/multi_photo_picker_field.dart';

/// 今日文武任务详情：查看任务说明 → 开始任务（专注模式）→ 拍照提交。
class TaskDetailPage extends StatefulWidget {
  final TaskItem task;

  const TaskDetailPage({super.key, required this.task});

  @override
  State<TaskDetailPage> createState() => _TaskDetailPageState();
}

enum _Phase { detail, submit }

class _TaskDetailPageState extends State<TaskDetailPage> {
  _Phase _phase = _Phase.detail;
  final List<File> _photos = [];
  bool _submitting = false;

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _startTask() async {
    // 劳动 / 运动等体力类任务不需要专注模式，直接进入拍照提交。
    if (widget.task.isPhysical) {
      setState(() => _phase = _Phase.submit);
      _toast('开始任务啦！做完记得拍照提交 📷');
      return;
    }
    final minutes = widget.task.plannedDuration > 0
        ? widget.task.plannedDuration
        : AppConfig.defaultFocusMinutes;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => FocusSessionView(
          durationMinutes: minutes,
          taskId: widget.task.id,
          onFinished: () => Navigator.of(context).pop(),
        ),
      ),
    );
    if (!mounted) return;
    setState(() => _phase = _Phase.submit);
    _toast('任务专注结束，请拍照提交任务');
  }

  Future<void> _submit() async {
    if (_childId.isEmpty) {
      _toast('未关联孩子档案，请重新登录');
      return;
    }
    if (widget.task.photoRequired && _photos.isEmpty) {
      _toast('请拍摄任务完成照片');
      return;
    }
    setState(() => _submitting = true);
    try {
      final photoPaths = <String>[];
      for (final f in _photos) {
        final p = await SubmitHelper.uploadPhoto(f, childId: _childId);
        if (p != null && p.isNotEmpty) photoPaths.add(p);
      }
      final url = '/tasks/${widget.task.id}/complete?child_id=$_childId';
      final result = await SubmitHelper.submitRecord(
        url: url,
        entityType: 'task_complete',
        body: {
          'photo_paths': photoPaths,
          'photo_path': photoPaths.isNotEmpty ? photoPaths.first : '',
          'completed_at': DateTime.now().toIso8601String(),
        },
      );
      if (!mounted) return;
      _toast(result == 'ok' ? '任务完成！🌟' : '已保存，联网后自动同步');
      if (result == 'ok') {
        Navigator.of(context).pop(true);
      } else {
        setState(() => _submitting = false);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      _toast(e.message);
      setState(() => _submitting = false);
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.task;
    return Scaffold(
      backgroundColor: const Color(0xFFFFF8F0),
      appBar: KidAppBar(title: '任务说明', emoji: '📋', color: const Color(0xFFFF7043)),
      body: _phase == _Phase.detail ? _buildDetail(t) : _buildSubmit(t),
    );
  }

  Widget _buildDetail(TaskItem t) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          _infoRow('📚 科目', t.subject.isNotEmpty ? t.subject : '未指定'),
          _infoRow('🏅 难度', '${t.difficultyLabel}${t.isRecurring ? ' · 循环任务' : ''}'),
          _infoRow('⏱ 预计时长', t.plannedDuration > 0 ? '${t.plannedDuration} 分钟' : '未指定'),
          if (t.plannedStart.isNotEmpty) _infoRow('🕐 开始时间', t.plannedStart),
          if (t.taskType.isNotEmpty) _infoRow('📝 类型', t.taskType),
          _infoRow('🌐 上网', t.isPhysical
              ? '本任务无需专注模式'
              : (t.needNetwork ? '专注期间可以上网' : '专注期间不能上网')),
          if (t.holiday) ...[
            const SizedBox(height: 12),
            _holidayBanner(t),
          ],
          if (t.isHomework && (t.content.isNotEmpty || t.attachments.isNotEmpty)) ...[
            const SizedBox(height: 12),
            _homeworkCard(t),
          ],
          if (t.penaltyPoints > 0) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF3E0),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                '未按时完成将扣除 ${t.penaltyPoints} 积分',
                style: const TextStyle(fontSize: 14, color: Color(0xFFE65100), fontWeight: FontWeight.w600),
              ),
            ),
          ],
          const SizedBox(height: 16),
          if (t.status == 'completed') ...[
            _reviewStatusCard(t),
            if (t.completedPhotos.isNotEmpty) ...[
              const SizedBox(height: 14),
              const Text('我提交的照片', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              SubmittedPhotoGrid(paths: t.completedPhotos, childId: _childId),
            ],
          ] else if (t.reviewStatus == 'rejected') ...[
            // 被驳回（退回未完成）：查看驳回原因与上次提交照片，可继续重新提交
            _reviewStatusCard(t),
            if (t.completedPhotos.isNotEmpty) ...[
              const SizedBox(height: 14),
              const Text('被驳回的提交照片', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              SubmittedPhotoGrid(paths: t.completedPhotos, childId: _childId),
            ],
          ] else ...[
            Text(
              t.isHomework
                  ? '点「写作业」进入专注模式，写完拍照提交，家长会给你检查。'
                  : t.isPhysical
                      ? '点「开始任务」后直接去做，做完拍照提交给家长看。'
                      : '点「开始任务」后进入专注模式，坚持到任务完成，最后拍照提交。',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 20),
            KidButton(
              label: t.isHomework ? '写作业' : '开始任务',
              emoji: t.isHomework ? '✍️' : '▶️',
              color: const Color(0xFF66BB6A),
              onTap: _startTask,
            ),
          ],
          // 假期作业：假期里每天都可以再交一部分，只有家长审核通过才算写完
          if (t.holidayOpen && (t.status == 'completed' || t.reviewStatus == 'rejected')) ...[
            const SizedBox(height: 18),
            Text(
              t.reviewStatus == 'rejected'
                  ? '这部分让家长看看，改好再交一次也可以：'
                  : '今天又写了一些？随时可以再交一部分，家长会一起检查：',
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            KidButton(
              label: '继续交今天的部分',
              emoji: '📤',
              color: const Color(0xFF66BB6A),
              onTap: _startTask,
            ),
          ],
        ],
      ),
    );
  }

  /// 假期作业说明：假期区间 + 已交天数 + 规则。
  Widget _holidayBanner(TaskItem t) {
    final end = t.holidayEnd;
    String fmt(DateTime d) => '${d.month}月${d.day}日';
    final start = DateTime.tryParse(t.plannedDate);
    final range = (start != null && end != null)
        ? (t.holidayDays <= 1 ? fmt(start) : '${fmt(start)}~${fmt(end)}')
        : '';
    final days = t.submittedDays.length;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final left = end == null ? 0 : end.difference(today).inDays + 1;

    final lines = <String>[
      '这${t.isHomework ? '份作业' : '项任务'}是假期${t.isHomework ? '作业' : '任务'}${range.isEmpty ? '' : '（$range）'}',
      '假期里每天都可以交一部分，家长审核通过才算写完，之后就不用再交了',
      if (left > 0) '今天还在假期里，还剩 $left 天',
    ];
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFFB74D)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text('🏖️', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
              Text(t.isHomework ? '假期作业' : '假期任务',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Color(0xFFE65100))),
              const Spacer(),
              if (days > 0)
                Text('已交 $days 天',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Color(0xFF2E7D32))),
            ],
          ),
          const SizedBox(height: 6),
          for (final l in lines)
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text(l, style: const TextStyle(fontSize: 13, color: Color(0xFF8D6E63), height: 1.4)),
            ),
        ],
      ),
    );
  }

  /// 已提交任务的审核状态提示。
  Widget _reviewStatusCard(TaskItem t) {
    final (emoji, title, color) = switch (t.reviewStatus) {
      'approved' => ('✅', '家长已通过', const Color(0xFF2E7D32)),
      'rejected' => ('❌', '家长已驳回', const Color(0xFFC62828)),
      _ => t.holiday
          ? ('⏳', '已交 ${t.submittedDays.length} 天，等家长看看', const Color(0xFFF57C00))
          : ('⏳', '已提交，等待家长审核', const Color(0xFFF57C00)),
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withValues(alpha: 0.4)),
          ),
          child: Row(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 22)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color),
                ),
              ),
            ],
          ),
        ),
        if (t.reviewComment.isNotEmpty) ...[
          const SizedBox(height: 10),
          Text(
            '家长留言：${t.reviewComment}',
            style: TextStyle(fontSize: 14, color: color, height: 1.4),
          ),
        ],
        if (t.reviewStatus == 'rejected') ...[
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: KidButton(
              label: '重新提交',
              emoji: '🔄',
              color: const Color(0xFF66BB6A),
              onTap: _startTask,
            ),
          ),
        ],
      ],
    );
  }

  /// 作业任务：展示作业内容与附件。
  Widget _homeworkCard(TaskItem t) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFE3F2FD),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('📝 作业内容', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          if (t.content.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(t.content, style: const TextStyle(fontSize: 15, height: 1.4)),
          ],
          if (t.attachments.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final a in t.attachments) _homeworkAttachment(a),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _homeworkAttachment(MessageAttachment a) {
    if (a.type == 'image') {
      return FutureBuilder<Uint8List?>(
        future: _loadAttachmentBytes(a.path),
        builder: (context, snap) {
          final bytes = snap.data;
          if (bytes == null || bytes.isEmpty) {
            return const SizedBox(width: 84, height: 84, child: Center(child: Text('🖼️')));
          }
          return ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: GestureDetector(
              onTap: () => _previewBytes(bytes),
              child: Image.memory(bytes, width: 84, height: 84, fit: BoxFit.cover),
            ),
          );
        },
      );
    }
    return InkWell(
      onTap: () => _openAttachment(a),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.attach_file, size: 16, color: Color(0xFF1E88E5)),
            const SizedBox(width: 4),
            Flexible(
              child: Text(a.name.isEmpty ? '附件' : a.name,
                  overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
            ),
          ],
        ),
      ),
    );
  }

  Future<Uint8List?> _loadAttachmentBytes(String path) async {
    try {
      return Uint8List.fromList(await ApiClient.instance.getBytes(
        '/messages/$_childId/attachment?path=${Uri.encodeComponent(path)}',
      ));
    } catch (_) {
      return null;
    }
  }

  void _previewBytes(Uint8List bytes) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PhotoViewPage(bytes: bytes, title: '查看图片')),
    );
  }

  Future<void> _openAttachment(MessageAttachment a) async {
    try {
      final bytes = await _loadAttachmentBytes(a.path);
      if (bytes == null || bytes.isEmpty) return;
      final dir = await getTemporaryDirectory();
      final name = (a.name.isEmpty ? 'attachment' : a.name).split(RegExp(r'[\\/]')).last;
      final file = File('${dir.path}/$name');
      await file.writeAsBytes(bytes, flush: true);
      await OpenFilex.open(file.path);
    } catch (e) {
      _toast('打开附件失败：$e');
    }
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 120, child: Text(label, style: const TextStyle(fontSize: 15, color: Colors.grey))),
          Expanded(
            child: Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }

  Widget _buildSubmit(TaskItem t) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(t.photoRequired ? '任务完成，拍照提交 📷' : '任务完成啦，确认提交 ✅',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(t.title, style: const TextStyle(fontSize: 15, color: Colors.grey)),
          const SizedBox(height: 18),
          if (t.photoRequired) ...[
            if (t.isPhysical)
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text('可拍摄或从相册上传多张照片',
                    style: TextStyle(fontSize: 13, color: Colors.grey)),
              ),
            MultiPhotoPickerField(
              cameraOnly: !t.isPhysical,
              onChanged: (files) {
                _photos
                  ..clear()
                  ..addAll(files);
              },
            ),
          ] else
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5E9),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                children: [
                  Text('✅', style: TextStyle(fontSize: 22)),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text('这项任务无需拍照，直接提交即可',
                        style: TextStyle(fontSize: 14, color: Colors.black54)),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 22),
          KidButton(
            label: '提交任务',
            emoji: '✅',
            color: const Color(0xFF66BB6A),
            loading: _submitting,
            onTap: _submit,
          ),
        ],
      ),
    );
  }
}
