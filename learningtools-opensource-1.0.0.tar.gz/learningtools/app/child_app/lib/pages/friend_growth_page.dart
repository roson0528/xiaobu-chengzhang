import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/models.dart';
import '../services/api_client.dart';
import '../services/auth_service.dart';
import '../services/local_db.dart';
import '../widgets/kid_widgets.dart';

const _typeEmojis = {
  'award': '🏆',
  'mistake': '😔',
  'milestone': '🌱',
  'other': '📝',
};

/// 好友成长：查看好友公开的成长记录（朋友圈式卡片 + 照片网格）。
class FriendGrowthPage extends StatefulWidget {
  final FriendChild friend;

  const FriendGrowthPage({super.key, required this.friend});

  @override
  State<FriendGrowthPage> createState() => _FriendGrowthPageState();
}

class _FriendGrowthPageState extends State<FriendGrowthPage> {
  List<GrowthRecord> _records = [];
  bool _loading = true;
  String? _error;
  final Map<String, Uint8List> _photoCache = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _childId => context.read<AuthService>().child?.id ?? '';

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    if (_childId.isEmpty) {
      setState(() => _loading = false);
      return;
    }
    try {
      final data = await ApiClient.instance
          .getJson('/friends/$_childId/friend/${widget.friend.childId}/growth') as List;
      // 本地缓存成长内容，离线可读已加载部分
      await LocalDb.instance.putCache('friend_growth_${widget.friend.childId}', {'items': data});
      setState(() {
        _records = data
            .map((e) => GrowthRecord.fromJson((e as Map).cast<String, dynamic>()))
            .toList();
        _loading = false;
      });
    } on ApiException catch (e) {
      // 离线降级：读本地缓存
      final cached = await LocalDb.instance.getCache('friend_growth_${widget.friend.childId}');
      final items = (cached?['items'] as List?) ?? const [];
      if (items.isNotEmpty) {
        setState(() {
          _records = items
              .map((e) => GrowthRecord.fromJson((e as Map).cast<String, dynamic>()))
              .toList();
          _loading = false;
        });
      } else {
        setState(() {
          _loading = false;
          _error = e.message;
        });
      }
    }
  }

  String _typeEmoji(String type) => _typeEmojis[type] ?? '📝';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF3E5F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFFAB47BC),
        foregroundColor: Colors.white,
        title: Text(
          'TA的成长 · ${widget.friend.name}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loading ? null : _load),
        ],
      ),
      body: RefreshIndicator(onRefresh: _load, child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _records.isEmpty) {
      return ListView(
        children: [const SizedBox(height: 80), KidEmpty(emoji: '📡', text: _error!)],
      );
    }
    if (_records.isEmpty) {
      return ListView(
        children: [
          const SizedBox(height: 60),
          KidEmpty(emoji: '🌱', text: '$_friendName还没有分享成长记录哦'),
        ],
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _records.length,
      itemBuilder: (_, i) => _recordCard(_records[i]),
    );
  }

  String get _friendName => widget.friend.name.isEmpty ? 'TA' : widget.friend.name;

  Widget _recordCard(GrowthRecord r) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(_typeEmoji(r.type), style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    r.title,
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
                Text(
                  _shortTime(r.createdAt),
                  style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                ),
              ],
            ),
            if (r.content.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(r.content, style: const TextStyle(fontSize: 14, color: Colors.black87)),
            ],
            if (r.photoPaths.isNotEmpty) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: r.photoPaths
                    .map((p) => ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 96,
                            height: 96,
                            child: _FriendPhoto(path: p, childId: _childId, cache: _photoCache),
                          ),
                        ))
                    .toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _shortTime(String iso) {
    if (iso.isEmpty || iso.length < 16) return '';
    return iso.replaceFirst('T', ' ').substring(5, 16);
  }
}

/// 单张好友成长照片：带缓存（Map<String, Uint8List>），加载中/失败显示 🖼️ 占位。
class _FriendPhoto extends StatefulWidget {
  final String path;
  final String childId;
  final Map<String, Uint8List> cache;

  const _FriendPhoto({
    required this.path,
    required this.childId,
    required this.cache,
  });

  @override
  State<_FriendPhoto> createState() => _FriendPhotoState();
}

class _FriendPhotoState extends State<_FriendPhoto> {
  Uint8List? _bytes;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _bytes = widget.cache[widget.path];
    if (_bytes == null) _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await ApiClient.instance.getBytes(
        '/growth/${widget.childId}/photo?path=${Uri.encodeComponent(widget.path)}',
      );
      if (bytes.isEmpty) {
        if (mounted) setState(() => _failed = true);
        return;
      }
      final data = Uint8List.fromList(bytes);
      widget.cache[widget.path] = data;
      if (mounted) setState(() => _bytes = data);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bytes = _bytes;
    if (_failed || bytes == null) {
      return Container(
        color: const Color(0xFFF5F5F5),
        child: const Center(child: Text('🖼️', style: TextStyle(fontSize: 30))),
      );
    }
    return Image.memory(bytes, fit: BoxFit.cover, gaplessPlayback: true);
  }
}
