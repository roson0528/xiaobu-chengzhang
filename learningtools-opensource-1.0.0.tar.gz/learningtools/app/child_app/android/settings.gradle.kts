pluginManagement {
    val flutterSdkPath =
        run {
            val properties = java.util.Properties()
            file("local.properties").inputStream().use { properties.load(it) }
            val flutterSdkPath = properties.getProperty("flutter.sdk")
            require(flutterSdkPath != null) { "flutter.sdk not set in local.properties" }
            flutterSdkPath
        }

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        // 本机 Maven Central 被 403，plugins.gradle.org 会 303 回源到
        // repo.maven.apache.org（同样 403），所以只保留阿里云镜像 + google()。
        // 阿里云 gradle-plugin 仓库即 plugins.gradle.org 的镜像。
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        google()
    }
}

// jni / camera 等插件会在 project 级声明仓库，与 Flutter 内置的
// FAIL_ON_PROJECT_REPOS 冲突，这里显式改为 PREFER_SETTINGS 并在 settings
// 声明统一仓库（本机 Maven Central 被 403，走阿里云镜像）。
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        // Flutter 引擎 AAR（插件通过 rootProject.allprojects 注入，PREFER_SETTINGS 下被忽略，
        // 必须在 settings 层显式声明）
        maven { url = uri("https://storage.googleapis.com/download.flutter.io") }
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        google()
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader") version "1.0.0"
    id("com.android.application") version "9.1.0" apply false
    id("org.jetbrains.kotlin.android") version "2.4.0" apply false
}

include(":app")
