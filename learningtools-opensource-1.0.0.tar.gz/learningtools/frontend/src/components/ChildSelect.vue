<template>
  <el-select
    :model-value="modelValue"
    placeholder="请选择孩子"
    clearable
    filterable
    style="width: 200px"
    @update:model-value="emit('update:modelValue', $event)"
  >
    <el-option
      v-for="c in childrenStore.children"
      :key="c.id"
      :label="c.name"
      :value="c.id"
    />
  </el-select>
</template>

<script setup lang="ts">
import { useChildrenStore } from '@/stores/children'

defineProps<{ modelValue: string }>()
const emit = defineEmits<{ (e: 'update:modelValue', v: string): void }>()
const childrenStore = useChildrenStore()
</script>