<template>
  <div class="app-menu">
    <div class="logo" @click="go('/dashboard')">
      <el-icon :size="24"><Reading /></el-icon>
      <span v-show="!collapsed" class="logo-text">小步成长</span>
    </div>
    <el-menu
      :default-active="activeMenu"
      :collapse="collapsed"
      :collapse-transition="false"
      router
      background-color="#001529"
      text-color="rgba(255,255,255,0.7)"
      active-text-color="#ffffff"
      class="app-menu-list"
      @select="emit('navigate')"
    >
      <el-menu-item v-for="item in visibleMenus" :key="item.path" :index="item.path">
        <el-icon><component :is="item.icon" /></el-icon>
        <template #title>{{ item.title }}</template>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  Reading,
  Odometer,
  Avatar,
  List,
  Stamp,
  Connection,
  VideoCamera,
  Trophy,
  Document,
  ChatDotRound,
  FolderOpened,
  Bell,
  Setting,
} from '@element-plus/icons-vue'
import type { Component } from 'vue'
import { useAuthStore } from '@/stores/auth'

defineProps<{ collapsed?: boolean }>()
const emit = defineEmits(['navigate'])

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()

const activeMenu = computed(() => route.path)

interface MenuItem {
  path: string
  title: string
  icon: Component
  adminOnly?: boolean
}

const menus: MenuItem[] = [
  { path: '/dashboard', title: '仪表盘', icon: Odometer },
  { path: '/children', title: '孩子管理', icon: Avatar },
  { path: '/tasks', title: '任务管理', icon: List },
  { path: '/checkins', title: '打卡审核', icon: Stamp },
  { path: '/friends', title: '好友管理', icon: Connection },
  { path: '/focus', title: '专注监控', icon: VideoCamera },
  { path: '/rewards', title: '奖励中心', icon: Trophy },
  { path: '/reports', title: '学习报告', icon: Document },
  { path: '/messages', title: '消息互动', icon: ChatDotRound },
  { path: '/chat-manage', title: '聊天记录管理', icon: FolderOpened, adminOnly: true },
  { path: '/notifications', title: '通知中心', icon: Bell },
  { path: '/admin', title: '管理后台', icon: Setting, adminOnly: true },
]

const visibleMenus = computed(() => (auth.isAdmin ? menus : menus.filter((m) => !m.adminOnly)))

function go(path: string) {
  router.push(path)
  emit('navigate')
}
</script>

<style scoped>
.app-menu {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: #001529;
}

.logo {
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #fff;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  flex-shrink: 0;
}

.app-menu-list {
  border-right: none;
  flex: 1;
  overflow-y: auto;
}

.app-menu-list :deep(.el-menu-item.is-active) {
  background: #1677ff !important;
}
</style>
