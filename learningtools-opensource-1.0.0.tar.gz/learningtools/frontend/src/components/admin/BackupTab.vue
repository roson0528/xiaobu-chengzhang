<template>
  <div v-loading="loading">
    <div class="tab-toolbar">
      <el-button type="primary" :icon="FolderAdd" :loading="creating" @click="createBackup">
        手动备份
      </el-button>
      <el-button :icon="Refresh" @click="load">刷新</el-button>
      <el-alert
        v-if="!auth.isSuperAdmin"
        type="info"
        :closable="false"
        class="inline-alert"
        title="恢复备份仅超级管理员可用"
      />
    </div>

    <el-table :data="backups" stripe>
      <el-table-column prop="backup_id" label="备份 ID" width="180" />
      <el-table-column label="创建时间" width="190">
        <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
      </el-table-column>
      <el-table-column label="文件数" width="90">
        <template #default="{ row }">{{ (row.files || []).length }}</template>
      </el-table-column>
      <el-table-column label="SQLite" width="80">
        <template #default="{ row }">
          <el-tag v-if="row.sqlite" type="success" size="small">有</el-tag>
          <el-tag v-else type="info" size="small">无</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="100" fixed="right">
        <template #default="{ row }">
          <el-button
            v-if="auth.isSuperAdmin"
            size="small"
            type="danger"
            link
            @click="restore(row)"
          >
            恢复
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-empty v-if="!backups.length" description="暂无备份，点击「手动备份」创建" />
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { FolderAdd, Refresh } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import * as adminApi from '@/api/admin'
import type { BackupItem } from '@/types'
import { confirmAction, formatDateTime } from '@/utils/date'

const auth = useAuthStore()
const backups = ref<BackupItem[]>([])
const loading = ref(false)
const creating = ref(false)

async function load() {
  loading.value = true
  try {
    backups.value = await adminApi.listBackups()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function createBackup() {
  creating.value = true
  try {
    const res = await adminApi.createBackup()
    ElMessage.success(`备份完成：${res.backup_id}（${res.files} 个文件）`)
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    creating.value = false
  }
}

async function restore(row: BackupItem) {
  const ok = await confirmAction(
    `确定从备份「${row.backup_id}」恢复吗？将覆盖当前数据库与 WebDAV 数据！`,
    '恢复确认',
    'warning',
  )
  if (!ok) return
  try {
    const res = await adminApi.restoreBackup(row.backup_id)
    ElMessage.success(`恢复完成：${res.restored_files} 个文件已恢复`)
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

onMounted(load)
</script>

<style scoped>
.tab-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.inline-alert {
  flex: 1;
  max-width: 420px;
}
</style>