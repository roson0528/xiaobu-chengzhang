<template>
  <div v-loading="loading">
    <div class="tab-toolbar">
      <el-radio-group v-model="limit" @change="load">
        <el-radio-button :value="100">最近 100 条</el-radio-button>
        <el-radio-button :value="200">最近 200 条</el-radio-button>
        <el-radio-button :value="500">最近 500 条</el-radio-button>
      </el-radio-group>
      <el-button :icon="Refresh" @click="load">刷新</el-button>
    </div>

    <el-table :data="logs" stripe size="small">
      <el-table-column prop="id" label="ID" width="70" />
      <el-table-column prop="actor" label="操作人" width="90">
        <template #default="{ row }">{{ row.actor || '-' }}</template>
      </el-table-column>
      <el-table-column prop="action" label="动作" width="150" show-overflow-tooltip />
      <el-table-column prop="target" label="目标" width="140" show-overflow-tooltip />
      <el-table-column prop="detail" label="详情" min-width="200" show-overflow-tooltip />
      <el-table-column label="时间" width="170">
        <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
      </el-table-column>
    </el-table>
    <el-empty v-if="!logs.length" description="暂无审计日志" />
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import * as adminApi from '@/api/admin'
import type { AuditLogItem } from '@/types'
import { formatDateTime } from '@/utils/date'

const logs = ref<AuditLogItem[]>([])
const loading = ref(false)
const limit = ref(200)

async function load() {
  loading.value = true
  try {
    logs.value = await adminApi.getAuditLog(limit.value)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.tab-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
</style>