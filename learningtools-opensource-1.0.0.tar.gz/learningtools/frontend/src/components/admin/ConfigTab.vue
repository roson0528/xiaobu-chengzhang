<template>
  <div v-loading="loading">
    <el-alert
      type="info"
      :closable="false"
      class="config-tip"
      title="全局配置以 JSON 格式保存到 WebDAV（system/config.json），请谨慎修改。"
    />
    <el-input
      v-model="configText"
      type="textarea"
      :rows="18"
      class="config-editor"
      placeholder="{}"
    />
    <div class="tab-toolbar">
      <el-button type="primary" :loading="saving" @click="save">保存配置</el-button>
      <el-button :icon="Refresh" @click="load">重新加载</el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import * as adminApi from '@/api/admin'

const configText = ref('')
const loading = ref(false)
const saving = ref(false)

async function load() {
  loading.value = true
  try {
    const config = await adminApi.getConfig()
    configText.value = JSON.stringify(config, null, 2)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function save() {
  let parsed: Record<string, unknown>
  try {
    parsed = JSON.parse(configText.value || '{}')
  } catch {
    ElMessage.error('JSON 格式不正确，请检查后重试')
    return
  }
  saving.value = true
  try {
    await adminApi.putConfig(parsed)
    ElMessage.success('配置已保存')
  } catch {
    // 错误提示由拦截器处理
  } finally {
    saving.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.config-tip {
  margin-bottom: 12px;
}
.config-editor {
  font-family: 'JetBrains Mono', Consolas, monospace;
  margin-bottom: 12px;
}
.tab-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
}
</style>