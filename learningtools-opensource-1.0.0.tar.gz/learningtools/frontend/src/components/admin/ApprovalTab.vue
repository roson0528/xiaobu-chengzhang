<template>
  <div v-loading="loading">
    <div class="tab-toolbar">
      <el-radio-group v-model="filter">
        <el-radio-button value="pending">待审批</el-radio-button>
        <el-radio-button value="rejected">已拒绝</el-radio-button>
        <el-radio-button value="disabled">已禁用</el-radio-button>
      </el-radio-group>
      <el-button :icon="Refresh" @click="load">刷新</el-button>
    </div>

    <el-table :data="filtered" stripe>
      <el-table-column prop="id" label="ID" width="70" />
      <el-table-column prop="username" label="用户名" min-width="120" />
      <el-table-column label="角色" width="120">
        <template #default="{ row }">
          <el-tag size="small">{{ roleLabel(row.role) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="email" label="邮箱" min-width="160">
        <template #default="{ row }">{{ row.email || '-' }}</template>
      </el-table-column>
      <el-table-column prop="phone" label="手机号" min-width="130">
        <template #default="{ row }">{{ row.phone || '-' }}</template>
      </el-table-column>
      <el-table-column label="注册时间" width="170">
        <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150" fixed="right">
        <template #default="{ row }">
          <el-button
            v-if="row.status === 'pending' || row.status === 'rejected'"
            size="small"
            type="success"
            link
            @click="handleApprove(row)"
          >
            通过
          </el-button>
          <el-button
            v-if="row.status === 'pending'"
            size="small"
            type="danger"
            link
            @click="handleReject(row)"
          >
            拒绝
          </el-button>
          <el-button
            v-if="row.status === 'disabled'"
            size="small"
            type="success"
            link
            @click="handleEnable(row)"
          >
            启用
          </el-button>
          <el-button
            v-if="row.status === 'active' || row.status === 'rejected'"
            size="small"
            type="warning"
            link
            @click="handleDisable(row)"
          >
            禁用
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-empty v-if="!filtered.length" description="该状态下暂无账号" />
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import * as usersApi from '@/api/users'
import type { User } from '@/types'
import { confirmAction, formatDateTime } from '@/utils/date'
import { roleLabel, statusText, statusType } from './adminUtils'

const users = ref<User[]>([])
const loading = ref(false)
const filter = ref('pending')

const filtered = computed(() => users.value.filter((u) => u.status === filter.value))

async function load() {
  loading.value = true
  try {
    users.value = await usersApi.listUsers()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function handleApprove(row: User) {
  const ok = await confirmAction(`确定通过账号「${row.username}」吗？`, '审批确认', 'info')
  if (!ok) return
  try {
    await usersApi.approveUser(row.id)
    ElMessage.success('已通过')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleReject(row: User) {
  const ok = await confirmAction(`确定拒绝账号「${row.username}」吗？`, '拒绝确认', 'warning')
  if (!ok) return
  try {
    await usersApi.rejectUser(row.id)
    ElMessage.success('已拒绝')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleEnable(row: User) {
  try {
    await usersApi.enableUser(row.id)
    ElMessage.success('已启用')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleDisable(row: User) {
  const ok = await confirmAction(`确定禁用账号「${row.username}」吗？`, '禁用确认', 'warning')
  if (!ok) return
  try {
    await usersApi.disableUser(row.id)
    ElMessage.success('已禁用')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

onMounted(load)
</script>

<style scoped>
.tab-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
</style>