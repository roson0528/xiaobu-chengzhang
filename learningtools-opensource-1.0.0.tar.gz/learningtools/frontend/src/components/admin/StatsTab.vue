<template>
  <div v-loading="loading">
    <el-row :gutter="16" class="stats-row">
      <el-col :xs="24" :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value">{{ stats.users ?? 0 }}</div>
          <div class="stat-label">用户总数</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #e6a23c">{{ stats.pending_users ?? 0 }}</div>
          <div class="stat-label">待审批用户</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :span="8">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #409eff">{{ stats.children ?? 0 }}</div>
          <div class="stat-label">孩子档案数</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16">
      <el-col :xs="24" :span="12">
        <el-card shadow="never">
          <template #header>用户角色分布</template>
          <EChart :option="roleOption" height="300px" />
        </el-card>
      </el-col>
      <el-col :xs="24" :span="12">
        <el-card shadow="never">
          <template #header>用户状态分布</template>
          <EChart :option="statusOption" height="300px" />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import type { EChartsOption } from 'echarts'
import EChart from '@/components/EChart.vue'
import * as adminApi from '@/api/admin'
import * as usersApi from '@/api/users'
import type { AdminStats, User } from '@/types'
import { roleLabel, statusText } from './adminUtils'

const stats = ref<AdminStats>({ users: 0, pending_users: 0, children: 0 })
const users = ref<User[]>([])
const loading = ref(false)

const roleOption = computed<EChartsOption>(() => ({
  tooltip: { trigger: 'item' },
  legend: { bottom: 0 },
  series: [
    {
      name: '角色',
      type: 'pie',
      radius: '60%',
      data: countBy(users.value, (u) => roleLabel(u.role)),
    },
  ],
}))

const statusOption = computed<EChartsOption>(() => ({
  tooltip: { trigger: 'item' },
  legend: { bottom: 0 },
  series: [
    {
      name: '状态',
      type: 'pie',
      radius: '60%',
      data: countBy(users.value, (u) => statusText(u.status)),
    },
  ],
}))

function countBy(list: User[], keyFn: (u: User) => string): Array<{ name: string; value: number }> {
  const map = new Map<string, number>()
  for (const u of list) {
    const k = keyFn(u)
    map.set(k, (map.get(k) || 0) + 1)
  }
  return [...map.entries()].map(([name, value]) => ({ name, value }))
}

async function load() {
  loading.value = true
  try {
    const [s, u] = await Promise.all([adminApi.getAdminStats(), usersApi.listUsers()])
    stats.value = s
    users.value = u
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.stats-row {
  margin-bottom: 16px;
}
</style>