export function roleLabel(role?: string): string {
  switch (role) {
    case 'super_admin':
      return '超级管理员'
    case 'family_admin':
      return '家庭管理员'
    case 'parent':
      return '家长'
    case 'child':
      return '孩子'
    case 'guest':
      return '访客'
    default:
      return role || '-'
  }
}

export function statusText(status?: string): string {
  switch (status) {
    case 'active':
      return '正常'
    case 'pending':
      return '待审批'
    case 'rejected':
      return '已拒绝'
    case 'disabled':
      return '已禁用'
    default:
      return status || '-'
  }
}

export function statusType(status?: string): 'success' | 'warning' | 'danger' | 'info' {
  switch (status) {
    case 'active':
      return 'success'
    case 'pending':
      return 'warning'
    case 'rejected':
    case 'disabled':
      return 'danger'
    default:
      return 'info'
  }
}