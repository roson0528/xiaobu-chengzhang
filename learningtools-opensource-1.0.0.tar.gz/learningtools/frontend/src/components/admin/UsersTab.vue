<template>
  <div v-loading="loading">
    <div class="tab-toolbar">
      <el-select v-model="statusFilter" placeholder="状态筛选" clearable style="width: 140px" @change="load">
        <el-option label="全部" value="" />
        <el-option label="正常" value="active" />
        <el-option label="待审批" value="pending" />
        <el-option label="已拒绝" value="rejected" />
        <el-option label="已禁用" value="disabled" />
      </el-select>
      <el-button :icon="Refresh" @click="load">刷新</el-button>
    </div>

    <el-table :data="filtered" stripe>
      <el-table-column prop="id" label="ID" width="70" />
      <el-table-column prop="username" label="用户名" min-width="120" />
      <el-table-column label="角色" width="120">
        <template #default="{ row }">
          <el-tag size="small">{{ roleLabel(row.role) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)" size="small">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="email" label="邮箱" min-width="150">
        <template #default="{ row }">{{ row.email || '-' }}</template>
      </el-table-column>
      <el-table-column prop="phone" label="手机号" min-width="120">
        <template #default="{ row }">{{ row.phone || '-' }}</template>
      </el-table-column>
      <el-table-column prop="family_id" label="家庭 ID" min-width="130">
        <template #default="{ row }">{{ row.family_id || '-' }}</template>
      </el-table-column>
      <el-table-column label="最近登录" width="170">
        <template #default="{ row }">{{ formatDateTime(row.last_login) }}</template>
      </el-table-column>
      <el-table-column label="存储配额(GB)" width="110">
        <template #default="{ row }">{{ row.quota_gb ?? 0 }}</template>
      </el-table-column>
      <el-table-column label="操作" width="220" fixed="right">
        <template #default="{ row }">
          <el-tooltip content="编辑" placement="top">
            <el-button size="small" link type="primary" :icon="Edit" @click="openEdit(row)" />
          </el-tooltip>
          <el-tooltip v-if="row.status === 'disabled'" content="启用" placement="top">
            <el-button size="small" link type="success" :icon="CircleCheck" @click="handleEnable(row)" />
          </el-tooltip>
          <el-tooltip
            v-else-if="row.status !== 'pending' && row.status !== 'rejected'"
            content="禁用"
            placement="top"
          >
            <el-button size="small" link type="warning" :icon="CircleClose" @click="handleDisable(row)" />
          </el-tooltip>
          <el-tooltip v-if="row.role === 'parent'" content="设置存储配额" placement="top">
            <el-button size="small" link type="primary" :icon="Coin" @click="openQuota(row)" />
          </el-tooltip>
          <el-tooltip v-if="auth.isSuperAdmin" content="删除" placement="top">
            <el-button size="small" link type="danger" :icon="Delete" @click="handleDelete(row)" />
          </el-tooltip>
          <el-tooltip v-if="auth.isSuperAdmin" content="改角色" placement="top">
            <el-button size="small" link type="info" :icon="UserIcon" @click="openRole(row)" />
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <el-empty v-if="!filtered.length" description="暂无用户" />

    <!-- 编辑用户 -->
    <el-dialog v-model="editVisible" title="编辑用户" width="420px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="邮箱">
          <el-input v-model="editForm.email" placeholder="选填" />
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="editForm.phone" placeholder="选填" />
        </el-form-item>
        <el-form-item label="家庭 ID">
          <el-input v-model="editForm.family_id" placeholder="选填" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="editVisible = false">取消</el-button>
        <el-button type="primary" :loading="editing" @click="submitEdit">保存</el-button>
      </template>
    </el-dialog>

    <!-- 改角色 -->
    <el-dialog v-model="roleVisible" title="修改角色" width="380px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="角色">
          <el-select v-model="roleForm.role" style="width: 100%">
            <el-option label="超级管理员" value="super_admin" />
            <el-option label="家庭管理员" value="family_admin" />
            <el-option label="家长" value="parent" />
            <el-option label="孩子" value="child" />
            <el-option label="访客" value="guest" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="roleVisible = false">取消</el-button>
        <el-button type="primary" :loading="changingRole" @click="submitRole">保存</el-button>
      </template>
    </el-dialog>

    <!-- 设置存储配额 -->
    <el-dialog v-model="quotaVisible" title="设置存储配额" width="400px" destroy-on-close>
      <el-form label-width="100px">
        <el-form-item label="账号">
          <span>{{ quotaForm.username }}</span>
        </el-form-item>
        <el-form-item label="配额 (GB)" required>
          <el-input-number v-model="quotaForm.quota_gb" :min="0" :max="10000" :step="1" style="width: 180px" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="quotaVisible = false">取消</el-button>
        <el-button type="primary" :loading="quotaSaving" @click="submitQuota">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { CircleCheck, CircleClose, Coin, Delete, Edit, Refresh, User as UserIcon } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import * as usersApi from '@/api/users'
import type { User } from '@/types'
import { confirmAction, formatDateTime } from '@/utils/date'
import { roleLabel, statusText, statusType } from './adminUtils'

const auth = useAuthStore()
const users = ref<User[]>([])
const loading = ref(false)
const statusFilter = ref('')

const filtered = computed(() => {
  if (!statusFilter.value) return users.value
  return users.value.filter((u) => u.status === statusFilter.value)
})

async function load() {
  loading.value = true
  try {
    users.value = await usersApi.listUsers()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function handleEnable(row: User) {
  try {
    await usersApi.enableUser(row.id)
    ElMessage.success('已启用')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleDisable(row: User) {
  const ok = await confirmAction(`确定禁用账号「${row.username}」吗？`, '禁用确认', 'warning')
  if (!ok) return
  try {
    await usersApi.disableUser(row.id)
    ElMessage.success('已禁用')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleDelete(row: User) {
  const ok = await confirmAction(
    `确定删除账号「${row.username}」(ID: ${row.id}) 吗？此操作不可恢复！`,
    '删除确认',
    'warning',
  )
  if (!ok) return
  try {
    await usersApi.deleteUser(row.id)
    ElMessage.success('已删除')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

// ---- 编辑 ----
const editVisible = ref(false)
const editing = ref(false)
const editForm = reactive({ id: 0, email: '', phone: '', family_id: '' })

function openEdit(row: User) {
  editForm.id = row.id
  editForm.email = row.email || ''
  editForm.phone = row.phone || ''
  editForm.family_id = row.family_id || ''
  editVisible.value = true
}

async function submitEdit() {
  editing.value = true
  try {
    await usersApi.updateUser(editForm.id, {
      email: editForm.email || undefined,
      phone: editForm.phone || undefined,
      family_id: editForm.family_id || undefined,
    })
    ElMessage.success('已保存')
    editVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    editing.value = false
  }
}

// ---- 改角色 ----
const roleVisible = ref(false)
const changingRole = ref(false)
const roleForm = reactive({ id: 0, role: 'parent' })

function openRole(row: User) {
  roleForm.id = row.id
  roleForm.role = row.role
  roleVisible.value = true
}

async function submitRole() {
  changingRole.value = true
  try {
    await usersApi.changeUserRole(roleForm.id, roleForm.role)
    ElMessage.success('角色已更新')
    roleVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    changingRole.value = false
  }
}

// ---- 存储配额 ----
const quotaVisible = ref(false)
const quotaSaving = ref(false)
const quotaForm = reactive({ id: 0, username: '', quota_gb: 0 })

function openQuota(row: User) {
  quotaForm.id = row.id
  quotaForm.username = row.username
  quotaForm.quota_gb = row.quota_gb ?? 0
  quotaVisible.value = true
}

async function submitQuota() {
  quotaSaving.value = true
  try {
    await usersApi.setUserQuota(quotaForm.id, quotaForm.quota_gb)
    ElMessage.success('配额已更新')
    quotaVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    quotaSaving.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.tab-toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
</style>