import { defineStore } from 'pinia'
import * as childrenApi from '@/api/children'
import type { Child } from '@/types'

export const useChildrenStore = defineStore('children', {
  state: () => ({
    children: [] as Child[],
    loaded: false,
    loading: false,
  }),
  getters: {
    firstChild: (s) => s.children[0] || null,
  },
  actions: {
    async ensureLoaded(force = false) {
      if (this.loaded && !force) return
      if (this.loading) return
      this.loading = true
      try {
        this.children = await childrenApi.listChildren()
        this.loaded = true
      } finally {
        this.loading = false
      }
    },
    async reload() {
      this.loaded = false
      await this.ensureLoaded(true)
    },
  },
})
