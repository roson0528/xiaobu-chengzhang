import { defineStore } from 'pinia'
import * as authApi from '@/api/auth'
import type { AuthUser, MeResult } from '@/types'

const TOKEN_KEY = 'lt_access_token'
const REFRESH_KEY = 'lt_refresh_token'
const USER_KEY = 'lt_user'

function loadUser(): AuthUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY)
    return raw ? (JSON.parse(raw) as AuthUser) : null
  } catch {
    return null
  }
}

export const useAuthStore = defineStore('auth', {
  state: () => ({
    accessToken: localStorage.getItem(TOKEN_KEY) || '',
    refreshToken: localStorage.getItem(REFRESH_KEY) || '',
    user: loadUser() as AuthUser | null,
  }),
  getters: {
    isLoggedIn: (s) => !!s.accessToken,
    role: (s) => s.user?.role || '',
    isAdmin: (s) => s.user?.role === 'super_admin' || s.user?.role === 'family_admin',
    isSuperAdmin: (s) => s.user?.role === 'super_admin',
    displayName: (s) => {
      if (!s.user) return ''
      return s.user.role === 'super_admin'
        ? `${s.user.username}（超级管理员）`
        : s.user.role === 'family_admin'
          ? `${s.user.username}（家庭管理员）`
          : `${s.user.username}（家长）`
    },
  },
  actions: {
    async login(username: string, password: string) {
      const result = await authApi.login({ username, password })
      this.accessToken = result.access_token
      this.refreshToken = result.refresh_token
      this.user = result.user
      localStorage.setItem(TOKEN_KEY, result.access_token)
      localStorage.setItem(REFRESH_KEY, result.refresh_token)
      localStorage.setItem(USER_KEY, JSON.stringify(result.user))
    },
    setMe(me: MeResult) {
      if (!this.user) return
      this.user = { ...this.user, ...me }
      localStorage.setItem(USER_KEY, JSON.stringify(this.user))
    },
    setAccessToken(token: string) {
      this.accessToken = token
      localStorage.setItem(TOKEN_KEY, token)
    },
    logout() {
      this.accessToken = ''
      this.refreshToken = ''
      this.user = null
      localStorage.removeItem(TOKEN_KEY)
      localStorage.removeItem(REFRESH_KEY)
      localStorage.removeItem(USER_KEY)
    },
  },
})
