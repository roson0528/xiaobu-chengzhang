import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/HomeView.vue'),
      meta: { public: true, title: '首页' },
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: { public: true, title: '登录' },
    },
    {
      path: '/',
      component: () => import('@/layouts/MainLayout.vue'),
      children: [
        {
          path: 'dashboard',
          name: 'dashboard',
          component: () => import('@/views/DashboardView.vue'),
          meta: { title: '仪表盘' },
        },
        {
          path: 'children',
          name: 'children',
          component: () => import('@/views/ChildrenView.vue'),
          meta: { title: '孩子管理' },
        },
        {
          path: 'tasks',
          name: 'tasks',
          component: () => import('@/views/TasksView.vue'),
          meta: { title: '任务管理' },
        },
        {
          path: 'checkins',
          name: 'checkins',
          component: () => import('@/views/CheckinsView.vue'),
          meta: { title: '打卡审核' },
        },
        {
          path: 'focus',
          name: 'focus',
          component: () => import('@/views/FocusView.vue'),
          meta: { title: '专注监控' },
        },
        {
          path: 'rewards',
          name: 'rewards',
          component: () => import('@/views/RewardsView.vue'),
          meta: { title: '奖励中心' },
        },
        {
          path: 'friends',
          name: 'friends',
          component: () => import('@/views/FriendsView.vue'),
          meta: { title: '好友管理' },
        },
        {
          path: 'reports',
          name: 'reports',
          component: () => import('@/views/ReportsView.vue'),
          meta: { title: '学习报告' },
        },
        {
          path: 'messages',
          name: 'messages',
          component: () => import('@/views/MessagesView.vue'),
          meta: { title: '消息互动' },
        },
        {
          path: 'chat-manage',
          name: 'chat-manage',
          component: () => import('@/views/ChatManageView.vue'),
          meta: { title: '聊天记录管理', admin: true },
        },
        {
          path: 'notifications',
          name: 'notifications',
          component: () => import('@/views/NotificationsView.vue'),
          meta: { title: '通知中心' },
        },
        {
          path: 'admin',
          name: 'admin',
          component: () => import('@/views/AdminView.vue'),
          meta: { title: '管理后台', admin: true },
        },
      ],
    },
    { path: '/:pathMatch(.*)*', redirect: '/dashboard' },
  ],
})

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (to.meta.public) {
    // 已登录用户访问首页/登录页时，直接进入管理后台（家长 App 内嵌 WebView 自动登录后也走这里）
    if (auth.isLoggedIn && (to.path === '/' || to.path === '/login')) {
      return { path: '/dashboard' }
    }
    return true
  }
  if (!auth.isLoggedIn) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  if (to.meta.admin && !auth.isAdmin) {
    return { path: '/dashboard' }
  }
  return true
})

router.afterEach((to) => {
  document.title = `${String(to.meta.title || '管理后台')} - 小步成长`
})

export default router