// 与后端 API 对应的类型定义（字段以 backend/app/routers 代码为准，可空字段做容错）

export interface AuthUser {
  id: number
  username: string
  role: string
  status: string
}

export interface LoginResult {
  access_token: string
  refresh_token: string
  token_type: string
  user: AuthUser
}

export interface MeResult {
  id: number
  username: string
  role: string
  email?: string | null
  phone?: string | null
  status: string
  family_id?: string | null
}

export interface User {
  id: number
  username: string
  role: string
  email?: string | null
  phone?: string | null
  status: string
  family_id?: string | null
  created_at?: string
  last_login?: string | null
  failed_attempts?: number
  locked_until?: string | null
  quota_gb?: number
}

export interface Child {
  id: string
  user_id?: number | null
  name: string
  grade?: number | null
  birthday?: string | null
  avatar?: string | null
  parent_ids?: string | null
  family_id?: string | null
  quota_mb?: number
  used_mb?: number
  photo_retention_days?: number
  video_retention_days?: number
  created_at?: string
}

export interface QuotaInfo {
  child_id: string
  quota_mb: number
  used_mb: number
}

/** 任务循环模式：none/daily 时 days 无意义（空数组）；weekly 时 days 为 1..7 */
export interface RepeatRule {
  type: 'none' | 'daily' | 'weekly'
  days: number[] // ISO 星期，1=周一 … 7=周日；仅 type==='weekly' 时有意义
}

export interface TaskItem {
  id?: string
  title: string
  subject?: string | null
  task_type?: string | null
  planned_date?: string | null
  planned_start?: string | null
  planned_duration?: number | null
  priority?: number
  difficulty?: string
  status?: string
  completed_at?: string | null
  repeat?: RepeatRule
  photo_required?: boolean
  penalty_points?: number
  reward_points?: number | null
  score?: number | null
  review_status?: string | null
  review_comment?: string | null
  completed_photo?: string | null
}

export interface WeeklyPlan {
  week: string
  tasks: TaskItem[]
  updated_at?: string
}

export interface TodayTasks {
  date: string
  tasks: TaskItem[]
}

export interface CheckinRecord {
  id: string
  checkin_type?: string
  subject?: string | null
  content?: string | null
  duration?: number | null
  photo_path?: string | null
  audio_path?: string | null
  video_path?: string | null
  status?: string
  review_comment?: string | null
  score?: number | null
  created_at?: string
}

export interface CheckinStats {
  total: number
  approved: number
  pending: number
}

/** 家长预设的打卡内容（孩子端选择打卡） */
export interface CheckinPreset {
  id: string
  title: string // 打卡内容标题，必填
  checkin_type: string // 作业/朗读/练字/家务/其他
  subject: string // 语文/数学/英语/科学/其他
  content?: string | null // 详细说明，可空
  duration: number // 建议时长(分钟)，可 0
  enabled: boolean // 是否启用（默认 true）
  repeat?: RepeatRule // 每天/每周（days 为 1..7）
  photo_required?: boolean // 是否需要拍照提交（默认 true）
  penalty_points?: number // 超时未完成扣分（0 不扣）
  need_network?: boolean // 是否需要联网：专注期间是否放开受管控设备的外网权限（默认 false）
  /** 假期作业/任务：在假期时长内持续存在，每天可交一部分，审核通过才算写完 */
  holiday?: boolean
  holiday_days?: number // 假期时长（天）
}

export interface FocusEvent {
  type: string
  timestamp?: string
  session_id?: string
}

export interface FocusSession {
  id: string
  child_id?: string
  started_at?: string
  ended_at?: string | null
  duration?: number
  task_id?: string
  task_name?: string
  distraction_count?: number
  photo_count?: number
  status?: string
  events?: FocusEvent[]
  photos?: string[]
  videos?: string[]
}

export interface PointRecord {
  points?: number
  reason?: string
  timestamp?: string
}

export interface PointsData {
  records: PointRecord[]
  /** 积分余额 */
  total: number
  /** 记录总条数（分页时用于展示与计算页数） */
  record_count?: number
  page?: number
  page_size?: number
  page_count?: number
}

export interface BadgeData {
  earned: unknown[]
}

export interface RankItem {
  child_id: string
  name?: string
  points?: number
  rank?: number
}

/** 消息附件（后端已返回，可能缺失）：type 为 image/audio/video/file */
export interface MessageAttachment {
  type?: string
  path?: string
  name?: string
  size?: number
}

export interface MessageItem {
  id: string
  sender_role?: string
  sender_name?: string
  content?: string
  read_at?: string | null
  created_at?: string
  attachments?: MessageAttachment[]
}

export interface NotificationItem {
  id: number
  user_id: number
  title?: string | null
  content?: string | null
  kind?: string
  read?: number
  created_at?: string
}

export interface ReportSummary {
  total_tasks?: number
  completed?: number
  completion_rate?: number
  total_study_minutes?: number
  total_fitness_minutes?: number
  focus_sessions?: number
  distraction_count?: number
}

export interface ScoringAnalysis {
  avg_task_score?: number | null
  avg_checkin_score?: number | null
  avg_score?: number | null
  level?: string
  distraction_count?: number
}

export interface Report {
  child_id?: string
  week?: string
  month?: string
  generated_at?: string
  summary?: ReportSummary
  scoring?: ScoringAnalysis
  subject_breakdown?: Record<string, number>
  daily_trend?: Record<string, number>
  suggestions?: string[]
}

/** 奖励目录：徽章类型 + 积分兑换内容 */
export interface BadgeItem {
  id: string
  name: string
  emoji?: string
  description?: string
}

export interface RedeemItem {
  id: string
  name: string
  emoji?: string
  cost: number
  /** 兑换后附赠的上网时长（分钟），0/缺省表示不放开上网 */
  net_minutes?: number
}

export interface RewardCatalog {
  badges: BadgeItem[]
  redeem_items: RedeemItem[]
}

/** 好友系统 */
export interface FriendItem {
  child_id: string
  name?: string
  avatar?: string | null
  grade?: number | null
}

export interface FriendRequest {
  id: string
  from_child: string
  to_child: string
  status: string
  created_at?: string
  from_name?: string
  to_name?: string
}

export interface FriendMessage {
  id: string
  from_child: string
  to_child: string
  content: string
  created_at?: string
}

export interface GrowthRecord {
  id: string
  type?: string
  title?: string
  content?: string | null
  photo_path?: string | null
  photo_paths?: string[] | null
  happened_at?: string | null
  created_at?: string
}

export interface BackupItem {
  backup_id: string
  created_at?: string
  sqlite?: string
  files?: string[]
}

export interface AuditLogItem {
  id: number
  actor?: string | null
  action?: string | null
  target?: string | null
  detail?: string | null
  created_at?: string
}

export interface AdminStats {
  users: number
  pending_users: number
  children: number
}

/** 聊天记录管理：单个孩子的聊天容量统计 */
export interface ChatChildStorage {
  child_id: string
  name?: string
  total_bytes: number
  messages_bytes: number
  images_bytes: number
  images_count: number
  videos_bytes: number
  videos_count: number
  audio_bytes?: number
  audio_count?: number
  files_bytes: number
  files_count: number
}

/** 聊天记录管理：单个家庭的聊天容量统计 */
export interface ChatFamilyStorage {
  family_id: string
  total_bytes: number
  chat_bytes: number
  p2p_bytes?: number
}

/** 聊天记录管理：整体容量统计 */
export interface ChatStorage {
  children: ChatChildStorage[]
  families: ChatFamilyStorage[]
  friends: { total_bytes: number; files_count: number }
  grand_total_bytes: number
}