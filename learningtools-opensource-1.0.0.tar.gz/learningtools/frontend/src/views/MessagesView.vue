<template>
  <div v-loading="loading">
    <el-row :gutter="16">
      <el-col :xs="24" :span="10">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>发送消息</span>
            </div>
          </template>
          <div class="toolbar">
            <ChildSelect v-model="childId" />
          </div>
          <el-input
            v-model="newContent"
            type="textarea"
            :rows="5"
            maxlength="500"
            show-word-limit
            placeholder="给孩子的消息内容…"
          />
          <div class="send-row">
            <el-button type="primary" :loading="sending" :disabled="!childId" @click="handleSend">
              发送给 {{ childName }}
            </el-button>
          </div>
        </el-card>
      </el-col>

      <el-col :xs="24" :span="14">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>消息记录</span>
              <el-button size="small" :icon="Refresh" @click="load">刷新</el-button>
            </div>
          </template>
          <el-table :data="messages" stripe>
            <el-table-column label="发送方" width="120">
              <template #default="{ row }">
                <el-tag size="small" :type="senderType(row.sender_role)">
                  {{ roleLabel(row.sender_role) }}
                </el-tag>
                <div class="sender-name">{{ row.sender_name || '-' }}</div>
              </template>
            </el-table-column>
            <el-table-column label="内容" min-width="220">
              <template #default="{ row }">
                <div class="msg-content">
                  <span v-if="row.content" class="msg-text">{{ row.content }}</span>
                  <span v-else class="msg-placeholder">
                    <el-icon><Paperclip /></el-icon>
                    附件
                  </span>
                  <div v-if="row.attachments?.length" class="msg-attachments">
                    <template v-for="(a, i) in imageAttachments(row)" :key="'img-' + i">
                      <div class="msg-thumb-wrap" @click="openViewer(row, i)">
                        <el-image
                          v-if="thumbSrc(row, i)"
                          :src="thumbSrc(row, i)"
                          fit="cover"
                          class="msg-thumb"
                        >
                          <template #error>
                            <div class="msg-thumb-error">🖼️</div>
                          </template>
                        </el-image>
                        <div v-else class="msg-thumb msg-thumb-loading"></div>
                      </div>
                    </template>
                    <template v-for="(a, j) in otherAttachments(row)" :key="'file-' + j">
                      <a
                        class="msg-file"
                        href="javascript:void(0)"
                        @click.prevent="downloadAttachment(a)"
                      >
                        📄 {{ a.name || '附件' }}{{ sizeLabel(a.size) }}
                      </a>
                    </template>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="发送时间" width="170">
              <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
            </el-table-column>
            <el-table-column label="状态" width="120">
              <template #default="{ row }">
                <el-tag v-if="row.read_at" type="success" size="small">已读</el-tag>
                <el-tag v-else type="warning" size="small">未读</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="100" fixed="right">
              <template #default="{ row }">
                <el-button
                  v-if="!row.read_at"
                  size="small"
                  link
                  type="primary"
                  @click="markRead(row)"
                >
                  标记已读
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <el-empty v-if="!messages.length" description="暂无消息" />
        </el-card>
      </el-col>
    </el-row>

    <el-image-viewer
      v-if="viewerVisible"
      :url-list="viewerUrls"
      :initial-index="viewerIndex"
      hide-on-click-modal
      @close="viewerVisible = false"
    />
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Paperclip, Refresh } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as messagesApi from '@/api/messages'
import type { MessageAttachment, MessageItem } from '@/types'
import { formatDateTime } from '@/utils/date'

const childrenStore = useChildrenStore()
const childId = ref('')
const messages = ref<MessageItem[]>([])
const newContent = ref('')
const loading = ref(false)
const sending = ref(false)

/** 每条消息已加载的图片附件 objectURL（按 attachments 中 image 顺序），卸载/重载时逐个 revoke */
const blobCache = new Map<string, string[]>()
/** 全屏预览状态 */
const viewerVisible = ref(false)
const viewerUrls = ref<string[]>([])
const viewerIndex = ref(0)

const childName = computed(
  () => childrenStore.children.find((c) => c.id === childId.value)?.name || '',
)

function roleLabel(role?: string): string {
  switch (role) {
    case 'super_admin':
      return '超级管理员'
    case 'family_admin':
      return '家庭管理员'
    case 'parent':
      return '家长'
    case 'child':
      return '孩子'
    default:
      return role || '-'
  }
}

function senderType(role?: string): 'danger' | 'warning' | 'primary' | 'success' | 'info' {
  if (role === 'child') return 'success'
  if (role === 'parent') return 'primary'
  if (role === 'family_admin') return 'warning'
  if (role === 'super_admin') return 'danger'
  return 'info'
}

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    viewerVisible.value = false // 关闭全屏预览，避免展示即将 revoke 的 URL
    releaseBlobCache()
    messages.value = await messagesApi.listMessages(childId.value)
    void fillAttachmentBlobs()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

/** 释放全部缓存 objectURL（加载新数据 / 组件卸载时调用） */
function releaseBlobCache() {
  for (const urls of blobCache.values()) {
    for (const url of urls) URL.revokeObjectURL(url)
  }
  blobCache.clear()
}

/** 异步为每条消息的图片附件拉取 blob URL 并缓存 */
async function fillAttachmentBlobs() {
  const currentChild = childId.value
  for (const m of messages.value) {
    if (childId.value !== currentChild) return // 切换孩子后放弃剩余填充
    const images = imageAttachments(m)
    if (!images.length) continue
    const urls: string[] = []
    for (const a of images) {
      if (!a.path) {
        urls.push('')
        continue
      }
      try {
        urls.push(await messagesApi.fetchMessageAttachmentBlob(currentChild, a.path))
      } catch {
        urls.push('') // 单张失败不阻塞整条消息
      }
    }
    blobCache.set(m.id, urls)
  }
}

function imageAttachments(m: MessageItem): MessageAttachment[] {
  return (m.attachments ?? []).filter((a) => a.type === 'image')
}

function otherAttachments(m: MessageItem): MessageAttachment[] {
  return (m.attachments ?? []).filter((a) => a.type !== 'image')
}

function thumbSrc(m: MessageItem, index: number): string {
  return blobCache.get(m.id)?.[index] ?? ''
}

function openViewer(m: MessageItem, index: number) {
  const urls = blobCache.get(m.id)
  if (!urls?.length) return
  viewerUrls.value = urls
  viewerIndex.value = index
  viewerVisible.value = true
}

function sizeLabel(size?: number): string {
  if (typeof size !== 'number' || !Number.isFinite(size) || size <= 0) return ''
  const kb = size / 1024
  return `（${kb >= 100 ? kb.toFixed(0) : kb.toFixed(1)} KB）`
}

async function downloadAttachment(a: MessageAttachment) {
  if (!a.path) return
  try {
    const url = await messagesApi.fetchMessageAttachmentBlob(childId.value, a.path)
    const link = document.createElement('a')
    link.href = url
    link.download = a.name || 'attachment'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleSend() {
  if (!newContent.value.trim()) {
    ElMessage.warning('请输入消息内容')
    return
  }
  sending.value = true
  try {
    await messagesApi.sendMessage(childId.value, newContent.value.trim())
    ElMessage.success('消息已发送')
    newContent.value = ''
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    sending.value = false
  }
}

async function markRead(row: MessageItem) {
  try {
    await messagesApi.markMessageRead(row.id, childId.value)
    ElMessage.success('已标记')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

watch(childId, () => {
  if (childId.value) load()
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})

onBeforeUnmount(() => {
  releaseBlobCache()
})
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.toolbar {
  margin-bottom: 12px;
}
.send-row {
  margin-top: 12px;
  text-align: right;
}
.sender-name {
  font-size: 12px;
  color: #909399;
  margin-top: 2px;
}
.msg-text {
  white-space: pre-wrap;
  word-break: break-word;
}
.msg-placeholder {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: #909399;
  font-size: 12px;
}
.msg-attachments {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 6px;
}
.msg-thumb-wrap {
  cursor: pointer;
}
.msg-thumb {
  display: block;
  width: 60px;
  height: 60px;
  border-radius: 6px;
}
.msg-thumb-loading {
  background: #f5f7fa;
}
.msg-thumb-error {
  width: 60px;
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 6px;
  font-size: 20px;
}
.msg-file {
  display: inline-flex;
  align-items: center;
  max-width: 200px;
  padding: 2px 8px;
  border-radius: 6px;
  background: #ecf5ff;
  color: #409eff;
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.msg-file:hover {
  background: #d9ecff;
  color: #337ecc;
}
</style>