<template>
  <div v-loading="loading">
    <el-card shadow="never" class="page-card">
      <el-radio-group v-model="mode" class="mode-switch">
        <el-radio-button value="manage">任务管理</el-radio-button>
        <el-radio-button value="review">任务审批</el-radio-button>
      </el-radio-group>

      <template v-if="mode === 'manage'">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-radio-group v-model="viewMode">
          <el-radio-button value="day">按日</el-radio-button>
          <el-radio-button value="week">按周</el-radio-button>
        </el-radio-group>
        <el-date-picker
          v-if="viewMode === 'day'"
          v-model="selectedDate"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="选择日期"
          :clearable="false"
          style="width: 160px"
        />
        <el-date-picker
          v-else
          v-model="weekDate"
          type="week"
          placeholder="选择周"
          format="YYYY-MM-DD"
          :clearable="false"
          style="width: 180px"
        />
        <el-button type="primary" :icon="Plus" @click="openCreate">新建任务</el-button>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
        <span class="tip">任务统一按周计划管理；完成/跳过操作由孩子端进行。</span>
      </div>

      <el-table :data="taskList" stripe class="compact-table">
        <el-table-column prop="title" label="标题" min-width="150">
          <template #default="{ row }">
            <span class="title-cell">
              {{ row.title || '-' }}
              <span v-if="row.status === 'completed' && row.completed_photo" class="media-icon" title="含完成照片">📷</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column label="科目" width="62" show-overflow-tooltip>
          <template #default="{ row }">{{ row.subject || '-' }}</template>
        </el-table-column>
        <el-table-column label="类型" width="62" show-overflow-tooltip>
          <template #default="{ row }">{{ row.task_type || '-' }}</template>
        </el-table-column>
        <el-table-column label="日期" width="94">
          <template #default="{ row }">{{ formatDate(row.planned_date) }}</template>
        </el-table-column>
        <el-table-column label="循环" width="90" show-overflow-tooltip>
          <template #default="{ row }">
            <span>{{ repeatLabel(row.repeat) }}</span>
            <el-tag v-if="row.holiday" type="warning" size="small" effect="plain" style="margin-left: 4px">
              假期{{ row.holiday_days || 0 }}天
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="开始时间" width="78">
          <template #default="{ row }">{{ row.planned_start || '-' }}</template>
        </el-table-column>
        <el-table-column label="时长(分)" width="68">
          <template #default="{ row }">{{ row.planned_duration ?? '-' }}</template>
        </el-table-column>
        <el-table-column label="优先级" width="58">
          <template #default="{ row }">
            <el-tag :type="priorityType(row.priority)" size="small">{{ priorityLabel(row.priority) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="难度" width="58">
          <template #default="{ row }">
            <el-tag :type="difficultyType(row.difficulty)" size="small">{{ difficultyLabel(row.difficulty) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="状态" width="74">
          <template #default="{ row }">
            <el-tag :type="statusTagType(row.status)">{{ statusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="完成时间" width="122" show-overflow-tooltip>
          <template #default="{ row }">{{ formatDateTime(row.completed_at) }}</template>
        </el-table-column>
        <el-table-column label="评分" width="50">
          <template #default="{ row }">{{ row.score ?? '-' }}</template>
        </el-table-column>
        <el-table-column label="操作" width="72" fixed="right" align="center">
          <template #default="{ row }">
            <template v-if="row.status === 'completed'">
              <el-tooltip content="评分" placement="top">
                <el-button size="small" link type="warning" :icon="Star" @click="openReview(row)" />
              </el-tooltip>
              <el-tooltip content="详情" placement="top">
                <el-button size="small" link type="primary" :icon="View" @click="openDetail(row)" />
              </el-tooltip>
            </template>
            <template v-else>
              <el-tooltip content="编辑" placement="top">
                <el-button size="small" link type="primary" :icon="Edit" @click="openEdit(row)" />
              </el-tooltip>
              <el-tooltip content="删除" placement="top">
                <el-button size="small" link type="danger" :icon="Delete" @click="handleDelete(row)" />
              </el-tooltip>
            </template>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!taskList.length" :description="viewMode === 'week' ? '该周暂无任务' : '该日期暂无任务'" />
      </template>

      <template v-else>
        <div class="toolbar">
          <ChildSelect v-model="childId" />
          <el-button :icon="Refresh" @click="loadReview">刷新</el-button>
          <span class="tip">孩子提交的任务都在这里审批。</span>
        </div>
        <el-table :data="reviewList" stripe class="compact-table">
          <el-table-column prop="title" label="标题" min-width="160">
            <template #default="{ row }">
              <span class="title-cell">
                {{ row.title || '-' }}
                <span v-if="row.completed_photo" class="media-icon" title="含完成照片">📷</span>
              </span>
            </template>
          </el-table-column>
          <el-table-column label="类型" width="70" show-overflow-tooltip>
            <template #default="{ row }">{{ row.task_type || row.subject || '-' }}</template>
          </el-table-column>
          <el-table-column label="日期" width="94">
            <template #default="{ row }">{{ formatDate(row.planned_date) }}</template>
          </el-table-column>
          <el-table-column label="提交时间" width="122" show-overflow-tooltip>
            <template #default="{ row }">{{ formatDateTime(row.completed_at) }}</template>
          </el-table-column>
          <el-table-column label="审核状态" width="90">
            <template #default="{ row }">
              <el-tag :type="reviewStatusTagType(row.review_status)" size="small">{{ reviewStatusLabel(row.review_status) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="96" fixed="right" align="center">
            <template #default="{ row }">
              <el-tooltip content="审批" placement="top">
                <el-button size="small" link type="warning" :icon="Star" @click="openReview(row)" />
              </el-tooltip>
              <el-tooltip content="详情" placement="top">
                <el-button size="small" link type="primary" :icon="View" @click="openDetail(row)" />
              </el-tooltip>
            </template>
          </el-table-column>
        </el-table>
        <el-empty v-if="!reviewList.length" description="暂无已提交待审批的任务" />
      </template>
    </el-card>

    <!-- 新建任务 -->
    <el-dialog v-model="createVisible" :title="editingId ? '编辑任务' : '新建任务'" width="480px" destroy-on-close>
      <el-form ref="formRef" :model="form" :rules="formRules" label-width="90px">
        <el-form-item label="标题" prop="title">
          <el-input v-model="form.title" placeholder="任务标题" />
        </el-form-item>
        <el-form-item label="科目">
          <el-input v-model="form.subject" placeholder="如 数学" />
        </el-form-item>
        <el-form-item label="类型">
          <el-select v-model="form.task_type" placeholder="类型" clearable allow-create filterable>
            <el-option v-for="t in taskTypes" :key="t" :label="t" :value="t" />
          </el-select>
        </el-form-item>
        <el-form-item label="日期">
          <el-date-picker v-model="form.planned_date" type="date" value-format="YYYY-MM-DD" placeholder="默认今天" />
        </el-form-item>
        <el-form-item label="循环模式">
          <el-radio-group v-model="form.repeat_type">
            <el-radio-button v-for="opt in REPEAT_OPTIONS" :key="opt.value" :value="opt.value">{{ opt.label }}</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-if="form.repeat_type === 'weekly'" label="重复星期">
          <el-checkbox-group v-model="form.repeat_days">
            <el-checkbox v-for="d in WEEKDAY_OPTIONS" :key="d.value" :value="d.value">{{ d.label }}</el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="开始时间">
          <el-time-picker v-model="form.planned_start" value-format="HH:mm" placeholder="开始时间" />
        </el-form-item>
        <el-form-item label="时长(分)">
          <el-input-number v-model="form.planned_duration" :min="0" :max="600" :step="10" />
        </el-form-item>
        <el-form-item label="优先级">
          <el-radio-group v-model="form.priority">
            <el-radio-button :value="0">无</el-radio-button>
            <el-radio-button :value="1">低</el-radio-button>
            <el-radio-button :value="2">中</el-radio-button>
            <el-radio-button :value="3">高</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="难度">
          <el-radio-group v-model="form.difficulty">
            <el-radio-button v-for="d in DIFFICULTY_OPTIONS" :key="d.value" :value="d.value">{{ d.label }}</el-radio-button>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="奖励积分">
          <el-input-number v-model="form.reward_points" :min="0" :max="1000" :step="5" />
          <div class="difficulty-hint">留空按难度默认奖励（简单10/中等15/困难20），设置后按此积分奖励</div>
        </el-form-item>
        <el-form-item label="拍照提交">
          <el-switch v-model="form.photo_required" active-text="需要拍照" inactive-text="无需拍照" />
          <div class="difficulty-hint">关闭后孩子可直接提交，无需上传照片</div>
        </el-form-item>
        <el-form-item label="未完成扣分">
          <el-input-number v-model="form.penalty_points" :min="0" :max="1000" :step="5" />
          <div class="difficulty-hint">超时未完成或被驳回时扣除这些积分，0 表示不扣</div>
        </el-form-item>
        <el-form-item label="需要联网">
          <el-switch v-model="form.need_network" active-text="需要联网" inactive-text="不需要联网" />
          <div class="difficulty-hint">
            勾选后，该任务开启专注模式期间会放开受管控设备（平板）的外网权限；不勾选则专注期间无法上网
          </div>
        </el-form-item>
        <el-form-item label="假期作业">
          <div class="holiday-row">
            <el-switch v-model="form.holiday" active-text="假期" inactive-text="非假期" />
            <template v-if="form.holiday">
              <span class="holiday-label">假期时长</span>
              <el-input-number v-model="form.holiday_days" :min="1" :max="60" :step="1" />
              <span class="holiday-label">天</span>
            </template>
          </div>
          <div class="difficulty-hint">
            勾选后，该任务/作业在这期间每天都会出现在孩子端；假期内每天可以交一部分，
            家长审核通过才算写完（归档后不再提交）；假期内提交不算超时，不扣分
          </div>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="createVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submit">{{ editingId ? '保存' : '创建' }}</el-button>
      </template>
    </el-dialog>

    <!-- 任务评分 -->
    <el-dialog v-model="reviewVisible" title="任务评分" width="440px" destroy-on-close>
      <el-form label-width="90px">
        <el-form-item label="审核结果">
          <el-radio-group v-model="reviewStatus">
            <el-radio value="approved">通过</el-radio>
            <el-radio value="rejected">驳回</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-for="d in SCORE_DIMENSIONS" :key="d.key" :label="d.label">
          <el-rate v-model="reviewRatings[d.key]" :max="5" />
        </el-form-item>
        <el-form-item label="总评分">
          <span class="score-preview">{{ computedReviewScore ?? '未打分' }}</span>
        </el-form-item>
        <el-form-item label="评语">
          <el-input
            v-model="reviewComment"
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="评语（选填）"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="reviewVisible = false">取消</el-button>
        <el-button type="primary" :loading="reviewing" @click="submitReview">确认</el-button>
      </template>
    </el-dialog>

    <!-- 任务详情 -->
    <el-dialog
      v-model="detailVisible"
      title="任务详情"
      width="520px"
      destroy-on-close
      @closed="cleanupDetailUrls"
    >
      <div v-if="detailRecord" v-loading="detailLoading" class="detail-body">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="标题">{{ detailRecord.title || '-' }}</el-descriptions-item>
          <el-descriptions-item label="科目">{{ detailRecord.subject || '-' }}</el-descriptions-item>
          <el-descriptions-item label="类型">{{ detailRecord.task_type || '-' }}</el-descriptions-item>
          <el-descriptions-item label="难度">{{ difficultyLabel(detailRecord.difficulty) }}</el-descriptions-item>
          <el-descriptions-item label="日期">{{ formatDate(detailRecord.planned_date) }}</el-descriptions-item>
          <el-descriptions-item label="时长(分)">{{ detailRecord.planned_duration ?? '-' }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="statusTagType(detailRecord.status)">{{ statusLabel(detailRecord.status) }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="完成时间">{{ formatDateTime(detailRecord.completed_at) }}</el-descriptions-item>
          <el-descriptions-item label="评分">{{ detailRecord.score ?? '-' }}</el-descriptions-item>
          <el-descriptions-item label="审核意见">{{ detailRecord.review_comment || '-' }}</el-descriptions-item>
        </el-descriptions>
        <div v-if="photoUrl" class="detail-media">
          <p class="media-label">完成照片</p>
          <el-image
            :src="photoUrl"
            fit="cover"
            class="detail-photo"
            :preview-src-list="[photoUrl]"
            preview-teleported
          />
        </div>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { Delete, Edit, Plus, Refresh, Star, View } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as tasksApi from '@/api/tasks'
import * as plansApi from '@/api/plans'
import type { RepeatRule, TaskItem } from '@/types'
import { repeatLabel, REPEAT_OPTIONS, WEEKDAY_OPTIONS } from '@/utils/repeat'
import { DIFFICULTY_OPTIONS, difficultyLabel, difficultyType } from '@/utils/difficulty'
import { SCORE_DIMENSIONS, ratingsToScore } from '@/utils/scoring'
import {
  confirmAction,
  currentIsoWeek,
  formatDate,
  formatDateTime,
  localToday,
  priorityLabel,
  statusLabel,
  statusTagType,
  toIsoWeek,
  weekStartDate,
} from '@/utils/date'

const childrenStore = useChildrenStore()
const childId = ref('')
const viewMode = ref<'day' | 'week'>('day')
const selectedDate = ref(localToday())
const weekDate = ref<Date>(weekStartDate(currentIsoWeek()))
const week = computed(() => toIsoWeek(weekDate.value))
const taskList = ref<TaskItem[]>([])
const loading = ref(false)

const mode = ref<'manage' | 'review'>('manage')
const reviewList = ref<TaskItem[]>([])

function reviewStatusLabel(v?: string): string {
  if (v === 'approved') return '已通过'
  if (v === 'rejected') return '已驳回'
  return '待审核'
}
function reviewStatusTagType(v?: string): 'success' | 'danger' | 'warning' | 'info' {
  if (v === 'approved') return 'success'
  if (v === 'rejected') return 'danger'
  return 'warning'
}

const taskTypes = ['作业', '预习', '复习', '阅读', '运动', '家务', '背诵', '其他']

function priorityType(v?: number): 'danger' | 'warning' | 'success' | 'info' {
  if (v === 3) return 'danger'
  if (v === 2) return 'warning'
  if (v === 1) return 'success'
  return 'info'
}

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    if (viewMode.value === 'week') {
      const plan = await plansApi.getWeeklyPlan(childId.value, week.value)
      taskList.value = plan.tasks || []
    } else {
      const today = localToday()
      if (selectedDate.value === today) {
        const res = await tasksApi.todayTasks(childId.value)
        taskList.value = res.tasks || []
      } else {
        const wk = toIsoWeek(new Date(selectedDate.value))
        const plan = await plansApi.getWeeklyPlan(childId.value, wk)
        taskList.value = (plan.tasks || []).filter((t) => t.planned_date === selectedDate.value)
      }
    }
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function loadReview() {
  if (!childId.value) return
  loading.value = true
  try {
    reviewList.value = await tasksApi.reviewTasks(childId.value)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

// ---- 新建任务 ----
const createVisible = ref(false)
const saving = ref(false)
const formRef = ref<FormInstance>()
const form = reactive({
  title: '',
  subject: '',
  task_type: '',
  planned_date: '',
  planned_start: '',
  planned_duration: undefined as number | undefined,
  priority: 0,
  difficulty: 'medium' as 'easy' | 'medium' | 'hard',
  repeat_type: 'none' as 'none' | 'daily' | 'weekly',
  repeat_days: [] as number[],
  photo_required: true,
  need_network: false,
  holiday: false,
  holiday_days: 7,
  penalty_points: 0,
  reward_points: undefined as number | undefined,
})
const formRules: FormRules = {
  title: [{ required: true, message: '请输入任务标题', trigger: 'blur' }],
}

const editingId = ref('')

function openCreate() {
  editingId.value = ''
  Object.assign(form, {
    title: '',
    subject: '',
    task_type: '',
    planned_date: selectedDate.value,
    planned_start: '',
    planned_duration: undefined,
    priority: 0,
    difficulty: 'medium',
    repeat_type: 'none',
    repeat_days: [],
    photo_required: true,
    need_network: false,
    holiday: false,
    holiday_days: 7,
    penalty_points: 0,
    reward_points: undefined,
  })
  createVisible.value = true
}

function openEdit(row: TaskItem) {
  editingId.value = row.id || ''
  const rep = row.repeat || { type: 'none', days: [] }
  Object.assign(form, {
    title: row.title || '',
    subject: row.subject || '',
    task_type: row.task_type || '',
    planned_date: row.planned_date || selectedDate.value,
    planned_start: row.planned_start || '',
    planned_duration: row.planned_duration ?? undefined,
    priority: row.priority ?? 0,
    difficulty: row.difficulty || 'medium',
    repeat_type: rep.type || 'none',
    repeat_days: Array.isArray(rep.days) ? [...rep.days] : [],
    photo_required: row.photo_required !== false,
    need_network: row.need_network === true,
    holiday: row.holiday === true,
    holiday_days: row.holiday === true && (row.holiday_days ?? 0) > 0 ? Number(row.holiday_days) : 7,
    penalty_points: row.penalty_points ?? 0,
    reward_points: row.reward_points ?? undefined,
  })
  createVisible.value = true
}

function buildRepeat(): RepeatRule {
  // 仅 weekly 时 days 有意义；none/daily 传空数组，planned_date 照常生效
  if (form.repeat_type === 'weekly') {
    return { type: 'weekly', days: form.repeat_days }
  }
  return { type: form.repeat_type, days: [] }
}

async function submit() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    const body = {
      title: form.title,
      subject: form.subject || null,
      task_type: form.task_type || null,
      planned_date: form.planned_date || null,
      planned_start: form.planned_start || null,
      planned_duration: form.planned_duration ?? null,
      priority: form.priority,
      difficulty: form.difficulty,
      repeat: buildRepeat(),
      photo_required: form.photo_required,
      need_network: form.need_network,
      holiday: form.holiday,
      holiday_days: form.holiday ? form.holiday_days || 7 : 0,
      penalty_points: form.penalty_points,
      reward_points: form.reward_points && form.reward_points > 0 ? form.reward_points : null,
    }
    if (editingId.value) {
      await tasksApi.updateTask(editingId.value, childId.value, body)
    } else {
      await tasksApi.createTask(childId.value, body)
    }
    ElMessage.success(editingId.value ? '任务已更新' : '任务已创建')
    createVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    saving.value = false
  }
}

async function handleDelete(row: TaskItem) {
  if (!row.id) return
  const ok = await confirmAction(`确定删除任务「${row.title || '-'}」吗？`, '删除确认', 'warning')
  if (!ok) return
  try {
    await tasksApi.deleteTask(row.id, childId.value)
    ElMessage.success('已删除')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

watch(childId, () => {
  if (!childId.value) return
  if (mode.value === 'review') loadReview()
  else load()
})

watch(mode, () => {
  if (!childId.value) return
  if (mode.value === 'review') loadReview()
  else load()
})

watch(viewMode, () => {
  if (childId.value) load()
})

watch(selectedDate, () => {
  if (childId.value && viewMode.value === 'day') load()
})

watch(week, () => {
  if (childId.value && viewMode.value === 'week') load()
})

// ---- 评分 ----
const reviewVisible = ref(false)
const reviewing = ref(false)
const reviewStatus = ref<'approved' | 'rejected'>('approved')
const reviewRatings = reactive<Record<string, number>>({})
const reviewComment = ref('')
let reviewRecord: TaskItem | null = null

const computedReviewScore = computed(() => ratingsToScore(reviewRatings))

function openReview(row: TaskItem) {
  reviewRecord = row
  reviewStatus.value = 'approved'
  Object.keys(reviewRatings).forEach((k) => delete reviewRatings[k])
  reviewComment.value = ''
  reviewVisible.value = true
}

async function submitReview() {
  if (!reviewRecord?.id) return
  reviewing.value = true
  try {
    await tasksApi.reviewTask(reviewRecord.id, childId.value, {
      status: reviewStatus.value,
      ratings: computedReviewScore.value !== undefined ? { ...reviewRatings } : undefined,
      comment: reviewComment.value.trim() || undefined,
    })
    ElMessage.success(reviewStatus.value === 'approved' ? '任务已通过' : '任务已驳回')
    reviewVisible.value = false
    await loadReview()
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    reviewing.value = false
  }
}

// ---- 详情 ----
const detailVisible = ref(false)
const detailLoading = ref(false)
const detailRecord = ref<TaskItem | null>(null)
const photoUrl = ref('')

function cleanupDetailUrls() {
  if (photoUrl.value) URL.revokeObjectURL(photoUrl.value)
  photoUrl.value = ''
  detailRecord.value = null
}

async function openDetail(row: TaskItem) {
  cleanupDetailUrls()
  detailRecord.value = row
  detailVisible.value = true
  detailLoading.value = true
  try {
    if (row.completed_photo) {
      photoUrl.value = await tasksApi.fetchTaskPhotoBlob(childId.value, row.completed_photo)
    }
  } catch {
    // 错误提示由拦截器处理
  } finally {
    detailLoading.value = false
  }
}

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.mode-switch {
  margin-bottom: 16px;
}
.toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.tip {
  color: #909399;
  font-size: 13px;
}
.compact-table :deep(.el-table__cell) {
  padding: 6px 0;
}
.compact-table :deep(.el-table__cell .cell) {
  padding: 0 6px;
}
.compact-table :deep(.el-table th.el-table__cell) {
  font-size: 13px;
}
.no-op {
  color: #c0c4cc;
}
.holiday-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}
.holiday-label {
  font-size: 13px;
  color: #606266;
}
.difficulty-hint {
  width: 100%;
  margin-top: 4px;
  font-size: 12px;
  color: #909399;
}
.score-preview {
  font-size: 16px;
  font-weight: 600;
  color: #f56c6c;
}
.title-cell {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.media-icon {
  cursor: default;
  font-size: 14px;
  flex-shrink: 0;
}
.detail-body {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.detail-media {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.media-label {
  margin: 0;
  font-size: 13px;
  color: #909399;
}
.detail-photo {
  width: 100%;
  max-height: 320px;
  border-radius: 6px;
}
</style>