<template>
  <div class="home">
    <!-- 背景装饰圆点 -->
    <div class="blobs" aria-hidden="true">
      <span class="blob blob-1" />
      <span class="blob blob-2" />
      <span class="blob blob-3" />
    </div>

    <div class="content">
      <!-- 代言人 小步 -->
      <div class="mascot-wrap">
        <div class="speech">
          <span>你好呀，我是小步 🌱</span>
        </div>
        <div class="mascot">
          <img src="/logo.png" alt="小步 · 小树苗" />
        </div>
      </div>

      <h1 class="title">小步成长</h1>
      <p class="tagline">陪伴和记录孩子的每一步成长，让好习惯生根发芽 🌱</p>

      <div class="actions">
        <el-button tag="a" href="/apk/app-release.apk" download="小步成长APP.apk" size="large" round class="dl-btn">
          下载小步成长APP
        </el-button>
        <el-button tag="a" href="/apk/parent-app-release.apk" download="小步家长APP.apk" size="large" round class="dl-btn">
          下载小步家长APP
        </el-button>
        <el-tooltip
          content="学习专用版：平板一打开 App 就自动进入专注模式，配合家长端「网络管控」使用"
          placement="top"
        >
          <el-button tag="a" href="/apk/app-release-tablet.apk" download="小步成长APP-学习专用版.apk" size="large" round class="dl-btn">
            下载学习专用版
          </el-button>
        </el-tooltip>
        <el-button type="primary" size="large" round class="enter-btn" @click="goApp">
          进入家长管理
        </el-button>
      </div>

      <!-- 功能亮点 -->
      <div class="features">
        <div v-for="f in features" :key="f.title" class="feature">
          <div class="feature-icon">
            <img :src="f.gif" :alt="f.title" loading="lazy" />
          </div>
          <div class="feature-title">{{ f.title }}</div>
          <div class="feature-desc">{{ f.desc }}</div>
        </div>
      </div>
    </div>

    <footer class="footer">© 小步成长 · 陪孩子快乐成长，让每一天都闪闪发光 ✨</footer>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const router = useRouter()
const auth = useAuthStore()

const features = [
  { gif: '/stickers/thumbs/s01.webp', title: '主动打卡', desc: '晨起、阅读、运动、家务、心情' },
  { gif: '/stickers/thumbs/s22.webp', title: '任务管理', desc: '布置任务，养成好习惯' },
  { gif: '/stickers/thumbs/s07.webp', title: '奖励中心', desc: '积分兑换，激励成长' },
  { gif: '/stickers/thumbs/s10.webp', title: '专注监控', desc: '学习状态一目了然' },
  { gif: '/stickers/thumbs/s13.webp', title: '学习报告', desc: '成长轨迹清晰可见' },
  { gif: '/stickers/thumbs/s04.webp', title: '家庭聊天', desc: '表情包让沟通更有趣' },
]

function goApp() {
  router.push(auth.isLoggedIn ? '/dashboard' : '/login')
}
</script>

<style scoped>
.home {
  position: relative;
  min-height: 100vh;
  overflow: hidden;
  background: linear-gradient(160deg, #b7ecff 0%, #d8f7d2 42%, #fff3c9 100%);
  font-family: 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
}

/* ---- 背景圆点 ---- */
.blobs span {
  position: absolute;
  border-radius: 50%;
  filter: blur(2px);
  opacity: 0.5;
}
.blob-1 {
  width: 320px;
  height: 320px;
  left: -80px;
  top: -60px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0));
}
.blob-2 {
  width: 400px;
  height: 400px;
  right: -120px;
  bottom: -100px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.85), rgba(255, 255, 255, 0));
}
.blob-3 {
  width: 240px;
  height: 240px;
  right: 12%;
  top: 20%;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.7), rgba(255, 255, 255, 0));
}

/* ---- 主体内容 ---- */
.content {
  position: relative;
  z-index: 2;
  max-width: 860px;
  margin: 0 auto;
  padding: 48px 20px 40px;
  text-align: center;
}

.mascot-wrap {
  position: relative;
  display: inline-flex;
  flex-direction: column;
  align-items: center;
}
.speech {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #fff;
  border: 2px solid #ffe08a;
  border-radius: 18px;
  padding: 8px 16px;
  font-size: 15px;
  font-weight: 600;
  color: #7a5c1e;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
  margin-bottom: 10px;
  animation: bob 4s ease-in-out infinite;
}
.speech::after {
  content: '';
  position: absolute;
  left: 50%;
  bottom: -9px;
  transform: translateX(-50%);
  border: 9px solid transparent;
  border-top-color: #ffe08a;
}
.mascot {
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: #fff;
  padding: 14px;
  box-shadow: 0 12px 30px rgba(46, 160, 67, 0.25), 0 0 0 6px rgba(255, 255, 255, 0.6);
  animation: bounce 3.2s ease-in-out infinite;
}
.mascot img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

@keyframes bounce {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-12px);
  }
}
@keyframes bob {
  0%,
  100% {
    transform: translateY(0) rotate(-1deg);
  }
  50% {
    transform: translateY(-6px) rotate(1deg);
  }
}

.title {
  margin: 22px 0 6px;
  font-size: 52px;
  font-weight: 900;
  letter-spacing: 4px;
  background: linear-gradient(90deg, #2e7d32, #43a047, #1e88e5);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
.tagline {
  margin: 0 0 26px;
  font-size: 17px;
  color: #5c6b4f;
}

.actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 12px;
  margin-bottom: 44px;
}
.dl-btn {
  font-weight: 600;
  text-decoration: none;
}
.dl-btn:hover,
.dl-btn:focus,
.dl-btn:active {
  text-decoration: none;
}
.enter-btn {
  padding: 14px 40px;
  font-size: 18px;
  font-weight: 700;
  box-shadow: 0 10px 24px rgba(30, 136, 229, 0.35);
  transition: transform 0.2s ease;
}
.enter-btn:hover {
  transform: translateY(-3px) scale(1.02);
}

/* ---- 功能亮点 ---- */
.features {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}
.feature {
  background: rgba(255, 255, 255, 0.82);
  border: 2px solid rgba(255, 255, 255, 0.9);
  border-radius: 18px;
  padding: 18px 14px;
  box-shadow: 0 8px 22px rgba(0, 0, 0, 0.06);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.feature:hover {
  transform: translateY(-4px);
  box-shadow: 0 14px 30px rgba(0, 0, 0, 0.1);
}
.feature-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 48px;
  margin-bottom: 8px;
}
.feature-icon img {
  width: 48px;
  height: 48px;
  object-fit: contain;
  border-radius: 10px;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.12));
}
.feature-title {
  font-size: 16px;
  font-weight: 700;
  color: #3d4a33;
}
.feature-desc {
  font-size: 12px;
  color: #8a9b7a;
  margin-top: 4px;
}

.footer {
  position: relative;
  z-index: 2;
  text-align: center;
  padding: 18px;
  font-size: 13px;
  color: #7f8f6f;
}

/* ---- 响应式 ---- */
@media (max-width: 768px) {
  .title {
    font-size: 38px;
  }
  .features {
    grid-template-columns: repeat(2, 1fr);
  }
}
</style>
