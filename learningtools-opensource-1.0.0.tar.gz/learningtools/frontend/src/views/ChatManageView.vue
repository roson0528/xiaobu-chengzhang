<template>
  <div v-loading="loading">
    <!-- 顶部统计卡 -->
    <el-row :gutter="16" class="page-card">
      <el-col :xs="12" :sm="8" :md="4">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value">{{ formatBytes(storage.grand_total_bytes) }}</div>
          <div class="stat-label">总占用</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="8" :md="4">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #409eff">{{ formatBytes(totals.imagesBytes) }}</div>
          <div class="stat-label">图片 · {{ totals.imagesCount }} 个</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="8" :md="4">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #e6a23c">{{ formatBytes(totals.videosBytes) }}</div>
          <div class="stat-label">视频 · {{ totals.videosCount }} 个</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="8" :md="4">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #67c23a">{{ formatBytes(totals.filesBytes) }}</div>
          <div class="stat-label">文件 · {{ totals.filesCount }} 个</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :sm="8" :md="4">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #909399">{{ formatBytes(totals.audioBytes) }}</div>
          <div class="stat-label">音频 · {{ totals.audioCount }} 个</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 全局操作 -->
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>全局操作</span>
          <el-button :icon="Refresh" @click="load">刷新</el-button>
        </div>
      </template>
      <div class="global-actions">
        <el-button type="danger" :icon="Delete" :loading="clearing" @click="clearAll">全删除</el-button>
        <el-button :icon="Picture" :loading="clearing" @click="clearScope('images')">清理图片</el-button>
        <el-button :icon="VideoCamera" :loading="clearing" @click="clearScope('videos')">清理视频</el-button>
        <el-button :icon="Document" :loading="clearing" @click="clearScope('files')">清理文件</el-button>
        <el-button :icon="Microphone" :loading="clearing" @click="clearScope('audio')">清理音频</el-button>
      </div>
      <div class="tip">「全删除」会清空所有家长/孩子消息、家庭/私聊群聊与好友聊天记录，操作不可恢复。</div>
    </el-card>

    <!-- 孩子列表 -->
    <el-card shadow="never">
      <template #header>
        <div class="card-header"><span>孩子聊天占用</span></div>
      </template>
      <el-table :data="storage.children" stripe>
        <el-table-column label="孩子" min-width="120">
          <template #default="{ row }">{{ row.name || row.child_id }}</template>
        </el-table-column>
        <el-table-column label="消息占用" width="110">
          <template #default="{ row }">{{ formatBytes(row.messages_bytes) }}</template>
        </el-table-column>
        <el-table-column label="图片" width="150">
          <template #default="{ row }">
            {{ row.images_count }} 个 · {{ formatBytes(row.images_bytes) }}
          </template>
        </el-table-column>
        <el-table-column label="视频" width="150">
          <template #default="{ row }">
            {{ row.videos_count }} 个 · {{ formatBytes(row.videos_bytes) }}
          </template>
        </el-table-column>
        <el-table-column label="文件" width="150">
          <template #default="{ row }">
            {{ row.files_count }} 个 · {{ formatBytes(row.files_bytes) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="300" fixed="right">
          <template #default="{ row }">
            <el-button size="small" type="danger" :loading="clearing" @click="clearChildAll(row)">
              清空所有
            </el-button>
            <el-button size="small" :loading="clearing" @click="clearChildScope(row, 'images')">清图片</el-button>
            <el-button size="small" :loading="clearing" @click="clearChildScope(row, 'videos')">清视频</el-button>
            <el-button size="small" :loading="clearing" @click="clearChildScope(row, 'files')">清文件</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!storage.children.length" description="暂无孩子聊天数据" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Delete, Document, Microphone, Picture, Refresh, VideoCamera } from '@element-plus/icons-vue'
import * as chatManageApi from '@/api/chatManage'
import type { ChatChildStorage, ChatStorage } from '@/types'
import { confirmAction } from '@/utils/date'

const loading = ref(false)
const clearing = ref(false)
const storage = reactive<ChatStorage>({
  children: [],
  families: [],
  friends: { total_bytes: 0, files_count: 0 },
  grand_total_bytes: 0,
})

const totals = computed(() => {
  let imagesBytes = 0
  let imagesCount = 0
  let videosBytes = 0
  let videosCount = 0
  let filesBytes = 0
  let filesCount = 0
  let audioBytes = 0
  let audioCount = 0
  for (const c of storage.children) {
    imagesBytes += c.images_bytes || 0
    imagesCount += c.images_count || 0
    videosBytes += c.videos_bytes || 0
    videosCount += c.videos_count || 0
    filesBytes += c.files_bytes || 0
    filesCount += c.files_count || 0
    audioBytes += c.audio_bytes || 0
    audioCount += c.audio_count || 0
  }
  return { imagesBytes, imagesCount, videosBytes, videosCount, filesBytes, filesCount, audioBytes, audioCount }
})

const scopeLabels: Record<string, string> = {
  all: '全部聊天数据',
  images: '图片附件',
  videos: '视频附件',
  files: '文件附件',
  audio: '音频附件',
}

function formatBytes(n?: number): string {
  const v = n || 0
  if (v <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = 0
  let x = v
  while (x >= 1024 && i < units.length - 1) {
    x /= 1024
    i += 1
  }
  const digits = i === 0 || x >= 100 ? 0 : 1
  return `${x.toFixed(digits)} ${units[i]}`
}

async function load() {
  loading.value = true
  try {
    const data = await chatManageApi.getChatStorage()
    storage.children = data.children
    storage.families = data.families
    storage.friends = data.friends
    storage.grand_total_bytes = data.grand_total_bytes
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function runClear(scope: string, childId: string | undefined, message: string) {
  const ok = await confirmAction(message, '清理确认', 'warning')
  if (!ok) return
  clearing.value = true
  try {
    const res = await chatManageApi.clearChat(scope as chatManageApi.ChatClearScope, childId ?? null)
    ElMessage.success(`已清理 ${res.deleted_count} 个文件`)
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    clearing.value = false
  }
}

function clearAll() {
  runClear('all', undefined, '确定清空所有聊天数据吗？此操作不可恢复！')
}

function clearScope(scope: string) {
  runClear(scope, undefined, `确定清理所有孩子的${scopeLabels[scope]}吗？此操作不可恢复！`)
}

function clearChildAll(row: ChatChildStorage) {
  const name = row.name || row.child_id
  runClear('all', row.child_id, `确定清空「${name}」的全部聊天数据吗？此操作不可恢复！`)
}

function clearChildScope(row: ChatChildStorage, scope: string) {
  const name = row.name || row.child_id
  runClear(scope, row.child_id, `确定清理「${name}」的${scopeLabels[scope]}吗？此操作不可恢复！`)
}

onMounted(() => {
  load()
})
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.global-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 8px;
}
.tip {
  color: #909399;
  font-size: 13px;
}
</style>
