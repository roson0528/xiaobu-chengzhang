<template>
  <el-card shadow="never">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="账号审批" name="approval">
        <ApprovalTab />
      </el-tab-pane>
      <el-tab-pane label="用户管理" name="users">
        <UsersTab />
      </el-tab-pane>
      <el-tab-pane label="系统统计" name="stats">
        <StatsTab />
      </el-tab-pane>
      <el-tab-pane label="审计日志" name="audit">
        <AuditTab />
      </el-tab-pane>
      <el-tab-pane label="备份管理" name="backup">
        <BackupTab />
      </el-tab-pane>
      <el-tab-pane label="全局配置" name="config">
        <ConfigTab />
      </el-tab-pane>
    </el-tabs>
  </el-card>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import ApprovalTab from '@/components/admin/ApprovalTab.vue'
import UsersTab from '@/components/admin/UsersTab.vue'
import StatsTab from '@/components/admin/StatsTab.vue'
import AuditTab from '@/components/admin/AuditTab.vue'
import BackupTab from '@/components/admin/BackupTab.vue'
import ConfigTab from '@/components/admin/ConfigTab.vue'

const activeTab = ref('approval')
</script>