<template>
  <div v-loading="loading">
    <!-- 统计卡片 -->
    <el-row :gutter="16" class="page-card">
      <el-col :xs="12" :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value">{{ stats.children }}</div>
          <div class="stat-label">孩子数量</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value">{{ stats.todayTasks }}</div>
          <div class="stat-label">今日任务</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #67c23a">{{ stats.todayCompleted }}</div>
          <div class="stat-label">今日已完成</div>
        </el-card>
      </el-col>
      <el-col :xs="12" :span="6">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #e6a23c">{{ stats.pendingCheckins }}</div>
          <div class="stat-label">待审核打卡</div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 图表 + 孩子概览 -->
    <el-row :gutter="16" class="page-card">
      <el-col :xs="24" :span="14">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>本周任务完成情况（{{ firstChild ? firstChild.name : '未选择' }}）</span>
              <span class="sub-text">{{ currentWeek }}</span>
            </div>
          </template>
          <EChart v-if="firstChild" :option="weekChartOption" height="300px" />
          <el-empty v-else description="暂无孩子数据" />
        </el-card>
      </el-col>
      <el-col :xs="24" :span="10">
        <el-card shadow="never">
          <template #header>
            <div class="card-header">
              <span>孩子列表概览</span>
              <el-button type="primary" size="small" link @click="$router.push('/children')">
                前往孩子管理
              </el-button>
            </div>
          </template>
          <el-table :data="childrenStore.children" size="small" max-height="300">
            <el-table-column prop="name" label="姓名" min-width="80" />
            <el-table-column label="年级" width="60">
              <template #default="{ row }">{{ row.grade ?? '-' }}</template>
            </el-table-column>
            <el-table-column label="配额用量" width="110">
              <template #default="{ row }">
                <el-progress
                  :percentage="quotaPercent(row)"
                  :stroke-width="8"
                  :status="quotaPercent(row) > 85 ? 'exception' : undefined"
                />
              </template>
            </el-table-column>
            <el-table-column label="照片保留" width="90">
              <template #default="{ row }">{{ row.photo_retention_days ?? '-' }} 天</template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 待审核打卡 -->
    <el-card shadow="never">
      <template #header>
        <div class="card-header">
          <span>待审核打卡</span>
          <el-button type="primary" size="small" link @click="$router.push('/checkins')">
            前往打卡审核
          </el-button>
        </div>
      </template>
      <el-table :data="pendingCheckins" size="small">
        <el-table-column label="孩子" width="100">
          <template #default="{ row }">{{ childName(row.child_id) }}</template>
        </el-table-column>
        <el-table-column prop="checkin_type" label="类型" width="110" />
        <el-table-column prop="subject" label="科目" width="100" />
        <el-table-column prop="content" label="内容" min-width="200" show-overflow-tooltip />
        <el-table-column label="时间" width="170">
          <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag type="warning">{{ statusLabel(row.status) }}</el-tag>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!pendingCheckins.length" description="暂无待审核打卡" :image-size="80" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import type { EChartsOption } from 'echarts'
import EChart from '@/components/EChart.vue'
import { useChildrenStore } from '@/stores/children'
import * as tasksApi from '@/api/tasks'
import * as checkinsApi from '@/api/checkins'
import * as plansApi from '@/api/plans'
import type { CheckinRecord, TaskItem } from '@/types'
import { currentIsoWeek, formatDateTime, statusLabel } from '@/utils/date'

const childrenStore = useChildrenStore()
const loading = ref(false)
const currentWeek = currentIsoWeek()

const stats = ref({ children: 0, todayTasks: 0, todayCompleted: 0, pendingCheckins: 0 })
const pendingCheckins = ref<Array<CheckinRecord & { child_id: string }>>([])
const weekTasks = ref<TaskItem[]>([])

const firstChild = computed(() => childrenStore.children[0] || null)

function quotaPercent(row: { quota_mb?: number; used_mb?: number }): number {
  if (!row.quota_mb) return 0
  return Math.min(100, Math.round(((row.used_mb ?? 0) / row.quota_mb) * 100))
}

function childName(id: string): string {
  return childrenStore.children.find((c) => c.id === id)?.name || id
}

const weekChartOption = computed<EChartsOption>(() => {
  const byDate = new Map<string, { total: number; completed: number }>()
  for (const t of weekTasks.value) {
    const d = t.planned_date || ''
    if (!byDate.has(d)) byDate.set(d, { total: 0, completed: 0 })
    const item = byDate.get(d)!
    item.total += 1
    if (t.status === 'completed') item.completed += 1
  }
  const dates = [...byDate.keys()].sort()
  return {
    tooltip: { trigger: 'axis' },
    legend: { data: ['计划任务', '已完成'] },
    grid: { left: 40, right: 20, top: 40, bottom: 30 },
    xAxis: { type: 'category', data: dates },
    yAxis: { type: 'value', minInterval: 1 },
    series: [
      {
        name: '计划任务',
        type: 'bar',
        stack: 'total',
        barMaxWidth: 36,
        itemStyle: { color: '#c0c4cc' },
        data: dates.map((d) => byDate.get(d)!.total),
      },
      {
        name: '已完成',
        type: 'bar',
        stack: 'total',
        barMaxWidth: 36,
        itemStyle: { color: '#67c23a' },
        data: dates.map((d) => byDate.get(d)!.completed),
      },
    ],
  }
})

async function load() {
  loading.value = true
  try {
    await childrenStore.ensureLoaded()
    const list = childrenStore.children
    stats.value.children = list.length

    const todayResults = await Promise.all(
      list.map((c) =>
        tasksApi.todayTasks(c.id).then((r) => ({ childId: c.id, data: r })).catch(() => null),
      ),
    )
    const checkinResults = await Promise.all(
      list.map((c) =>
        checkinsApi
          .listCheckins(c.id)
          .then((records) => ({ childId: c.id, records }))
          .catch(() => null),
      ),
    )

    let todayTasks = 0
    let todayCompleted = 0
    for (const r of todayResults) {
      if (!r) continue
      todayTasks += r.data.tasks.length
      todayCompleted += r.data.tasks.filter((t) => t.status === 'completed').length
    }
    stats.value.todayTasks = todayTasks
    stats.value.todayCompleted = todayCompleted

    const pending: Array<CheckinRecord & { child_id: string }> = []
    for (const r of checkinResults) {
      if (!r) continue
      for (const rec of r.records) {
        if (rec.status === 'pending') pending.push({ ...rec, child_id: r.childId })
      }
    }
    pending.sort((a, b) => String(b.created_at || '').localeCompare(String(a.created_at || '')))
    pendingCheckins.value = pending.slice(0, 20)
    stats.value.pendingCheckins = pending.length

    // 本周计划（用于图表）
    if (list.length) {
      const plan = await plansApi.getWeeklyPlan(list[0].id, currentWeek).catch(() => null)
      weekTasks.value = plan?.tasks || []
    }
  } finally {
    loading.value = false
  }
}

onMounted(() => {
  load()
})
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.sub-text {
  color: #909399;
  font-size: 13px;
}
</style>