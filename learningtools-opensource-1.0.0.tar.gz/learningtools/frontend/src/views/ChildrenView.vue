<template>
  <div v-loading="loading">
    <el-card shadow="never" class="page-card">
      <div class="toolbar">
        <el-button type="primary" :icon="Plus" @click="openCreate">新增孩子账号</el-button>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>

      <el-table :data="childrenStore.children" stripe>
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column label="年级" width="70">
          <template #default="{ row }">{{ row.grade ?? '-' }}</template>
        </el-table-column>
        <el-table-column label="生日" width="110">
          <template #default="{ row }">{{ formatDate(row.birthday) }}</template>
        </el-table-column>
        <el-table-column label="存储配额" width="160">
          <template #default="{ row }">
            <el-progress
              :percentage="quotaPercent(row)"
              :stroke-width="10"
              :format="() => `${formatBytesToMb(row.used_mb)} / ${formatBytesToMb(row.quota_mb)}`"
            />
          </template>
        </el-table-column>
        <el-table-column label="保留期" width="160">
          <template #default="{ row }">
            照片 {{ row.photo_retention_days ?? '-' }} 天 / 视频 {{ row.video_retention_days ?? '-' }} 天
          </template>
        </el-table-column>
        <el-table-column label="孩子账号" width="120">
          <template #default="{ row }">
            <el-tag v-if="row.user_id" type="success" size="small">已创建 (ID: {{ row.user_id }})</el-tag>
            <el-tag v-else type="info" size="small">无</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="创建时间" width="160">
          <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-tooltip content="编辑" placement="top">
              <el-button size="small" link type="primary" :icon="Edit" @click="openEdit(row)" />
            </el-tooltip>
            <el-tooltip content="设置配额" placement="top">
              <el-button size="small" link type="warning" :icon="Coin" @click="openQuota(row)" />
            </el-tooltip>
            <el-tooltip content="设置保留期" placement="top">
              <el-button size="small" link type="info" :icon="Timer" @click="openRetention(row)" />
            </el-tooltip>
            <el-tooltip v-if="auth.isAdmin" content="删除" placement="top">
              <el-button size="small" link type="danger" :icon="Delete" @click="handleDelete(row)" />
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新建 / 编辑 -->
    <el-dialog
      v-model="formVisible"
      :title="editingId ? '编辑孩子' : '新增孩子账号'"
      width="480px"
      destroy-on-close
    >
      <el-form ref="formRef" :model="form" :rules="formRules" label-width="90px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" placeholder="请输入姓名" />
        </el-form-item>
        <el-form-item label="年级">
          <el-input-number v-model="form.grade" :min="1" :max="12" placeholder="选填" />
        </el-form-item>
        <el-form-item label="生日">
          <el-date-picker v-model="form.birthday" type="date" value-format="YYYY-MM-DD" placeholder="选填" />
        </el-form-item>
        <el-form-item label="头像地址">
          <el-input v-model="form.avatar" placeholder="选填，图片 URL" />
        </el-form-item>
        <template v-if="!editingId">
          <el-divider content-position="left">孩子账号（可选，用于孩子端登录）</el-divider>
          <el-form-item label="用户名">
            <el-input v-model="form.username" placeholder="选填，同时填写密码才创建账号" />
          </el-form-item>
          <el-form-item label="密码">
            <el-input v-model="form.password" type="password" show-password placeholder="至少 6 位" />
          </el-form-item>
        </template>
      </el-form>
      <template #footer>
        <el-button @click="formVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submitForm">保存</el-button>
      </template>
    </el-dialog>

    <!-- 配额设置 -->
    <el-dialog v-model="quotaVisible" title="设置存储配额" width="420px" destroy-on-close>
      <el-form label-width="100px">
        <el-form-item label="当前用量">
          <span>{{ formatBytesToMb(quotaForm.used_mb) }}</span>
        </el-form-item>
        <el-form-item label="配额 (MB)" required>
          <el-input-number v-model="quotaForm.quota_mb" :min="0" :step="128" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="quotaVisible = false">取消</el-button>
        <el-button type="primary" :loading="quotaSaving" @click="submitQuota">保存</el-button>
      </template>
    </el-dialog>

    <!-- 保留期设置 -->
    <el-dialog v-model="retentionVisible" title="设置数据保留期" width="420px" destroy-on-close>
      <el-form label-width="130px">
        <el-form-item label="照片保留 (天)">
          <el-input-number v-model="retentionForm.photo_retention_days" :min="0" />
        </el-form-item>
        <el-form-item label="视频保留 (天)">
          <el-input-number v-model="retentionForm.video_retention_days" :min="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="retentionVisible = false">取消</el-button>
        <el-button type="primary" :loading="retentionSaving" @click="submitRetention">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { Coin, Delete, Edit, Plus, Refresh, Timer } from '@element-plus/icons-vue'
import { useChildrenStore } from '@/stores/children'
import { useAuthStore } from '@/stores/auth'
import * as childrenApi from '@/api/children'
import type { Child } from '@/types'
import { confirmAction, formatBytesToMb, formatDate, formatDateTime } from '@/utils/date'

const childrenStore = useChildrenStore()
const auth = useAuthStore()
const loading = ref(false)

function quotaPercent(row: Child): number {
  if (!row.quota_mb) return 0
  return Math.min(100, Math.round(((row.used_mb ?? 0) / row.quota_mb) * 100))
}

async function load() {
  loading.value = true
  try {
    await childrenStore.reload()
  } finally {
    loading.value = false
  }
}

// ---- 新建 / 编辑 ----
const formVisible = ref(false)
const saving = ref(false)
const editingId = ref('')
const formRef = ref<FormInstance>()
const form = reactive({
  name: '',
  grade: undefined as number | undefined,
  birthday: '' as string,
  avatar: '',
  username: '',
  password: '',
})
const formRules: FormRules = {
  name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
}

function openCreate() {
  editingId.value = ''
  Object.assign(form, { name: '', grade: undefined, birthday: '', avatar: '', username: '', password: '' })
  formVisible.value = true
}

function openEdit(row: Child) {
  editingId.value = row.id
  Object.assign(form, {
    name: row.name,
    grade: row.grade ?? undefined,
    birthday: row.birthday || '',
    avatar: row.avatar || '',
    username: '',
    password: '',
  })
  formVisible.value = true
}

async function submitForm() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  saving.value = true
  try {
    const body: childrenApi.ChildBody = {
      name: form.name,
      grade: form.grade ?? null,
      birthday: form.birthday || null,
      avatar: form.avatar || null,
    }
    if (!editingId.value) {
      body.username = form.username || null
      body.password = form.password || null
      if ((body.username && !body.password) || (!body.username && body.password)) {
        ElMessage.warning('孩子账号的用户名和密码需同时填写')
        return
      }
      await childrenApi.createChild(body)
      ElMessage.success('创建成功')
    } else {
      await childrenApi.updateChild(editingId.value, body)
      ElMessage.success('保存成功')
    }
    formVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    saving.value = false
  }
}

// ---- 配额 ----
const quotaVisible = ref(false)
const quotaSaving = ref(false)
const quotaForm = reactive({ childId: '', quota_mb: 2048, used_mb: 0 })

async function openQuota(row: Child) {
  quotaForm.childId = row.id
  quotaForm.quota_mb = row.quota_mb ?? 2048
  quotaForm.used_mb = row.used_mb ?? 0
  try {
    const info = await childrenApi.getQuota(row.id)
    quotaForm.quota_mb = info.quota_mb
    quotaForm.used_mb = info.used_mb
  } catch {
    // 保留默认值
  }
  quotaVisible.value = true
}

async function submitQuota() {
  quotaSaving.value = true
  try {
    await childrenApi.setQuota(quotaForm.childId, quotaForm.quota_mb)
    ElMessage.success('配额已更新')
    quotaVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    quotaSaving.value = false
  }
}

// ---- 保留期 ----
const retentionVisible = ref(false)
const retentionSaving = ref(false)
const retentionForm = reactive({ childId: '', photo_retention_days: 30, video_retention_days: 15 })

function openRetention(row: Child) {
  retentionForm.childId = row.id
  retentionForm.photo_retention_days = row.photo_retention_days ?? 30
  retentionForm.video_retention_days = row.video_retention_days ?? 15
  retentionVisible.value = true
}

async function submitRetention() {
  retentionSaving.value = true
  try {
    await childrenApi.setRetention(retentionForm.childId, {
      photo_retention_days: retentionForm.photo_retention_days,
      video_retention_days: retentionForm.video_retention_days,
    })
    ElMessage.success('保留期已更新')
    retentionVisible.value = false
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    retentionSaving.value = false
  }
}

// ---- 删除 ----
async function handleDelete(row: Child) {
  const ok = await confirmAction(`确定删除孩子「${row.name}」吗？此操作不可恢复！`, '删除确认', 'warning')
  if (!ok) return
  try {
    await childrenApi.deleteChild(row.id)
    ElMessage.success('已删除')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

onMounted(load)
</script>

<style scoped>
.toolbar {
  margin-bottom: 16px;
  display: flex;
  gap: 8px;
}
</style>