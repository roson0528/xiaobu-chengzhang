<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-date-picker
          v-model="month"
          type="month"
          value-format="YYYY-MM"
          placeholder="选择月份"
          :clearable="false"
          style="width: 160px"
        />
        <el-button :icon="Refresh" @click="load">刷新</el-button>
        <span class="tip">孩子每天可记录心情（开心/一般/疲惫），家长在此查看。</span>
      </div>

      <el-table :data="records" stripe>
        <el-table-column prop="date" label="日期" width="120" />
        <el-table-column label="心情" width="120">
          <template #default="{ row }">
            <el-tag :type="moodType(row.mood)" effect="dark">{{ moodLabel(row.mood) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="备注" min-width="220" show-overflow-tooltip>
          <template #default="{ row }">{{ row.note || '-' }}</template>
        </el-table-column>
        <el-table-column label="提交时间" width="170">
          <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
        </el-table-column>
      </el-table>

      <el-empty v-if="!records.length" description="该月暂无心情记录" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import { Refresh } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as moodApi from '@/api/mood'
import type { MoodRecord } from '@/api/mood'
import { formatDateTime } from '@/utils/date'

const childrenStore = useChildrenStore()
const childId = ref('')
const month = ref(new Date().toISOString().slice(0, 7))
const records = ref<MoodRecord[]>([])
const loading = ref(false)

const MOOD_LABELS: Record<string, string> = { happy: '开心', ok: '一般', tired: '疲惫' }

function moodLabel(m?: string): string {
  return (m && MOOD_LABELS[m]) || '-'
}

function moodType(m?: string): 'success' | 'info' | 'danger' {
  if (m === 'happy') return 'success'
  if (m === 'tired') return 'danger'
  return 'info'
}

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    records.value = await moodApi.listMood(childId.value, month.value)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

watch(childId, () => {
  if (childId.value) load()
})

watch(month, () => {
  if (childId.value) load()
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.tip {
  color: #909399;
  font-size: 13px;
}
</style>
