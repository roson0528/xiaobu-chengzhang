<template>
  <div class="login-page">
    <div class="login-card">
      <div class="login-title">
        <el-icon :size="32"><Reading /></el-icon>
        <h2>小步成长管理后台</h2>
        <p>家长端 · 管理员端</p>
      </div>
      <el-form ref="formRef" :model="form" :rules="rules" size="large" @keyup.enter="handleLogin">
        <el-form-item prop="username">
          <el-input v-model="form.username" placeholder="用户名" :prefix-icon="User" />
        </el-form-item>
        <el-form-item prop="password">
          <el-input
            v-model="form.password"
            type="password"
            show-password
            placeholder="密码"
            :prefix-icon="Lock"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" class="login-btn" :loading="loading" @click="handleLogin">
            登 录
          </el-button>
        </el-form-item>
        <div class="login-footer">
          <el-link type="primary" :underline="false" @click="regVisible = true">注册账号</el-link>
        </div>
      </el-form>
    </div>

    <!-- 注册 -->
    <el-dialog v-model="regVisible" title="注册账号（家长）" width="440px" destroy-on-close>
      <el-form ref="regFormRef" :model="regForm" :rules="regRules" label-width="80px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="regForm.username" placeholder="请输入用户名" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="regForm.password" type="password" show-password placeholder="至少 6 位" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="regForm.email" placeholder="选填" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="regForm.phone" placeholder="选填" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="regVisible = false">取消</el-button>
        <el-button type="primary" :loading="regSaving" @click="handleRegister">注册</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, type FormInstance, type FormRules } from 'element-plus'
import { User, Lock, Reading } from '@element-plus/icons-vue'
import { useAuthStore } from '@/stores/auth'
import * as authApi from '@/api/auth'

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()

const formRef = ref<FormInstance>()
const form = reactive({ username: '', password: '' })
const loading = ref(false)
const rules: FormRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
}

async function handleLogin() {
  const valid = await formRef.value?.validate().catch(() => false)
  if (!valid) return
  loading.value = true
  try {
    await auth.login(form.username, form.password)
    ElMessage.success('登录成功')
    const redirect = (route.query.redirect as string) || '/dashboard'
    router.push(redirect)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

// ---- 注册 ----
const regVisible = ref(false)
const regSaving = ref(false)
const regFormRef = ref<FormInstance>()
const regForm = reactive({ username: '', password: '', email: '', phone: '' })
const regRules: FormRules = {
  username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, message: '密码至少 6 位', trigger: 'blur' },
  ],
}

async function handleRegister() {
  const valid = await regFormRef.value?.validate().catch(() => false)
  if (!valid) return
  regSaving.value = true
  try {
    const res = await authApi.register({
      username: regForm.username,
      password: regForm.password,
      email: regForm.email || undefined,
      phone: regForm.phone || undefined,
    })
    ElMessage.success(res.message || '注册成功，等待管理员审批')
    regVisible.value = false
  } catch {
    // 错误提示由拦截器处理
  } finally {
    regSaving.value = false
  }
}
</script>

<style scoped>
.login-page {
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #1677ff 0%, #0d3f8f 100%);
}

.login-card {
  width: 400px;
  max-width: calc(100vw - 32px);
  padding: 40px 36px 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
}

@media (max-width: 768px) {
  .login-card {
    padding: 28px 20px 20px;
  }
}

.login-title {
  text-align: center;
  margin-bottom: 28px;
  color: #1677ff;
}

.login-title h2 {
  margin: 8px 0 4px;
  font-size: 20px;
  color: #303133;
}

.login-title p {
  margin: 0;
  color: #909399;
  font-size: 13px;
}

.login-btn {
  width: 100%;
}

.login-footer {
  text-align: center;
}
</style>