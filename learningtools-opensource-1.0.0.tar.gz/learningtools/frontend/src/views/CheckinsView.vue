<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <el-tabs v-model="mainTab">
        <!-- 打卡审核 -->
        <el-tab-pane label="打卡审核" name="review">
          <div class="toolbar">
            <ChildSelect v-model="childId" />
            <el-button :icon="Refresh" @click="loadRecords">刷新</el-button>
            <el-button type="success" :icon="Check" :disabled="!selectedRecords.length" @click="batchApprove">
              批量通过
            </el-button>
            <el-button type="danger" :icon="Close" :disabled="!selectedRecords.length" @click="batchReject">
              批量驳回
            </el-button>
            <span v-if="selectedRecords.length" class="tip">已选 {{ selectedRecords.length }} 条</span>
          </div>

          <el-tabs v-model="recordTab">
            <el-tab-pane label="全部" name="all" />
            <el-tab-pane label="待审核" name="pending" />
            <el-tab-pane label="已通过" name="approved" />
            <el-tab-pane label="已驳回" name="rejected" />
          </el-tabs>

          <el-table :data="filteredRecords" stripe class="compact-table" @selection-change="onSelectionChange">
            <el-table-column type="selection" width="40" />
            <el-table-column prop="checkin_type" label="类型" width="84" show-overflow-tooltip />
            <el-table-column prop="subject" label="科目" width="62" show-overflow-tooltip>
              <template #default="{ row }">{{ row.subject || '-' }}</template>
            </el-table-column>
            <el-table-column prop="content" label="内容" min-width="160" show-overflow-tooltip>
              <template #default="{ row }">
                <span class="content-cell">
                  {{ row.content || '-' }}
                  <span v-if="row.photo_path" class="media-icon" title="含照片">📷</span>
                  <span v-if="row.audio_path" class="media-icon" title="含录音">🎙️</span>
                </span>
              </template>
            </el-table-column>
            <el-table-column label="时长(分)" width="68">
              <template #default="{ row }">{{ row.duration ?? '-' }}</template>
            </el-table-column>
            <el-table-column label="提交时间" width="132" show-overflow-tooltip>
              <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
            </el-table-column>
            <el-table-column label="状态" width="74">
              <template #default="{ row }">
                <el-tag :type="statusTagType(row.status)">{{ statusLabel(row.status) }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="审核意见" min-width="120" show-overflow-tooltip>
              <template #default="{ row }">{{ row.review_comment || '-' }}</template>
            </el-table-column>
            <el-table-column label="评分" width="50">
              <template #default="{ row }">{{ row.score ?? '-' }}</template>
            </el-table-column>
            <el-table-column label="操作" width="88" fixed="right" align="center">
              <template #default="{ row }">
                <template v-if="row.status === 'pending'">
                  <el-tooltip content="详情" placement="top">
                    <el-button size="small" link type="primary" :icon="View" @click="openDetail(row)" />
                  </el-tooltip>
                  <el-tooltip content="通过" placement="top">
                    <el-button size="small" link type="success" :icon="Check" @click="openApprove(row)" />
                  </el-tooltip>
                  <el-tooltip content="驳回" placement="top">
                    <el-button size="small" link type="danger" :icon="Close" @click="openReject(row)" />
                  </el-tooltip>
                </template>
                <el-tooltip v-else content="详情" placement="top">
                  <el-button size="small" link type="primary" :icon="View" @click="openDetail(row)" />
                </el-tooltip>
              </template>
            </el-table-column>
          </el-table>

          <el-empty v-if="!filteredRecords.length" description="该分类暂无打卡记录" />
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <!-- 通过（评分） -->
    <el-dialog v-model="approveVisible" title="通过打卡" width="440px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item v-for="d in SCORE_DIMENSIONS" :key="d.key" :label="d.label">
          <el-rate v-model="approveRatings[d.key]" :max="5" />
        </el-form-item>
        <el-form-item label="总评分">
          <span class="score-preview">{{ approveScorePreview ?? '未打分' }}</span>
        </el-form-item>
        <el-form-item label="评语">
          <el-input
            v-model="approveComment"
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="评语（选填）"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="approveVisible = false">取消</el-button>
        <el-button type="primary" :loading="approving" @click="submitApprove">确认通过</el-button>
      </template>
    </el-dialog>

    <!-- 驳回原因 -->
    <el-dialog v-model="rejectVisible" title="驳回打卡" width="440px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item v-for="d in SCORE_DIMENSIONS" :key="d.key" :label="d.label">
          <el-rate v-model="rejectRatings[d.key]" :max="5" />
        </el-form-item>
        <el-form-item label="总评分">
          <span class="score-preview">{{ rejectScorePreview ?? '未打分' }}</span>
        </el-form-item>
        <el-form-item label="驳回原因" required>
          <el-input
            v-model="rejectComment"
            type="textarea"
            :rows="3"
            maxlength="200"
            show-word-limit
            placeholder="请填写驳回原因（必填）"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="rejectVisible = false">取消</el-button>
        <el-button type="danger" :loading="rejecting" @click="submitReject">确认驳回</el-button>
      </template>
    </el-dialog>

    <!-- 打卡详情 -->
    <el-dialog
      v-model="detailVisible"
      title="打卡详情"
      width="520px"
      destroy-on-close
      @closed="cleanupDetailUrls"
    >
      <div v-if="detailRecord" v-loading="detailLoading" class="detail-body">
        <el-descriptions :column="1" border>
          <el-descriptions-item label="类型">{{ detailRecord.checkin_type || '-' }}</el-descriptions-item>
          <el-descriptions-item label="科目">{{ detailRecord.subject || '-' }}</el-descriptions-item>
          <el-descriptions-item label="内容">{{ detailRecord.content || '-' }}</el-descriptions-item>
          <el-descriptions-item label="时长(分)">{{ detailRecord.duration ?? '-' }}</el-descriptions-item>
          <el-descriptions-item label="提交时间">{{ formatDateTime(detailRecord.created_at) }}</el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="statusTagType(detailRecord.status)">{{ statusLabel(detailRecord.status) }}</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="审核意见">{{ detailRecord.review_comment || '-' }}</el-descriptions-item>
          <el-descriptions-item label="评分">{{ detailRecord.score ?? '-' }}</el-descriptions-item>
        </el-descriptions>
        <div v-if="photoUrl" class="detail-media">
          <p class="media-label">打卡照片</p>
          <el-image :src="photoUrl" fit="cover" class="detail-photo" :preview-src-list="[photoUrl]" preview-teleported />
        </div>
        <div v-if="audioUrl" class="detail-media">
          <p class="media-label">朗读录音</p>
          <audio :src="audioUrl" controls class="detail-audio" />
        </div>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Check, Close, Refresh, View } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as checkinsApi from '@/api/checkins'
import type { CheckinRecord } from '@/types'
import { confirmAction, formatDateTime, statusLabel, statusTagType } from '@/utils/date'
import { SCORE_DIMENSIONS, ratingsToScore } from '@/utils/scoring'

const childrenStore = useChildrenStore()
const childId = ref('')
const loading = ref(false)

// ---- 打卡审核 ----
const mainTab = ref('review')
const recordTab = ref('pending')
const records = ref<CheckinRecord[]>([])

const filteredRecords = computed(() => {
  if (recordTab.value === 'all') return records.value
  return records.value.filter((r) => r.status === recordTab.value)
})

async function loadRecords() {
  if (!childId.value) return
  loading.value = true
  try {
    records.value = await checkinsApi.listCheckins(childId.value)
    selectedRecords.value = []
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

// ---- 批量审核 ----
const selectedRecords = ref<CheckinRecord[]>([])

function onSelectionChange(rows: CheckinRecord[]) {
  selectedRecords.value = rows
}

function pendingSelectedIds(): string[] {
  return selectedRecords.value.filter((r) => r.status === 'pending').map((r) => r.id)
}

async function batchApprove() {
  const ids = pendingSelectedIds()
  if (!ids.length) return
  const ok = await confirmAction(`确定通过选中的 ${ids.length} 条打卡吗？`, '批量通过', 'success')
  if (!ok) return
  try {
    await checkinsApi.batchReview(childId.value, ids, 'approve')
    ElMessage.success(`已通过 ${ids.length} 条`)
    await loadRecords()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function batchReject() {
  const ids = pendingSelectedIds()
  if (!ids.length) return
  try {
    const { value } = await ElMessageBox.prompt('请输入驳回原因（将应用到所选记录）', '批量驳回', {
      confirmButtonText: '确认驳回',
      cancelButtonText: '取消',
      inputPlaceholder: '驳回原因',
      inputValidator: (v: string) => (v && v.trim() ? true : '请填写驳回原因'),
    })
    await checkinsApi.batchReview(childId.value, ids, 'reject', value.trim())
    ElMessage.success(`已驳回 ${ids.length} 条`)
    await loadRecords()
  } catch {
    // 用户取消或请求失败
  }
}

// ---- 通过（评分对话框） ----
const approveVisible = ref(false)
const approveRatings = reactive<Record<string, number>>({})
const approveComment = ref('')
const approving = ref(false)
let approvingRecord: CheckinRecord | null = null

const approveScorePreview = computed(() => ratingsToScore(approveRatings))

function openApprove(row: CheckinRecord) {
  approvingRecord = row
  Object.keys(approveRatings).forEach((k) => delete approveRatings[k])
  approveComment.value = ''
  approveVisible.value = true
}

async function submitApprove() {
  if (!approvingRecord) return
  approving.value = true
  try {
    await checkinsApi.approveCheckin(
      approvingRecord.id,
      childId.value,
      approveComment.value.trim() || undefined,
      approveScorePreview.value !== undefined ? { ...approveRatings } : undefined,
    )
    ElMessage.success('已通过')
    approveVisible.value = false
    await loadRecords()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    approving.value = false
  }
}

// ---- 详情 ----
const detailVisible = ref(false)
const detailLoading = ref(false)
const detailRecord = ref<CheckinRecord | null>(null)
const photoUrl = ref('')
const audioUrl = ref('')

function cleanupDetailUrls() {
  if (photoUrl.value) URL.revokeObjectURL(photoUrl.value)
  if (audioUrl.value) URL.revokeObjectURL(audioUrl.value)
  photoUrl.value = ''
  audioUrl.value = ''
  detailRecord.value = null
}

async function openDetail(row: CheckinRecord) {
  cleanupDetailUrls()
  detailRecord.value = row
  detailVisible.value = true
  detailLoading.value = true
  try {
    if (row.photo_path) {
      photoUrl.value = await checkinsApi.fetchSubmissionPhotoBlob(childId.value, row.photo_path)
    }
    if (row.audio_path) {
      audioUrl.value = await checkinsApi.fetchAudioBlob(childId.value, row.audio_path)
    }
  } catch {
    // 错误提示由拦截器处理
  } finally {
    detailLoading.value = false
  }
}

// ---- 驳回 ----
const rejectVisible = ref(false)
const rejectComment = ref('')
const rejectRatings = reactive<Record<string, number>>({})
const rejecting = ref(false)
let rejectingRecord: CheckinRecord | null = null

const rejectScorePreview = computed(() => ratingsToScore(rejectRatings))

function openReject(row: CheckinRecord) {
  rejectingRecord = row
  rejectComment.value = ''
  Object.keys(rejectRatings).forEach((k) => delete rejectRatings[k])
  rejectVisible.value = true
}

async function submitReject() {
  if (!rejectComment.value.trim()) {
    ElMessage.warning('请填写驳回原因')
    return
  }
  rejecting.value = true
  try {
    await checkinsApi.rejectCheckin(
      rejectingRecord!.id,
      childId.value,
      rejectComment.value.trim(),
      rejectScorePreview.value !== undefined ? { ...rejectRatings } : undefined,
    )
    ElMessage.success('已驳回')
    rejectVisible.value = false
    await loadRecords()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    rejecting.value = false
  }
}

watch(childId, () => {
  if (childId.value) {
    loadRecords()
  }
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}
.no-op {
  color: #c0c4cc;
}
.compact-table :deep(.el-table__cell) {
  padding: 6px 0;
}
.compact-table :deep(.el-table__cell .cell) {
  padding: 0 6px;
}
.compact-table :deep(.el-table th.el-table__cell) {
  font-size: 13px;
}
.score-preview {
  font-size: 16px;
  font-weight: 600;
  color: #f56c6c;
}
.content-cell {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.media-icon {
  cursor: default;
  font-size: 14px;
  flex-shrink: 0;
}
.detail-body {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.detail-media {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.media-label {
  margin: 0;
  font-size: 13px;
  color: #909399;
}
.detail-photo {
  width: 100%;
  max-height: 320px;
  border-radius: 6px;
}
.detail-audio {
  width: 100%;
}
</style>