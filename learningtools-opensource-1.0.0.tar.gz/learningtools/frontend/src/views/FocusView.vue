<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-tabs v-model="activeTab" class="inline-tabs">
          <el-tab-pane label="专注会话" name="sessions" />
          <el-tab-pane label="专注照片" name="photos" />
        </el-tabs>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>

      <!-- 会话列表 -->
      <template v-if="activeTab === 'sessions'">
        <div class="toolbar">
          <el-date-picker
            v-model="sessionDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择日期（默认今天）"
            clearable
            style="width: 220px"
            @change="loadSessions"
          />
          <el-button size="small" @click="sessionDate = localToday(); loadSessions()">今天</el-button>
          <span class="photo-count">{{ sessions.length }} 个会话</span>
        </div>

        <el-table :data="sessions" stripe>
          <el-table-column label="会话" min-width="170" show-overflow-tooltip>
            <template #default="{ row }">{{ row.task_name || '自由任务' }}</template>
          </el-table-column>
          <el-table-column label="开始时间" width="170">
            <template #default="{ row }">{{ formatDateTime(row.started_at) }}</template>
          </el-table-column>
          <el-table-column label="结束时间" width="170">
            <template #default="{ row }">{{ formatDateTime(row.ended_at) }}</template>
          </el-table-column>
          <el-table-column label="时长" width="120">
            <template #default="{ row }">{{ formatDuration(row.duration) }}</template>
          </el-table-column>
          <el-table-column label="分心次数" width="90">
            <template #default="{ row }">
              <span :class="{ 'distract-high': (row.distraction_count || 0) > 3 }">
                {{ row.distraction_count ?? 0 }}
              </span>
            </template>
          </el-table-column>
          <el-table-column label="照片数" width="80">
            <template #default="{ row }">{{ row.photo_count ?? 0 }}</template>
          </el-table-column>
          <el-table-column label="状态" width="90">
            <template #default="{ row }">
              <el-tag :type="statusTagType(row.status)">{{ statusLabel(row.status) }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="关联任务" width="160" show-overflow-tooltip>
            <template #default="{ row }">{{ row.task_id || '-' }}</template>
          </el-table-column>
          <el-table-column label="操作" width="90" fixed="right">
            <template #default="{ row }">
              <el-button size="small" link type="primary" @click="showSessionPhotos(row)">照片</el-button>
            </template>
          </el-table-column>
        </el-table>
        <el-empty v-if="!sessions.length" description="该日期暂无专注会话" />
      </template>

      <!-- 照片列表 -->
      <template v-else>
        <div class="toolbar">
          <el-date-picker
            v-model="photoDate"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="选择日期（不选则列日期目录）"
            style="width: 220px"
            @change="loadPhotos"
          />
          <span class="photo-count">{{ photoFiles.length }} 张照片</span>
        </div>

        <!-- 未选日期时列出的日期目录 -->
        <div v-if="dirEntries.length" class="dir-list">
          <span class="dir-hint">选择日期查看照片：</span>
          <el-tag
            v-for="d in dirEntries"
            :key="d"
            class="dir-tag"
            type="info"
            effect="plain"
            @click="photoDate = d.replace(/\/$/, ''); loadPhotos()"
          >
            📁 {{ d.replace(/\/$/, '') }}
          </el-tag>
        </div>

        <!-- 照片缩略图网格 -->
        <div v-loading="photoLoading" class="photo-grid">
          <div v-for="(p, i) in photoFiles" :key="p.path" class="photo-item">
            <div class="photo-thumb-wrap">
              <el-image
                :src="p.url"
                fit="cover"
                class="photo-thumb"
                :preview-src-list="previewUrls"
                :initial-index="i"
                preview-teleported
                lazy
              >
                <template #error>
                  <div class="photo-error">加载失败</div>
                </template>
              </el-image>
              <el-tag v-if="annotationFor(p)?.distracted" type="danger" size="small" class="distract-badge">
                分心
              </el-tag>
            </div>
            <div class="photo-meta">
              <span class="photo-name" :title="p.path">{{ basename(p.path) }}</span>
              <div class="photo-actions">
                <el-button
                  v-if="annotationFor(p)?.distracted"
                  size="small"
                  link
                  class="annotated-btn"
                  @click="toggleDistracted(p)"
                >
                  已标分心
                </el-button>
                <el-button v-else size="small" link class="annotate-btn" @click="toggleDistracted(p)">
                  标分心
                </el-button>
                <el-button size="small" type="danger" link @click="removePhoto(p.path)">删除</el-button>
              </div>
            </div>
          </div>
          <el-empty
            v-if="!photoFiles.length && !dirEntries.length"
            class="photo-empty"
            description="该日期暂无照片"
          />
        </div>
      </template>
    </el-card>

    <!-- 会话照片抽屉 -->
    <el-drawer
      v-model="photosVisible"
      :title="`会话照片${sessionPhotos.length ? `（${sessionPhotos.length} 张）` : ''}`"
      size="640px"
    >
      <div v-loading="sessionPhotosLoading" class="session-photo-grid">
        <div v-for="(p, i) in sessionPhotos" :key="p.path" class="session-photo-item">
          <el-image
            :src="p.url"
            fit="cover"
            class="photo-thumb"
            :preview-src-list="sessionPreviewUrls"
            :initial-index="i"
            preview-teleported
            lazy
          >
            <template #error>
              <div class="photo-error">加载失败</div>
            </template>
          </el-image>
          <span class="photo-name" :title="p.path">{{ basename(p.path) }}</span>
        </div>
        <el-empty
          v-if="!sessionPhotos.length && !sessionPhotosLoading"
          class="photo-empty"
          description="该会话暂无照片"
        />
      </div>
    </el-drawer>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Refresh } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as focusApi from '@/api/focus'
import type { PhotoAnnotation } from '@/api/focus'
import type { FocusSession } from '@/types'
import { confirmAction, formatDateTime, formatDuration, localToday, statusLabel, statusTagType } from '@/utils/date'

interface PhotoItem {
  path: string
  url?: string
}

const IMG_EXT = /\.(jpe?g|png|gif|webp|bmp)$/i

const childrenStore = useChildrenStore()
const childId = ref('')
const activeTab = ref('sessions')
const sessions = ref<FocusSession[]>([])
const photos = ref<PhotoItem[]>([])
const annotations = ref<PhotoAnnotation[]>([])
const photoDate = ref('')
const sessionDate = ref(localToday())
const loading = ref(false)
const photoLoading = ref(false)

const photosVisible = ref(false)
const sessionPhotos = ref<PhotoItem[]>([])
const sessionPhotosLoading = ref(false)

const dirEntries = computed(() => photos.value.filter((p) => p.path.endsWith('/')).map((p) => p.path))
const photoFiles = computed(() => photos.value.filter((p) => !p.path.endsWith('/')))
const previewUrls = computed(() => photoFiles.value.map((p) => p.url).filter((u): u is string => !!u))
const sessionPreviewUrls = computed(() =>
  sessionPhotos.value.map((p) => p.url).filter((u): u is string => !!u),
)

function basename(path: string): string {
  return path.split('/').filter(Boolean).pop() || path
}

/**
 * 按照片 path 匹配标注：annotation.path 是完整路径（{childId}/focus/{日期}/{文件名}），
 * 而 listPhotos 返回的 p.path 形如 {日期}/{文件名}，两者 key 不一致，
 * 用“以 p.path 结尾 / 包含 p.path / 完全相等”的方式匹配。
 */
function annotationFor(p: PhotoItem): PhotoAnnotation | undefined {
  return annotations.value.find(
    (a) => a.path === p.path || a.path.endsWith('/' + p.path) || a.path.includes(p.path),
  )
}

async function loadAnnotations() {
  if (!childId.value) return
  try {
    annotations.value = await focusApi.listAnnotations(childId.value)
  } catch {
    // 错误提示由拦截器处理
  }
}

async function loadSessions() {
  if (!childId.value) return
  try {
    sessions.value = await focusApi.listSessions(childId.value, sessionDate.value || undefined)
  } catch {
    // 错误提示由拦截器处理
  }
}

function revokePhotos() {
  for (const p of photos.value) {
    if (p.url) URL.revokeObjectURL(p.url)
  }
  for (const p of sessionPhotos.value) {
    if (p.url) URL.revokeObjectURL(p.url)
  }
}

/** 限量并发映射，避免一次性并发拉取所有照片打爆服务端限流 */
async function mapWithConcurrency<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>,
): Promise<R[]> {
  const results: R[] = new Array(items.length)
  let next = 0
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next++
      results[i] = await fn(items[i])
    }
  })
  await Promise.all(workers)
  return results
}

async function loadPhotos() {
  if (!childId.value) return
  revokePhotos()
  photoLoading.value = true
  try {
    const paths = await focusApi.listPhotos(childId.value, photoDate.value || undefined)
    // 只保留日期目录或图片文件，隐藏 .json/.bak 等数据文件
    const items = paths.filter((p) => p.endsWith('/') || IMG_EXT.test(p))
    photos.value = await mapWithConcurrency(items, 6, async (p): Promise<PhotoItem> => {
      if (p.endsWith('/')) return { path: p }
      const url = await focusApi.fetchPhotoBlob(childId.value, p).catch(() => undefined)
      return { path: p, url }
    })
    await loadAnnotations()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    photoLoading.value = false
  }
}

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    if (activeTab.value === 'sessions') await loadSessions()
    else await loadPhotos()
  } finally {
    loading.value = false
  }
}

async function showSessionPhotos(row: FocusSession) {
  photosVisible.value = true
  sessionPhotosLoading.value = true
  sessionPhotos.value = []
  const paths = (row.photos || []) as string[]
  try {
    sessionPhotos.value = await mapWithConcurrency(paths, 6, async (p): Promise<PhotoItem> => {
      const url = await focusApi.fetchPhotoBlob(childId.value, p).catch(() => undefined)
      return { path: p, url }
    })
  } catch {
    // 错误提示由拦截器处理
  } finally {
    sessionPhotosLoading.value = false
  }
}

async function removePhoto(path: string) {
  const ok = await confirmAction(`确定删除照片「${basename(path)}」吗？`, '删除确认', 'warning')
  if (!ok) return
  try {
    await focusApi.deletePhoto(childId.value, path)
    ElMessage.success('已删除')
    await loadPhotos()
    await loadAnnotations()
  } catch {
    // 错误提示由拦截器处理
  }
}

/** 切换「分心」标注：已标注则取消，未标注则打标。path 直接使用 listPhotos 返回的路径。 */
async function toggleDistracted(p: PhotoItem) {
  const distracted = !annotationFor(p)?.distracted
  try {
    await focusApi.annotatePhoto(childId.value, { path: p.path, distracted })
    ElMessage.success(distracted ? '已标记为分心' : '已取消分心标注')
    await loadAnnotations()
  } catch {
    // 错误提示由拦截器处理
  }
}

watch(childId, () => {
  if (childId.value) load()
})

watch(activeTab, () => {
  if (childId.value) load()
})

onBeforeUnmount(revokePhotos)

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}
.inline-tabs {
  flex: 1;
}
.distract-high {
  color: #f56c6c;
  font-weight: 600;
}
.photo-count {
  color: #909399;
  font-size: 13px;
}
.dir-list {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 12px;
}
.dir-hint {
  color: #909399;
  font-size: 13px;
}
.dir-tag {
  cursor: pointer;
}
.photo-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 14px;
}
.photo-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.session-photo-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 14px;
}
.session-photo-item {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.photo-thumb-wrap {
  position: relative;
}
.distract-badge {
  position: absolute;
  top: 6px;
  right: 6px;
  z-index: 2;
}
.photo-thumb {
  width: 100%;
  height: 130px;
  border-radius: 6px;
  background: #f5f7fa;
  cursor: pointer;
}
.photo-error {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #c0c4cc;
  font-size: 13px;
}
.photo-meta {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
}
.photo-actions {
  display: flex;
  align-items: center;
  gap: 2px;
  flex-shrink: 0;
}
.annotate-btn {
  color: #909399;
}
.annotated-btn {
  color: #f56c6c;
  border: 1px solid #f56c6c;
  border-radius: 4px;
  padding: 0 4px;
  line-height: 20px;
}
.photo-name {
  font-size: 12px;
  color: #606266;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.photo-empty {
  grid-column: 1 / -1;
}
</style>