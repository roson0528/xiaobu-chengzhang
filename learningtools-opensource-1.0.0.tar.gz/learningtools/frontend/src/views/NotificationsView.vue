<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <div class="toolbar">
        <el-switch v-model="unreadOnly" active-text="只看未读" @change="load" />
        <el-date-picker
          v-model="date"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="选择日期（默认今天）"
          clearable
          style="width: 200px"
          @change="load"
        />
        <el-button size="small" @click="date = localToday(); load()">今天</el-button>
        <el-button v-if="auth.isAdmin" :icon="Setting" @click="openKeyDialog">设置Server酱Key</el-button>
        <el-button type="primary" :icon="Bell" @click="testVisible = true">发送测试通知</el-button>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>

      <el-table :data="notifications" stripe>
        <el-table-column label="标题" min-width="160">
          <template #default="{ row }">
            <span :class="{ unread: !row.read }">{{ row.title || '(无标题)' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="内容" min-width="240" show-overflow-tooltip />
        <el-table-column label="类型" width="100">
          <template #default="{ row }">
            <el-tag size="small">{{ row.kind || 'system' }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="时间" width="170">
          <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="90">
          <template #default="{ row }">
            <el-tag v-if="row.read" type="info" size="small">已读</el-tag>
            <el-tag v-else type="warning" size="small">未读</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="110" fixed="right">
          <template #default="{ row }">
            <el-button v-if="!row.read" size="small" link type="primary" @click="markRead(row)">
              标记已读
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-if="!notifications.length" description="该日期暂无通知" />
    </el-card>

    <!-- 设置 Server酱 Key -->
    <el-dialog v-model="keyVisible" title="设置 Server酱 Key" width="500px" destroy-on-close>
      <el-form label-width="90px">
        <el-form-item label="SendKey">
          <el-input v-model="serverKey" placeholder="输入 Server酱 SendKey，如 SCTxxx..." clearable />
        </el-form-item>
        <el-form-item label="当前状态">
          <el-tag v-if="keyConfigured" type="success" size="small">已配置</el-tag>
          <el-tag v-else type="info" size="small">未配置</el-tag>
        </el-form-item>
        <el-form-item label="说明">
          <span class="hint">在 sct.ftqq.com 登录后复制 SendKey 粘贴到此。保存后立即生效，测试通知 / 学习提醒 / 每日报告将推送到你的微信。</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="keyVisible = false">取消</el-button>
        <el-button type="primary" :loading="keySaving" @click="handleSaveKey">保存</el-button>
      </template>
    </el-dialog>

    <!-- 测试通知 -->
    <el-dialog v-model="testVisible" title="发送测试通知" width="440px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="消息内容">
          <el-input v-model="testMessage" type="textarea" :rows="3" placeholder="测试消息内容" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="testVisible = false">取消</el-button>
        <el-button type="primary" :loading="testing" @click="handleTest">发送</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { Bell, Refresh, Setting } from '@element-plus/icons-vue'
import * as notificationsApi from '@/api/notifications'
import { useAuthStore } from '@/stores/auth'
import type { NotificationItem } from '@/types'
import { formatDateTime, localToday } from '@/utils/date'

const auth = useAuthStore()
const notifications = ref<NotificationItem[]>([])
const loading = ref(false)
const unreadOnly = ref(false)
const date = ref(localToday())

async function load() {
  loading.value = true
  try {
    notifications.value = await notificationsApi.listNotifications(unreadOnly.value, date.value || undefined)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function markRead(row: NotificationItem) {
  try {
    await notificationsApi.markNotificationRead(row.id)
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

// ---- Server酱 Key ----
const keyVisible = ref(false)
const keySaving = ref(false)
const serverKey = ref('')
const keyConfigured = ref(false)

async function openKeyDialog() {
  keyVisible.value = true
  try {
    const res = await notificationsApi.getServerchanKey()
    serverKey.value = res.key || ''
    keyConfigured.value = res.configured
  } catch {
    // 错误提示由拦截器处理
  }
}

async function handleSaveKey() {
  keySaving.value = true
  try {
    const res = await notificationsApi.setServerchanKey(serverKey.value)
    keyConfigured.value = res.configured
    ElMessage.success(res.configured ? '已保存，Server酱推送已启用' : '已保存（Key 已清空）')
    keyVisible.value = false
  } catch {
    // 错误提示由拦截器处理
  } finally {
    keySaving.value = false
  }
}

// ---- 测试通知 ----
const testVisible = ref(false)
const testing = ref(false)
const testMessage = ref('这是一条测试消息')

async function handleTest() {
  testing.value = true
  try {
    const res = await notificationsApi.testNotification(testMessage.value)
    if (res.status === 'skipped') {
      ElMessage.warning(res.reason || '未发送（Server酱未配置）')
    } else {
      ElMessage.success('测试通知已发送')
    }
    testVisible.value = false
  } catch {
    // 错误提示由拦截器处理
  } finally {
    testing.value = false
  }
}

onMounted(load)
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.unread {
  font-weight: 600;
}
.hint {
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
}
</style>