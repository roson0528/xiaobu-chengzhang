<template>
  <div v-loading="loading">
    <el-card shadow="never" class="page-card">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-radio-group v-model="reportType">
          <el-radio-button value="weekly">周报</el-radio-button>
          <el-radio-button value="monthly">月报</el-radio-button>
        </el-radio-group>
        <el-date-picker
          v-if="reportType === 'weekly'"
          v-model="weekDate"
          type="week"
          format="YYYY-MM-DD"
          placeholder="选择周"
          style="width: 180px"
          :clearable="false"
        />
        <el-date-picker
          v-else
          v-model="monthValue"
          type="month"
          value-format="YYYY-MM"
          placeholder="选择月份"
          style="width: 160px"
          :clearable="false"
        />
        <el-button type="primary" :icon="View" @click="loadReport">查看 / 生成报告</el-button>
        <el-button :icon="Refresh" @click="regenerate">重新生成</el-button>
        <el-button type="success" :icon="Download" :disabled="!report" @click="exportPdf">
          导出 PDF
        </el-button>
        <el-button type="warning" plain :icon="Download" :loading="exportingZip" @click="exportZipData">
          导出数据 ZIP
        </el-button>
      </div>

      <template v-if="report">
        <el-alert
          v-if="report.week"
          type="info"
          :closable="false"
          class="page-card"
          :title="`${report.week} 周报（生成于 ${formatDateTime(report.generated_at)}）`"
        />
        <el-alert
          v-else-if="report.month"
          type="info"
          :closable="false"
          class="page-card"
          :title="`${report.month} 月报（生成于 ${formatDateTime(report.generated_at)}）`"
        />

        <el-row :gutter="16" class="page-card">
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ summary.total_tasks ?? 0 }}</div>
              <div class="stat-label">总任务</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value" style="color: #67c23a">{{ summary.completed ?? 0 }}</div>
              <div class="stat-label">已完成</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ fmtRate(summary.completion_rate) }}</div>
              <div class="stat-label">完成率</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ summary.total_study_minutes ?? 0 }} 分</div>
              <div class="stat-label">学习时长</div>
            </el-card>
          </el-col>
        </el-row>

        <el-row :gutter="16" class="page-card">
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ summary.total_fitness_minutes ?? 0 }} 分</div>
              <div class="stat-label">运动时长</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ summary.focus_sessions ?? 0 }}</div>
              <div class="stat-label">专注次数</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value" style="color: #f56c6c">{{ summary.distraction_count ?? 0 }}</div>
              <div class="stat-label">分心次数</div>
            </el-card>
          </el-col>
          <el-col :xs="12" :span="6">
            <el-card shadow="hover" class="stat-card">
              <div class="stat-value">{{ (summary.total_study_minutes ?? 0) + (summary.total_fitness_minutes ?? 0) }} 分</div>
              <div class="stat-label">总投入时长</div>
            </el-card>
          </el-col>
        </el-row>

        <!-- 打分分析 -->
        <el-card v-if="report.scoring" shadow="never" class="page-card">
          <template #header>打分分析</template>
          <el-row :gutter="16">
            <el-col :xs="12" :span="6">
              <el-card shadow="hover" class="stat-card">
                <div class="stat-value">{{ fmtScore(scoring.avg_score) }}</div>
                <div class="stat-label">综合平均分</div>
              </el-card>
            </el-col>
            <el-col :xs="12" :span="6">
              <el-card shadow="hover" class="stat-card">
                <div class="stat-value">
                  <el-tag :type="levelTagType(scoring.level)">{{ scoring.level || '-' }}</el-tag>
                </div>
                <div class="stat-label">评价等级</div>
              </el-card>
            </el-col>
            <el-col :xs="12" :span="6">
              <el-card shadow="hover" class="stat-card">
                <div class="stat-value">{{ fmtScore(scoring.avg_task_score) }}</div>
                <div class="stat-label">任务平均分</div>
              </el-card>
            </el-col>
            <el-col :xs="12" :span="6">
              <el-card shadow="hover" class="stat-card">
                <div class="stat-value">{{ fmtScore(scoring.avg_checkin_score) }}</div>
                <div class="stat-label">打卡平均分</div>
              </el-card>
            </el-col>
            <el-col :xs="12" :span="6">
              <el-card shadow="hover" class="stat-card">
                <div class="stat-value" style="color: #f56c6c">{{ scoring.distraction_count ?? '-' }}</div>
                <div class="stat-label">分心次数</div>
              </el-card>
            </el-col>
          </el-row>
        </el-card>

        <el-row v-if="reportType === 'weekly'" :gutter="16" class="page-card">
          <el-col :xs="24" :span="12">
            <el-card shadow="never">
              <template #header>学科时长分布</template>
              <EChart v-if="hasSubjectData" :option="subjectOption" height="280px" />
              <el-empty v-else description="暂无学科数据" :image-size="80" />
            </el-card>
          </el-col>
          <el-col :xs="24" :span="12">
            <el-card shadow="never">
              <template #header>每日完成时长</template>
              <EChart v-if="hasTrendData" :option="trendOption" height="280px" />
              <el-empty v-else description="暂无趋势数据" :image-size="80" />
            </el-card>
          </el-col>
        </el-row>

        <el-card v-if="report.suggestions?.length" shadow="never">
          <template #header>建议</template>
          <ul class="suggestions">
            <li v-for="(s, i) in report.suggestions" :key="i">{{ s }}</li>
          </ul>
        </el-card>
      </template>

      <el-empty v-else description="请选择孩子与周期，点击「查看 / 生成报告」" />
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { View, Refresh, Download } from '@element-plus/icons-vue'
import type { EChartsOption } from 'echarts'
import ChildSelect from '@/components/ChildSelect.vue'
import EChart from '@/components/EChart.vue'
import { useChildrenStore } from '@/stores/children'
import * as reportsApi from '@/api/reports'
import * as exportApi from '@/api/export'
import type { Report, ScoringAnalysis } from '@/types'
import {
  currentIsoWeek,
  currentMonth,
  downloadBlob,
  formatDateTime,
  toIsoWeek,
  weekStartDate,
} from '@/utils/date'

const childrenStore = useChildrenStore()
const childId = ref('')
const reportType = ref<'weekly' | 'monthly'>('weekly')
const weekDate = ref<Date>(weekStartDate(currentIsoWeek()))
const monthValue = ref(currentMonth())
const report = ref<Report | null>(null)
const loading = ref(false)
const exporting = ref(false)
const exportingZip = ref(false)

const summary = computed(() => report.value?.summary || {})
const scoring = computed<ScoringAnalysis>(() => report.value?.scoring || {})

function fmtRate(v?: number): string {
  if (v === undefined || v === null) return '-'
  return `${Number(v).toFixed(1)}%`
}

/** 分数保留 1 位小数，无值显示 '-' */
function fmtScore(v?: number | null): string {
  if (v === undefined || v === null || Number.isNaN(Number(v))) return '-'
  return Number(v).toFixed(1)
}

/** 评价等级 → el-tag 颜色：优秀/良好/合格/需努力 → success/warning/info/danger */
function levelTagType(level?: string): 'success' | 'warning' | 'info' | 'danger' {
  switch (level) {
    case '优秀':
      return 'success'
    case '良好':
      return 'warning'
    case '合格':
      return 'info'
    case '需努力':
      return 'danger'
    default:
      return 'info'
  }
}

const hasSubjectData = computed(
  () => !!report.value?.subject_breakdown && Object.keys(report.value.subject_breakdown).length > 0,
)
const hasTrendData = computed(
  () => !!report.value?.daily_trend && Object.keys(report.value.daily_trend).length > 0,
)

const subjectOption = computed<EChartsOption>(() => {
  const breakdown = report.value?.subject_breakdown || {}
  return {
    tooltip: { trigger: 'item', formatter: '{b}: {c} 分钟 ({d}%)' },
    legend: { type: 'scroll', bottom: 0 },
    series: [
      {
        name: '学科时长',
        type: 'pie',
        radius: ['35%', '65%'],
        data: Object.entries(breakdown).map(([name, value]) => ({ name, value })),
        label: { formatter: '{b}: {c}分' },
      },
    ],
  }
})

const trendOption = computed<EChartsOption>(() => {
  const trend = report.value?.daily_trend || {}
  const dates = Object.keys(trend).sort()
  return {
    tooltip: { trigger: 'axis' },
    grid: { left: 50, right: 20, top: 30, bottom: 40 },
    xAxis: { type: 'category', data: dates, axisLabel: { rotate: dates.length > 5 ? 30 : 0 } },
    yAxis: { type: 'value', name: '分钟' },
    series: [
      {
        name: '完成时长',
        type: 'bar',
        barMaxWidth: 40,
        itemStyle: { color: '#409eff' },
        data: dates.map((d) => trend[d]),
      },
    ],
  }
})

async function loadReport() {
  if (!childId.value) return
  loading.value = true
  try {
    if (reportType.value === 'weekly') {
      report.value = await reportsApi.getWeeklyReport(childId.value, currentWeekLabel.value)
    } else {
      report.value = await reportsApi.getMonthlyReport(childId.value, monthValue.value)
    }
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

async function regenerate() {
  if (!childId.value) return
  loading.value = true
  try {
    if (reportType.value === 'weekly') {
      report.value = await reportsApi.generateReport(childId.value, { week: currentWeekLabel.value })
    } else {
      report.value = await reportsApi.generateReport(childId.value, { month: monthValue.value })
    }
    ElMessage.success('报告已重新生成')
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

const currentWeekLabel = computed(() => toIsoWeek(weekDate.value))

async function exportPdf() {
  if (!childId.value || !report.value) return
  exporting.value = true
  try {
    const opts = reportType.value === 'weekly' ? { week: currentWeekLabel.value } : { month: monthValue.value }
    const blob = await reportsApi.exportReportPdf(childId.value, opts)
    const label = reportType.value === 'weekly' ? `周报_${currentWeekLabel.value}` : `月报_${monthValue.value}`
    downloadBlob(blob, `${label}_${childId.value}.pdf`)
    ElMessage.success('PDF 已开始下载')
  } catch {
    // 错误提示由拦截器处理
  } finally {
    exporting.value = false
  }
}

async function exportZipData() {
  if (!childId.value) return
  exportingZip.value = true
  try {
    const res = await exportApi.exportZip(childId.value)
    for (const path of res.parts) {
      const blob = await exportApi.downloadExport(childId.value, path)
      const name = path.split('/').pop() || 'export.zip'
      downloadBlob(blob, name)
    }
    ElMessage.success(`已打包 ${res.media_count} 个媒体文件，ZIP 开始下载`)
  } catch {
    // 错误提示由拦截器处理
  } finally {
    exportingZip.value = false
  }
}

watch(reportType, () => {
  report.value = null
})

watch(childId, () => {
  report.value = null
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}
.suggestions {
  margin: 0;
  padding-left: 20px;
  line-height: 1.9;
}
</style>