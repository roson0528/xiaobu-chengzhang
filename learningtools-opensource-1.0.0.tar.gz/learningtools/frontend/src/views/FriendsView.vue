<template>
  <div v-loading="loading">
    <el-card shadow="never">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="好友列表" name="friends" />
        <el-tab-pane label="申请审批" name="requests" />
      </el-tabs>

      <!-- 好友列表 -->
      <template v-if="activeTab === 'friends'">
        <el-table :data="friends" stripe>
          <el-table-column prop="child_id" label="孩子 ID" min-width="140" />
          <el-table-column label="姓名" min-width="120">
            <template #default="{ row }">{{ row.name || '-' }}</template>
          </el-table-column>
          <el-table-column label="年级" width="100">
            <template #default="{ row }">{{ row.grade ?? '-' }}</template>
          </el-table-column>
        </el-table>
        <el-empty v-if="!friends.length" description="暂无好友" />
      </template>

      <!-- 申请审批 -->
      <template v-if="activeTab === 'requests'">
        <el-divider content-position="left">收到的申请</el-divider>
        <el-table v-if="incoming.length" :data="incoming" stripe>
          <el-table-column label="申请方" min-width="140">
            <template #default="{ row }">{{ row.from_name || row.from_child }}</template>
          </el-table-column>
          <el-table-column prop="from_child" label="孩子 ID" min-width="140" />
          <el-table-column label="申请时间" width="180">
            <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
          </el-table-column>
          <el-table-column label="操作" width="140" fixed="right">
            <template #default="{ row }">
              <template v-if="row.status === 'pending'">
                <el-tooltip content="通过" placement="top">
                  <el-button size="small" link type="success" :icon="Check" @click="approve(row)" />
                </el-tooltip>
                <el-tooltip content="拒绝" placement="top">
                  <el-button size="small" link type="danger" :icon="Close" @click="reject(row)" />
                </el-tooltip>
              </template>
              <el-tag v-else :type="requestTagType(row.status)" size="small">
                {{ requestStatusLabel(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
        </el-table>
        <el-empty v-if="!incoming.length" description="暂无收到的申请" />

        <el-divider content-position="left">发出的申请</el-divider>
        <el-table v-if="outgoing.length" :data="outgoing" stripe>
          <el-table-column label="申请对象" min-width="140">
            <template #default="{ row }">{{ row.to_name || row.to_child }}</template>
          </el-table-column>
          <el-table-column prop="to_child" label="孩子 ID" min-width="140" />
          <el-table-column label="状态" width="120">
            <template #default="{ row }">
              <el-tag :type="requestTagType(row.status)" size="small">
                {{ requestStatusLabel(row.status) }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="申请时间" width="180">
            <template #default="{ row }">{{ formatDateTime(row.created_at) }}</template>
          </el-table-column>
        </el-table>
        <el-empty v-if="!outgoing.length" description="暂无发出的申请" />
      </template>
    </el-card>
  </div>
</template>

<script setup lang="ts">
import { onMounted, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Check, Close, Refresh } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import * as friendsApi from '@/api/friends'
import type { FriendItem, FriendRequest } from '@/types'
import { confirmAction, formatDateTime } from '@/utils/date'

const childrenStore = useChildrenStore()
const childId = ref('')
const activeTab = ref('friends')
const loading = ref(false)
const friends = ref<FriendItem[]>([])
const incoming = ref<FriendRequest[]>([])
const outgoing = ref<FriendRequest[]>([])

function requestStatusLabel(status?: string): string {
  switch (status) {
    case 'pending':
      return '待处理'
    case 'approved':
      return '已通过'
    case 'rejected':
      return '已拒绝'
    default:
      return status || '-'
  }
}

function requestTagType(status?: string): 'success' | 'warning' | 'danger' | 'info' {
  switch (status) {
    case 'approved':
      return 'success'
    case 'pending':
      return 'warning'
    case 'rejected':
      return 'danger'
    default:
      return 'info'
  }
}

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    const [friendList, reqs] = await Promise.all([
      friendsApi.listFriends(childId.value).catch(() => [] as FriendItem[]),
      friendsApi
        .listRequests(childId.value)
        .catch(() => ({ incoming: [] as FriendRequest[], outgoing: [] as FriendRequest[] })),
    ])
    friends.value = friendList
    incoming.value = reqs.incoming
    outgoing.value = reqs.outgoing
  } finally {
    loading.value = false
  }
}

async function approve(row: FriendRequest) {
  try {
    await friendsApi.approveRequest(row.id)
    ElMessage.success('已通过')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

async function reject(row: FriendRequest) {
  const ok = await confirmAction('确定拒绝该好友申请吗？', '拒绝确认', 'warning')
  if (!ok) return
  try {
    await friendsApi.rejectRequest(row.id)
    ElMessage.success('已拒绝')
    await load()
  } catch {
    // 错误提示由拦截器处理
  }
}

watch(childId, () => {
  if (childId.value) load()
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}
</style>
