<template>
  <div v-loading="loading">
    <el-row :gutter="16" class="page-card">
      <el-col :xs="24" :span="12">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #e6a23c">{{ pointsData.total ?? 0 }}</div>
          <div class="stat-label">{{ childName }} 当前积分</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :span="12">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-value" style="color: #409eff">{{ badges.length }}</div>
          <div class="stat-label">已获得徽章</div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never">
      <div class="toolbar">
        <ChildSelect v-model="childId" />
        <el-button type="primary" :icon="EditPen" @click="openAdjust">积分奖惩</el-button>
        <el-button type="warning" :icon="Present" @click="redeemVisible = true">兑换奖励</el-button>
        <el-button :icon="Refresh" @click="load">刷新</el-button>
      </div>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="积分记录" name="records" />
        <el-tab-pane label="徽章" name="badges" />
        <el-tab-pane v-if="isRewardManager" label="奖励设置" name="settings" />
      </el-tabs>

      <!-- 积分记录：按时间倒序分页，最新在最前，每页 30 条 -->
      <el-table
        v-if="activeTab === 'records'"
        v-loading="pointsLoading"
        :data="pointsData.records || []"
        stripe
      >
        <el-table-column label="变动" width="100">
          <template #default="{ row }">
            <span :class="(row.points ?? 0) >= 0 ? 'plus' : 'minus'">
              {{ (row.points ?? 0) >= 0 ? '+' : '' }}{{ row.points ?? 0 }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="reason" label="原因" min-width="200" show-overflow-tooltip />
        <el-table-column label="时间" width="180">
          <template #default="{ row }">{{ formatDateTime(row.timestamp) }}</template>
        </el-table-column>
      </el-table>
      <el-empty v-if="activeTab === 'records' && !(pointsData.records || []).length" description="暂无积分记录" />
      <div v-if="activeTab === 'records' && pointsTotal > 0" class="points-pager">
        <el-pagination
          v-model:current-page="pointsPage"
          :page-size="POINTS_PAGE_SIZE"
          :total="pointsTotal"
          background
          layout="total, prev, pager, next, jumper"
          @current-change="onPointsPageChange"
        />
      </div>

      <!-- 徽章 -->
      <div v-if="activeTab === 'badges'" class="badge-list">
        <el-tag v-for="(b, i) in badges" :key="i" size="large" type="warning" effect="plain" class="badge-item">
          <el-icon><Medal /></el-icon>
          {{ badgeLabel(b) }}
        </el-tag>
      </div>
      <el-empty v-if="activeTab === 'badges' && !badges.length" description="暂无徽章" />

      <!-- 奖励设置 -->
      <template v-if="activeTab === 'settings'">
        <el-card shadow="never" class="catalog-card points-card">
          <template #header>
            <div class="card-header">
              <span>积分奖励设置</span>
              <el-button type="primary" size="small" :loading="savingPoints" @click="savePointsSettings">
                保存设置
              </el-button>
            </div>
          </template>
          <el-alert
            type="info"
            :closable="false"
            show-icon
            class="points-alert"
            title="设定孩子完成每项行为获得的积分，例如完成家务奖励 30 分、运动打卡奖励 10 分。保存后立即生效。"
          />
          <div class="points-grid">
            <div v-for="g in pointsGroups" :key="g.key" class="points-group">
              <div class="points-group-title">{{ g.title }}</div>
              <div v-for="item in g.items" :key="item.key" class="points-item">
                <span class="points-label">{{ item.label }}</span>
                <el-input-number
                  v-model="pointsSettings[item.key]"
                  :min="0"
                  :max="1000"
                  :step="5"
                  size="small"
                />
              </div>
            </div>
          </div>
        </el-card>

        <el-row :gutter="16">
          <el-col :xs="24" :md="12">
            <el-card shadow="never" class="catalog-card">
              <template #header>
                <div class="card-header">
                  <span>徽章目录</span>
                  <el-button type="primary" size="small" :icon="Plus" @click="openBadgeDialog">
                    新增徽章
                  </el-button>
                </div>
              </template>
              <div v-for="b in catalog.badges" :key="b.id" class="catalog-item">
                <span class="catalog-emoji">{{ b.emoji || '🏅' }}</span>
                <div class="catalog-info">
                  <div class="catalog-name">{{ b.name }}</div>
                  <div v-if="b.description" class="catalog-desc">{{ b.description }}</div>
                </div>
                <el-tooltip content="删除" placement="top">
                  <el-button size="small" link type="danger" :icon="Delete" @click="removeBadge(b)" />
                </el-tooltip>
              </div>
              <el-empty v-if="!catalog.badges.length" description="暂无徽章，点击右上角新增" :image-size="60" />
            </el-card>
          </el-col>
          <el-col :xs="24" :md="12">
            <el-card shadow="never" class="catalog-card">
              <template #header>
                <div class="card-header">
                  <span>兑换目录</span>
                  <el-button type="warning" size="small" :icon="Plus" @click="openItemDialog">
                    新增兑换项
                  </el-button>
                </div>
              </template>
              <div v-for="it in catalog.redeem_items" :key="it.id" class="catalog-item">
                <span class="catalog-emoji">{{ it.emoji || '🎁' }}</span>
                <div class="catalog-info">
                  <div class="catalog-name">{{ it.name }}</div>
                  <div class="catalog-desc">
                    所需积分：{{ it.cost }}
                    <span v-if="it.net_minutes" style="color: #409eff">
                      · 附赠上网 {{ it.net_minutes }} 分钟
                    </span>
                  </div>
                </div>
                <el-tooltip content="删除" placement="top">
                  <el-button size="small" link type="danger" :icon="Delete" @click="removeItem(it)" />
                </el-tooltip>
              </div>
              <el-empty
                v-if="!catalog.redeem_items.length"
                description="暂无兑换项，点击右上角新增"
                :image-size="60"
              />
            </el-card>
          </el-col>
        </el-row>
      </template>
    </el-card>

    <!-- 积分奖惩：正分=奖励，负分=扣分 -->
    <el-dialog v-model="adjustVisible" title="积分奖惩" width="460px" destroy-on-close>
      <el-form label-width="90px">
        <el-form-item label="当前积分">
          <span style="color: #e6a23c; font-weight: 600">{{ pointsData.total ?? 0 }}</span>
        </el-form-item>
        <el-form-item label="奖惩分数" required>
          <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap">
            <el-input-number v-model="adjustForm.points" :min="-1000" :max="1000" :step="1" style="width: 140px" />
            <span :style="{ color: adjustForm.points >= 0 ? '#67c23a' : '#f56c6c', fontWeight: 600 }">
              {{ adjustForm.points > 0 ? '奖励' : adjustForm.points < 0 ? '扣除' : '未填写' }}
              {{ Math.abs(adjustForm.points) }} 分
            </span>
          </div>
          <div class="adjust-hint">填正数表示奖励，填负数表示扣分（例如 +10 奖励 10 分，-10 扣除 10 分）。</div>
          <div class="adjust-quick">
            <el-button size="small" @click="adjustForm.points = 5">+5</el-button>
            <el-button size="small" @click="adjustForm.points = 10">+10</el-button>
            <el-button size="small" @click="adjustForm.points = 20">+20</el-button>
            <el-button size="small" @click="adjustForm.points = -5">-5</el-button>
            <el-button size="small" @click="adjustForm.points = -10">-10</el-button>
            <el-button size="small" @click="adjustForm.points = -20">-20</el-button>
          </div>
        </el-form-item>
        <el-form-item label="奖惩理由" required>
          <el-input
            v-model="adjustForm.reason"
            type="textarea"
            :rows="2"
            maxlength="60"
            show-word-limit
            placeholder="如：主动帮忙做家务 / 说谎话"
          />
        </el-form-item>
        <el-form-item label="发给孩子">
          <el-switch v-model="adjustForm.notify" active-text="同时发到孩子端聊天框" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="adjustVisible = false">取消</el-button>
        <el-button type="primary" :loading="adjusting" @click="submitAdjust">确认</el-button>
      </template>
    </el-dialog>

    <!-- 兑换奖励 -->
    <el-dialog v-model="redeemVisible" title="兑换奖励" width="440px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="当前积分">
          <span style="color: #e6a23c; font-weight: 600">{{ pointsData.total ?? 0 }}</span>
        </el-form-item>
        <el-form-item label="奖励名称" required>
          <el-input v-model="redeemForm.reward_name" placeholder="如：看动画 30 分钟" />
        </el-form-item>
        <el-form-item label="所需积分" required>
          <el-input-number v-model="redeemForm.cost" :min="1" :max="(pointsData.total ?? 0)" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="redeemVisible = false">取消</el-button>
        <el-button type="warning" :loading="redeeming" @click="submitRedeem">确认兑换</el-button>
      </template>
    </el-dialog>

    <!-- 新增徽章 -->
    <el-dialog v-model="badgeDialogVisible" title="新增徽章" width="420px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="名称" required>
          <el-input v-model="badgeForm.name" placeholder="如：阅读之星" maxlength="30" />
        </el-form-item>
        <el-form-item label="Emoji">
          <div class="emoji-picker">
            <div class="emoji-grid">
              <span
                v-for="e in badgeEmojiPresets"
                :key="e"
                class="emoji-option"
                :class="{ selected: badgeForm.emoji === e }"
                @click="badgeForm.emoji = e"
              >{{ e }}</span>
            </div>
            <el-input
              v-model="badgeForm.emoji"
              placeholder="或手动输入自定义 Emoji（选填）"
              maxlength="8"
              clearable
            />
          </div>
        </el-form-item>
        <el-form-item label="描述">
          <el-input v-model="badgeForm.description" type="textarea" :rows="2" placeholder="选填" maxlength="100" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="badgeDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="savingBadge" @click="submitBadge">保存</el-button>
      </template>
    </el-dialog>

    <!-- 新增兑换项 -->
    <el-dialog v-model="itemDialogVisible" title="新增兑换项" width="420px" destroy-on-close>
      <el-form label-width="80px">
        <el-form-item label="名称" required>
          <el-input v-model="itemForm.name" placeholder="如：看动画 30 分钟" maxlength="30" />
        </el-form-item>
        <el-form-item label="Emoji">
          <el-input v-model="itemForm.emoji" placeholder="如：🎬（选填）" maxlength="8" />
        </el-form-item>
        <el-form-item label="所需积分" required>
          <el-input-number v-model="itemForm.cost" :min="1" :max="10000" />
        </el-form-item>
        <el-form-item label="附赠上网">
          <el-input-number v-model="itemForm.net_minutes" :min="0" :max="1440" :step="15" />
          <span style="margin-left: 8px; color: #909399; font-size: 12px">
            分钟（0 = 不放开上网）
          </span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="itemDialogVisible = false">取消</el-button>
        <el-button type="warning" :loading="savingItem" @click="submitItem">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { Present, Refresh, Medal, Plus, Delete, EditPen } from '@element-plus/icons-vue'
import ChildSelect from '@/components/ChildSelect.vue'
import { useChildrenStore } from '@/stores/children'
import { useAuthStore } from '@/stores/auth'
import * as rewardsApi from '@/api/rewards'
import type { BadgeData, BadgeItem, PointsData, RedeemItem, RewardCatalog } from '@/types'
import { badgeLabel, confirmAction, formatDateTime } from '@/utils/date'

const childrenStore = useChildrenStore()
const auth = useAuthStore()
const childId = ref('')
const activeTab = ref('records')
// 积分记录分页：每页 30 条，按时间倒序（最新在前）
const POINTS_PAGE_SIZE = 30
const pointsPage = ref(1)
const pointsTotal = ref(0)
const pointsLoading = ref(false)
const loading = ref(false)
const pointsData = ref<PointsData>({ records: [], total: 0 })
const badges = ref<unknown[]>([])
const catalog = ref<RewardCatalog>({ badges: [], redeem_items: [] })

const isRewardManager = computed(() => auth.isAdmin || auth.role === 'parent')

/** 新增徽章可选用的预设 Emoji */
const badgeEmojiPresets = [
  '🏆', '🥇', '🥈', '🥉', '⭐', '🌟', '✨', '🎖️', '🏅', '📚',
  '📖', '✏️', '🖊️', '📐', '🔬', '🧪', '🚀', '🎨', '🎵', '⚽',
  '🏀', '🎮', '🧩', '🐦', '🔥', '🌈', '🌱', '💪', '🧠', '❤️',
  '💎', '🎁', '🎯', '🏃‍♂️', '🏊‍♂️', '🚴', '🐱', '🐶', '🦁', '🎓',
]

const childName = computed(
  () => childrenStore.children.find((c) => c.id === childId.value)?.name || '',
)

async function load() {
  if (!childId.value) return
  loading.value = true
  try {
    const [points, badgeData] = await Promise.all([
      rewardsApi.getPoints(childId.value, {
        order: 'desc',
        page: pointsPage.value,
        page_size: POINTS_PAGE_SIZE,
      }),
      rewardsApi.getBadges(childId.value).catch(() => ({ earned: [] } as BadgeData)),
    ])
    applyPoints(points)
    badges.value = badgeData.earned || []
    await loadCatalog()
    await loadPointsSettings()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    loading.value = false
  }
}

/** 统一落到 pointsData，并同步分页总数。 */
function applyPoints(points: PointsData) {
  pointsData.value = points
  pointsTotal.value = points.record_count ?? (points.records || []).length
}

/** 翻页：显式用组件回调传入的页码，不依赖 v-model 的更新时序。 */
async function onPointsPageChange(page: number) {
  pointsPage.value = page
  await loadPoints()
}

/** 只重新拉取当前页的积分记录（翻页时调用，不重载整个页面）。 */
async function loadPoints() {
  if (!childId.value) return
  pointsLoading.value = true
  try {
    applyPoints(
      await rewardsApi.getPoints(childId.value, {
        order: 'desc',
        page: pointsPage.value,
        page_size: POINTS_PAGE_SIZE,
      }),
    )
  } catch {
    // 错误提示由拦截器处理
  } finally {
    pointsLoading.value = false
  }
}

// ---- 奖励设置：徽章目录 + 兑换目录 ----
async function loadCatalog() {
  if (!childId.value) return
  try {
    catalog.value = await rewardsApi.getCatalog(childId.value)
  } catch {
    catalog.value = { badges: [], redeem_items: [] }
  }
}

// ---- 积分奖励设置 ----
const pointsSettings = reactive<Record<string, number>>({})
const savingPoints = ref(false)

/** 可配置的积分奖励行为（key 与后端 DEFAULT_POINTS 对应）。 */
const pointsGroups = [
  {
    key: 'task',
    title: '完成任务（作业）',
    items: [
      { key: 'task_easy', label: '简单任务' },
      { key: 'task_medium', label: '中等任务' },
      { key: 'task_hard', label: '困难任务' },
      { key: 'homework_classroom', label: '课堂作业（孩子自行提交）' },
    ],
  },
  {
    key: 'checkin',
    title: '完成打卡（审核通过后奖励）',
    items: [
      { key: 'checkin_晨起', label: '晨起打卡' },
      { key: 'checkin_阅读', label: '阅读打卡' },
      { key: 'checkin_运动', label: '运动打卡' },
      { key: 'checkin_家务', label: '家务打卡' },
      { key: 'checkin_心情', label: '心情打卡' },
    ],
  },
]

async function loadPointsSettings() {
  if (!childId.value) return
  try {
    const data = await rewardsApi.getPointsSettings(childId.value)
    Object.keys(pointsSettings).forEach((k) => delete pointsSettings[k])
    Object.assign(pointsSettings, data.points || {})
  } catch {
    // 错误提示由拦截器处理
  }
}

async function savePointsSettings() {
  if (!childId.value) return
  savingPoints.value = true
  try {
    await rewardsApi.updatePointsSettings(childId.value, { ...pointsSettings })
    ElMessage.success('积分奖励设置已保存')
  } catch {
    // 错误提示由拦截器处理
  } finally {
    savingPoints.value = false
  }
}

const badgeDialogVisible = ref(false)
const savingBadge = ref(false)
const badgeForm = reactive({ name: '', emoji: '', description: '' })

function openBadgeDialog() {
  badgeForm.name = ''
  badgeForm.emoji = ''
  badgeForm.description = ''
  badgeDialogVisible.value = true
}

async function submitBadge() {
  if (!badgeForm.name.trim()) {
    ElMessage.warning('请填写徽章名称')
    return
  }
  savingBadge.value = true
  try {
    await rewardsApi.addBadge(childId.value, {
      name: badgeForm.name.trim(),
      emoji: badgeForm.emoji.trim() || undefined,
      description: badgeForm.description.trim() || undefined,
    })
    ElMessage.success('徽章已新增')
    badgeDialogVisible.value = false
    await loadCatalog()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    savingBadge.value = false
  }
}

async function removeBadge(b: BadgeItem) {
  const ok = await confirmAction(`确定删除徽章「${b.name}」吗？`, '删除确认', 'warning')
  if (!ok) return
  try {
    await rewardsApi.deleteBadge(childId.value, b.id)
    ElMessage.success('已删除')
    await loadCatalog()
  } catch {
    // 错误提示由拦截器处理
  }
}

const itemDialogVisible = ref(false)
const savingItem = ref(false)
const itemForm = reactive({ name: '', emoji: '', cost: 10, net_minutes: 0 })

function openItemDialog() {
  itemForm.name = ''
  itemForm.emoji = ''
  itemForm.cost = 10
  itemForm.net_minutes = 0
  itemDialogVisible.value = true
}

async function submitItem() {
  if (!itemForm.name.trim()) {
    ElMessage.warning('请填写兑换项名称')
    return
  }
  savingItem.value = true
  try {
    await rewardsApi.addRedeemItem(childId.value, {
      name: itemForm.name.trim(),
      emoji: itemForm.emoji.trim() || undefined,
      cost: itemForm.cost,
      net_minutes: itemForm.net_minutes || 0,
    })
    ElMessage.success('兑换项已新增')
    itemDialogVisible.value = false
    await loadCatalog()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    savingItem.value = false
  }
}

async function removeItem(it: RedeemItem) {
  const ok = await confirmAction(`确定删除兑换项「${it.name}」吗？`, '删除确认', 'warning')
  if (!ok) return
  try {
    await rewardsApi.deleteRedeemItem(childId.value, it.id)
    ElMessage.success('已删除')
    await loadCatalog()
  } catch {
    // 错误提示由拦截器处理
  }
}

// ---- 兑换 ----
const redeemVisible = ref(false)
const redeeming = ref(false)
const redeemForm = reactive({ reward_name: '', cost: 10 })

// ---- 积分奖惩 ----
const adjustVisible = ref(false)
const adjusting = ref(false)
const adjustForm = reactive({ points: 10, reason: '', notify: true })

function openAdjust() {
  if (!childId.value) {
    ElMessage.warning('请先选择孩子')
    return
  }
  adjustForm.points = 10
  adjustForm.reason = ''
  adjustForm.notify = true
  adjustVisible.value = true
}

async function submitAdjust() {
  if (!adjustForm.points) {
    ElMessage.warning('请填写奖惩分数（正数奖励、负数扣分）')
    return
  }
  if (!adjustForm.reason.trim()) {
    ElMessage.warning('请填写奖惩理由')
    return
  }
  adjusting.value = true
  try {
    const res = await rewardsApi.adjustPoints(childId.value, {
      points: adjustForm.points,
      reason: adjustForm.reason.trim(),
      notify: adjustForm.notify,
    })
    // 直接用返回结果刷新积分，避免多一次请求
    applyPoints(res.points)
    ElMessage.success(
      `${adjustForm.points > 0 ? '奖励' : '扣除'} ${Math.abs(adjustForm.points)} 分` +
        (adjustForm.notify ? '，已发到孩子端聊天框' : ''),
    )
    adjustVisible.value = false
    pointsPage.value = 1
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    adjusting.value = false
  }
}

async function submitRedeem() {
  if (!redeemForm.reward_name.trim()) {
    ElMessage.warning('请填写奖励名称')
    return
  }
  redeeming.value = true
  try {
    await rewardsApi.redeemReward(childId.value, redeemForm.reward_name.trim(), redeemForm.cost)
    ElMessage.success('兑换成功')
    redeemVisible.value = false
    // 新增的记录在最新一页，回到第 1 页展示
    pointsPage.value = 1
    await load()
  } catch {
    // 错误提示由拦截器处理
  } finally {
    redeeming.value = false
  }
}

watch(childId, () => {
  pointsPage.value = 1
  if (childId.value) load()
})

onMounted(async () => {
  await childrenStore.ensureLoaded()
  if (childrenStore.children.length && !childId.value) {
    childId.value = childrenStore.children[0].id
  }
})
</script>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 8px;
}
.plus {
  color: #67c23a;
  font-weight: 600;
}
.minus {
  color: #f56c6c;
  font-weight: 600;
}
.points-pager {
  display: flex;
  justify-content: flex-end;
  padding: 12px 0 4px;
}
.badge-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  padding: 8px 0;
}
.badge-item {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
  padding: 8px 14px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.catalog-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
}
.catalog-item:last-child {
  border-bottom: none;
}
.catalog-emoji {
  font-size: 20px;
  width: 28px;
  text-align: center;
  flex-shrink: 0;
}
.catalog-info {
  flex: 1;
  min-width: 0;
}
.catalog-name {
  font-weight: 600;
  font-size: 14px;
}
.catalog-desc {
  font-size: 12px;
  color: #909399;
  margin-top: 2px;
}
.emoji-picker {
  width: 100%;
}
.emoji-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-bottom: 8px;
  max-height: 120px;
  overflow-y: auto;
}
.emoji-option {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  line-height: 1;
  border: 1px solid #e4e7ed;
  border-radius: 6px;
  cursor: pointer;
  background: #fff;
  transition: all 0.15s;
}
.emoji-option:hover {
  border-color: #409eff;
  background: #ecf5ff;
}
.emoji-option.selected {
  border-color: #409eff;
  background: #ecf5ff;
  box-shadow: 0 0 0 2px rgba(64, 158, 255, 0.2);
}
.points-card {
  margin-bottom: 16px;
}
.points-alert {
  margin-bottom: 14px;
}
.points-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}
.points-group {
  flex: 1 1 220px;
  min-width: 200px;
}
.points-group-title {
  font-weight: 600;
  font-size: 14px;
  margin-bottom: 8px;
  color: #303133;
}
.points-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 0;
  border-bottom: 1px dashed #f0f0f0;
}
.points-item:last-child {
  border-bottom: none;
}
.points-label {
  font-size: 13px;
  color: #606266;
}

.adjust-hint {
  font-size: 12px;
  color: #909399;
  line-height: 1.5;
  margin-top: 4px;
}

.adjust-quick {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 6px;
}
</style>