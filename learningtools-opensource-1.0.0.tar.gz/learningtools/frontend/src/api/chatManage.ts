import http from './http'
import type { ChatStorage } from '@/types'

export async function getChatStorage(): Promise<ChatStorage> {
  const res = await http.get<ChatStorage>('/chat-manage/storage')
  return res.data
}

export type ChatClearScope = 'all' | 'images' | 'videos' | 'files' | 'audio'

export interface ClearResult {
  status: string
  deleted_count: number
}

export async function clearChat(scope: ChatClearScope, childId?: string | null): Promise<ClearResult> {
  const res = await http.post<ClearResult>('/chat-manage/clear', {
    scope,
    child_id: childId ?? null,
  })
  return res.data
}
