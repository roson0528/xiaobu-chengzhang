import http from './http'
import type { AdminStats, AuditLogItem, BackupItem } from '@/types'

export async function getAuditLog(limit = 200): Promise<AuditLogItem[]> {
  const res = await http.get<AuditLogItem[]>('/admin/audit-log', { params: { limit } })
  return res.data
}

export async function getAdminStats(): Promise<AdminStats> {
  const res = await http.get<AdminStats>('/admin/stats')
  return res.data
}

export async function listBackups(): Promise<BackupItem[]> {
  const res = await http.get<BackupItem[]>('/admin/backup')
  return res.data
}

export async function createBackup(): Promise<{ backup_id: string; files: number }> {
  const res = await http.post<{ backup_id: string; files: number }>('/admin/backup')
  return res.data
}

export async function restoreBackup(backupId: string): Promise<{ restored_files: number }> {
  const res = await http.post<{ restored_files: number }>('/admin/restore', { backup_id: backupId })
  return res.data
}

export async function getConfig(): Promise<Record<string, unknown>> {
  const res = await http.get<Record<string, unknown>>('/admin/config')
  return res.data
}

export async function putConfig(config: Record<string, unknown>): Promise<void> {
  await http.put('/admin/config', { config })
}
