import http from './http'

export interface MoodRecord {
  id: string
  mood: 'happy' | 'ok' | 'tired'
  note?: string | null
  date: string
  created_at?: string
}

export async function listMood(childId: string, month?: string): Promise<MoodRecord[]> {
  const res = await http.get<MoodRecord[]>(`/mood/${childId}`, { params: { month } })
  return res.data
}
