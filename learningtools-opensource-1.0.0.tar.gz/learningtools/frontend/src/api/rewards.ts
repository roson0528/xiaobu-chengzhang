import http from './http'
import type { BadgeData, PointsData, RankItem, RewardCatalog } from '@/types'

/** 积分记录查询参数（不传时返回全部记录，保持与旧调用方一致）。 */
export interface PointsQuery {
  page?: number
  page_size?: number
  /** desc = 按时间倒序（最新在前） */
  order?: 'keep' | 'asc' | 'desc'
}

export async function getPoints(childId: string, params?: PointsQuery): Promise<PointsData> {
  const res = await http.get<PointsData>(`/rewards/${childId}/points`, { params })
  return res.data
}

export async function getBadges(childId: string): Promise<BadgeData> {
  const res = await http.get<BadgeData>(`/rewards/${childId}/badges`)
  return res.data
}

export async function redeemReward(childId: string, reward_name: string, cost: number): Promise<PointsData> {
  const res = await http.post<PointsData>(`/rewards/${childId}/redeem`, { reward_name, cost })
  return res.data
}

export async function getRank(childId: string): Promise<RankItem[]> {
  const res = await http.get<RankItem[]>(`/rewards/${childId}/rank`)
  return res.data
}

// ---- 徽章目录 + 积分兑换目录 ----

export async function getCatalog(childId: string): Promise<RewardCatalog> {
  const res = await http.get<RewardCatalog>(`/rewards/${childId}/catalog`)
  return res.data
}

export async function addBadge(childId: string, body: { name: string; emoji?: string; description?: string }): Promise<void> {
  await http.post(`/rewards/${childId}/badges`, body)
}

export async function deleteBadge(childId: string, badgeId: string): Promise<void> {
  await http.delete(`/rewards/${childId}/badges/${badgeId}`)
}

export async function addRedeemItem(
  childId: string,
  body: { name: string; emoji?: string; cost: number; net_minutes?: number },
): Promise<void> {
  await http.post(`/rewards/${childId}/redeem_items`, body)
}

export async function deleteRedeemItem(childId: string, itemId: string): Promise<void> {
  await http.delete(`/rewards/${childId}/redeem_items/${itemId}`)
}

// ---- 手动积分奖惩（正分=奖励，负分=扣分） ----

export interface AdjustPayload {
  /** 正数=奖励，负数=扣分 */
  points: number
  /** 奖惩理由，会记入积分记录 */
  reason?: string
  /** 是否把分数与理由发到孩子端聊天框 */
  notify?: boolean
}

export interface AdjustResult {
  points: PointsData
  message: unknown | null
}

export async function adjustPoints(childId: string, body: AdjustPayload): Promise<AdjustResult> {
  const res = await http.post<AdjustResult>(`/rewards/${childId}/adjust`, body)
  return res.data
}

// ---- 积分奖励设置（每项行为奖励多少积分） ----

export interface PointsSettings {
  points: Record<string, number>
}

export async function getPointsSettings(childId: string): Promise<PointsSettings> {
  const res = await http.get<PointsSettings>(`/rewards/${childId}/settings`)
  return res.data
}

export async function updatePointsSettings(childId: string, points: Record<string, number>): Promise<PointsSettings> {
  const res = await http.put<PointsSettings>(`/rewards/${childId}/settings`, { points })
  return res.data
}
