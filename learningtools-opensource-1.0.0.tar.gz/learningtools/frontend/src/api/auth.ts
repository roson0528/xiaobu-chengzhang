import http from './http'
import type { AuthUser, LoginResult, MeResult, User } from '@/types'

export interface LoginBody {
  username: string
  password: string
}

export interface RegisterBody {
  username: string
  password: string
  email?: string
  phone?: string
}

export async function login(body: LoginBody): Promise<LoginResult> {
  const res = await http.post<LoginResult>('/auth/login', body)
  return res.data
}

export async function refreshToken(refresh_token: string): Promise<{ access_token: string }> {
  const res = await http.post<{ access_token: string }>('/auth/refresh', { refresh_token })
  return res.data
}

export async function logout(): Promise<void> {
  await http.post('/auth/logout')
}

export async function getMe(): Promise<MeResult> {
  const res = await http.get<MeResult>('/auth/me')
  return res.data
}

export async function changePassword(old_password: string, new_password: string): Promise<void> {
  await http.post('/auth/change-password', { old_password, new_password })
}

export async function register(body: RegisterBody): Promise<{ id: number; username: string; status: string; message: string }> {
  const res = await http.post<{ id: number; username: string; status: string; message: string }>('/auth/register', body)
  return res.data
}

export type { AuthUser, User }
