import http from './http'
import type { TaskItem, WeeklyPlan } from '@/types'

export async function getWeeklyPlan(childId: string, week: string): Promise<WeeklyPlan> {
  const res = await http.get<WeeklyPlan>(`/plans/${childId}/weekly/${week}`)
  return res.data
}

export async function saveWeeklyPlan(childId: string, week: string, tasks: TaskItem[]): Promise<WeeklyPlan> {
  const res = await http.put<WeeklyPlan>(`/plans/${childId}/weekly/${week}`, { tasks })
  return res.data
}

export async function saveTemplate(childId: string, tasks: TaskItem[]): Promise<WeeklyPlan> {
  const res = await http.post<WeeklyPlan>(`/plans/${childId}/template`, { tasks })
  return res.data
}

export async function getTemplate(childId: string): Promise<WeeklyPlan> {
  const res = await http.get<WeeklyPlan>(`/plans/${childId}/template`)
  return res.data
}

export async function applyTemplate(childId: string): Promise<WeeklyPlan> {
  const res = await http.post<WeeklyPlan>(`/plans/${childId}/apply-template`)
  return res.data
}
