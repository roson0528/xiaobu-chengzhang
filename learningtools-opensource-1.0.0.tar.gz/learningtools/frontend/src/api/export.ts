import http from './http'

export interface ExportZipResult {
  parts: string[]
  media_count: number
}

/** 打包数据 + 媒体（录音/视频/照片）为 ZIP，可选分卷（part_size_mb=0 表示单个 ZIP）。 */
export async function exportZip(childId: string, partSizeMb = 0): Promise<ExportZipResult> {
  const res = await http.post<ExportZipResult>(`/export/${childId}/zip`, { part_size_mb: partSizeMb })
  return res.data
}

/** 下载某个导出包（path 为 reports 下相对路径）。 */
export async function downloadExport(childId: string, path: string): Promise<Blob> {
  const res = await http.get<Blob>(`/export/${childId}/download`, {
    params: { path },
    responseType: 'blob',
  })
  return res.data as Blob
}
