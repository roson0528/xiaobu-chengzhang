import http from './http'
import type { Report } from '@/types'

export async function getWeeklyReport(childId: string, week: string): Promise<Report> {
  const res = await http.get<Report>(`/reports/${childId}/weekly/${week}`)
  return res.data
}

export async function getMonthlyReport(childId: string, month: string): Promise<Report> {
  const res = await http.get<Report>(`/reports/${childId}/monthly/${month}`)
  return res.data
}

export async function generateReport(
  childId: string,
  opts: { week?: string; month?: string },
): Promise<Report> {
  const res = await http.post<Report>(`/reports/${childId}/generate`, null, { params: opts })
  return res.data
}

export async function exportReportPdf(
  childId: string,
  opts: { week?: string; month?: string },
): Promise<Blob> {
  const res = await http.get<Blob>(`/reports/${childId}/export/pdf`, {
    params: opts,
    responseType: 'blob',
  })
  return res.data
}
