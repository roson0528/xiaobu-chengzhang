import http from './http'
import type { NotificationItem } from '@/types'

export async function listNotifications(unreadOnly = false, date?: string): Promise<NotificationItem[]> {
  const res = await http.get<NotificationItem[]>('/notifications', {
    params: { unread_only: unreadOnly, date },
  })
  return res.data
}

export async function markNotificationRead(notificationId: number): Promise<void> {
  await http.post(`/notifications/${notificationId}/read`)
}

export async function testNotification(message: string): Promise<{ status: string; reason?: string; result?: unknown }> {
  const res = await http.post<{ status: string; reason?: string; result?: unknown }>('/notifications/test', { message })
  return res.data
}

export async function getServerchanKey(): Promise<{ key: string; masked: string; configured: boolean }> {
  const res = await http.get<{ key: string; masked: string; configured: boolean }>('/notifications/serverchan-key')
  return res.data
}

export async function setServerchanKey(key: string): Promise<{ status: string; configured: boolean }> {
  const res = await http.post<{ status: string; configured: boolean }>('/notifications/serverchan-key', { key })
  return res.data
}
