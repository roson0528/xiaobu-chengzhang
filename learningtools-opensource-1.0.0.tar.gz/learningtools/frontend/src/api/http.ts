import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'

const http = axios.create({
  baseURL: '/api/v1',
  timeout: 60000,
})

http.interceptors.request.use((config) => {
  const auth = useAuthStore()
  if (auth.accessToken) {
    config.headers.Authorization = `Bearer ${auth.accessToken}`
  }
  return config
})

function extractDetail(error: AxiosError): string {
  const data = error.response?.data as Record<string, unknown> | undefined
  if (!data) return error.message || '请求失败'
  const detail = data.detail
  if (typeof detail === 'string') return detail
  if (Array.isArray(detail)) {
    return detail
      .map((d) => (typeof d === 'object' && d !== null && 'msg' in d ? String((d as { msg: unknown }).msg) : String(d)))
      .join('；')
  }
  if (typeof detail === 'object' && detail !== null) {
    try {
      return JSON.stringify(detail)
    } catch {
      return '请求失败'
    }
  }
  return error.message || '请求失败'
}

/** 并发 401 时只发起一次刷新，其余复用同一个 Promise。 */
let refreshPromise: Promise<string | null> | null = null

async function doRefresh(refreshToken: string): Promise<string | null> {
  try {
    // 用裸 axios 调用，避免被本拦截器递归处理
    const res = await axios.post('/api/v1/auth/refresh', { refresh_token: refreshToken })
    const token = res.data?.access_token as string | undefined
    if (token) {
      useAuthStore().setAccessToken(token)
      return token
    }
    return null
  } catch {
    return null
  }
}

http.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const status = error.response?.status
    const config = error.config as (InternalAxiosRequestConfig & { _retried?: boolean }) | undefined

    if (status === 401 && config && !config._retried) {
      const auth = useAuthStore()
      if (auth.refreshToken) {
        if (!refreshPromise) {
          refreshPromise = doRefresh(auth.refreshToken).finally(() => {
            refreshPromise = null
          })
        }
        const newToken = await refreshPromise
        if (newToken) {
          config._retried = true
          config.headers.set('Authorization', `Bearer ${newToken}`)
          return http.request(config)
        }
      }
      auth.logout()
      if (window.location.pathname !== '/login') {
        window.location.href = '/login'
      }
      return Promise.reject(error)
    }

    if (status !== 401) {
      ElMessage.error(extractDetail(error))
    }
    return Promise.reject(error)
  },
)

export default http
