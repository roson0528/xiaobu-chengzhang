import http from './http'
import type { MessageItem } from '@/types'

export async function listMessages(childId: string): Promise<MessageItem[]> {
  const res = await http.get<MessageItem[]>(`/messages/${childId}`)
  return res.data
}

export async function sendMessage(childId: string, content: string): Promise<MessageItem> {
  const res = await http.post<MessageItem>(`/messages/${childId}`, { content })
  return res.data
}

export async function markMessageRead(messageId: string, childId: string): Promise<void> {
  await http.post(`/messages/${messageId}/read`, null, { params: { child_id: childId } })
}

/** 拉取附件字节并生成可显示/下载的 objectURL（调用方负责 revoke）。 */
export async function fetchMessageAttachmentBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/messages/${childId}/attachment`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}
