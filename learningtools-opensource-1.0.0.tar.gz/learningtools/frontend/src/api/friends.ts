import http from './http'
import type { FriendItem, FriendMessage, FriendRequest, GrowthRecord } from '@/types'

export async function listFriends(childId: string): Promise<FriendItem[]> {
  const res = await http.get<FriendItem[]>(`/friends/${childId}`)
  return res.data
}

export async function searchChildren(name: string): Promise<FriendItem[]> {
  const res = await http.get<FriendItem[]>('/friends/search', { params: { name } })
  return res.data
}

export async function sendFriendRequest(childId: string, toChild: string): Promise<FriendRequest> {
  const res = await http.post<FriendRequest>(`/friends/${childId}/request`, { to_child: toChild })
  return res.data
}

export async function listRequests(childId: string): Promise<{ incoming: FriendRequest[]; outgoing: FriendRequest[] }> {
  const res = await http.get<{ incoming: FriendRequest[]; outgoing: FriendRequest[] }>(`/friends/${childId}/requests`)
  return res.data
}

export async function approveRequest(requestId: string): Promise<void> {
  await http.post(`/friends/requests/${requestId}/approve`)
}

export async function rejectRequest(requestId: string): Promise<void> {
  await http.post(`/friends/requests/${requestId}/reject`)
}

export async function listFriendMessages(childId: string, friendChildId: string): Promise<FriendMessage[]> {
  const res = await http.get<FriendMessage[]>(`/friends/${childId}/messages/${friendChildId}`)
  return res.data
}

export async function friendGrowth(childId: string, friendChildId: string): Promise<GrowthRecord[]> {
  const res = await http.get<GrowthRecord[]>(`/friends/${childId}/friend/${friendChildId}/growth`)
  return res.data
}

/** 成长照片（path 传完整存储路径）。 */
export async function fetchGrowthPhotoBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/growth/${childId}/photo`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}
