import http from './http'
import type { FocusSession } from '@/types'

export async function listSessions(childId: string, date?: string): Promise<FocusSession[]> {
  const res = await http.get<FocusSession[]>(`/focus/${childId}/sessions`, { params: { date } })
  return res.data
}

export async function listPhotos(childId: string, date?: string): Promise<string[]> {
  const res = await http.get<string[]>(`/focus/${childId}/photos`, { params: { date } })
  return res.data
}

/** 带 token 拉取照片 blob 并生成 object URL（用于缩略图/预览，token 不进 URL）。 */
export async function fetchPhotoBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/focus/${childId}/photo`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}

export async function deletePhoto(childId: string, path: string): Promise<void> {
  await http.delete(`/focus/photos`, { params: { child_id: childId, path } })
}

export interface PhotoAnnotation {
  path: string
  distracted: boolean
  note?: string
  marked_at?: string
  marked_by?: string
}

export async function annotatePhoto(
  childId: string,
  body: { path: string; distracted: boolean; note?: string },
): Promise<void> {
  await http.post(`/focus/${childId}/photo/annotate`, body)
}

export async function listAnnotations(childId: string): Promise<PhotoAnnotation[]> {
  const res = await http.get<PhotoAnnotation[]>(`/focus/${childId}/annotations`)
  return res.data
}
