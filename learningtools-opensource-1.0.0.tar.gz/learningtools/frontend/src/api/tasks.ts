import http from './http'
import type { RepeatRule, TaskItem, TodayTasks } from '@/types'

export interface TaskBody {
  title: string
  subject?: string | null
  task_type?: string | null
  planned_date?: string | null
  planned_start?: string | null
  planned_duration?: number | null
  priority?: number
  difficulty?: string
  repeat?: RepeatRule
  photo_required?: boolean
  penalty_points?: number
  reward_points?: number | null
}

export async function todayTasks(childId: string): Promise<TodayTasks> {
  const res = await http.get<TodayTasks>(`/tasks/${childId}/today`)
  return res.data
}

export async function createTask(childId: string, body: TaskBody): Promise<TaskItem> {
  const res = await http.post<TaskItem>(`/tasks/${childId}`, body)
  return res.data
}

export async function updateTask(taskId: string, childId: string, body: TaskBody): Promise<void> {
  await http.put(`/tasks/${taskId}`, body, { params: { child_id: childId } })
}

export async function deleteTask(taskId: string, childId: string): Promise<void> {
  await http.delete(`/tasks/${taskId}`, { params: { child_id: childId } })
}

export async function reviewTask(
  taskId: string,
  childId: string,
  body: { status: 'approved' | 'rejected'; score?: number; comment?: string; ratings?: Record<string, number> },
): Promise<void> {
  await http.post(`/tasks/${taskId}/review`, body, { params: { child_id: childId } })
}

/** 列出孩子已提交、待审批（含已审批）的任务。 */
export async function reviewTasks(childId: string): Promise<TaskItem[]> {
  const res = await http.get<{ tasks: TaskItem[] }>(`/tasks/${childId}/review`)
  return res.data.tasks
}

/** 任务完成照片（path 传完整存储路径）。 */
export async function fetchTaskPhotoBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/submissions/${childId}/photo`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}
