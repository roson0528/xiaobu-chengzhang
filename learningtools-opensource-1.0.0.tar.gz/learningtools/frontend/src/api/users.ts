import http from './http'
import type { User } from '@/types'

export async function listUsers(): Promise<User[]> {
  const res = await http.get<User[]>('/users')
  return res.data
}

export async function updateUser(userId: number, body: { email?: string; phone?: string; family_id?: string }): Promise<void> {
  await http.put(`/users/${userId}`, body)
}

export async function deleteUser(userId: number): Promise<void> {
  await http.delete(`/users/${userId}`)
}

export async function approveUser(userId: number): Promise<void> {
  await http.post(`/users/${userId}/approve`)
}

export async function rejectUser(userId: number): Promise<void> {
  await http.post(`/users/${userId}/reject`)
}

export async function disableUser(userId: number): Promise<void> {
  await http.post(`/users/${userId}/disable`)
}

export async function enableUser(userId: number): Promise<void> {
  await http.post(`/users/${userId}/enable`)
}

export async function changeUserRole(userId: number, role: string): Promise<void> {
  await http.put(`/users/${userId}/role`, { role })
}

export async function setUserQuota(userId: number, quota_gb: number): Promise<void> {
  await http.put(`/users/${userId}/quota`, { quota_gb })
}
