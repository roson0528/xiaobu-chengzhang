import http from './http'
import type { CheckinPreset, CheckinRecord, CheckinStats, RepeatRule } from '@/types'

export async function listCheckins(childId: string): Promise<CheckinRecord[]> {
  const res = await http.get<CheckinRecord[]>(`/checkins/${childId}`)
  return res.data
}

export async function checkinStats(childId: string): Promise<CheckinStats> {
  const res = await http.get<CheckinStats>(`/checkins/${childId}/stats`)
  return res.data
}

export async function approveCheckin(
  checkinId: string,
  childId: string,
  comment?: string,
  ratings?: Record<string, number>,
): Promise<void> {
  await http.post(`/checkins/${checkinId}/review`, { comment, ratings }, { params: { child_id: childId } })
}

export async function rejectCheckin(
  checkinId: string,
  childId: string,
  comment?: string,
  ratings?: Record<string, number>,
): Promise<void> {
  await http.post(`/checkins/${checkinId}/reject`, { comment, ratings }, { params: { child_id: childId } })
}

export async function batchReview(
  childId: string,
  ids: string[],
  action: 'approve' | 'reject',
  comment?: string,
  score?: number,
): Promise<void> {
  await http.post(`/checkins/${childId}/batch-review`, { ids, action, comment, score })
}

/** 打卡提交照片（path 传完整存储路径）。 */
export async function fetchSubmissionPhotoBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/submissions/${childId}/photo`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}

/** 朗读打卡录音（path 传完整存储路径）。 */
export async function fetchAudioBlob(childId: string, path: string): Promise<string> {
  const res = await http.get(`/checkins/${childId}/audio`, {
    params: { path },
    responseType: 'blob',
  })
  return URL.createObjectURL(res.data as Blob)
}

// ---- 打卡任务预设（家长预设打卡内容） ----

export interface CheckinPresetBody {
  title: string
  checkin_type: string
  subject: string
  content?: string | null
  duration: number
  enabled: boolean
  repeat?: RepeatRule
  photo_required?: boolean
  penalty_points?: number
}

export async function listPresets(childId: string): Promise<CheckinPreset[]> {
  const res = await http.get<{ items: CheckinPreset[] }>(`/checkins/${childId}/presets`)
  return res.data.items || []
}

export async function createPreset(childId: string, body: CheckinPresetBody): Promise<CheckinPreset> {
  const res = await http.post<CheckinPreset>(`/checkins/${childId}/presets`, body)
  return res.data
}

export async function updatePreset(childId: string, presetId: string, body: CheckinPresetBody): Promise<void> {
  await http.put(`/checkins/${childId}/presets/${presetId}`, body)
}

export async function deletePreset(childId: string, presetId: string): Promise<void> {
  await http.delete(`/checkins/${childId}/presets/${presetId}`)
}
