import http from './http'
import type { Child, QuotaInfo } from '@/types'

export interface ChildBody {
  name: string
  grade?: number | null
  birthday?: string | null
  avatar?: string | null
  username?: string | null
  password?: string | null
}

export async function listChildren(): Promise<Child[]> {
  const res = await http.get<Child[]>('/children')
  return res.data
}

export async function getChild(childId: string): Promise<Child> {
  const res = await http.get<Child>(`/children/${childId}`)
  return res.data
}

export async function createChild(body: ChildBody): Promise<{ id: string; name: string; user_id?: number | null }> {
  const res = await http.post<{ id: string; name: string; user_id?: number | null }>('/children', body)
  return res.data
}

export async function updateChild(childId: string, body: Partial<ChildBody>): Promise<void> {
  await http.put(`/children/${childId}`, body)
}

export async function deleteChild(childId: string): Promise<void> {
  await http.delete(`/children/${childId}`)
}

export async function getQuota(childId: string): Promise<QuotaInfo> {
  const res = await http.get<QuotaInfo>(`/children/${childId}/quota`)
  return res.data
}

export async function setQuota(childId: string, quota_mb: number): Promise<void> {
  await http.put(`/children/${childId}/quota`, { quota_mb })
}

export async function setRetention(
  childId: string,
  body: { photo_retention_days?: number; video_retention_days?: number },
): Promise<void> {
  await http.put(`/children/${childId}/retention`, body)
}
