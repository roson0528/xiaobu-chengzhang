import { createApp } from 'vue'
import { createPinia } from 'pinia'
// Element Plus 组件/样式改为按需自动导入（见 vite.config.ts 的 Components 插件）；
// 命令式组件 ElMessage / ElMessageBox 的样式在此手动引入。
import 'element-plus/es/components/message/style/css'
import 'element-plus/es/components/message-box/style/css'
import App from './App.vue'
import router from './router'
import './styles/main.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')