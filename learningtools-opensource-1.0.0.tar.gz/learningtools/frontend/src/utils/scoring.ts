export interface RatingDimension {
  key: string
  label: string
}

export const SCORE_DIMENSIONS: RatingDimension[] = [
  { key: 'completion', label: '完成度' },
  { key: 'diligence', label: '认真度' },
  { key: 'accuracy', label: '正确率' },
]

/** 维度评分（1-5 星）→ 0-100 总分；无有效评分返回 undefined。 */
export function ratingsToScore(ratings: Record<string, number>): number | undefined {
  const vals = SCORE_DIMENSIONS.map((d) => ratings[d.key]).filter(
    (v): v is number => typeof v === 'number' && v > 0,
  )
  if (!vals.length) return undefined
  return Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 20)
}
