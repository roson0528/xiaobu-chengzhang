// 日期辅助：ISO 周计算等

import { ElMessageBox } from 'element-plus'

/** 弹出确认框；确认返回 true，取消返回 false（不会抛异常） */
export async function confirmAction(
  message: string,
  title = '提示',
  type: 'warning' | 'info' | 'success' | 'error' = 'warning',
): Promise<boolean> {
  try {
    await ElMessageBox.confirm(message, title, {
      type,
      confirmButtonText: '确定',
      cancelButtonText: '取消',
    })
    return true
  } catch {
    return false
  }
}

export function pad(n: number): string {
  return String(n).padStart(2, '0')
}

/** 计算某个日期所在的 ISO 周，返回 "YYYY-Www" */
export function toIsoWeek(d: Date): string {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
  const dayNum = date.getUTCDay() || 7
  date.setUTCDate(date.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1))
  const weekNo = Math.ceil(((date.getTime() - yearStart.getTime()) / 86400000 + 1) / 7)
  return `${date.getUTCFullYear()}-W${pad(weekNo)}`
}

/** 由 ISO 周标识（如 2026-W37）计算该周周一 */
export function weekStartDate(week: string): Date {
  const match = /^(\d{4})-W(\d{2})$/.exec(week)
  if (!match) return new Date()
  const year = Number(match[1])
  const w = Number(match[2])
  const jan4 = new Date(year, 0, 4)
  const day = jan4.getDay() || 7
  return new Date(year, 0, 4 - day + 1 + (w - 1) * 7)
}

export function currentIsoWeek(): string {
  return toIsoWeek(new Date())
}

export function currentMonth(): string {
  const now = new Date()
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}`
}

/** 本地时区的当天日期（与服务端 datetime.now() 对齐） */
export function localToday(): string {
  const now = new Date()
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`
}

export function formatDate(d?: string | null): string {
  if (!d) return '-'
  return d.slice(0, 10)
}

export function formatDateTime(d?: string | null): string {
  if (!d) return '-'
  return d.replace('T', ' ').slice(0, 19)
}

export function formatDuration(seconds?: number | null): string {
  if (!seconds || seconds <= 0) return '0 秒'
  const s = Math.floor(seconds)
  if (s < 60) return `${s} 秒`
  const m = Math.floor(s / 60)
  if (m < 60) return `${m} 分钟${s % 60 ? ` ${s % 60} 秒` : ''}`
  const h = Math.floor(m / 60)
  return `${h} 小时 ${m % 60} 分钟`
}

export function formatBytesToMb(mb?: number | null): string {
  if (mb === undefined || mb === null) return '-'
  return `${mb.toFixed(1)} MB`
}

/** Element Plus 按键名 → priority 数值 */
export function priorityValue(label: string): number {
  switch (label) {
    case '高':
      return 3
    case '中':
      return 2
    case '低':
      return 1
    default:
      return 0
  }
}

export function priorityLabel(v?: number | null): string {
  switch (v) {
    case 3:
      return '高'
    case 2:
      return '中'
    case 1:
      return '低'
    default:
      return '无'
  }
}

export function statusTagType(status?: string): 'success' | 'warning' | 'info' | 'danger' {
  switch (status) {
    case 'completed':
      return 'success'
    case 'approved':
      return 'success'
    case 'pending':
      return 'warning'
    case 'rejected':
    case 'skipped':
      return 'danger'
    default:
      return 'info'
  }
}

export function statusLabel(status?: string): string {
  switch (status) {
    case 'pending':
      return '待处理'
    case 'approved':
      return '已通过'
    case 'rejected':
      return '已驳回'
    case 'completed':
      return '已完成'
    case 'skipped':
      return '已跳过'
    case 'active':
      return '进行中'
    case 'ended':
      return '已结束'
    case 'disabled':
      return '已禁用'
    default:
      return status || '-'
  }
}

/** 下载 Blob 为文件 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

/** 徽章条目 → 显示文本（后端结构未知，做容错） */
export function badgeLabel(item: unknown): string {
  if (typeof item === 'string') return item
  if (item && typeof item === 'object') {
    const obj = item as Record<string, unknown>
    const name = obj.name ?? obj.title ?? obj.badge_name ?? obj.label
    if (typeof name === 'string' && name) return name
    try {
      return JSON.stringify(item)
    } catch {
      return String(item)
    }
  }
  return String(item)
}