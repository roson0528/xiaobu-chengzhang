export type Difficulty = 'easy' | 'medium' | 'hard'

export const DIFFICULTY_OPTIONS: { value: Difficulty; label: string }[] = [
  { value: 'easy', label: '简单' },
  { value: 'medium', label: '中等' },
  { value: 'hard', label: '困难' },
]

export function difficultyLabel(v?: string): string {
  return DIFFICULTY_OPTIONS.find((o) => o.value === v)?.label || '中等'
}

export function difficultyType(v?: string): 'success' | 'warning' | 'danger' | 'info' {
  if (v === 'easy') return 'success'
  if (v === 'hard') return 'danger'
  if (v === 'medium') return 'warning'
  return 'info'
}

export const DIFFICULTY_POINTS: Record<string, number> = { easy: 10, medium: 15, hard: 20 }
