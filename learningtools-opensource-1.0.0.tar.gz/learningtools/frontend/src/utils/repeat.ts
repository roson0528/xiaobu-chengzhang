// 任务循环模式辅助：选项常量与中文标签

import type { RepeatRule } from '@/types'

export const REPEAT_OPTIONS: { label: string; value: RepeatRule['type'] }[] = [
  { label: '不重复', value: 'none' },
  { label: '每天', value: 'daily' },
  { label: '每周', value: 'weekly' },
]

export const WEEKDAY_OPTIONS: { label: string; value: number }[] = [
  { label: '周一', value: 1 },
  { label: '周二', value: 2 },
  { label: '周三', value: 3 },
  { label: '周四', value: 4 },
  { label: '周五', value: 5 },
  { label: '周六', value: 6 },
  { label: '周日', value: 7 },
]

const WEEKDAY_LABELS: Record<number, string> = {
  1: '周一',
  2: '周二',
  3: '周三',
  4: '周四',
  5: '周五',
  6: '周六',
  7: '周日',
}

/** 循环模式 → 中文描述，如「每天」「每周一、三、五」「不重复」 */
export function repeatLabel(repeat?: RepeatRule | null): string {
  if (!repeat || repeat.type === 'none') return '不重复'
  if (repeat.type === 'daily') return '每天'
  const days = Array.isArray(repeat.days) ? repeat.days : []
  if (!days.length) return '每周'
  const sorted = [...new Set(days)]
    .filter((d) => d >= 1 && d <= 7)
    .sort((a, b) => a - b)
  if (!sorted.length) return '每周'
  return `每周${sorted.map((d) => WEEKDAY_LABELS[d] ?? `周${d}`).join('、')}`
}
