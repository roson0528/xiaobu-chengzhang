"""清理部署过程中的测试数据：删除所有测试孩子/账号及其 WebDAV 目录。

保留 super_admin（admin）账号。仅清理 learningtools 根下的 child_* 目录。
"""
import base64
import json
import urllib.error
import urllib.request

BASE = "http://localhost:51666/api/v1"
WEBDAV = "https://your-nas.example.com/dav"
WEBDAV_USER = "roson"
WEBDAV_PASS = "your-webdav-password"
WEBDAV_ROOT = "/learningtools"


def http(method, url, token=None, body=None):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or "{}")
        except Exception:
            return e.code, {}


def dav(method, path, depth=None):
    headers = {"Authorization": "Basic " + base64.b64encode(f"{WEBDAV_USER}:{WEBDAV_PASS}".encode()).decode()}
    if depth is not None:
        headers["Depth"] = str(depth)
    req = urllib.request.Request(WEBDAV + path, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()


def list_dav(path):
    """返回 (files, dirs) —— 相对 path 的直接子项。"""
    status, body = dav("PROPFIND", path, depth=1)
    if status != 207:
        return [], []
    import re
    hrefs = re.findall(rb"<[^>]*href[^>]*>([^<]+)</[^>]*href[^>]*>", body)
    files, dirs = [], []
    base = path.rstrip("/") + "/"
    for h in hrefs:
        u = urllib.request.urlparse(h.decode())
        p = urllib.request.unquote(u.path)
        if p == path.rstrip("/") + "/" or p == path.rstrip("/"):
            continue
        if p.endswith("/"):
            dirs.append(p)
        else:
            files.append(p)
    return files, dirs


def delete_tree(path):
    """递归删除 WebDAV 集合。"""
    files, dirs = list_dav(path)
    for f in files:
        dav("DELETE", f)
    for d in dirs:
        delete_tree(d)
        dav("DELETE", d)
    dav("DELETE", path)


def main():
    s, admin = http("POST", BASE + "/auth/login", body={"username": "admin", "password": "admin123456"})
    assert s == 200, "admin 登录失败"
    token = admin["access_token"]

    # 1. 删除所有孩子（SQLite 行 + WebDAV 目录）
    s, children = http("GET", BASE + "/children", token=token)
    for c in children:
        cid = c.get("id", "")
        print(f"删除孩子 {cid} ({c.get('name')})")
        http("DELETE", f"{BASE}/children/{cid}", token=token)
        delete_tree(f"{WEBDAV_ROOT}/{cid}")
        print(f"  WebDAV {cid} 已清理")

    # 2. 删除所有非 super_admin 用户
    s, users = http("GET", BASE + "/users", token=token)
    for u in users:
        if u.get("role") == "super_admin":
            continue
        print(f"删除用户 {u.get('username')} (role={u.get('role')})")
        http("DELETE", f"{BASE}/users/{u.get('id')}", token=token)

    # 3. 汇总
    s, children = http("GET", BASE + "/children", token=token)
    s, users = http("GET", BASE + "/users", token=token)
    print(f"\n清理完成：剩余孩子 {len(children)} 个，用户 {len(users)} 个（{', '.join(u['username'] for u in users)}）")


if __name__ == "__main__":
    main()
