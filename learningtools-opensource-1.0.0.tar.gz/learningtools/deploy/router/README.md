# 学习平台 · 上网管控（软路由侧）

让 **MRX-W09 平板** 默认无法上网，只有下面两种情况才临时放行：

1. 孩子在孩子端打开一个**家长勾选了「需要联网」的任务/作业**并开始专注 —— 专注结束即收回；
2. 孩子用积分**兑换了带「附赠上网时长」的奖励** —— 时长用完即收回。

家长还可以在家长端「网络管控」里用「一键断网 / 一键联网」硬开关直接覆盖。

> 平板本身没有独立的联网权，能否上网完全由孩子端 App 的状态决定。
> 「需要联网」在发布任务/布置作业时**默认不勾选**，自由专注（没有任务）一律不放行。

## 设计原则：纯增量，不碰任何现有功能

路由器上已经跑着「家长控制」(`timecontrol`)、`passwall`、`openclash`、
`game-defense`、`ban_sync` 等防火墙逻辑。本方案**只新增自己的东西**：

| 新增内容 | 位置 | 说明 |
| --- | --- | --- |
| nft 表 | `inet lt_netctl` | 只有我们自己读写，其它模块完全不知道它的存在 |
| 代理脚本 | `/usr/bin/lt-netctl` | 拉策略 + 判定 + 应用 |
| 开机脚本 | `/etc/init.d/lt-netctl` | 开机重建 tmpfs 里的 include 文件并应用一次 |
| cron | `* * * * * /usr/bin/lt-netctl` | 每分钟同步一次（精度 1 分钟） |
| fw4 include | `/var/etc/lt-netctl.include` | 防火墙重载后立刻重放 |
| 状态文件 | `/etc/lt-netctl.token` `.policy.json` `.skew` `.applied` | token / 缓存 / 时钟偏移 / 已应用签名 |
| 日志 | `/var/log/lt-netctl.log` | 只在状态变化或出错时写 |

**没有修改**：`timecontrol`、`firewall` 的既有 include（只追加了一条）、
`passwall`、`openclash`、`game-defense`、`sync_ban_ips` 的任何配置或规则。

### 为什么不能改造 timecontrol

内核 `nf_hook_slow` 语义：同 hook 上的多个 base chain 按优先级依次执行，
**`accept` 只结束当前 chain 并继续走下一个 base chain，只有 `drop`/`reject` 才终止**。
所以「另起一张高优先级表 accept」是压不住 `timecontrol` 的 `REJECT` 的。
本方案的封禁/放行**全部由我们自己的 `drop` 完成**，因此与 `timecontrol` 完全解耦：

* 封禁：早于 conntrack 的 `priority raw` 上 `drop`，一定生效；
* 放行：不产生任何规则（而不是去 accept），让流量走原来的链路。

## 判定逻辑

路由器不依赖「后端按时下发」也能正确工作。每分钟：

1. 带 token 拉 `GET /api/v1/netcontrol/policy`（3s 连接 / 6s 总超时，走内网 `--resolve`）；
2. 成功 → 缓存到本地，并记下 `skew = server_ts - local_ts`（限幅 ±10 分钟）；
3. 用 `本地时间 + skew` 与策略里的 epoch 秒比较，**本地判定**当前是否放行；
4. 结果与上次一致则什么都不做（零规则抖动），变化才重建整张表（原子生效）。

| 后端策略 | 表内容 |
| --- | --- |
| `mode=allow_all` 且未过期 | 空表（完全放开） |
| `mode=enforce` 且 `allow_until_ts > now` | `ether saddr <MAC> ip daddr <平台IP> tcp dport 51666 accept` + `ether saddr <MAC> drop` |
| `mode=enforce` | 同上，无 accept（只放行学习平台） |
| `mode=block_all` | `ether saddr <MAC> drop`（连学习平台一起断） |
| `enabled=false` | 空表（不管控） |

故障安全：**后端连续不可达时沿用缓存 + 本地时间判定，到期照常收紧**；
连缓存都没有（刚重启且后端不可用）时按「默认限制」处理。
也就是说，会自己失效的一定是「临时放行」，绝不会是「限制」。

## 安装 / 重新部署

```bash
export SSHPASS='<路由器密码>'
SSH="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@YOUR_ROUTER_IP"

# 1) 备份
sshpass -e ssh $SSH 'mkdir -p /root/lt-netctl-backup && cd /root/lt-netctl-backup && \
  cp -a /etc/config/firewall firewall.bak && cp -a /etc/crontabs/root crontab.bak && \
  iptables-save > iptables.bak; nft list ruleset > nftables.bak'

# 2) 脚本 + token
cat lt-netctl      | sshpass -e ssh $SSH 'cat > /usr/bin/lt-netctl && chmod 755 /usr/bin/lt-netctl'
cat lt-netctl.init | sshpass -e ssh $SSH 'cat > /etc/init.d/lt-netctl && chmod 755 /etc/init.d/lt-netctl'
sshpass -e ssh $SSH "printf '%s' '<AGENT_TOKEN>' > /etc/lt-netctl.token && chmod 600 /etc/lt-netctl.token"

# 3) 空跑确认（不产生任何改动）
sshpass -e ssh $SSH '/usr/bin/lt-netctl --show'

# 4) 开机自启 + cron + fw4 include
sshpass -e ssh $SSH '/etc/init.d/lt-netctl enable && /etc/init.d/lt-netctl start'
sshpass -e ssh $SSH 'grep -q lt-netctl /etc/crontabs/root || echo "* * * * * /usr/bin/lt-netctl" >> /etc/crontabs/root; /etc/init.d/cron reload'
sshpass -e ssh $SSH 'uci add firewall include >/dev/null
  uci set firewall.@include[-1].type="script"
  uci set firewall.@include[-1].path="/var/etc/lt-netctl.include"
  uci set firewall.@include[-1].fw4_compatible="1"
  uci set firewall.@include[-1].enabled="1"
  uci commit firewall'
```

`AGENT_TOKEN` 取自后端 `system/netcontrol.json` 的 `agent_token` 字段。

## 排查

```bash
/usr/bin/lt-netctl --show     # 看判定结果 + 将要应用的规则（不改动）
nft list table inet lt_netctl # 看规则和命中计数
tail -20 /var/log/lt-netctl.log
logread | grep lt-netctl      # 看 cron 是否在跑
```

常见情况：

* **计数器一直是 0** → 设备没在线，或换了 MAC（Android 随机 MAC 会变）。
  用 `ip neigh | grep YOUR_ROUTER_IP` 核对，必要时在家长端「网络管控」里改 MAC。
* **孩子说上不了网但应该在专注** → 先确认这条任务/作业真的勾了「需要联网」；
  再看 `/var/log/lt-netctl.log` 是否在“后端不可达”，以及后端
  `GET /api/v1/netcontrol/policy?token=...` 是否正常返回。
* **勾了「需要联网」还是不放开** → 后端要能按孩子端传来的 `task_id` 找到任务。
  循环任务（每天/每周）的主记录一直留在**它被创建的那一周**，孩子端每天点的
  却还是同一个 `task_id`（例：「英语打卡」创建于 3 周前）。所以查找**必须遍历
  所有周计划文件**，不能只看本周和上周 —— 后端已统一走 `tasks._find_task`。
  自查：`POST /api/v1/focus/{child}/start` 返回后，会话里的 `task_name` 若是
  「自由任务」，就说明任务没找到，`need_network` 会退化成 False。
* **刚点专注还是上不了网** → 路由器是**每分钟**同步一次（cron），最多等 60 秒生效；
  结束后同样最多 60 秒收回。这是设计精度，不是故障。
* **平板完全没网（连 App 都打不开）** → 说明被 `block_all` 断网了，
  家长端「网络管控」点「恢复正常管控」即可。

## 回滚

```bash
export SSHPASS='<路由器密码>'
SSH="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@YOUR_ROUTER_IP"

sshpass -e ssh $SSH '/etc/init.d/lt-netctl disable; /etc/init.d/lt-netctl stop'
sshpass -e ssh $SSH 'nft delete table inet lt_netctl 2>/dev/null; \
  sed -i "/lt-netctl/d" /etc/crontabs/root; /etc/init.d/cron reload; \
  rm -f /var/etc/lt-netctl.include /etc/lt-netctl.*'
sshpass -e ssh $SSH 'cp /root/lt-netctl-backup/firewall.bak /etc/config/firewall && fw4 reload'
```

其余模块（`timecontrol` 等）从头到尾没被改过，不需要恢复。
