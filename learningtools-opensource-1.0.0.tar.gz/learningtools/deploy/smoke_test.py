import datetime
import json
import time
import urllib.error
import urllib.request

BASE = "http://localhost:51666/api/v1"
PASS = 0
FAIL = 0


def call(method, path, token=None, body=None, form=None):
    url = BASE + path
    headers = {"Content-Type": "application/json"}
    data = None
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if form is not None:
        boundary = "----testboundary"
        parts = []
        for k, v in form.items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n')
        parts.append(f"--{boundary}--\r\n")
        data = "".join(parts).encode()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
    elif body is not None:
        data = json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read().decode() or "{}")
        except Exception:
            return e.code, {}


def check(name, ok, extra=""):
    global PASS, FAIL
    if ok:
        PASS += 1
        print(f"  ✅ {name} {extra}")
    else:
        FAIL += 1
        print(f"  ❌ {name} {extra}")


uname = f"xiaoming_{int(time.time())}"

print("== 1. 管理员登录 ==")
s, admin = call("POST", "/auth/login", body={"username": "admin", "password": "admin123456"})
check("admin login", s == 200 and "access_token" in admin)
at = admin.get("access_token", "")

print("== 2. 创建孩子(带账号) ==")
s, child = call("POST", "/children", token=at, body={
    "name": "小明", "grade": 3, "username": uname, "password": "xiaoming123"
})
check("create child", s == 200 and "id" in child, str(child.get("id", "")))
cid = child.get("id", "")

print("== 3. 孩子账号登录 ==")
s, child_login = call("POST", "/auth/login", body={"username": uname, "password": "xiaoming123"})
check("child login", s == 200 and child_login.get("user", {}).get("role") == "child")
ct = child_login.get("access_token", "")

print("== 4. 创建周计划+今日任务 ==")
today = datetime.date.today().isoformat()
iso = datetime.date.today().isocalendar()
week = f"{iso.year}-W{iso.week:02d}"
task = {"id": "task_test1", "title": "语文作业", "subject": "语文",
        "task_type": "homework", "planned_date": today, "planned_start": "19:00",
        "planned_duration": 30, "priority": 1, "status": "pending"}
s, plan = call("PUT", f"/plans/{cid}/weekly/{week}", token=at, body={"tasks": [task]})
check("create plan", s == 200, f"HTTP {s} {plan}")

print("== 5. 孩子查看今日任务 ==")
s, today_resp = call("GET", f"/tasks/{cid}/today", token=ct)
check("today tasks", s == 200 and len(today_resp.get("tasks", [])) == 1,
      f"HTTP {s} count={len(today_resp.get('tasks', []))}")

print("== 6. 完成任务(从登录态解析孩子) ==")
s, r = call("POST", "/tasks/task_test1/complete", token=ct)
check("complete task", s == 200, f"HTTP {s} {r}")

print("== 7. 提交打卡 ==")
s, r = call("POST", f"/checkins/{cid}", token=ct, body={"checkin_type": "学习打卡", "subject": "语文", "duration": 30})
check("submit checkin", s == 200, f"HTTP {s} {r}")

print("== 8. 提交运动打卡 ==")
s, r = call("POST", f"/fitness/{cid}", token=ct, body={"exercise_type": "跳绳", "duration": 20, "count": 500})
check("submit fitness", s == 200, f"HTTP {s} {r}")

print("== 9. 专注会话 ==")
s, session = call("POST", f"/focus/{cid}/start", token=ct, form={"task_id": "task_test1"})
check("start focus", s == 200, f"HTTP {s} {session.get('id','')[:24]}")
sid = session.get("id", "")
s, r = call("POST", f"/focus/{cid}/event", token=ct, form={"type": "background_switch", "session_id": sid})
check("report event", s == 200, f"HTTP {s}")
s, r = call("POST", f"/focus/{cid}/stop", token=ct, form={"session_id": sid})
check("stop focus", s == 200, f"HTTP {s}")

print("== 10. 积分/徽章 ==")
s, pts = call("GET", f"/rewards/{cid}/points", token=at)
check("points", s == 200 and (pts.get("total") or 0) > 0, f"total={pts.get('total')}")
s, badges = call("GET", f"/rewards/{cid}/badges", token=at)
check("badges", s == 200, f"HTTP {s}")

print("== 11. 专注会话列表 ==")
s, sessions = call("GET", f"/focus/{cid}/sessions", token=at)
check("focus sessions", s == 200 and len(sessions) >= 1, f"count={len(sessions)}")

print("== 12. 生成周报 ==")
s, report = call("GET", f"/reports/{cid}/weekly/{week}", token=at)
rate = (report.get("summary") or {}).get("completion_rate")
check("weekly report", s == 200 and "summary" in report, f"完成率={rate}")

print("== 13. 管理员统计 ==")
s, stats = call("GET", "/admin/stats", token=at)
check("admin stats", s == 200, str(stats))

print("== 14. 权限校验(child 访问 users 应 403) ==")
s, r = call("GET", "/users", token=ct)
check("rbac 403", s == 403, f"got {s}")

print("== 15. 同步 pull ==")
s, snap = call("GET", f"/sync/pull?child_id={cid}", token=ct)
check("sync pull", s == 200 and "plan_tasks" in snap, f"HTTP {s}")

print(f"\n========== 结果: {PASS} 通过, {FAIL} 失败 ==========")
