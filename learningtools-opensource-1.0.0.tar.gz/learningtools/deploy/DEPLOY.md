# LearningTools 部署与运维说明

> 学习工具全家桶：家长端 / 孩子端 APP + 管理后台 Web，服务端为 Docker 容器栈，
> 文件存储依赖局域网内的群晖（Synology）NAS WebDAV。

---

## 1. 架构总览

```
                      Internet / 局域网
                            │
                    ┌───────▼────────┐
                    │  learningtools-nginx   │  :51666 (80)
                    │  nginx:1.27-alpine     │
                    │  · 静态站点 frontend/dist│
                    │  · /api/ 反向代理        │
                    │  · /apk/ 下载分发       │
                    └───────┬────────┘
                            │  /api/  upstream backend:8000
              ┌─────────────┼──────────────┐
              ▼                             ▼
 ┌────────────────────┐        ┌────────────────────┐
 │ learningtools-backend│      │ learningtools-scheduler│
 │  FastAPI (gunicorn) │      │  APScheduler 定时任务  │
 │  :8000 全部业务接口   │      │  清理/日报/备份/打卡审核│
 └─────────┬──────────┘        └──────────┬─────────┘
           │ SQLite (卷)                 │
           │ aiosqlite                  │
           ▼                             ▼
 ┌────────────────────┐        ┌────────────────────┐
 │ learningtools-redis │       │  群晖 NAS WebDAV     │
 │  redis:7-alpine     │       │  YOUR_NAS_IP:5005 │
 │  锁 / 配额 / 会话    │       │  文件存储(JSON/图片/APK)│
 └────────────────────┘        └────────────────────┘

 ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
 │ 孩子端 APK    │   │ 家长端 APK    │   │ 管理后台 Web  │
 │ cn.angh.     │   │ cn.angh.     │   │ Vue3+Element │
 │ learning_app │   │ learning_    │   │ Plus (nginx   │
 │  (Flutter)   │   │ parent (Flut)│   │  静态托管)    │
 └──────────────┘   └──────────────┘   └──────────────┘
```

---

## 2. 服务端 Docker 容器清单

| 容器名 | 镜像 | 作用 | 端口 | 重启策略 |
|---|---|---|---|---|
| `learningtools-nginx` | `nginx:1.27-alpine` | 静态站点 + `/api/` 反向代理 + `/apk/` APK 下载 | `51666:80` | `unless-stopped` |
| `learningtools-backend` | `deploy-backend`（本地构建，Python 3.12-slim） | FastAPI 全部业务接口，gunicorn 运行 | 仅内网 `8000` | `unless-stopped` |
| `learningtools-scheduler` | `deploy-scheduler`（与 backend 同镜像） | APScheduler 定时任务（清理/日报/备份/打卡自动审核） | 仅内网 `8000` | `unless-stopped` |
| `learningtools-redis` | `redis:7-alpine` | 分布式锁 / 配额计数 / 会话 sid / 队列 | 仅内网 `6379`（AOF 持久化） | `unless-stopped` |

> 注：`learningtools-scheduler` 与 `learningtools-backend` 使用**同一份后端代码**，
> 仅启动命令不同（backend=`gunicorn app.main:app`，scheduler=`python -m app.tasks.scheduler`）。

### 后端功能模块（`/api/v1/*`）

auth、users、children、tasks、plans、homework、messages、family（家庭群聊/私聊）、
friends、checkins、fitness、reading、mistakes、mood、diary、focus、rewards、
growth、reports、submissions、sync、export、notifications、chat-manage、admin。

---

## 3. 客户端应用清单

| 应用 | 包名 | 当前版本 | 分发方式 |
|---|---|---|---|
| 孩子端 | `cn.angh.learning_app` | 0.72 | `/apk/app-release.apk` |
| 家长/管理端 | `cn.angh.learning_parent` | 0.96 | `/apk/parent-app-release.apk` |
| 管理后台 Web | — | — | `http://localhost/`（nginx 托管） |

---

## 4. 环境依赖

### 4.1 宿主机运行时依赖

| 依赖 | 版本/要求 | 说明 |
|---|---|---|
| Linux（systemd） | — | 当前为 Debian/Ubuntu 系 |
| Docker Engine | 29.x | `docker.service` 已 `enable`（开机自启） |
| Docker Compose | v2（插件，`docker compose`） | v5.5.0 |

### 4.2 外部依赖（非容器，需保证网络可达）

| 依赖 | 地址 | 用途 | 必需 |
|---|---|---|---|
| 群晖 NAS WebDAV | `https://your-nas.example.com/dav`（用户 `roson`，根 `/learningtools`） | **核心文件存储**：JSON 数据、聊天/打卡图片、APK、备份 | ✅ 必需 |
| Server酱（ServerChan） | 推送 Key | 系统告警推送（可选） | ⬜ 可选 |
| SMTP | 邮件服务器 | 邮件通知（可选，当前未配置） | ⬜ 可选 |

> ⚠️ 注意区分：宿主机上还有一个 `paddleocr-server` 容器也监听 `5005`（本机端口），
> 与本项目**无关**。本项目 WebDAV 走的是 NAS 的 `YOUR_NAS_IP:5005`，不要混淆。

### 4.3 构建工具链（仅在需要重新构建时）

| 工具 | 路径/版本 | 用途 |
|---|---|---|
| Flutter SDK | `/data/apps/learningtools/.sdk/flutter/bin` | 编译孩子端/家长端 APK |
| Node + pnpm | 系统全局 | 编译管理后台 Web（`frontend/`） |
| Python 3.12 | 由 Docker 镜像提供 | 后端（无需宿主机 Python） |

---

## 5. 配置与环境变量（`deploy/.env`）

| 键 | 作用 |
|---|---|
| `WEBDAV_URL/USER/PASSWORD/ROOT` | NAS WebDAV 存储凭据与根路径 |
| `JWT_SECRET/ALGORITHM/EXPIRE_MINUTES/REFRESH_TOKEN_EXPIRE_DAYS` | 登录令牌 |
| `HOST/PORT/REDIS_URL/CORS_ORIGINS` | 服务监听、Redis、跨域白名单 |
| `DEFAULT_QUOTA_MB/PHOTO_/VIDEO_/AUDIO_RETENTION_DAYS` | 配额与媒体保留期 |
| `SERVERCHAN_SENDKEY` | Server酱告警（可选） |
| `SMTP_*` | 邮件（可选） |
| `TZ` | 时区（`your-tz`） |

> 改完 `.env` 后需 `docker compose up -d` 重启容器生效。

---

## 6. 端口与网络

| 端口 | 服务 | 暴露范围 |
|---|---|---|
| 51666 | nginx（站点/API/APK） | 公网/局域网 |
| 8000 | backend / scheduler | 仅 compose 内网 `learningtools-net` |
| 6379 | redis | 仅 compose 内网 |

Compose 网络：`learningtools-net`。容器间用服务名互访（`backend`、`redis`）。

---

## 7. 数据与存储位置

| 数据 | 位置 |
|---|---|
| SQLite（用户/孩子档案） | Docker 卷 `backend-data` → 容器内 `/app/data/app.db` |
| Redis（AOF） | Docker 卷 `redis-data` |
| 业务 JSON / 图片 / 附件 / 备份 | 群晖 NAS WebDAV `learningtools/`（按 family_id、child_id 分目录） |
| 管理后台静态资源 + APK | 宿主机 `frontend/dist/`（只读挂载进 nginx） |

---

## 8. 定时任务（scheduler 容器）

| 任务 | 周期 |
|---|---|
| 数据清理 `cleanup` | 每天 02:00 |
| 每日报告 `daily_report` | 每天 21:00 |
| 备份 `backup` | 每周日 03:00 |
| 打卡自动审核 `checkin_auto_approve` | 每 30 分钟 |

---

## 9. 开机自启动

### 现状（已生效）

1. `docker.service` 已 `systemctl enable`，开机自动启动 Docker daemon；
2. 四个容器均配置 `restart: unless-stopped`，Docker 启动后会自动拉起。

因此**当前已经具备开机自启动能力**。

### 推荐：注册 systemd 服务做显式编排

已提供单元文件 `deploy/learningtools.service`。安装（需 root）：

```bash
sudo cp /data/apps/learningtools/deploy/learningtools.service /etc/systemd/system/learningtools.service
sudo systemctl daemon-reload
sudo systemctl enable --now learningtools.service
```

之后可用：

```bash
sudo systemctl status learningtools   # 查看状态
sudo systemctl restart learningtools  # 重启整个栈
```

---

## 10. 常用运维命令

```bash
cd /data/apps/learningtools/deploy

# 启动 / 停止 / 查看
docker compose up -d
docker compose down          # 注意：会移除容器（数据卷保留）
docker compose ps
docker compose logs -f backend

# 重启单个容器
docker restart learningtools-backend

# 查看健康
curl http://127.0.0.1:51666/health
curl http://127.0.0.1:51666/api/v1/app/latest          # 孩子端版本
curl http://127.0.0.1:51666/api/v1/app/parent/latest   # 家长端版本
```

---

## 11. 构建与部署流程

### 11.1 后端

```bash
cd /data/apps/learningtools
docker compose -f deploy/docker-compose.yml build backend
docker compose -f deploy/docker-compose.yml up -d backend scheduler
```

### 11.2 管理后台 Web

```bash
cd /data/apps/learningtools/frontend
pnpm install
pnpm build          # 输出到 frontend/dist/（nginx 直接托管，无需重启容器）
```

### 11.3 客户端 APK（孩子端 / 家长端）

```bash
export PATH="/data/apps/learningtools/.sdk/flutter/bin:$PATH"

# 孩子端
cd /data/apps/learningtools/app/child_app
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk \
   /data/apps/learningtools/frontend/dist/apk/app-release.apk

# 家长端
cd /data/apps/learningtools/app/parent_app
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk \
   /data/apps/learningtools/frontend/dist/apk/parent-app-release.apk
```

### 11.4 发版（触发 App 升级提示）

同时改三处版本号并保证一致：

1. `backend/app/config.py`：`app_version` / `app_parent_version`
2. 孩子端 `app/child_app/lib/config.dart`：`appVersion`
3. 家长端 `app/parent_app/lib/config.dart`：`appVersion`

重新编译 APK 并部署到 `frontend/dist/apk/` 后重启 backend 即可。
