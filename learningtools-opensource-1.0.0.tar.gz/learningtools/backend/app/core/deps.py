from datetime import datetime, timezone

import aiosqlite
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.config import settings
from app.core.rbac import Permission, has_permission
from app.core.security import decode_token
from app.database import get_db  # noqa: F401  向后兼容的再导出
from app.redis_client import get_redis

bearer_scheme = HTTPBearer(auto_error=False)


def _is_locked(locked_until: str | None) -> bool:
    if not locked_until:
        return False
    try:
        lock_time = datetime.fromisoformat(locked_until)
        return lock_time > datetime.now(timezone.utc)
    except ValueError:
        return False


async def get_current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> dict:
    if creds is None:
        raise HTTPException(status_code=401, detail="未登录")
    try:
        payload = decode_token(creds.credentials)
    except Exception:
        raise HTTPException(status_code=401, detail="凭证无效或已过期")
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="凭证类型错误")

    user_id = payload.get("sub")
    try:
        user_id_int = int(user_id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=401, detail="凭证无效")

    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM users WHERE id = ?", (user_id_int,))
        row = await cur.fetchone()

    if row is None:
        raise HTTPException(status_code=401, detail="用户不存在")
    user = dict(row)
    if user["status"] != "active":
        raise HTTPException(status_code=403, detail="账号未激活或被禁用")

    # 单设备登录：孩子账号的 token 携带 sid，与 Redis 当前会话不一致即被踢下线
    if user["role"] == "child" and payload.get("sid"):
        r = get_redis()
        current = await r.get(f"child_sid:{user_id_int}")
        if current != payload["sid"]:
            raise HTTPException(status_code=401, detail="已在其他设备登录，请重新登录")
    return user


def require_permission(permission: Permission):
    async def dependency(current_user: dict = Depends(get_current_user)) -> dict:
        if not has_permission(current_user["role"], permission):
            raise HTTPException(status_code=403, detail="权限不足")
        return current_user

    return dependency


def require_role(*roles: str):
    """要求当前用户属于给定角色之一。"""

    async def dependency(current_user: dict = Depends(get_current_user)) -> dict:
        if current_user["role"] not in roles:
            raise HTTPException(status_code=403, detail="权限不足")
        return current_user

    return dependency


async def get_child(child_id: str, current_user: dict, db) -> dict:
    """校验当前用户对孩子档案的访问权限，返回孩子记录。"""
    cur = await db.execute("SELECT * FROM children WHERE id = ?", (child_id,))
    row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="孩子不存在")
    child = dict(row)

    role = current_user["role"]
    if role in ("super_admin", "family_admin"):
        return child
    if role == "parent":
        parent_ids = [p for p in (child.get("parent_ids") or "").split(",") if p]
        if str(current_user["id"]) in parent_ids:
            return child
        # 同家庭家长（爸爸/妈妈）共享孩子数据
        if current_user.get("family_id") and child.get("family_id") == current_user["family_id"]:
            return child
        raise HTTPException(status_code=403, detail="无权限访问该孩子")
    if role == "child":
        if child.get("user_id") == current_user["id"]:
            return child
        raise HTTPException(status_code=403, detail="无权限访问")
    raise HTTPException(status_code=403, detail="无权限访问")


async def list_accessible_children(current_user: dict, db) -> list:
    """返回当前用户可见的孩子列表。"""
    role = current_user["role"]
    if role in ("super_admin", "family_admin"):
        sql = "SELECT * FROM children ORDER BY created_at"
        params: tuple = ()
    elif role == "parent":
        sql = "SELECT * FROM children ORDER BY created_at"
        params = ()
    else:  # child
        sql = "SELECT * FROM children WHERE user_id = ?"
        params = (current_user["id"],)

    cur = await db.execute(sql, params)
    rows = await cur.fetchall()
    children = [dict(r) for r in rows]

    if role == "parent":
        children = [
            c
            for c in children
            if str(current_user["id"]) in [p for p in (c.get("parent_ids") or "").split(",") if p]
            or (current_user.get("family_id") and c.get("family_id") == current_user["family_id"])
        ]
    return children


async def get_my_child_id(current_user: dict, db) -> str | None:
    """孩子账号 → 其关联的孩子档案 id。"""
    if current_user["role"] != "child":
        return None
    cur = await db.execute("SELECT id FROM children WHERE user_id = ?", (current_user["id"],))
    row = await cur.fetchone()
    return row["id"] if row else None
