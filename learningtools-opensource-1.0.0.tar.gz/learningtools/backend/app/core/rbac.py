from enum import Enum


class Permission(str, Enum):
    SYSTEM_CONFIG = "system:config"
    ACCOUNT_APPROVE = "account:approve"
    QUOTA_MANAGE = "quota:manage"
    CHILD_EDIT = "child:edit"
    PLAN_EDIT = "plan:edit"
    CHECKIN_REVIEW = "checkin:review"
    FOCUS_MONITOR = "focus:monitor"
    PHOTO_VIEW = "photo:view"
    PHOTO_MANAGE = "photo:manage"
    ALERT_CONFIG = "alert:config"
    DATA_EXPORT = "data:export"
    TASK_VIEW = "task:view"
    CHECKIN_EXECUTE = "checkin:execute"
    FOCUS_ENTER = "focus:enter"
    REPORT_VIEW = "report:view"


ROLE_PERMISSIONS: dict[str, set[Permission]] = {
    "super_admin": set(Permission),
    "family_admin": {
        Permission.ACCOUNT_APPROVE,
        Permission.QUOTA_MANAGE,
        Permission.CHILD_EDIT,
        Permission.PLAN_EDIT,
        Permission.CHECKIN_REVIEW,
        Permission.FOCUS_MONITOR,
        Permission.PHOTO_VIEW,
        Permission.PHOTO_MANAGE,
        Permission.ALERT_CONFIG,
        Permission.DATA_EXPORT,
        Permission.TASK_VIEW,
        Permission.REPORT_VIEW,
    },
    "parent": {
        Permission.CHILD_EDIT,
        Permission.PLAN_EDIT,
        Permission.CHECKIN_REVIEW,
        Permission.FOCUS_MONITOR,
        Permission.PHOTO_VIEW,
        Permission.ALERT_CONFIG,
        Permission.TASK_VIEW,
        Permission.REPORT_VIEW,
    },
    "child": {
        Permission.TASK_VIEW,
        Permission.CHECKIN_EXECUTE,
        Permission.FOCUS_ENTER,
        Permission.REPORT_VIEW,
    },
    "guest": {Permission.REPORT_VIEW},
}


def has_permission(role: str, permission: Permission) -> bool:
    return permission in ROLE_PERMISSIONS.get(role, set())
