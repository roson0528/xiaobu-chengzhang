from datetime import datetime, timedelta

import aiosqlite

from app.config import settings
from app.services.webdav_service import webdav_service


class CleanupTask:
    async def run_daily(self) -> dict:
        """清理超过保留期的专注照片/视频。"""
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT id, photo_retention_days, video_retention_days FROM children")
            children = [dict(r) for r in await cur.fetchall()]

        deleted = 0
        for child in children:
            cid = child["id"]
            photo_days = child.get("photo_retention_days") or settings.default_photo_retention_days
            video_days = child.get("video_retention_days") or settings.default_video_retention_days
            audio_days = settings.default_audio_retention_days

            for kind, days in (("focus", photo_days), ("videos", video_days)):
                base = f"{cid}/{kind}"
                try:
                    items = await webdav_service.list_files(base)
                except Exception:
                    continue
                for item in items:
                    if not isinstance(item, str):
                        continue
                    name = item.rstrip("/")
                    try:
                        d = datetime.strptime(name, "%Y-%m-%d")
                    except ValueError:
                        continue
                    if d < datetime.now() - timedelta(days=days):
                        await webdav_service.delete(f"{base}/{name}")
                        deleted += 1

            # 朗读打卡录音：文件名为 YYYYmmdd_HHMMSS.m4a，按日期清理
            audio_base = f"{cid}/checkins/audio"
            try:
                items = await webdav_service.list_files(audio_base)
            except Exception:
                items = []
            for item in items:
                if not isinstance(item, str):
                    continue
                name = item.rstrip("/")
                try:
                    d = datetime.strptime(name[:8], "%Y%m%d")
                except ValueError:
                    continue
                if d < datetime.now() - timedelta(days=audio_days):
                    await webdav_service.delete(f"{audio_base}/{name}")
                    deleted += 1
        return {"deleted": deleted}


cleanup_task = CleanupTask()
