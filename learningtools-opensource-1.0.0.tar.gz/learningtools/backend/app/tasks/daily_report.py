from datetime import datetime

import aiosqlite

from app.config import settings
from app.services.report_service import report_service
from app.services.serverchan import serverchan
from app.services.webdav_service import webdav_service


class DailyReportTask:
    async def run_daily(self) -> dict:
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT id, name FROM children")
            children = [dict(r) for r in await cur.fetchall()]

        now = datetime.now()
        today = now.strftime("%Y-%m-%d")
        iso = now.isocalendar()
        week = f"{iso.year}-W{iso.week:02d}"
        sent = 0
        weekly_generated = 0

        # 周日（ISO 周一~周日）21:00 生成本周周报，供孩子端「本周成长回顾」使用。
        is_sunday = now.isoweekday() == 7

        for child in children:
            cid = child["id"]
            plan = await webdav_service.read_json(f"{cid}/plans/weekly_{week}.json", {"tasks": []})
            today_tasks = [t for t in plan.get("tasks", []) if t.get("planned_date") == today]
            completed = sum(1 for t in today_tasks if t.get("status") == "completed")
            study_minutes = sum(
                t.get("planned_duration", 0) or 0 for t in today_tasks if t.get("status") == "completed"
            )
            report = {
                "total": len(today_tasks),
                "completed": completed,
                "study_minutes": study_minutes,
                "fitness_minutes": 0,
                "focus_sessions": 0,
            }
            if serverchan.enabled:
                await serverchan.notify_daily_report(child["name"], report)
                sent += 1
            if is_sunday:
                try:
                    await report_service.generate_weekly_report(cid, week)
                    weekly_generated += 1
                except Exception:
                    # 单个孩子周报生成失败不阻断整体
                    continue
        return {"sent": sent, "weekly_generated": weekly_generated}


daily_report_task = DailyReportTask()
