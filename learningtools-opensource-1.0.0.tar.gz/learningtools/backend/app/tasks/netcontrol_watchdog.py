"""上网管控代理看门狗：路由器代理「哑火」时主动推送告警。

背景（2026-10-04 实际事故）：WebDAV 一次瞬时读失败，后端把
``system/netcontrol.json`` 误判为「不存在」并重建，连带换掉了路由器令牌；
路由器手里还是旧令牌 → ``/policy`` 持续 403 → 管控策略冻结在旧缓存上，
整整三天没有任何人发现 —— 孩子专注模式里需要联网的任务全都上不了网。

根因已在 ``netcontrol_service._load`` 堵住（读失败不再重建、不再换令牌）。
本看门狗是第二层兜底：只要代理安静超过阈值就推微信告警，「坏了也要响」。
"""

import asyncio
import logging
import time

from app.redis_client import get_redis
from app.services.netcontrol_service import AGENT_ALERT_SECONDS, netcontrol_service
from app.services.serverchan import serverchan

logger = logging.getLogger(__name__)

CHECK_INTERVAL = 300                 # 每 5 分钟检查一次
ALERT_THROTTLE_SECONDS = 6 * 3600    # 同一问题最多 6 小时提醒一次


async def _alert(silence: int, token_error: bool) -> None:
    """推送一次告警（Redis 节流，跨进程共享）。"""
    r = get_redis()
    key = "throttle:netcontrol_agent_down"
    if not await r.set(key, "1", nx=True, ex=ALERT_THROTTLE_SECONDS):
        return
    minutes = silence // 60
    reason = (
        "路由器代理携带的令牌与后端不一致（多半是配置被重建或改过令牌）"
        if token_error
        else "路由器代理已停止拉取策略"
    )
    content = (
        f"## 上网管控可能已失效\n\n"
        f"**原因**: {reason}\n\n"
        f"**已失联**: 约 {minutes} 分钟\n\n"
        f"**影响**: 路由器会冻结在最后一次拿到的策略上；"
        f"孩子端「需要联网」的专注模式/任务可能上不了网。\n\n"
        f"**自查**: 在路由器上执行 `cat /etc/lt-netctl.token`，"
        f"与家长端「网络管控」页显示的令牌对比，不一致则用"
        f"`printf '%s' '<新令牌>' > /etc/lt-netctl.token` 覆盖后执行一次 `/usr/bin/lt-netctl`。\n"
    )
    result = await serverchan.send_notification(title="⚠️ 上网管控代理失联", content=content)
    logger.warning("netcontrol 代理失联 %s 分钟，已告警: %s", minutes, result)


async def run_forever() -> None:
    """常驻循环（由 main.py 的 lifespan 启动）。"""
    logger.info("netcontrol 看门狗已启动：每 %s 秒检查一次", CHECK_INTERVAL)
    while True:
        try:
            await asyncio.sleep(CHECK_INTERVAL)
            silence = int(netcontrol_service.agent_silence_seconds())
            if silence < AGENT_ALERT_SECONDS:
                continue
            status = netcontrol_service.agent_status()
            logger.warning(
                "netcontrol 代理已安静 %s 秒（token_error=%s）", silence, status["token_error"]
            )
            await _alert(silence, bool(status["token_error"]))
        except asyncio.CancelledError:
            logger.info("netcontrol 看门狗停止")
            raise
        except Exception:
            logger.exception("netcontrol 看门狗本轮检查失败")
            # 避免异常导致循环退出后整个任务静默消失
            await asyncio.sleep(60)


def start() -> asyncio.Task:
    return asyncio.create_task(run_forever(), name="netcontrol-watchdog")
