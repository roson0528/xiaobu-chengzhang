import asyncio
import logging

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from app.database import init_db
from app.tasks.backup import backup_task
from app.tasks.checkin_auto_approve import checkin_auto_approve_task
from app.tasks.cleanup import cleanup_task
from app.tasks.daily_report import daily_report_task
from app.tasks.penalty import penalty_task

# 关键：主机（PVE 虚拟机）夜里可能被挂起/备份/关机，定时任务会整体错过。
# APScheduler 默认 misfire_grace_time 只有 1 秒，醒来后判定「迟到太久」直接丢弃，
# 而且只在日志里留一句 was missed by —— 惩罚任务因此静默失效了两周多。
# 这里给所有任务放宽迟到容忍并开启合并执行：醒来后补跑一次，绝不静默丢弃。
MISFIRE_GRACE_SECONDS = 6 * 3600


def _setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    # httpx 每次 WebDAV 请求都打一条 INFO，调度器日志会被淹没
    logging.getLogger("httpx").setLevel(logging.WARNING)


async def main() -> None:
    _setup_logging()
    logger = logging.getLogger("learningtools.scheduler")
    await init_db()
    scheduler = AsyncIOScheduler(timezone="your-tz")
    jobs = [
        (cleanup_task.run_daily, CronTrigger(hour=2, minute=0), "cleanup"),
        (daily_report_task.run_daily, CronTrigger(hour=21, minute=0), "daily_report"),
        (backup_task.run_weekly, CronTrigger(day_of_week="sun", hour=3, minute=0), "backup"),
        (checkin_auto_approve_task.run, IntervalTrigger(minutes=30), "checkin_auto_approve"),
        (penalty_task.run_daily, CronTrigger(hour=0, minute=30), "penalty"),
    ]
    for func, trigger, job_id in jobs:
        scheduler.add_job(
            func,
            trigger,
            id=job_id,
            replace_existing=True,
            misfire_grace_time=MISFIRE_GRACE_SECONDS,
            coalesce=True,          # 错过多次只补跑一次
        )
    scheduler.start()
    logger.info("调度器已启动：%s 个任务（迟到容忍 %s 小时）", len(jobs), MISFIRE_GRACE_SECONDS // 3600)
    try:
        while True:
            await asyncio.sleep(3600)
    except (KeyboardInterrupt, asyncio.CancelledError):
        scheduler.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
