from datetime import datetime, timedelta

import aiosqlite

from app.config import settings
from app.routers.checkins import _award_approved_checkins
from app.services.webdav_service import webdav_service


class CheckinAutoApproveTask:
    """超时未审核的打卡自动通过（可配置：settings.checkin_auto_approve_hours，0 表示关闭）。"""

    @staticmethod
    def _older_than(record: dict, threshold: datetime) -> bool:
        try:
            return datetime.fromisoformat(record.get("created_at", "")) < threshold
        except Exception:
            return False

    async def run(self) -> dict:
        hours = settings.checkin_auto_approve_hours
        if hours <= 0:
            return {"auto_approved": 0, "disabled": True}

        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT id FROM children")
            children = [dict(r) for r in await cur.fetchall()]

        month = datetime.now().strftime("%Y-%m")
        threshold = datetime.now() - timedelta(hours=hours)
        total = 0

        for child in children:
            cid = child["id"]
            data = await webdav_service.read_json(f"{cid}/checkins/{month}.json", {"records": []})
            pending = [
                r for r in data.get("records", [])
                if r.get("status") == "pending" and self._older_than(r, threshold)
            ]
            if not pending:
                continue
            ids = {r.get("id") for r in pending}

            def _mutate(d: dict) -> dict:
                for r in d.get("records", []):
                    if r.get("id") in ids:
                        r["status"] = "approved"
                        r["review_comment"] = "超时未审核，自动通过"
                        r["auto_approved"] = True
                return d

            await webdav_service.mutate_json(f"{cid}/checkins/{month}.json", _mutate, {"records": []})
            # 超时自动通过同样奖励积分（与家长手动审核通过一致）
            await _award_approved_checkins(cid, month, list(ids))
            total += len(ids)

        return {"auto_approved": total}


checkin_auto_approve_task = CheckinAutoApproveTask()
