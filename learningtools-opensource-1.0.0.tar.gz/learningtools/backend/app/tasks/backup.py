from app.services.backup_service import backup_service


class BackupTask:
    async def run_weekly(self) -> dict:
        return await backup_service.create_backup()


backup_task = BackupTask()
