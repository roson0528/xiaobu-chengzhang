import logging
from datetime import date, timedelta

import aiosqlite

from app.config import settings
from app.routers.tasks import _weekly_files
from app.services import holiday as holiday_util
from app.services.reward_service import reward_service
from app.services.settings_service import get_setting, set_setting
from app.services.webdav_service import webdav_service

logger = logging.getLogger(__name__)


def _weekday_of(day_str: str) -> int:
    try:
        y, m, d = map(int, day_str.split("-"))
        return date(y, m, d).isoweekday()
    except Exception:
        return 0


def _task_due_on(task: dict, day: str) -> bool:
    """任务在指定日期是否该判定扣分。

    * **假期作业/任务**：只在**假期最后一天**判定一次 —— 假期里任意一天提交都算按时，
      所以整个假期期间都不该扣分；假期结束还没交，才会在最后一天被判为未完成。
    * 其余任务：按 repeat 展开（skip/defer 不影响惩罚判断）。
    """
    holiday_end = holiday_util.holiday_end(task)
    if holiday_end is not None:
        return day == holiday_end
    repeat = task.get("repeat")
    if not isinstance(repeat, dict):
        repeat = {}
    rtype = repeat.get("type") or "none"
    if rtype == "daily":
        return True
    if rtype == "weekly":
        days = repeat.get("days") or []
        return _weekday_of(day) in days
    return task.get("planned_date") == day


def _task_satisfied(task: dict, day: str) -> bool:
    """任务是否在指定日期真正完成（完成且未被驳回）。"""
    if task.get("status") != "completed":
        return False
    if task.get("review_status") == "rejected":
        return False
    completed_at = task.get("completed_at") or ""
    if not completed_at:
        return True  # 老数据缺 completed_at，按已完成算
    # 假期作业：假期里可能分好几天交，只要「有任意一天是在假期内提交的」就算按时
    if holiday_util.is_holiday(task):
        start, end = holiday_util.holiday_start(task), holiday_util.holiday_end(task)
        if not (start and end):
            return False
        days = holiday_util.submission_days(task) or [str(completed_at)[:10]]
        return any(start <= d <= end for d in days if d)
    return completed_at.startswith(day)


def _preset_matches_date(preset: dict, day: str) -> bool:
    repeat = preset.get("repeat")
    if not isinstance(repeat, dict):
        repeat = {}
    rtype = repeat.get("type") or "none"
    if rtype == "weekly":
        days = repeat.get("days") or []
        return _weekday_of(day) in days
    return True  # none / daily


class PenaltyTask:
    """超时未完成任务/打卡惩罚：每天凌晨补算「上次算到哪天」之后的每一天。

    为什么要补算：主机（PVE 虚拟机）夜里可能被挂起/备份，00:30 的任务会整体错过；
    APScheduler 默认只容忍极短的迟到，错过一次就直接丢弃，而且**没有任何提示**。
    2026-09-21 起连续两周多没扣分就是这么来的（日志里全是 "was missed by"）。

    这里改成按水位线（app_settings.penalty_last_date）补算：错过几天就补几天，
    上限 CATCHUP_DAYS 天；重复执行是安全的，因为每天是否已扣由任务上的
    ``penalty_applied_dates`` 去重。
    """

    CATCHUP_DAYS = 7
    WATERMARK_KEY = "penalty_last_date"

    async def run_daily(self, dry_run: bool = False, since: str | None = None) -> dict:
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT id FROM children")
            children = [dict(r) for r in await cur.fetchall()]

        today = date.today()
        yesterday = today - timedelta(days=1)
        earliest = today - timedelta(days=self.CATCHUP_DAYS)

        last = await get_setting(self.WATERMARK_KEY, "")
        try:
            start = date.fromisoformat(last) + timedelta(days=1)
        except Exception:
            # 首次运行（或水位线损坏）：只算昨天，不追历史
            start = yesterday
        if since:
            # 手动补算：显式指定起点（后台/运维用）
            try:
                start = date.fromisoformat(since)
            except Exception:
                pass
        if start < earliest:
            start = earliest
        if start > yesterday:
            logger.info("penalty: 无需补算（水位线 %s）", last or "-")
            return {
                "target": yesterday.isoformat(),
                "days": [],
                "task_penalties": 0,
                "checkin_penalties": 0,
                "dry_run": dry_run,
            }

        days: list[date] = []
        cursor = start
        while cursor <= yesterday:
            days.append(cursor)
            cursor += timedelta(days=1)

        task_penalties = 0
        checkin_penalties = 0
        details: list[dict] = []
        for day in days:
            iso = day.isocalendar()
            week = f"{iso.year}-W{iso.week:02d}"
            for child in children:
                cid = child["id"]
                tp, cp = await self._process_child(cid, day.isoformat(), week, dry_run=dry_run)
                task_penalties += tp
                checkin_penalties += cp
                if tp or cp:
                    details.append({"day": day.isoformat(), "child": cid, "task": tp, "checkin": cp})

        if not dry_run:
            # 只有真正落库后才推进水位线，中途异常下次还能重来
            await set_setting(self.WATERMARK_KEY, yesterday.isoformat())

        result = {
            "target": yesterday.isoformat(),
            "days": [d.isoformat() for d in days],
            "task_penalties": task_penalties,
            "checkin_penalties": checkin_penalties,
            "details": details,
            "dry_run": dry_run,
        }
        logger.warning("penalty 执行完毕: %s", result)
        return result

    async def _process_child(
        self, cid: str, target: str, week: str, dry_run: bool = False
    ) -> tuple[int, int]:
        task_penalties = 0
        checkin_penalties = 0

        # ---- 任务惩罚 ----
        # 循环任务（每天/每周）的**母记录留在创建那一周**的文件里，之后不再复制。
        # 所以只读「昨天所在周」会漏掉这些任务 —— 2026-09-21 起连续两周多没扣分，
        # 根因就在这里（昨天所在周的文件里根本没有这些任务）。必须扫描全部周文件。
        pairs: list[tuple[str, dict]] = []
        by_id: dict[str, dict] = {}
        for entry in await _weekly_files(cid):
            name = str(entry.get("name") or "")
            if not (name.startswith("weekly_") and name.endswith(".json")):
                continue
            w = name[len("weekly_"):-len(".json")]
            other = await webdav_service.read_json(entry.get("path") or "", {"tasks": []})
            for t in other.get("tasks", []):
                tid = t.get("id")
                if tid and tid not in by_id:
                    pairs.append((w, t))
                    by_id[tid] = t

        by_week: dict[str, list[str]] = {}
        for w, t in pairs:
            pp = t.get("penalty_points") or 0
            if pp <= 0 or not _task_due_on(t, target):
                continue
            if target in (t.get("penalty_applied_dates") or []):
                continue
            if _task_satisfied(t, target):
                continue
            by_week.setdefault(w, []).append(t.get("id"))

        for w, ids in by_week.items():
            def _mark(plan_data: dict, ids: list = ids) -> dict:
                for t in plan_data.get("tasks", []):
                    if t.get("id") in ids:
                        applied = t.setdefault("penalty_applied_dates", [])
                        if not isinstance(applied, list):
                            applied = []
                            t["penalty_applied_dates"] = applied
                        if target not in applied:
                            applied.append(target)
                return plan_data

            if dry_run:
                task_penalties += len(ids)
                continue
            await webdav_service.mutate_json(f"{cid}/plans/weekly_{w}.json", _mark, {"tasks": []})
            for tid in ids:
                pp = (by_id.get(tid) or {}).get("penalty_points") or 0
                await reward_service.award_points(cid, -pp, f"任务超时未完成扣分（{target}）")
                task_penalties += 1

        # ---- 打卡任务惩罚 ----
        presets_data = await webdav_service.read_json(f"{cid}/checkins/presets.json", {"items": []})
        presets = presets_data.get("items", [])
        month = target[:7]
        checkins = await webdav_service.read_json(f"{cid}/checkins/{month}.json", {"records": []})
        records = [r for r in checkins.get("records", []) if (r.get("created_at") or "").startswith(target)]

        penalized_preset_ids = []
        for p in presets:
            pp = p.get("penalty_points") or 0
            if pp <= 0 or not _preset_matches_date(p, target):
                continue
            if target in (p.get("penalty_applied_dates") or []):
                continue
            satisfied = any(
                r.get("preset_id") == p.get("id") and r.get("status") != "rejected"
                for r in records
            )
            if satisfied:
                continue
            penalized_preset_ids.append(p.get("id"))

        if penalized_preset_ids:
            if dry_run:
                checkin_penalties += len(penalized_preset_ids)
            else:
                def _mark_presets(data: dict) -> dict:
                    for p in data.get("items", []):
                        if p.get("id") in penalized_preset_ids:
                            applied = p.setdefault("penalty_applied_dates", [])
                            if not isinstance(applied, list):
                                applied = []
                                p["penalty_applied_dates"] = applied
                            if target not in applied:
                                applied.append(target)
                    return data

                await webdav_service.mutate_json(
                    f"{cid}/checkins/presets.json", _mark_presets, {"items": []}
                )
                for p in presets:
                    if p.get("id") in penalized_preset_ids:
                        pp = p.get("penalty_points") or 0
                        await reward_service.award_points(cid, -pp, f"打卡超时未完成扣分（{target}）")
                        checkin_penalties += 1

        return task_penalties, checkin_penalties


penalty_task = PenaltyTask()
