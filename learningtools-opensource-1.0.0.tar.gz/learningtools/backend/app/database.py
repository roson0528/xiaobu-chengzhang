import os
from datetime import datetime, timezone

import aiosqlite

from app.config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'parent',
    email TEXT,
    phone TEXT,
    status TEXT DEFAULT 'pending',
    family_id TEXT,
    nickname TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    last_login TEXT,
    failed_attempts INTEGER DEFAULT 0,
    locked_until TEXT,
    quota_gb INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS children (
    id TEXT PRIMARY KEY,
    user_id INTEGER,
    name TEXT NOT NULL,
    grade INTEGER,
    birthday TEXT,
    avatar TEXT,
    parent_ids TEXT,
    family_id TEXT,
    quota_mb INTEGER DEFAULT 2048,
    used_mb REAL DEFAULT 0,
    photo_retention_days INTEGER DEFAULT 30,
    video_retention_days INTEGER DEFAULT 15,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    actor TEXT,
    action TEXT,
    target TEXT,
    detail TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT,
    content TEXT,
    kind TEXT DEFAULT 'system',
    read INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT DEFAULT (datetime('now','localtime'))
);
"""


async def init_db() -> None:
    os.makedirs(os.path.dirname(settings.sqlite_path), exist_ok=True)
    async with aiosqlite.connect(settings.sqlite_path) as db:
        await db.executescript(SCHEMA)
        await db.commit()
        await _migrate(db)


async def _migrate(db) -> None:
    """轻量迁移：为已有库补充后加字段。"""

    async def _has_column(table: str, column: str) -> bool:
        cur = await db.execute(f"PRAGMA table_info({table})")
        rows = await cur.fetchall()
        # PRAGMA table_info 返回 (cid, name, type, notnull, dflt_value, pk)
        return any(r[1] == column for r in rows)

    if not await _has_column("users", "quota_gb"):
        await db.execute("ALTER TABLE users ADD COLUMN quota_gb INTEGER DEFAULT 0")
        await db.commit()

    if not await _has_column("users", "nickname"):
        await db.execute("ALTER TABLE users ADD COLUMN nickname TEXT")
        await db.commit()


async def get_db():
    db = await aiosqlite.connect(settings.sqlite_path)
    db.row_factory = aiosqlite.Row
    try:
        yield db
    finally:
        await db.close()


async def add_audit_log(actor: str, action: str, target: str = "", detail: str = "") -> None:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        await db.execute(
            "INSERT INTO audit_log (actor, action, target, detail) VALUES (?, ?, ?, ?)",
            (actor, action, target, detail),
        )
        await db.commit()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
