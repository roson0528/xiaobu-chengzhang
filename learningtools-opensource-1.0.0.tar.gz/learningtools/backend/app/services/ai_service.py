import base64
import os

import httpx


class AIService:
    """AI 辅助服务（OCR / ASR / 视觉分析），端点未配置时优雅跳过。"""

    def __init__(self):
        self.ocr_endpoint = os.environ.get("OCR_ENDPOINT", "")
        self.asr_endpoint = os.environ.get("ASR_ENDPOINT", "")
        self.vision_endpoint = os.environ.get("VISION_ENDPOINT", "")

    async def check_homework(self, image_path: str) -> dict:
        if not self.ocr_endpoint:
            return {"status": "skipped", "reason": "OCR 未配置"}
        with open(image_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.ocr_endpoint, json={"image": img_b64}, timeout=30
                )
                return resp.json()
        except Exception as e:
            return {"status": "error", "reason": str(e)}

    async def check_recitation(self, audio_path: str, expected_text: str) -> dict:
        if not self.asr_endpoint:
            return {"status": "skipped", "reason": "ASR 未配置"}
        with open(audio_path, "rb") as f:
            audio_b64 = base64.b64encode(f.read()).decode()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.asr_endpoint,
                    json={"audio": audio_b64, "expected": expected_text},
                    timeout=60,
                )
                return resp.json()
        except Exception as e:
            return {"status": "error", "reason": str(e)}

    async def analyze_focus_photo(self, image_path: str) -> dict:
        if not self.vision_endpoint:
            return {"status": "skipped", "reason": "视觉分析未配置"}
        with open(image_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    self.vision_endpoint, json={"image": img_b64}, timeout=30
                )
                return resp.json()
        except Exception as e:
            return {"status": "error", "reason": str(e)}


ai_service = AIService()
