"""上网管控服务。

家长可对指定设备（默认 MRX-W09 平板）设置上网放行策略，软路由上的轻量代理
（``/usr/bin/lt-netctl``，cron 每分钟执行）主动拉取本策略并落地为 nftables 规则。

设计要点：

* **默认限制**：设备默认只能访问「学习平台」（``pass_through``），其余出网流量丢弃。
* **两种临时放行**：专注模式（focus）与兑换奖励（reward），都写成一个带到期时间的
  *grant*，到期即失效，不依赖任何人工操作。
* **故障安全**：策略里除人类可读的 ``*_until`` 外，还返回 ``*_until_ts``（epoch 秒）
  与 ``server_ts``。路由器代理会把 ``server_ts - local_ts`` 作为时钟偏移缓存下来，
  即使后端不可达，也能用本地时间正确判定到期 —— 断网的是「放行」，不是「限制」。
* **纯增量**：路由侧只维护自己独立的 nft 表，不修改 timecontrol / firewall /
  passwall / openclash 等任何现有配置。
"""

from __future__ import annotations

import ipaddress
import logging
import re
import secrets
import time
from datetime import datetime, time as dtime, timedelta
from typing import Any

from fastapi import HTTPException

from app.services.webdav_service import WebDavReadError, webdav_service

logger = logging.getLogger(__name__)

POLICY_PATH = "system/netcontrol.json"

# 路由器代理的存活判定：代理 cron 每分钟拉一次策略
AGENT_STALE_SECONDS = 180         # 超过 3 分钟没拉到 → 视为异常
AGENT_ALERT_SECONDS = 900         # 超过 15 分钟 → 推送告警
_agent_last_seen: float | None = None      # 最近一次成功拉取策略的本地时间戳
_agent_last_token_error: float | None = None
_service_started_at = time.time()

# 管控模式
MODE_ENFORCE = "enforce"          # 默认：限制上网（仅放行学习平台）
MODE_ALLOW_ALL = "allow_all"      # 一键联网：完全放开
MODE_BLOCK_ALL = "block_all"      # 一键断网：完全断开（含学习平台）

MODE_LABELS = {
    MODE_ENFORCE: "正常管控",
    MODE_ALLOW_ALL: "一键联网",
    MODE_BLOCK_ALL: "一键断网",
}

# 授权来源
GRANT_FOCUS = "focus"
GRANT_REWARD = "reward"

# 专注模式的兜底上限：即使客户端一直有心跳，单次专注最多放行这么久
FOCUS_MAX_MINUTES = 90
# 专注模式无心跳容忍时间：APP 被杀后最多再放行这么久
FOCUS_HEARTBEAT_GRACE_MINUTES = 10


def _now() -> datetime:
    return datetime.now()


def _parse(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _ts(value: Any) -> int | None:
    dt = _parse(value)
    return int(dt.timestamp()) if dt else None


def _parse_hm(value: Any) -> dtime | None:
    """解析 "HH:MM"。"""
    try:
        hh, mm = str(value).strip().split(":")[:2]
        h, m = int(hh), int(mm)
        if 0 <= h <= 23 and 0 <= m <= 59:
            return dtime(hour=h, minute=m)
    except (TypeError, ValueError):
        pass
    return None


def _window_end(window: dict, now: datetime) -> datetime | None:
    """now 落在该时段内 → 返回时段结束时间；否则 None。

    支持跨夜时段（如 22:00–07:00）：该时段归属于 *开始那天* 的星期。
    星期采用 ISO 编号：周一=1 … 周日=7。
    """
    start = _parse_hm(window.get("start"))
    end = _parse_hm(window.get("end"))
    if start is None or end is None or start == end:
        return None
    days = {int(x) for x in (window.get("days") or []) if str(x).strip().isdigit()}
    days = {d for d in days if 1 <= d <= 7} or {1, 2, 3, 4, 5, 6, 7}
    t = now.time()
    today = now.isoweekday()
    yesterday = ((today - 2) % 7) + 1

    def _end_at(day_offset: int) -> datetime:
        return (now + timedelta(days=day_offset)).replace(
            hour=end.hour, minute=end.minute, second=0, microsecond=0
        )

    if start < end:
        # 同日时段
        if today in days and start <= t < end:
            return _end_at(0)
        return None
    # 跨夜时段
    if today in days and t >= start:
        return _end_at(1)
    if yesterday in days and t < end:
        return _end_at(0)
    return None


def _default_device() -> dict:
    return {
        "id": "mrx_w09",
        "name": "MRX-W09",
        "mac": "22:0D:8D:F9:8D:05",
        "ip": "YOUR_ROUTER_IP",
        "child_id": None,          # None = 任意孩子的授权都对该设备生效
        "enabled": True,
        "manual_mode": MODE_ENFORCE,
        "manual_until": None,      # 手动模式的到期时间，None = 永久有效
        "pass_through": [
            {"ip": "27.203.107.229", "port": 51666, "note": "学习平台"},
        ],
        "grants": [],
        # 时间段控制：窗口内放行，窗口外按 out_action 处理
        "schedule": {"enabled": False, "windows": [], "out_action": "restricted"},
    }


class NetControlService:
    # ---------- 存储 ----------

    async def _load(self) -> dict:
        try:
            data = await webdav_service.read_json_strict(POLICY_PATH)
        except WebDavReadError as e:
            # 读不到 ≠ 没配置。绝不能在这里重建文件：会连带换掉 token，
            # 而路由器手里还是旧 token → 403 失联 → 管控长期失效。
            # 直接报错，让路由器继续用本地缓存策略。
            logger.warning("netcontrol 配置读取失败，保留远端现状: %s", e)
            raise HTTPException(
                status_code=503, detail="管控配置暂时读取失败，请稍后重试"
            ) from e
        if data is None:
            # 确实不存在 → 首次初始化
            data = {"token": secrets.token_urlsafe(24), "devices": [_default_device()]}
            await webdav_service.safe_write_json(POLICY_PATH, data)
            return data
        fixed = False
        if not isinstance(data, dict) or "devices" not in data:
            # 文件损坏：保留原 token（否则路由器立刻失联），只补齐结构
            old_token = data.get("token") if isinstance(data, dict) else None
            data = {
                "token": old_token or secrets.token_urlsafe(24),
                "devices": [_default_device()],
            }
            fixed = True
        if not data.get("token"):
            data["token"] = secrets.token_urlsafe(24)
            fixed = True
        if not data.get("devices"):
            data["devices"] = [_default_device()]
            fixed = True
        if fixed:
            await webdav_service.safe_write_json(POLICY_PATH, data)
        return data

    async def _mutate(self, fn) -> dict:
        def _apply(data: Any) -> Any:
            if not isinstance(data, dict) or "devices" not in data:
                old_token = data.get("token") if isinstance(data, dict) else None
                data = {
                    "token": old_token or secrets.token_urlsafe(24),
                    "devices": [_default_device()],
                }
            if not data.get("token"):
                data["token"] = secrets.token_urlsafe(24)
            if not data.get("devices"):
                data["devices"] = [_default_device()]
            fn(data)
            data["updated_at"] = _now().isoformat()
            return data

        try:
            return await webdav_service.mutate_json(
                POLICY_PATH,
                _apply,
                {"token": secrets.token_urlsafe(24), "devices": [_default_device()]},
                strict=True,      # 读失败就别写：宁可这次操作失败，也不能覆盖远端配置
            )
        except WebDavReadError as e:
            logger.warning("netcontrol 配置读取失败，本次修改未生效: %s", e)
            raise HTTPException(
                status_code=503, detail="管控配置暂时读取失败，请稍后重试"
            ) from e

    async def get_token(self) -> str:
        return (await self._load()).get("token") or ""

    # ---------- 路由器代理存活 ----------

    def note_agent_poll(self) -> None:
        """代理成功拉取策略时调用（内存态，重启后重新计时即可）。"""
        global _agent_last_seen
        _agent_last_seen = time.time()

    def note_agent_token_error(self) -> None:
        """代理拿着错误 token 来拉策略（多半是两边不同步）。"""
        global _agent_last_token_error
        _agent_last_token_error = time.time()

    def agent_status(self, token_error: bool = False) -> dict:
        now = time.time()
        age = None if _agent_last_seen is None else int(now - _agent_last_seen)
        return {
            "last_seen_at": (
                datetime.fromtimestamp(_agent_last_seen).isoformat()
                if _agent_last_seen
                else None
            ),
            "age_seconds": age,
            "online": age is not None and age <= AGENT_STALE_SECONDS,
            "token_error": token_error
            or (
                _agent_last_token_error is not None
                and (_agent_last_seen is None or _agent_last_token_error > _agent_last_seen)
            ),
            "stale_seconds_threshold": AGENT_STALE_SECONDS,
        }

    def agent_silence_seconds(self) -> float:
        """代理「安静」了多久：以最近一次成功拉取为准，从未拉过则从服务启动算起。"""
        return time.time() - (_agent_last_seen or _service_started_at)

    async def effective_for_child(self, child_id: str) -> dict:
        """某孩子当前真正生效的管控策略（按设备绑定关系匹配）。

        用于判定「孩子开着需要联网的任务、但设备被一键断网挡住」这类静默故障。
        """
        data = await self._load()
        now = _now()
        for d in data.get("devices") or []:
            if not d.get("enabled", True):
                continue
            bound = d.get("child_id")
            if bound in (None, "", child_id):
                return {
                    "device_id": d.get("id"),
                    "device_name": d.get("name"),
                    **self.effective(d, now),
                }
        return {
            "device_id": None,
            "device_name": None,
            "action": "allow",
            "mode": MODE_ENFORCE,
            "enabled": False,
            "reason": "无绑定设备",
        }

    # ---------- 查询 ----------

    def _find(self, data: dict, device_id: str | None) -> dict | None:
        devices = data.get("devices") or []
        if not device_id:
            return devices[0] if devices else None
        for d in devices:
            if d.get("id") == device_id:
                return d
        return None

    @staticmethod
    def _live_grants(device: dict, now: datetime) -> list[dict]:
        alive = []
        for g in device.get("grants") or []:
            until = _parse(g.get("until"))
            if until and until > now:
                alive.append(g)
        return alive

    def effective(self, device: dict, now: datetime | None = None) -> dict:
        """算出设备当前真正生效的策略。"""
        now = now or _now()
        if not device:
            return {
                "action": "allow",
                "mode": MODE_ENFORCE,
                "enabled": False,
                "allow_until": None,
                "allow_until_ts": None,
                "grants": [],
                "reason": "无设备配置",
            }

        mode = device.get("manual_mode") or MODE_ENFORCE
        manual_until = _parse(device.get("manual_until"))
        if manual_until and manual_until <= now:
            # 限时的手动模式已到期，自动回落到正常管控
            mode = MODE_ENFORCE
            manual_until = None

        live = self._live_grants(device, now)
        allow_until = max((_parse(g.get("until")) for g in live), default=None)

        # 时间段控制：窗口内放行、窗口外限制（可配置为断网）
        schedule = device.get("schedule") or {}
        sched_on = bool(schedule.get("enabled")) and bool(schedule.get("windows"))
        win_end: datetime | None = None
        win_label = ""
        if sched_on:
            for w in schedule.get("windows") or []:
                e = _window_end(w, now)
                if e and (win_end is None or e > win_end):
                    win_end = e
                    win_label = f"{w.get('start')}–{w.get('end')}"

        if not device.get("enabled", True):
            action = "allow"
            reason = "管控已停用"
        elif mode == MODE_BLOCK_ALL:
            action = "block"
            reason = "一键断网"
        elif mode == MODE_ALLOW_ALL:
            action = "allow"
            reason = "一键联网"
        elif sched_on and win_end:
            action = "allow"
            reason = f"时段放行 {win_label}"
            # 放行截止时间 = 时段结束点：路由器据此本地计时，
            # 即使后端失联，到点也会自动收回（与专注/奖励同一套机制）。
            allow_until = win_end
        elif sched_on:
            if (schedule.get("out_action") or "restricted") == "block":
                action = "block"
                reason = "时段外断网"
            else:
                action = "restricted"
                reason = "时段外限制"
        elif allow_until and allow_until > now:
            action = "allow"
            reason = "、".join(g.get("note") or g.get("source") or "临时放行" for g in live)
        else:
            action = "restricted"
            reason = "默认限制"

        return {
            "action": action,
            "mode": mode,
            "enabled": bool(device.get("enabled", True)),
            "manual_until": manual_until.isoformat() if manual_until else None,
            "manual_until_ts": int(manual_until.timestamp()) if manual_until else None,
            "allow_until": allow_until.isoformat() if allow_until else None,
            "allow_until_ts": int(allow_until.timestamp()) if allow_until else None,
            "grants": [
                {
                    "source": g.get("source"),
                    "note": g.get("note"),
                    "until": g.get("until"),
                    "until_ts": _ts(g.get("until")),
                }
                for g in live
            ],
            "reason": reason,
        }

    async def state(self, device_id: str | None = None) -> dict:
        """家长端读取：设备列表 + 选中设备的生效策略 + 路由器代理存活状态。"""
        data = await self._load()
        device = self._find(data, device_id)
        now = _now()
        return {
            "server_time": now.isoformat(),
            "device": device,
            "effective": self.effective(device or {}, now),
            # 多设备：家长端据此做设备切换（支持任意 IP）
            "devices": [
                {**d, "effective": self.effective(d, now)}
                for d in (data.get("devices") or [])
            ],
            "modes": [{"value": k, "label": v} for k, v in MODE_LABELS.items()],
            # 代理是否还在正常拉策略：家长端据此提示「路由器可能未同步」
            "agent": self.agent_status(),
        }

    async def agent_policy(self) -> dict:
        """软路由代理拉取：只包含执行管控所需的最小信息。

        除了人类可读的 ISO 时间，还给出 epoch 秒与 ``mode_until_ts``，
        让路由器代理在**后端不可达**时也能用本地时间正确判定到期。
        ``pass_rules`` 是预格式化好的 ``ip port`` 文本，便于 shell 侧直接拼 nft 规则。
        """
        data = await self._load()
        now = _now()
        devices = []
        for d in data.get("devices") or []:
            eff = self.effective(d, now)
            pass_rules = []
            for p in d.get("pass_through") or []:
                ip = str(p.get("ip") or "").strip()
                if not ip:
                    continue
                port = p.get("port")
                pass_rules.append(f"{ip} {int(port)}" if port else ip)
            devices.append(
                {
                    "id": d.get("id"),
                    "name": d.get("name"),
                    "mac": (d.get("mac") or "").lower(),
                    "ip": d.get("ip"),
                    "enabled": eff["enabled"],
                    "action": eff["action"],
                    "mode": eff["mode"],
                    "mode_until_ts": eff.get("manual_until_ts") or 0,
                    "allow_until": eff["allow_until"],
                    "allow_until_ts": eff["allow_until_ts"] or 0,
                    "pass_through": d.get("pass_through") or [],
                    "pass_rules": pass_rules,
                }
            )
        return {
            "server_time": now.isoformat(),
            "server_ts": int(now.timestamp()),
            "count": len(devices),
            "devices": devices,
        }

    # ---------- 写入 ----------

    async def set_mode(
        self,
        mode: str,
        device_id: str | None = None,
        minutes: int | None = None,
    ) -> dict:
        if mode not in MODE_LABELS:
            raise ValueError(f"未知模式: {mode}")
        until = None
        if minutes and minutes > 0:
            until = (_now() + timedelta(minutes=minutes)).isoformat()

        def _apply(data: dict) -> None:
            device = self._find(data, device_id)
            if not device:
                raise ValueError("设备不存在")
            device["manual_mode"] = mode
            device["manual_until"] = until
            if mode == MODE_ENFORCE:
                # 恢复管控时清掉手动覆盖
                device["manual_until"] = None

        await self._mutate(_apply)
        return await self.state(device_id)

    async def set_device(
        self,
        device_id: str | None = None,
        child_id: Any = ...,
        enabled: bool | None = None,
        name: str | None = None,
        ip: str | None = None,
        mac: str | None = None,
    ) -> dict:
        def _apply(data: dict) -> None:
            device = self._find(data, device_id)
            if not device:
                raise ValueError("设备不存在")
            if child_id is not ...:
                device["child_id"] = child_id or None
            if enabled is not None:
                device["enabled"] = bool(enabled)
            if name:
                device["name"] = name
            if ip:
                device["ip"] = ip
            if mac:
                device["mac"] = mac.upper()

        await self._mutate(_apply)
        return await self.state(device_id)

    async def add_grant(
        self,
        source: str,
        minutes: int,
        device_id: str | None = None,
        child_id: str | None = None,
        note: str = "",
        cap_minutes: int | None = None,
    ) -> dict | None:
        """给设备增加/续期一个临时放行窗口。

        ``source`` 相同的授权会被覆盖（滚动续期）；``cap_minutes`` 用于限制单次
        授权相对「首次创建时间」的总时长上限（专注模式的 90 分钟兜底）。
        """
        if minutes <= 0:
            return None

        def _apply(data: dict) -> None:
            device = self._find(data, device_id)
            if not device:
                return
            bound = device.get("child_id")
            if bound and child_id and bound != child_id:
                # 设备已绑定到别的孩子，忽略该孩子的授权
                return
            now = _now()
            new_until = now + timedelta(minutes=minutes)
            grants = [
                g
                for g in (device.get("grants") or [])
                if g.get("source") != source
            ]
            prev = next(
                (g for g in (device.get("grants") or []) if g.get("source") == source),
                None,
            )
            if cap_minutes and prev:
                started = _parse(prev.get("started_at")) or now
                new_until = min(new_until, started + timedelta(minutes=cap_minutes))
            grants.append(
                {
                    "source": source,
                    "note": note,
                    "started_at": (prev or {}).get("started_at") or now.isoformat(),
                    "until": new_until.isoformat(),
                }
            )
            device["grants"] = grants

        await self._mutate(_apply)
        return await self.state(device_id)

    async def clear_grant(
        self, source: str, device_id: str | None = None, child_id: str | None = None
    ) -> dict | None:
        def _apply(data: dict) -> None:
            device = self._find(data, device_id)
            if not device:
                return
            bound = device.get("child_id")
            if bound and child_id and bound != child_id:
                return
            device["grants"] = [
                g for g in (device.get("grants") or []) if g.get("source") != source
            ]

        await self._mutate(_apply)
        return await self.state(device_id)

    async def add_device(self, ip: str, name: str = "", mac: str = "") -> dict:
        """新增一台受管控设备（按 IP 识别，MAC 选填）。

        `lnetctl` 代理优先用 MAC 匹配，MAC 为空时退化为按 IP 匹配，
        所以**任意 IP 都能直接纳入管控**，不需要先拿到设备的 MAC。
        """
        raw_ip = (ip or "").strip()
        try:
            addr = ipaddress.ip_address(raw_ip)
        except ValueError as e:
            raise ValueError("IP 格式不正确") from e
        if addr.version != 4:
            raise ValueError("目前只支持 IPv4 地址")
        ip_text = str(addr)
        mac_text = (mac or "").strip().upper()
        if mac_text and not re.fullmatch(r"([0-9A-F]{2}:){5}[0-9A-F]{2}", mac_text):
            raise ValueError("MAC 格式不正确，形如 22:0D:8D:F9:8D:05")
        new_id = "dev_" + ip_text.replace(".", "_")
        chosen = {"id": new_id}

        def _apply(data: dict) -> None:
            devices = data.setdefault("devices", [])
            for d in devices:
                if (d.get("ip") or "").strip() == ip_text:
                    raise ValueError("这个 IP 已经在管控列表里了")
                if mac_text and (d.get("mac") or "").strip().upper() == mac_text:
                    raise ValueError("这个 MAC 已经在管控列表里了")
            if any(d.get("id") == new_id for d in devices):
                new_id_ = f"{new_id}_{len(devices)}"
            else:
                new_id_ = new_id
            chosen["id"] = new_id_
            devices.append(
                {
                    "id": new_id_,
                    "name": (name or "").strip() or f"设备 {ip_text}",
                    "mac": mac_text,
                    "ip": ip_text,
                    "child_id": None,
                    "enabled": True,
                    "manual_mode": MODE_ENFORCE,
                    "manual_until": None,
                    # 新设备默认不放行任何站点（只有学习平台那台平板需要）
                    "pass_through": [],
                    "grants": [],
                    "schedule": {
                        "enabled": False,
                        "windows": [],
                        "out_action": "restricted",
                    },
                }
            )

        await self._mutate(_apply)
        return await self.state(chosen["id"])

    async def delete_device(self, device_id: str) -> dict:
        def _apply(data: dict) -> None:
            devices = data.get("devices") or []
            if len(devices) <= 1:
                raise ValueError("至少保留一台受管控设备")
            rest = [d for d in devices if d.get("id") != device_id]
            if len(rest) == len(devices):
                raise ValueError("设备不存在")
            data["devices"] = rest

        await self._mutate(_apply)
        return await self.state(None)

    async def set_schedule(
        self,
        device_id: str | None = None,
        enabled: bool = True,
        windows: list | None = None,
        out_action: str = "restricted",
    ) -> dict:
        """设置时段控制：窗口内放行，窗口外按 out_action 处理。

        星期用 ISO 编号（周一=1 … 周日=7）；支持跨夜时段（22:00–07:00）。
        """
        if out_action not in ("restricted", "block"):
            raise ValueError("时段外动作只能是 restricted（限制）或 block（断网）")

        cleaned: list[dict] = []
        for w in windows or []:
            if not isinstance(w, dict):
                raise ValueError("时间段格式不正确")
            days = sorted(
                {
                    int(str(d).strip())
                    for d in (w.get("days") or [])
                    if str(d).strip().isdigit() and 1 <= int(str(d).strip()) <= 7
                }
            )
            if not days:
                raise ValueError("每个时间段至少要选一天")
            start = _parse_hm(w.get("start"))
            end = _parse_hm(w.get("end"))
            if start is None or end is None:
                raise ValueError("时间格式不正确，需要 HH:MM")
            if start == end:
                raise ValueError("开始时间与结束时间不能相同")
            cleaned.append(
                {
                    "days": days,
                    "start": start.strftime("%H:%M"),
                    "end": end.strftime("%H:%M"),
                }
            )
        if enabled and not cleaned:
            raise ValueError("开启时段控制前，请至少添加一个时间段")

        def _apply(data: dict) -> None:
            device = self._find(data, device_id)
            if not device:
                raise ValueError("设备不存在")
            device["schedule"] = {
                "enabled": bool(enabled),
                "windows": cleaned,
                "out_action": out_action,
            }

        await self._mutate(_apply)
        return await self.state(device_id)

    async def device_for_child(self, child_id: str) -> dict | None:
        """找到该孩子对应的管控设备（未绑定孩子的设备对所有孩子生效）。"""
        data = await self._load()
        for d in data.get("devices") or []:
            bound = d.get("child_id")
            if bound == child_id or not bound:
                return d
        return None


netcontrol_service = NetControlService()
