from datetime import datetime

from app.services.webdav_service import webdav_service


def _is_int(v) -> bool:
    """宽松判断是否可转为整数（int/float/数字字符串）。"""
    if isinstance(v, bool):
        return False
    if isinstance(v, int):
        return True
    if isinstance(v, float):
        return v.is_integer()
    if isinstance(v, str):
        return v.strip().isdigit() or (v.strip().startswith("-") and v.strip()[1:].isdigit())
    return False

BADGE_RULES = [
    (100, "beginner", "初学者"),
    (500, "learner", "小学者"),
    (1000, "scholar", "小学霸"),
    (5000, "master", "学习大师"),
]

# 各项行为的默认积分奖励（家长可在「奖励设置」里覆盖）。
DEFAULT_POINTS = {
    "task_easy": 10,       # 完成任务（简单）
    "task_medium": 15,     # 完成任务（中等）
    "task_hard": 20,       # 完成任务（困难）
    "homework_classroom": 20,  # 孩子自行提交的课堂作业（优秀满分，良好一半）
    "checkin_晨起": 5,     # 晨起打卡
    "checkin_阅读": 10,    # 阅读打卡
    "checkin_运动": 10,    # 运动打卡
    "checkin_家务": 30,    # 家务打卡
    "checkin_心情": 5,     # 心情打卡
}


class RewardService:
    async def get_settings(self, child_id: str) -> dict:
        """读取（或合并默认值）该孩子的积分奖励设置。"""
        saved = await webdav_service.read_json(
            f"{child_id}/rewards/settings.json", {"points": {}}
        )
        points = dict(DEFAULT_POINTS)
        saved_points = saved.get("points") or {}
        if isinstance(saved_points, dict):
            points.update({k: int(v) for k, v in saved_points.items() if _is_int(v)})
        return {"points": points}

    async def update_settings(self, child_id: str, points: dict) -> dict:
        """保存积分奖励设置（仅保留数值分值，负数按 0 处理）。"""
        clean = {}
        for k, v in (points or {}).items():
            if not _is_int(v):
                continue
            val = int(v)
            clean[k] = val if val >= 0 else 0
        await webdav_service.write_json(f"{child_id}/rewards/settings.json", {"points": clean})
        return {"points": clean}

    async def get_behavior_points(self, child_id: str, key: str) -> int:
        """某行为对应的积分（无自定义设置时用默认值）。"""
        settings = await self.get_settings(child_id)
        try:
            return int(settings.get("points", {}).get(key, DEFAULT_POINTS.get(key, 0)))
        except (TypeError, ValueError):
            return DEFAULT_POINTS.get(key, 0)

    async def award_points(self, child_id: str, points: int, reason: str) -> dict:
        """原子累加积分（分布式锁保护读改写）。"""
        def _mutate(data: dict) -> dict:
            data.setdefault("records", [])
            data["records"].append(
                {
                    "points": points,
                    "reason": reason,
                    "timestamp": datetime.now().isoformat(),
                }
            )
            data["total"] = data.get("total", 0) + points
            return data

        updated = await webdav_service.mutate_json(
            f"{child_id}/rewards/points.json", _mutate, default={"records": [], "total": 0}
        )
        await self.check_badges(child_id)
        return updated

    async def check_badges(self, child_id: str) -> list:
        points = await webdav_service.read_json(
            f"{child_id}/rewards/points.json", {"total": 0}
        )
        total = points.get("total", 0)

        def _mutate(badges: dict) -> dict:
            badges.setdefault("earned", [])
            existing = {b.get("code") for b in badges["earned"]}
            for threshold, code, name in BADGE_RULES:
                if total >= threshold and code not in existing:
                    badges["earned"].append(
                        {
                            "code": code,
                            "name": name,
                            "earned_at": datetime.now().isoformat(),
                        }
                    )
                    existing.add(code)
            return badges

        return await webdav_service.mutate_json(
            f"{child_id}/rewards/badges.json", _mutate, default={"earned": []}
        )


reward_service = RewardService()
