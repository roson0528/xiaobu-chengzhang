import aiosqlite
from datetime import datetime

from app.config import settings


class NotificationService:
    async def create(self, user_id: int, title: str, content: str, kind: str = "system") -> int:
        # 用本地时间（容器 CST）存储，保证“当天通知”按本地日期归档正确
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        async with aiosqlite.connect(settings.sqlite_path) as db:
            cur = await db.execute(
                "INSERT INTO notifications (user_id, title, content, kind, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (user_id, title, content, kind, created_at),
            )
            await db.commit()
            return cur.lastrowid

    async def list_for(self, user_id: int, unread_only: bool = False, date: str | None = None) -> list:
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            sql = "SELECT * FROM notifications WHERE user_id = ?"
            params: list = [user_id]
            if unread_only:
                sql += " AND read = 0"
            if date:
                sql += " AND substr(created_at, 1, 10) = ?"
                params.append(date)
            sql += " ORDER BY id DESC LIMIT 100"
            cur = await db.execute(sql, params)
            rows = await cur.fetchall()
            return [dict(r) for r in rows]

    async def mark_read(self, notification_id: int, user_id: int) -> bool:
        async with aiosqlite.connect(settings.sqlite_path) as db:
            cur = await db.execute(
                "UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?",
                (notification_id, user_id),
            )
            await db.commit()
            return cur.rowcount > 0

    # ---------- 业务事件通知（任务/作业） ----------

    async def notify_user(self, user_id: int, title: str, content: str, kind: str = "system") -> int:
        """给单个用户发通知（user_id 为 0/None 时跳过）。"""
        if not user_id:
            return 0
        return await self.create(int(user_id), title, content, kind)

    async def _parent_user_ids(self, child_id: str) -> list[int]:
        """返回应收到该孩子事件通知的家长用户 id 列表（parent_ids + 同家庭家长/管理员）。"""
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT parent_ids, family_id FROM children WHERE id = ?", (child_id,)
            )
            row = await cur.fetchone()
            if not row:
                return []
            ids: set[int] = set()
            for p in (row["parent_ids"] or "").split(","):
                p = p.strip()
                if p.isdigit():
                    ids.add(int(p))
            fid = row["family_id"]
            if fid:
                cur2 = await db.execute(
                    "SELECT id FROM users WHERE family_id = ? AND role IN "
                    "('parent','family_admin','super_admin')",
                    (fid,),
                )
                for r in await cur2.fetchall():
                    ids.add(r["id"])
            return sorted(ids)

    async def _child_user_id(self, child_id: str) -> int | None:
        """返回孩子绑定的账号 user_id（无账号则 None）。"""
        async with aiosqlite.connect(settings.sqlite_path) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT user_id FROM children WHERE id = ?", (child_id,))
            row = await cur.fetchone()
            return row["user_id"] if row and row["user_id"] else None

    async def notify_parents(self, child_id: str, title: str, content: str, kind: str = "task"):
        for uid in await self._parent_user_ids(child_id):
            await self.create(uid, title, content, kind)

    async def notify_child(self, child_id: str, title: str, content: str, kind: str = "task"):
        uid = await self._child_user_id(child_id)
        if uid:
            await self.create(uid, title, content, kind)


notification_service = NotificationService()
