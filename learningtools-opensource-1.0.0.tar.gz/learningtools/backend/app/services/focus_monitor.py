import time

from app.redis_client import get_redis
from app.services.serverchan import serverchan


class FocusMonitor:
    """专注监控事件分析。分心计数下沉到 Redis，跨 gunicorn worker 共享。"""

    async def process_event(self, child_id: str, child_name: str, event: dict) -> None:
        event_type = event.get("type")
        if event_type == "background_switch":
            await self._handle_background_switch(child_id, child_name, event)
        elif event_type == "focus_lost":
            await self._handle_focus_lost(child_id, child_name, event)
        elif event_type == "photo_missing":
            await self._handle_photo_missing(child_id, child_name, event)

    async def _count_recent(self, child_id: str, event_type: str, minutes: int) -> int:
        """滑动窗口内计数：记录事件时间戳到 Redis 列表，淘汰窗口外的。"""
        r = get_redis()
        key = f"distraction:{child_id}:{event_type}"
        now = time.time()
        cutoff = now - minutes * 60
        await r.rpush(key, now)
        vals = await r.lrange(key, 0, -1)
        recent = [float(v) for v in vals if float(v) > cutoff]
        pipe = r.pipeline()
        pipe.delete(key)
        for v in recent:
            pipe.rpush(key, v)
        pipe.expire(key, minutes * 60 + 10)
        await pipe.execute()
        return len(recent)

    async def _handle_background_switch(self, child_id, child_name, event):
        recent = await self._count_recent(child_id, "background_switch", 5)
        if recent >= 3:
            await serverchan.notify_distraction(
                child_id=child_id,
                child_name=child_name,
                reason="频繁切换应用",
                timestamp=event.get("timestamp", ""),
            )

    async def _handle_focus_lost(self, child_id, child_name, event):
        await serverchan.notify_distraction(
            child_id=child_id,
            child_name=child_name,
            reason="注意力分散",
            timestamp=event.get("timestamp", ""),
        )

    async def _handle_photo_missing(self, child_id, child_name, event):
        recent = await self._count_recent(child_id, "photo_missing", 15)
        if recent >= 2:
            await serverchan.notify_distraction(
                child_id=child_id,
                child_name=child_name,
                reason="拍照异常",
                timestamp=event.get("timestamp", ""),
            )


focus_monitor = FocusMonitor()
