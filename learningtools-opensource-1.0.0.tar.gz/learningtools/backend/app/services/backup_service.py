import json
import os
import shutil
from datetime import datetime

from app.config import settings
from app.services.webdav_service import webdav_service


class BackupService:
    def __init__(self):
        self.backup_dir = os.path.join(settings.data_dir, "backups")

    def _ensure_dir(self):
        os.makedirs(self.backup_dir, exist_ok=True)

    async def list_recursive(self, remote_path: str, prefix: str = "") -> list[str]:
        """递归列出 WebDAV 下的所有文件（相对路径）。"""
        result: list[str] = []
        try:
            items = await webdav_service.list_files(remote_path)
        except Exception:
            return result
        for item in items:
            if not isinstance(item, str) or not item:
                continue
            name = item.rstrip("/")
            if not name:
                continue
            rel = f"{prefix}/{name}" if prefix else name
            full = f"{remote_path}/{name}"
            if name.endswith("/") or item.endswith("/"):
                result.extend(await self.list_recursive(full, rel))
            else:
                result.append(rel)
        return result

    async def create_backup(self) -> dict:
        """备份 SQLite + WebDAV 上所有 JSON 文件（不备份照片/视频大文件）。"""
        self._ensure_dir()
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(self.backup_dir, ts)
        os.makedirs(dest, exist_ok=True)

        # SQLite
        if os.path.exists(settings.sqlite_path):
            shutil.copy2(settings.sqlite_path, os.path.join(dest, "app.db"))

        # WebDAV JSON 文件
        files = await self.list_recursive("")
        manifest = {"created_at": datetime.now().isoformat(), "sqlite": "app.db", "files": []}
        for f in files:
            if f.endswith(".json"):
                local = os.path.join(dest, f.replace("/", "_"))
                try:
                    await webdav_service.download_file(f, local)
                    manifest["files"].append(f)
                except Exception:
                    continue
        with open(os.path.join(dest, "manifest.json"), "w", encoding="utf-8") as fp:
            json.dump(manifest, fp, ensure_ascii=False, indent=2)
        return {"backup_id": ts, "files": len(manifest["files"])}

    async def list_backups(self) -> list:
        self._ensure_dir()
        result = []
        for name in sorted(os.listdir(self.backup_dir), reverse=True):
            p = os.path.join(self.backup_dir, name)
            if os.path.isdir(p):
                manifest_path = os.path.join(p, "manifest.json")
                manifest = {}
                if os.path.exists(manifest_path):
                    with open(manifest_path, encoding="utf-8") as fp:
                        manifest = json.load(fp)
                result.append({"backup_id": name, **manifest})
        return result

    async def restore(self, backup_id: str) -> dict:
        dest = os.path.join(self.backup_dir, backup_id)
        if not os.path.isdir(dest):
            raise FileNotFoundError(backup_id)
        # 恢复 SQLite
        sqlite_backup = os.path.join(dest, "app.db")
        if os.path.exists(sqlite_backup):
            shutil.copy2(sqlite_backup, settings.sqlite_path)
        # 恢复 WebDAV JSON
        manifest_path = os.path.join(dest, "manifest.json")
        restored = 0
        if os.path.exists(manifest_path):
            with open(manifest_path, encoding="utf-8") as fp:
                manifest = json.load(fp)
            for f in manifest.get("files", []):
                local = os.path.join(dest, f.replace("/", "_"))
                if os.path.exists(local):
                    with open(local, encoding="utf-8") as fp2:
                        data = json.load(fp2)
                    await webdav_service.write_json(f, data)
                    restored += 1
        return {"restored_files": restored}


backup_service = BackupService()
