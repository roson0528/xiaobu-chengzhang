import os
from datetime import datetime, timedelta

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas

from app.services.webdav_service import webdav_service


def _week_start(week: str) -> datetime:
    """解析 ISO 周标识（如 2026-W37）为周一 00:00。"""
    year, w = week.split("-W")
    return datetime.strptime(f"{year}-W{int(w):02d}-1", "%G-W%V-%u")


class ReportService:
    async def _week_focus(self, child_id: str, start: datetime, end: datetime) -> list:
        data = await webdav_service.read_json(f"{child_id}/focus/sessions.json", {"sessions": []})
        result = []
        for s in data.get("sessions", []):
            try:
                st = datetime.fromisoformat(s.get("started_at", ""))
            except ValueError:
                continue
            if start <= st <= end:
                result.append(s)
        return result

    async def _week_checkins(self, child_id: str, start: datetime, end: datetime) -> list:
        """取本周打卡记录（跨月安全，遍历起止月）。"""
        result = []
        months = set()
        cur = start
        while cur <= end:
            months.add(cur.strftime("%Y-%m"))
            cur = cur + timedelta(days=28)
        for m in months:
            data = await webdav_service.read_json(f"{child_id}/checkins/{m}.json", {"records": []})
            for r in data.get("records", []):
                try:
                    ct = datetime.fromisoformat(r.get("created_at", ""))
                except ValueError:
                    continue
                if start <= ct <= end:
                    result.append(r)
        return result

    async def _photo_distraction_count(self, child_id: str) -> int:
        data = await webdav_service.read_json(f"{child_id}/focus/annotations.json", {"items": []})
        return sum(1 for a in data.get("items", []) if a.get("distracted"))

    def _scoring_analysis(self, tasks: list, checkins: list, distraction_count: int) -> dict:
        task_scores = [t.get("score") for t in tasks if isinstance(t.get("score"), (int, float))]
        checkin_scores = [c.get("score") for c in checkins if isinstance(c.get("score"), (int, float))]
        scores = task_scores + checkin_scores
        avg = round(sum(scores) / len(scores), 1) if scores else None
        # 打分分析：分心越少、平均分越高，专注表现越好
        level = "待评价"
        if avg is not None:
            if avg >= 90:
                level = "优秀"
            elif avg >= 75:
                level = "良好"
            elif avg >= 60:
                level = "合格"
            else:
                level = "需努力"
        return {
            "avg_task_score": round(sum(task_scores) / len(task_scores), 1) if task_scores else None,
            "avg_checkin_score": round(sum(checkin_scores) / len(checkin_scores), 1) if checkin_scores else None,
            "avg_score": avg,
            "level": level,
            "distraction_count": distraction_count,
        }

    async def generate_weekly_report(self, child_id: str, week: str) -> dict:
        start = _week_start(week)
        end = start + timedelta(days=6, hours=23, minutes=59, seconds=59)

        plan = await webdav_service.read_json(f"{child_id}/plans/weekly_{week}.json", {"tasks": []})
        tasks = plan.get("tasks", [])
        completed_tasks = [t for t in tasks if t.get("status") == "completed"]
        total_study = sum(t.get("planned_duration", 0) or 0 for t in completed_tasks)

        sessions = await self._week_focus(child_id, start, end)
        focus_count = len(sessions)
        distraction_count = sum(s.get("distraction_count", 0) or 0 for s in sessions)
        distraction_count += await self._photo_distraction_count(child_id)

        checkins = await self._week_checkins(child_id, start, end)

        fitness = await webdav_service.read_json(
            f"{child_id}/fitness/{start.strftime('%Y-%m')}.json", {"records": []}
        )
        fitness_minutes = sum(
            r.get("duration", 0) or 0 for r in fitness.get("records", [])
        )

        report = {
            "child_id": child_id,
            "week": week,
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "total_tasks": len(tasks),
                "completed": len(completed_tasks),
                "completion_rate": (len(completed_tasks) / len(tasks) * 100) if tasks else 0.0,
                "total_study_minutes": total_study,
                "total_fitness_minutes": fitness_minutes,
                "focus_sessions": focus_count,
                "distraction_count": distraction_count,
            },
            "scoring": self._scoring_analysis(completed_tasks, checkins, distraction_count),
            "subject_breakdown": self._subject_breakdown(completed_tasks),
            "daily_trend": self._daily_trend(tasks),
            "suggestions": self._suggestions(total_study),
        }
        await webdav_service.write_json(f"{child_id}/reports/weekly_{week}.json", report)
        return report

    async def generate_monthly_report(self, child_id: str, month: str) -> dict:
        year, mon = month.split("-")
        start = datetime(int(year), int(mon), 1)
        if int(mon) == 12:
            end = datetime(int(year) + 1, 1, 1) - timedelta(seconds=1)
        else:
            end = datetime(int(year), int(mon) + 1, 1) - timedelta(seconds=1)

        # 汇总该月所有周计划任务
        total_study = 0
        total_tasks = 0
        completed = 0
        iso = start.isocalendar()
        cur = start
        while cur <= end:
            w = f"{cur.isocalendar().year}-W{cur.isocalendar().week:02d}"
            plan = await webdav_service.read_json(f"{child_id}/plans/weekly_{w}.json", {"tasks": []})
            for t in plan.get("tasks", []):
                total_tasks += 1
                if t.get("status") == "completed":
                    completed += 1
                    total_study += t.get("planned_duration", 0) or 0
            cur += timedelta(days=7)

        sessions = await self._week_focus(child_id, start, end)
        fitness = await webdav_service.read_json(
            f"{child_id}/fitness/{month}.json", {"records": []}
        )
        fitness_minutes = sum(r.get("duration", 0) or 0 for r in fitness.get("records", []))

        report = {
            "child_id": child_id,
            "month": month,
            "generated_at": datetime.now().isoformat(),
            "summary": {
                "total_tasks": total_tasks,
                "completed": completed,
                "completion_rate": (completed / total_tasks * 100) if total_tasks else 0.0,
                "total_study_minutes": total_study,
                "total_fitness_minutes": fitness_minutes,
                "focus_sessions": len(sessions),
                "distraction_count": sum(s.get("distraction_count", 0) or 0 for s in sessions),
            },
        }
        await webdav_service.write_json(f"{child_id}/reports/monthly_{month}.json", report)
        return report

    async def export_pdf(self, child_id: str, report: dict) -> str:
        filename = f"/tmp/report_{child_id}_{report.get('week', report.get('month'))}.pdf"
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        c = canvas.Canvas(filename, pagesize=A4)
        width, height = A4

        c.setFont("STSong-Light", 18)
        title = "周报" if "week" in report else "月报"
        period = report.get("week") or report.get("month")
        c.drawString(30 * mm, height - 30 * mm, f"学习报告 {title} - {period}")

        c.setFont("STSong-Light", 12)
        y = height - 50 * mm
        summary = report.get("summary", {})
        lines = [
            f"总任务: {summary.get('total_tasks', 0)}",
            f"已完成: {summary.get('completed', 0)}",
            f"完成率: {summary.get('completion_rate', 0):.1f}%",
            f"学习时长: {summary.get('total_study_minutes', 0)} 分钟",
            f"运动时长: {summary.get('total_fitness_minutes', 0)} 分钟",
            f"专注次数: {summary.get('focus_sessions', 0)}",
            f"分心次数: {summary.get('distraction_count', 0)}",
        ]
        for line in lines:
            c.drawString(30 * mm, y, line)
            y -= 8 * mm

        c.save()
        return filename

    def _subject_breakdown(self, tasks: list) -> dict:
        breakdown: dict[str, int] = {}
        for t in tasks:
            subject = t.get("subject") or "其他"
            breakdown[subject] = breakdown.get(subject, 0) + (t.get("planned_duration", 0) or 0)
        return breakdown

    def _daily_trend(self, tasks: list) -> dict:
        trend: dict[str, int] = {}
        for t in tasks:
            date = t.get("planned_date", "")
            if t.get("status") == "completed" and date:
                trend[date] = trend.get(date, 0) + (t.get("planned_duration", 0) or 0)
        return trend

    def _suggestions(self, total_study: int) -> list:
        s = []
        if total_study < 300:
            s.append("本周学习时间偏少，建议适当增加。")
        elif total_study > 900:
            s.append("本周学习时间较长，注意劳逸结合。")
        return s


report_service = ReportService()
