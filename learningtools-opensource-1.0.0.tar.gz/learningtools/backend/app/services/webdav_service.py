import asyncio
import json
import logging
import os
import re
import uuid
import urllib.parse
from typing import Any, Callable

import httpx
from fastapi import HTTPException

from app.config import settings
from app.redis_client import get_redis

logger = logging.getLogger(__name__)

_HREF_RE = re.compile(r"<[^>]*href>([^<]+)</[^>]*href>")
_SIZE_RE = re.compile(r"<[^>]*getcontentlength>([^<]+)</[^>]*getcontentlength>", re.I)
_RESPONSE_RE = re.compile(r"<[^>]*response>", re.I)
_COLLECTION_RE = re.compile(r"<[^>]*collection", re.I)


class WebDavReadError(RuntimeError):
    """WebDAV 读取失败（超时 / 401 / 403 / 5xx / 响应非法）。

    与「文件确实不存在」严格区分：前者是暂时性故障，调用方必须保留现状；
    后者才允许初始化新的默认配置。
    """

    def __init__(self, path: str, detail: str) -> None:
        super().__init__(f"WebDAV 读取失败 {path}: {detail}")
        self.path = path
        self.detail = detail


class WebDAVService:
    """WebDAV 存储服务（基于 httpx 直接实现，完全掌控 URL 与认证）。

    后端是唯一写入方；业务 JSON 经 read/mutate/write 读写；大文件走 upload/download。
    读改写由 Redis 分布式锁保护，避免并发丢更新。
    """

    def __init__(self):
        self.base = f"{settings.webdav_url}{settings.webdav_root.rstrip('/')}"
        self.auth = httpx.BasicAuth(settings.webdav_user, settings.webdav_password)
        self._tmp = "/tmp/webdav_cache"
        self._client: httpx.AsyncClient | None = None
        os.makedirs(self._tmp, exist_ok=True)

    def _get_client(self) -> httpx.AsyncClient:
        """复用单个 httpx 客户端（连接池 + keep-alive），避免每个请求都重新建连。

        Synology WebDAV 首次建连/认证较慢（实测首次 6-7s、后续 0.01s），
        复用以大幅降低读改写的持锁时间，从而减少「资源繁忙」。
        """
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                auth=self.auth,
                timeout=httpx.Timeout(60.0, connect=10.0),
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            )
        return self._client

    def _url(self, path: str) -> str:
        p = path.strip("/")
        if not p:
            return self.base + "/"
        segs = [urllib.parse.quote(s, safe="") for s in p.split("/") if s]
        return self.base + "/" + "/".join(segs)

    async def _request(self, method: str, path: str, timeout: float = 60.0, **kwargs) -> httpx.Response:
        client = self._get_client()
        return await client.request(method, self._url(path), timeout=timeout, **kwargs)

    # ---------- 目录 ----------

    async def exists(self, remote_path: str) -> bool:
        try:
            r = await self._request("PROPFIND", remote_path, headers={"Depth": "0"})
            return r.status_code == 207
        except Exception:
            return False

    async def ensure_dir(self, remote_dir: str) -> None:
        if not remote_dir:
            return
        parts = [p for p in remote_dir.split("/") if p]
        cur = ""
        for p in parts:
            cur = f"{cur}/{p}" if cur else p
            if not await self.exists(cur):
                r = await self._request("MKCOL", cur)
                if r.status_code not in (200, 201, 405):
                    r.raise_for_status()

    async def delete(self, remote_path: str) -> None:
        r = await self._request("DELETE", remote_path)
        if r.status_code not in (200, 204, 404):
            r.raise_for_status()

    async def list_files(self, remote_path: str) -> list:
        try:
            r = await self._request("PROPFIND", remote_path, headers={"Depth": "1"}, timeout=30.0)
        except Exception:
            return []
        if r.status_code != 207:
            return []
        base = (settings.webdav_root.rstrip("/") + "/" + remote_path.strip("/")).rstrip("/") + "/"
        result = []
        for h in _HREF_RE.findall(r.text):
            p = urllib.parse.unquote(h)
            if p == base:
                continue
            if p.startswith(base):
                name = p[len(base):]
                if name:
                    result.append(name)
        return result

    async def get_size(self, remote_path: str) -> int:
        try:
            r = await self._request("PROPFIND", remote_path, headers={"Depth": "0"}, timeout=30.0)
            m = _SIZE_RE.search(r.text)
            return int(m.group(1)) if m else 0
        except Exception:
            return 0

    async def list_entries(self, remote_path: str) -> list[dict]:
        """列出 remote_path 的直接子项，返回 [{name, path, is_dir, size}]。

        相比 list_files 额外返回「是否目录」与「文件大小」，供容量统计与递归删除使用；
        目录/文件缺失或 WebDAV 异常时返回空列表（不抛异常）。
        """
        try:
            r = await self._request("PROPFIND", remote_path, headers={"Depth": "1"}, timeout=30.0)
        except Exception:
            return []
        if r.status_code != 207:
            return []
        base = (settings.webdav_root.rstrip("/") + "/" + remote_path.strip("/")).rstrip("/") + "/"
        result = []
        for blk in _RESPONSE_RE.split(r.text)[1:]:
            hm = _HREF_RE.search(blk)
            if not hm:
                continue
            p = urllib.parse.unquote(hm.group(1))
            if not p.startswith(base):
                continue
            name = p[len(base):].rstrip("/")
            if not name or "/" in name:
                continue
            sm = _SIZE_RE.search(blk)
            result.append({
                "name": name,
                "path": f"{remote_path.strip('/')}/{name}".strip("/"),
                "is_dir": bool(_COLLECTION_RE.search(blk)),
                "size": int(sm.group(1)) if sm else 0,
            })
        return result

    # ---------- JSON ----------

    async def read_json(self, path: str, default: Any = None) -> Any:
        try:
            r = await self._request("GET", path)
            if r.status_code == 200:
                return r.json()
            # 401/403 通常是凭据失效或 NAS 封锁 IP，需显式告警便于排查
            logger.warning("read_json %s -> HTTP %s（%s）", path, r.status_code, r.text[:120])
        except Exception as e:
            logger.warning("read_json failed %s: %s", path, e)
        return default

    async def read_json_strict(self, path: str) -> Any:
        """读取 JSON：文件不存在返回 None，其余失败一律抛 WebDavReadError。

        ``read_json`` 出错时静默返回 default，调用方无法分辨「文件不存在」和
        「这次没读到」。对 system/netcontrol.json 这种存有长期凭据（路由器令牌）
        的文件，误判成「不存在」会重建文件并换掉令牌，路由器仍持旧令牌即 403
        失联（2026-10-04 实际故障），故敏感配置必须走严格读取。
        """
        try:
            r = await self._request("GET", path)
        except Exception as e:
            raise WebDavReadError(path, str(e)) from e
        if r.status_code == 404:
            return None
        if r.status_code != 200:
            raise WebDavReadError(path, f"HTTP {r.status_code} {r.text[:120]}")
        try:
            return r.json()
        except Exception as e:
            raise WebDavReadError(path, f"响应不是合法 JSON: {e}") from e

    async def write_json(self, path: str, data: Any) -> None:
        content = json.dumps(data, ensure_ascii=False, indent=2)
        await self.ensure_dir("/".join(path.split("/")[:-1]))
        r = await self._request("PUT", path, content=content.encode("utf-8"))
        r.raise_for_status()

    async def safe_write_json(self, path: str, data: Any) -> None:
        if await self.exists(path):
            try:
                await self._request("COPY", path, headers={"Destination": self._url(f"{path}.bak")})
            except Exception:
                pass
        await self.write_json(path, data)

    # ---------- 文件 ----------

    async def upload_file(self, local_path: str, remote_path: str) -> None:
        await self.ensure_dir("/".join(remote_path.split("/")[:-1]))
        with open(local_path, "rb") as f:
            content = f.read()
        r = await self._request("PUT", remote_path, content=content, timeout=300.0)
        r.raise_for_status()

    async def download_file(self, remote_path: str, local_path: str) -> None:
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)
        r = await self._request("GET", remote_path, timeout=300.0)
        r.raise_for_status()
        with open(local_path, "wb") as f:
            f.write(r.content)

    # ---------- 原子读改写（分布式锁） ----------

    async def mutate_json(
        self,
        path: str,
        mutate_fn: Callable[[Any], Any | None],
        default: Any = None,
        strict: bool = False,
    ) -> Any:
        lock_key = f"lock:dav:{path}"
        token = str(uuid.uuid4())
        r = get_redis()

        # 锁有效期须覆盖一次读改写的正常耗时；WebDAV 偶发慢时读写各可能接近
        # 60s 超时，30s 的旧 TTL 会在操作未完成时锁已过期，既可能误放并发写，
        # 也会让后续请求误判。这里放宽到 120s。
        lock_ttl = 120
        # 获取窗口从 2s 放宽到 ~15s：WebDAV 慢导致持锁时间变长时，后续请求
        # 多等一会即可成功，而不是立刻报「资源繁忙」。
        acquired = await r.set(lock_key, token, nx=True, ex=lock_ttl)
        if not acquired:
            for _ in range(30):
                await asyncio.sleep(0.5)
                acquired = await r.set(lock_key, token, nx=True, ex=lock_ttl)
                if acquired:
                    break
        if not acquired:
            raise HTTPException(status_code=503, detail="资源繁忙，请稍后重试")

        try:
            if strict:
                # 读失败直接抛出（WebDavReadError），绝不拿默认值去覆盖远端文件
                data = await self.read_json_strict(path)
                if data is None:
                    data = default
            else:
                data = await self.read_json(path, default)
            result = mutate_fn(data)
            if result is not None:
                data = result
            await self.safe_write_json(path, data)
            return data
        finally:
            release = (
                "if redis.call('get', KEYS[1]) == ARGV[1] "
                "then return redis.call('del', KEYS[1]) else return 0 end"
            )
            try:
                await r.eval(release, 1, lock_key, token)
            except Exception:
                logger.exception("release lock failed %s", lock_key)


webdav_service = WebDAVService()
