import asyncio
import time
from collections import defaultdict

import httpx

from app.config import settings
from app.redis_client import get_redis
from app.services.settings_service import get_setting

# 分心告警节流窗口（秒）
MIN_NOTIFY_INTERVAL = 300


class ServerChanService:
    """Server酱（Turbo 版）微信推送。节流状态下沉到 Redis，跨 worker 共享。"""

    def __init__(self) -> None:
        # 后台页面在线设置的 Key（优先级高于 .env 配置），启动时从 app_settings 加载
        self._runtime_sendkey: str = ""

    @property
    def sendkey(self) -> str:
        return self._runtime_sendkey or settings.serverchan_sendkey

    @property
    def enabled(self) -> bool:
        return bool(self.sendkey)

    async def load_runtime_sendkey(self) -> None:
        """启动时从 app_settings 读取后台设置的 Key（若未设置则保持 .env 值）。"""
        self._runtime_sendkey = await get_setting("serverchan_sendkey", "")

    def set_runtime_sendkey(self, key: str) -> None:
        self._runtime_sendkey = (key or "").strip()

    async def send_notification(self, title: str, content: str) -> dict | None:
        if not self.enabled:
            return None
        url = f"https://sctapi.ftqq.com/{self.sendkey}.send"
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    url,
                    json={"title": title[:32], "desp": content[:32000]},
                    timeout=10,
                )
                return resp.json()
        except Exception as e:
            return {"error": str(e)}

    async def _throttled(self, key: str) -> bool:
        """返回 True 表示放行，False 表示仍在节流窗口内。"""
        r = get_redis()
        ok = await r.set(f"throttle:{key}", "1", nx=True, ex=MIN_NOTIFY_INTERVAL)
        return bool(ok)

    async def notify_distraction(
        self,
        child_id: str,
        child_name: str,
        reason: str,
        timestamp: str,
        photo_url: str | None = None,
    ) -> None:
        if not await self._throttled(f"distraction:{child_id}"):
            return
        content = (
            f"## 学习提醒\n\n"
            f"**孩子**: {child_name}\n\n"
            f"**情况**: {reason}\n\n"
            f"**时间**: {timestamp}\n\n"
        )
        if photo_url:
            content += f"![现场照片]({photo_url})\n\n"
        await self.send_notification(title=f"⚠️ {child_name} 学习不专注提醒", content=content)

    async def notify_daily_report(self, child_name: str, report: dict) -> None:
        content = (
            f"## 今日学习报告\n\n"
            f"**孩子**: {child_name}\n\n"
            f"**完成任务**: {report.get('completed', 0)}/{report.get('total', 0)}\n\n"
            f"**学习时长**: {report.get('study_minutes', 0)} 分钟\n\n"
            f"**运动时长**: {report.get('fitness_minutes', 0)} 分钟\n\n"
            f"**专注次数**: {report.get('focus_sessions', 0)}\n\n"
        )
        await self.send_notification(title=f"📊 {child_name} 今日学习报告", content=content)


serverchan = ServerChanService()
