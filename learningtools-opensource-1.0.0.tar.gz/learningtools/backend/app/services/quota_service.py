import io
import os

from fastapi import HTTPException, UploadFile
from PIL import Image

from app.config import settings
from app.redis_client import get_redis


class QuotaService:
    """配额管理：配额真相源在 SQLite children.quota_mb，Redis 只做已用量计数器缓存。"""

    async def get_quota(self, child_id: str, db) -> int:
        cur = await db.execute("SELECT quota_mb FROM children WHERE id = ?", (child_id,))
        row = await cur.fetchone()
        if row is None:
            return settings.default_quota_mb
        return int(row["quota_mb"])

    async def get_used(self, child_id: str) -> float:
        r = get_redis()
        v = await r.get(f"used:{child_id}")
        return float(v) if v else 0.0

    async def check_and_reserve(self, child_id: str, db, file_size_bytes: int) -> None:
        quota_mb = await self.get_quota(child_id, db)
        used_mb = await self.get_used(child_id)
        file_mb = file_size_bytes / (1024 * 1024)
        if used_mb + file_mb > quota_mb:
            raise HTTPException(
                status_code=413,
                detail=f"存储空间不足。已用 {used_mb:.1f}MB / {quota_mb}MB",
            )
        r = get_redis()
        await r.incrbyfloat(f"used:{child_id}", file_mb)
        await db.execute(
            "UPDATE children SET used_mb = used_mb + ? WHERE id = ?", (file_mb, child_id)
        )
        await db.commit()

    async def release(self, child_id: str, file_size_mb: float) -> None:
        r = get_redis()
        await r.incrbyfloat(f"used:{child_id}", -file_size_mb)

    async def compress_image(
        self, file: UploadFile, max_width: int = 1280, quality: int = 75
    ) -> bytes:
        content = await file.read()
        return self.compress_bytes(content, max_width, quality)

    def compress_bytes(
        self, content: bytes, max_width: int = 1280, quality: int = 75
    ) -> bytes:
        try:
            img = Image.open(io.BytesIO(content))
            if img.width > max_width:
                ratio = max_width / img.width
                img = img.resize((max_width, int(img.height * ratio)), Image.LANCZOS)
            output = io.BytesIO()
            img.convert("RGB").save(output, format="JPEG", quality=quality, optimize=True)
            return output.getvalue()
        except Exception:
            # 无法识别/压缩时保留原始字节，避免上传失败
            return content


quota_service = QuotaService()
