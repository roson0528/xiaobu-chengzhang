"""假期作业 / 假期任务的公共判定。

布置「作业」或「任务」时可以勾选「假期」并设置假期时长（天）。勾选后：

* 该作业/任务在 ``[planned_date, planned_date + 时长 - 1]`` 这段区间内**每天都会出现**
  （孩子端的「今日任务」「今日作业」、家长端按日期查找都一致）；
* **假期区间内提交都算按时完成**，不会被「超时未完成扣分」；
* 只有假期结束仍未提交，才会在假期最后一天被判定为未完成并扣一次分。

字段：``holiday: bool`` 与 ``holiday_days: int``（都直接存在周计划的任务对象里）。
"""

from datetime import date, timedelta

# 假期时长上限（防止误填导致任务长期不结算）
MAX_HOLIDAY_DAYS = 60
DEFAULT_HOLIDAY_DAYS = 7


def is_holiday(task: dict | None) -> bool:
    return bool(task.get("holiday")) if isinstance(task, dict) else False


def holiday_days(task: dict) -> int:
    """假期时长（天）。非假期任务返回 0。"""
    if not is_holiday(task):
        return 0
    try:
        n = int(task.get("holiday_days") or 0)
    except (TypeError, ValueError):
        n = 0
    if n <= 0:
        n = DEFAULT_HOLIDAY_DAYS
    return min(n, MAX_HOLIDAY_DAYS)


def holiday_start(task: dict) -> str | None:
    """假期第一天（即 planned_date）。"""
    s = str(task.get("planned_date") or "")
    return s or None


def _shift(day: str, days: int) -> str | None:
    try:
        d = date(*map(int, day.split("-")))
    except (TypeError, ValueError):
        return None
    return (d + timedelta(days=days)).isoformat()


def holiday_end(task: dict) -> str | None:
    """假期最后一天（含）。非假期任务或日期非法时返回 None。"""
    n = holiday_days(task)
    start = holiday_start(task)
    if not n or not start:
        return None
    return _shift(start, n - 1)


def in_window(task: dict, day: str) -> bool:
    """``day`` 是否落在该任务的假期区间内。"""
    start, end = holiday_start(task), holiday_end(task)
    if not start or not end:
        return False
    return start <= day <= end


def is_archived(task: dict | None) -> bool:
    """假期作业审核通过 = 写完了，从「今日任务」归档（按日期查找仍能查到）。"""
    if not is_holiday(task):
        return False
    return task.get("status") == "completed" and task.get("review_status") == "approved"


def submission_days(task: dict) -> list[str]:
    """假期作业已经提交过的日期（升序）。"""
    days = [str(s.get("date") or "") for s in (task.get("submissions") or []) if isinstance(s, dict)]
    return sorted({d for d in days if d})


def window_dates(task: dict, until: str | None = None) -> set[str]:
    """假期区间内的所有日期；``until`` 给出时只返回早于它的日期。"""
    start, end = holiday_start(task), holiday_end(task)
    if not start or not end:
        return set()
    if until and end >= until:
        end = _shift(until, -1)
        if end is None or end < start:
            return set()
    out: set[str] = set()
    cur, stop = start, end
    for _ in range(MAX_HOLIDAY_DAYS + 1):
        if cur > stop:
            break
        out.add(cur)
        nxt = _shift(cur, 1)
        if nxt is None:
            break
        cur = nxt
    return out


def remaining_days(task: dict, today: str) -> int:
    """距离假期结束还剩几天（含今天）；不在区间内返回 0。"""
    end = holiday_end(task)
    if not end or not in_window(task, today):
        return 0
    try:
        e = date(*map(int, end.split("-")))
        t = date(*map(int, today.split("-")))
    except (TypeError, ValueError):
        return 0
    return max(0, (e - t).days + 1)
