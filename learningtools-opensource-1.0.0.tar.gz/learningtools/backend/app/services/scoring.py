"""评分标准统一：家长按维度（完成度/认真度/正确率）打分，1-5 星，折合 0-100 总分。"""

SCORE_DIMENSIONS = [
    {"key": "completion", "label": "完成度"},
    {"key": "diligence", "label": "认真度"},
    {"key": "accuracy", "label": "正确率"},
]

_DIMENSION_KEYS = [d["key"] for d in SCORE_DIMENSIONS]


def ratings_to_score(ratings: dict | None) -> int | None:
    """维度评分（1-5）→ 0-100 总分；无有效评分返回 None（沿用旧 score）。"""
    if not ratings:
        return None
    vals = []
    for k in _DIMENSION_KEYS:
        v = ratings.get(k)
        if isinstance(v, (int, float)) and 0 < v <= 5:
            vals.append(float(v))
    if not vals:
        return None
    return round(sum(vals) / len(vals) * 20)


def sanitize_ratings(ratings: dict | None) -> dict | None:
    """只保留合法维度（1-5），否则返回 None。"""
    if not isinstance(ratings, dict):
        return None
    out = {}
    for k in _DIMENSION_KEYS:
        v = ratings.get(k)
        if isinstance(v, (int, float)) and 0 < v <= 5:
            out[k] = int(v)
    return out or None
