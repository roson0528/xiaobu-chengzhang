"""运行时可配置项：持久化在 SQLite app_settings 表，供后台页面在线修改。"""
import aiosqlite

from app.config import settings


async def get_setting(key: str, default: str = "") -> str:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        cur = await db.execute("SELECT value FROM app_settings WHERE key = ?", (key,))
        row = await cur.fetchone()
        return (row[0] if row else default)


async def set_setting(key: str, value: str) -> None:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        await db.execute(
            "INSERT INTO app_settings (key, value, updated_at) "
            "VALUES (?, ?, datetime('now','localtime')) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, "
            "updated_at = excluded.updated_at",
            (key, value),
        )
        await db.commit()
