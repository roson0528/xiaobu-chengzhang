from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # WebDAV 存储
    webdav_url: str = "https://your-nas.example.com/dav"
    webdav_user: str = "roson"
    webdav_password: str = ""
    webdav_root: str = "/learningtools"

    # Server酱
    serverchan_sendkey: str = ""

    # JWT
    jwt_secret: str = "change-me"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 1440
    refresh_token_expire_days: int = 30

    # 服务
    host: str = "0.0.0.0"
    port: int = 8000
    redis_url: str = "redis://127.0.0.1:6379/0"
    cors_origins: str = "http://localhost"

    # 配额 / 保留期
    default_quota_mb: int = 2048
    default_photo_retention_days: int = 30
    default_video_retention_days: int = 15
    default_audio_retention_days: int = 90

    # 打卡审核：超时自动通过（小时），0 表示不自动通过
    checkin_auto_approve_hours: int = 0

    # 单设备登录（孩子账号）：同一孩子账号后登录的设备会踢掉先登录的设备
    single_device_login: bool = True

    # 邮件（可选）
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""

    # 本地数据路径（容器内）
    data_dir: str = "/app/data"
    sqlite_path: str = "/app/data/app.db"

    # 初始管理员账号
    admin_username: str = "admin"
    admin_password: str = "admin123456"

    # App 升级
    app_version: str = "3.6"                           # 孩子端（正式版 V3.6）
    app_apk_path: str = "/apk/app-release.apk"         # 相对站点根路径
    # 学习专用版（平板变体）：打开即自动进入专注模式
    app_tablet_apk_path: str = "/apk/app-release-tablet.apk"
    app_parent_version: str = "3.11"                    # 家长/管理端（正式版 V3.10）
    app_parent_apk_path: str = "/apk/parent-app-release.apk"

    @property
    def cors_origin_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


settings = Settings()
