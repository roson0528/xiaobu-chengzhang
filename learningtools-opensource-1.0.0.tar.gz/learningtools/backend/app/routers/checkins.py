import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.quota_service import quota_service
from app.services.reward_service import reward_service
from app.services.scoring import ratings_to_score, sanitize_ratings
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/checkins", tags=["打卡"])

# 主动打卡类型（孩子主动发起，家长审核通过后才奖励积分）
CHECKIN_TYPES = ["晨起", "阅读", "运动", "家务", "心情"]


def _month() -> str:
    return datetime.now().strftime("%Y-%m")


async def _award_approved_checkins(child_id: str, month: str, ids: list[str]) -> int:
    """为刚通过审核的打卡记录补发积分（按 rewarded 标记幂等，避免重复奖励）。"""
    data = await webdav_service.read_json(f"{child_id}/checkins/{month}.json", {"records": []})
    to_award = [
        r for r in data.get("records", [])
        if r.get("id") in ids and r.get("status") == "approved" and not r.get("rewarded")
    ]
    if not to_award:
        return 0
    for r in to_award:
        ctype = r.get("checkin_type") or ""
        points = await reward_service.get_behavior_points(child_id, f"checkin_{ctype}")
        grade = r.get("grade")
        if grade == "good":
            points = max(1, points // 2)
        label = f"完成{ctype}打卡"
        if grade == "excellent":
            label += "（优秀）"
        elif grade == "good":
            label += "（良好）"
        await reward_service.award_points(child_id, points, label)

    def _mark(d: dict) -> dict:
        for r in d.get("records", []):
            if r.get("id") in ids:
                r["rewarded"] = True
        return d

    await webdav_service.mutate_json(f"{child_id}/checkins/{month}.json", _mark, {"records": []})
    return len(to_award)


async def _find_checkin_month(child_id: str, checkin_id: str) -> str | None:
    months = [_month()]
    for m in months:
        data = await webdav_service.read_json(f"{child_id}/checkins/{m}.json", {"records": []})
        if any(r.get("id") == checkin_id for r in data.get("records", [])):
            return m
    return None


class CheckinBody(BaseModel):
    checkin_type: str
    subject: str | None = None
    content: str | None = None
    duration: int | None = None
    photo_path: str | None = None
    photo_paths: list[str] | None = None
    audio_path: str | None = None
    video_path: str | None = None
    preset_id: str | None = None  # 对应的打卡任务 id（用于超时惩罚匹配）
    created_at: str | None = None  # 提交时间（客户端附带，缺省用服务器时间）


class ReviewBody(BaseModel):
    comment: str | None = None
    score: int | None = None  # 评分（如 1-100 或星级分值），可选
    ratings: dict | None = None  # 维度评分 {completion,diligence,accuracy} 1-5
    grade: str | None = None  # 优秀 excellent / 良好 good（优秀满分，良好一半）


class BatchReviewBody(BaseModel):
    ids: list[str]
    action: str  # approve / reject
    comment: str | None = None
    score: int | None = None


@router.post("/{child_id}")
async def submit_checkin(
    child_id: str,
    body: CheckinBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    month = _month()
    record = body.dict()
    record["id"] = f"checkin_{uuid.uuid4().hex[:10]}"
    record["status"] = "pending"
    record["rewarded"] = False  # 审核通过后由审核接口奖励积分
    record["created_at"] = (body.created_at or "").strip() or datetime.now().isoformat()
    # 多张照片：优先 photo_paths，兼容单张 photo_path
    paths = [p for p in (record.get("photo_paths") or []) if p]
    if not paths and record.get("photo_path"):
        paths = [record["photo_path"]]
    if paths:
        record["photo_paths"] = paths
        record["photo_path"] = paths[0]

    def _mutate(data: dict) -> dict:
        data.setdefault("records", [])
        data["records"].append(record)
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/{month}.json", _mutate, {"records": []})
    # 注意：不再在提交时奖励积分，改为审核通过后奖励（见 review_checkin / checkin_auto_approve）。
    return record


@router.get("/{child_id}")
async def list_checkins(
    child_id: str,
    date: str | None = None,
    month: str | None = None,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    if date:
        m = date[:7]
        data = await webdav_service.read_json(f"{child_id}/checkins/{m}.json", {"records": []})
        return [r for r in data.get("records", []) if (r.get("created_at") or "").startswith(date)]
    if month:
        data = await webdav_service.read_json(f"{child_id}/checkins/{month}.json", {"records": []})
        return data.get("records", [])
    m = _month()
    data = await webdav_service.read_json(f"{child_id}/checkins/{m}.json", {"records": []})
    return data.get("records", [])


@router.post("/{checkin_id}/review")
async def review_checkin(
    checkin_id: str,
    child_id: str,
    body: ReviewBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    month = await _find_checkin_month(child_id, checkin_id)
    if month is None:
        raise HTTPException(status_code=404, detail="打卡记录不存在")

    ratings = sanitize_ratings(body.ratings)

    def _mutate(data: dict) -> dict:
        for r in data.get("records", []):
            if r.get("id") == checkin_id:
                r["status"] = "approved"
                r["review_comment"] = body.comment
                if body.grade in ("excellent", "good"):
                    r["grade"] = body.grade
                if ratings:
                    r["ratings"] = ratings
                    r["score"] = ratings_to_score(ratings)
                elif body.score is not None:
                    r["score"] = body.score
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/{month}.json", _mutate, {"records": []})
    await _award_approved_checkins(child_id, month, [checkin_id])
    return {"status": "ok"}


@router.post("/{checkin_id}/reject")
async def reject_checkin(
    checkin_id: str,
    child_id: str,
    body: ReviewBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    month = await _find_checkin_month(child_id, checkin_id)
    if month is None:
        raise HTTPException(status_code=404, detail="打卡记录不存在")

    ratings = sanitize_ratings(body.ratings)

    def _mutate(data: dict) -> dict:
        for r in data.get("records", []):
            if r.get("id") == checkin_id:
                r["status"] = "rejected"
                r["review_comment"] = body.comment
                r.pop("grade", None)
                if ratings:
                    r["ratings"] = ratings
                    r["score"] = ratings_to_score(ratings)
                elif body.score is not None:
                    r["score"] = body.score
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/{month}.json", _mutate, {"records": []})
    return {"status": "ok"}


@router.post("/{child_id}/batch-review")
async def batch_review_checkins(
    child_id: str,
    body: BatchReviewBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """批量审核打卡（当前月份）：approve 或 reject 一组打卡记录。"""
    await get_child(child_id, current_user, db)
    if body.action not in ("approve", "reject"):
        raise HTTPException(status_code=400, detail="action 需为 approve 或 reject")
    if not body.ids:
        raise HTTPException(status_code=400, detail="ids 不能为空")
    month = _month()
    idset = set(body.ids)

    def _mutate(data: dict) -> dict:
        for r in data.get("records", []):
            if r.get("id") in idset:
                r["status"] = "approved" if body.action == "approve" else "rejected"
                if body.comment is not None:
                    r["review_comment"] = body.comment
                if body.score is not None:
                    r["score"] = body.score
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/{month}.json", _mutate, {"records": []})
    if body.action == "approve":
        await _award_approved_checkins(child_id, month, body.ids)
    return {"status": "ok", "count": len(body.ids)}


@router.get("/{child_id}/stats")
async def checkin_stats(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    await get_child(child_id, current_user, db)
    month = _month()
    data = await webdav_service.read_json(f"{child_id}/checkins/{month}.json", {"records": []})
    records = data.get("records", [])
    total = len(records)
    approved = sum(1 for r in records if r.get("status") == "approved")
    pending = sum(1 for r in records if r.get("status") == "pending")
    return {"total": total, "approved": approved, "pending": pending}


# ---------------- 打卡任务预设（家长配置，孩子端选择） ----------------

class PresetBody(BaseModel):
    title: str
    checkin_type: str = "作业"
    subject: str | None = None
    content: str | None = None
    duration: int | None = None
    enabled: bool = True
    repeat: dict | None = None       # {"type":"daily"|"weekly","days":[1..7]}
    photo_required: bool = True      # 是否需要拍照提交
    penalty_points: int = 0          # 超时未完成扣分（0 表示不扣）


async def _load_presets(child_id: str) -> dict:
    return await webdav_service.read_json(f"{child_id}/checkins/presets.json", {"items": []})


def _preset_matches_today(preset: dict, today: datetime) -> bool:
    """打卡任务是否应在今天出现（支持按星期重复）。"""
    rep = preset.get("repeat") or {}
    if not isinstance(rep, dict):
        rep = {}
    rtype = rep.get("type") or "none"
    if rtype == "weekly":
        days = rep.get("days") or []
        return today.isoweekday() in days
    # none / daily：每天都显示
    return True


@router.get("/{child_id}/presets")
async def list_presets(
    child_id: str,
    for_today: bool = False,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    data = await _load_presets(child_id)
    items = data.get("items", [])
    if for_today:
        now = datetime.now()
        items = [p for p in items if _preset_matches_today(p, now)]
    return {"items": items}


@router.post("/{child_id}/presets")
async def create_preset(
    child_id: str,
    body: PresetBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    preset = body.dict()
    preset["id"] = f"preset_{uuid.uuid4().hex[:10]}"
    if not preset.get("repeat"):
        preset["repeat"] = {"type": "daily", "days": []}

    def _mutate(data: dict) -> dict:
        data.setdefault("items", [])
        data["items"].append(preset)
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/presets.json", _mutate, {"items": []})
    return preset


@router.put("/{child_id}/presets/{preset_id}")
async def update_preset(
    child_id: str,
    preset_id: str,
    body: PresetBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    updates = body.dict()
    if not updates.get("repeat"):
        updates["repeat"] = {"type": "daily", "days": []}

    def _mutate(data: dict) -> dict:
        for p in data.get("items", []):
            if p.get("id") == preset_id:
                p.update(updates)
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/presets.json", _mutate, {"items": []})
    return {"status": "ok"}


@router.delete("/{child_id}/presets/{preset_id}")
async def delete_preset(
    child_id: str,
    preset_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)

    def _mutate(data: dict) -> dict:
        data["items"] = [p for p in data.get("items", []) if p.get("id") != preset_id]
        return data

    await webdav_service.mutate_json(f"{child_id}/checkins/presets.json", _mutate, {"items": []})
    return {"status": "ok"}


# ---------------- 朗读录音上传 ----------------

@router.post("/{child_id}/audio")
async def upload_audio(
    child_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """上传朗读打卡录音，存储到 {child_id}/checkins/audio/。"""
    await get_child(child_id, current_user, db)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="录音内容为空")
    if len(raw) > 30 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="录音超过 30MB 限制")
    await quota_service.check_and_reserve(child_id, db, len(raw))

    ext = ".m4a"
    fname = datetime.now().strftime("%Y%m%d_%H%M%S") + ext
    remote_path = f"{child_id}/checkins/audio/{fname}"

    local_tmp = f"/tmp/audio_{uuid.uuid4().hex}{ext}"
    with open(local_tmp, "wb") as f:
        f.write(raw)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    return {"path": remote_path, "size": len(raw)}


@router.get("/{child_id}/audio")
async def view_audio(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent", "child")),
):
    """查看/播放朗读打卡录音（path 可为完整存储路径或文件名）。"""
    await get_child(child_id, current_user, db)
    prefix = f"{child_id}/checkins/audio/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/checkins/audio/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="录音不存在")
    local = f"/tmp/audio_view_{uuid.uuid4().hex}.m4a"
    await webdav_service.download_file(remote, local)
    return FileResponse(local, media_type="audio/mp4")
