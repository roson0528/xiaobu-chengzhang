from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.routers.tasks import _task_matches_today, _today_view
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/sync", tags=["同步"])


def _current_week() -> str:
    iso = datetime.now().isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


class PushBody(BaseModel):
    records: list[dict] = []


@router.get("/pull")
async def pull(
    child_id: str,
    last_sync: str | None = None,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    child = await get_child(child_id, current_user, db)
    week = _current_week()
    today = datetime.now().strftime("%Y-%m-%d")
    month = datetime.now().strftime("%Y-%m")

    plan = await webdav_service.read_json(f"{child_id}/plans/weekly_{week}.json", {"tasks": []})
    points = await webdav_service.read_json(f"{child_id}/rewards/points.json", {"total": 0})
    badges = await webdav_service.read_json(f"{child_id}/rewards/badges.json", {"earned": []})
    messages = await webdav_service.read_json(f"{child_id}/messages.json", {"messages": []})
    checkins = await webdav_service.read_json(f"{child_id}/checkins/{month}.json", {"records": []})

    return {
        "server_time": datetime.now().isoformat(),
        "child": {"id": child["id"], "name": child["name"], "grade": child["grade"]},
        "week": week,
        "today": today,
        "plan_tasks": plan.get("tasks", []),
        "today_tasks": [_today_view(t, today) for t in plan.get("tasks", []) if _task_matches_today(t, today)],
        "points": points,
        "badges": badges,
        "messages": messages.get("messages", []),
        "checkins": checkins.get("records", []),
    }


@router.post("/push")
async def push(
    body: PushBody,
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    month = datetime.now().strftime("%Y-%m")
    accepted: list[str] = []

    for rec in body.records:
        entity_type = rec.get("entity_type")
        entity_id = rec.get("entity_id") or f"sync_{datetime.now().timestamp()}"
        payload = rec.get("payload") or {}

        path_map = {
            "checkin": f"{child_id}/checkins/{month}.json",
            "fitness": f"{child_id}/fitness/{month}.json",
            "reading": f"{child_id}/reading/{month}.json",
            "mistake": f"{child_id}/mistakes/{month}.json",
        }
        if entity_type not in path_map:
            continue
        path = path_map[entity_type]
        payload["id"] = entity_id
        payload.setdefault("created_at", datetime.now().isoformat())

        def _mutate(data: dict, _id=entity_id, _payload=payload) -> dict:
            data.setdefault("records", [])
            if not any(r.get("id") == _id for r in data["records"]):
                data["records"].append(_payload)
            return data

        await webdav_service.mutate_json(path, _mutate, {"records": []})
        accepted.append(entity_id)

    return {"accepted": accepted}
