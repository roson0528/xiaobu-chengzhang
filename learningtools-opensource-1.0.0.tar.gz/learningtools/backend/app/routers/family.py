import os
import uuid
from datetime import datetime

import aiosqlite
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.config import settings
from app.core.deps import get_current_user, get_db, require_role
from app.routers.messages import AttachmentItem, _media_type, _type_of
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/family", tags=["家庭"])


class BindBody(BaseModel):
    username: str


class ChatBody(BaseModel):
    content: str = ""
    attachments: list[AttachmentItem] = []


def _now() -> str:
    return datetime.now().isoformat()


def _family_of(user: dict) -> str:
    fid = user.get("family_id")
    if not fid:
        raise HTTPException(status_code=400, detail="账号尚未归属家庭，请联系管理员绑定")
    return fid


async def _display_name(user: dict, db) -> str:
    if user.get("role") == "child":
        cur = await db.execute("SELECT name FROM children WHERE user_id = ?", (user["id"],))
        row = await cur.fetchone()
        if row and row["name"]:
            return row["name"]
    return (user.get("nickname") or "").strip() or user.get("username", "")


async def _members(fid: str, db) -> list[dict]:
    cur = await db.execute("SELECT * FROM users WHERE family_id = ? ORDER BY id", (fid,))
    rows = await cur.fetchall()
    members = []
    for r in rows:
        u = dict(r)
        members.append({
            "id": u["id"],
            "username": u["username"],
            "nickname": u.get("nickname") or "",
            "role": u["role"],
            "display_name": await _display_name(u, db),
        })
    return members


@router.get("/members")
async def list_members(db=Depends(get_db), current_user=Depends(get_current_user)):
    fid = _family_of(current_user)
    members = await _members(fid, db)
    cur = await db.execute("SELECT * FROM children WHERE family_id = ? ORDER BY created_at", (fid,))
    children = [dict(r) for r in await cur.fetchall()]
    return {"family_id": fid, "members": members, "children": children}


@router.post("/bind")
async def bind_member(
    body: BindBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """把另一个家长/孩子账号绑定到当前家庭（同 family_id 实现数据同步）。"""
    fid = _family_of(current_user)
    cur = await db.execute("SELECT * FROM users WHERE username = ?", (body.username,))
    row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="账号不存在")
    target = dict(row)
    if target["id"] == current_user["id"]:
        raise HTTPException(status_code=400, detail="不能绑定自己")

    # 1) 目标账号归入本家庭
    await db.execute("UPDATE users SET family_id = ? WHERE id = ?", (fid, target["id"]))

    # 2) 同步孩子档案与其登录账号的家庭归属
    cur = await db.execute("SELECT * FROM children")
    all_children = [dict(r) for r in await cur.fetchall()]
    for ch in all_children:
        pids = [p for p in (ch.get("parent_ids") or "").split(",") if p]
        is_parent = str(target["id"]) in pids
        is_child_account = ch.get("user_id") and ch["user_id"] == target["id"]
        if is_parent or is_child_account:
            await db.execute("UPDATE children SET family_id = ? WHERE id = ?", (fid, ch["id"]))
            if ch.get("user_id"):
                await db.execute(
                    "UPDATE users SET family_id = ? WHERE id = ?", (fid, ch["user_id"])
                )
    await db.commit()
    return {"status": "ok", "family_id": fid}


def _p2p_key(fid: str, a: int, b: int) -> str:
    lo, hi = sorted((int(a), int(b)))
    return f"{fid}/p2p/{lo}_{hi}.json"


def _chat_file(fid: str) -> str:
    return f"{fid}/family_chat.json"


# ---------------- 附件上传（家庭群聊 + 私聊共用 {family_id}/chat_attachments/） ----------------

async def _upload_attachment(fid: str, file: UploadFile) -> dict:
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="文件内容为空")
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件超过 50MB 限制")
    safe_name = os.path.basename(file.filename or "file").replace("/", "_").replace("\\", "_") or "file"
    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = f"{now.strftime('%H-%M-%S')}_{uuid.uuid4().hex[:6]}_{safe_name}"
    remote_path = f"{fid}/chat_attachments/{date_dir}/{fname}"

    local_tmp = f"/tmp/fam_up_{uuid.uuid4().hex}"
    with open(local_tmp, "wb") as f:
        f.write(raw)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)
    return {"type": _type_of(safe_name), "path": remote_path, "name": safe_name, "size": len(raw)}


async def _view_attachment(fid: str, path: str):
    prefix = f"{fid}/chat_attachments/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{fid}/chat_attachments/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="附件不存在")
    local = f"/tmp/fam_view_{uuid.uuid4().hex}"
    await webdav_service.download_file(remote, local)
    media = _media_type(rel)
    if media.startswith("image/"):
        return FileResponse(local, media_type=media)
    return FileResponse(local, media_type=media, filename=os.path.basename(rel))


# ---------------- 家庭群聊 ----------------

@router.get("/chat")
async def family_chat(db=Depends(get_db), current_user=Depends(get_current_user)):
    fid = _family_of(current_user)
    data = await webdav_service.read_json(_chat_file(fid), {"messages": []})
    return data.get("messages", [])


@router.post("/chat")
async def send_family_chat(
    body: ChatBody,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    content = body.content.strip()
    if not content and not body.attachments:
        raise HTTPException(status_code=400, detail="内容不能为空")
    msg = {
        "id": f"fm_{uuid.uuid4().hex[:10]}",
        "sender_id": current_user["id"],
        "sender_name": await _display_name(current_user, db),
        "sender_role": current_user["role"],
        "content": content,
        "attachments": [a.model_dump() for a in body.attachments],
        "created_at": _now(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(_chat_file(fid), _mutate, {"messages": []})
    return msg


@router.post("/chat/attachment")
async def upload_chat_attachment(
    file: UploadFile = File(...),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    return await _upload_attachment(fid, file)


@router.get("/chat/attachment")
async def view_chat_attachment(
    path: str,
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    return await _view_attachment(fid, path)


# ---------------- 家庭私聊（家长↔家长、家长↔孩子） ----------------

@router.get("/p2p/{user_id}")
async def p2p_chat(
    user_id: int,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    cur = await db.execute("SELECT id FROM users WHERE id = ? AND family_id = ?", (user_id, fid))
    if await cur.fetchone() is None:
        raise HTTPException(status_code=403, detail="对方不在本家庭")
    key = _p2p_key(fid, current_user["id"], user_id)
    data = await webdav_service.read_json(key, {"messages": []})
    return data.get("messages", [])


@router.post("/p2p/{user_id}")
async def send_p2p(
    user_id: int,
    body: ChatBody,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    cur = await db.execute("SELECT id FROM users WHERE id = ? AND family_id = ?", (user_id, fid))
    if await cur.fetchone() is None:
        raise HTTPException(status_code=403, detail="对方不在本家庭")
    content = body.content.strip()
    if not content and not body.attachments:
        raise HTTPException(status_code=400, detail="内容不能为空")
    msg = {
        "id": f"pm_{uuid.uuid4().hex[:10]}",
        "sender_id": current_user["id"],
        "sender_name": await _display_name(current_user, db),
        "sender_role": current_user["role"],
        "content": content,
        "attachments": [a.model_dump() for a in body.attachments],
        "created_at": _now(),
    }
    key = _p2p_key(fid, current_user["id"], user_id)

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(key, _mutate, {"messages": []})
    return msg


@router.post("/p2p/{user_id}/attachment")
async def upload_p2p_attachment(
    user_id: int,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    cur = await db.execute("SELECT id FROM users WHERE id = ? AND family_id = ?", (user_id, fid))
    if await cur.fetchone() is None:
        raise HTTPException(status_code=403, detail="对方不在本家庭")
    return await _upload_attachment(fid, file)


@router.get("/p2p/{user_id}/attachment")
async def view_p2p_attachment(
    user_id: int,
    path: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    fid = _family_of(current_user)
    cur = await db.execute("SELECT id FROM users WHERE id = ? AND family_id = ?", (user_id, fid))
    if await cur.fetchone() is None:
        raise HTTPException(status_code=403, detail="对方不在本家庭")
    return await _view_attachment(fid, path)
