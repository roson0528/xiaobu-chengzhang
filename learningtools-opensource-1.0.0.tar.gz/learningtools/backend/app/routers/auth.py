import aiosqlite
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.core.deps import get_current_user, get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.redis_client import get_redis

router = APIRouter(prefix="/api/v1/auth", tags=["认证"])


class RegisterBody(BaseModel):
    username: str
    password: str
    email: str | None = None
    phone: str | None = None


class LoginBody(BaseModel):
    username: str
    password: str
    device_id: str | None = None  # 可选：设备标识（用于单设备登录）


class RefreshBody(BaseModel):
    refresh_token: str


class ChangePasswordBody(BaseModel):
    old_password: str
    new_password: str


@router.post("/register")
async def register(body: RegisterBody, db=Depends(get_db)):
    if len(body.password) < 6:
        raise HTTPException(status_code=400, detail="密码至少 6 位")
    exists = await db.execute("SELECT id FROM users WHERE username = ?", (body.username,))
    if await exists.fetchone():
        raise HTTPException(status_code=400, detail="用户名已存在")
    cur = await db.execute(
        "INSERT INTO users (username, password_hash, role, email, phone, status, family_id) "
        "VALUES (?, ?, 'parent', ?, ?, 'pending', ?)",
        (body.username, hash_password(body.password), body.email, body.phone,
         f"fam_{uuid.uuid4().hex[:12]}"),
    )
    await db.commit()
    return {"id": cur.lastrowid, "username": body.username, "status": "pending",
            "message": "注册成功，等待管理员审批"}


@router.post("/login")
async def login(body: LoginBody, db=Depends(get_db)):
    cur = await db.execute("SELECT * FROM users WHERE username = ?", (body.username,))
    row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    user = dict(row)

    # 老账号无 family_id 时懒补齐，保证家庭功能可用
    if not user.get("family_id"):
        await db.execute(
            "UPDATE users SET family_id = ? WHERE id = ?",
            (f"fam_{uuid.uuid4().hex[:12]}", user["id"]),
        )
        await db.commit()
        user["family_id"] = (await (await db.execute(
            "SELECT family_id FROM users WHERE id = ?", (user["id"],)
        )).fetchone())[0]

    if user.get("locked_until"):
        try:
            if datetime.fromisoformat(user["locked_until"]) > datetime.now(timezone.utc):
                raise HTTPException(status_code=423, detail="账号已锁定，请稍后再试")
        except ValueError:
            pass

    if not verify_password(body.password, user["password_hash"]):
        failed = user["failed_attempts"] + 1
        locked_until = None
        if failed >= 5:
            locked_until = (datetime.now(timezone.utc) + timedelta(minutes=15)).isoformat()
            failed = 0
        await db.execute(
            "UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?",
            (failed, locked_until, user["id"]),
        )
        await db.commit()
        raise HTTPException(status_code=401, detail="用户名或密码错误")

    if user["status"] == "pending":
        raise HTTPException(status_code=403, detail="账号待审批")
    if user["status"] in ("rejected", "disabled"):
        raise HTTPException(status_code=403, detail="账号已禁用或拒绝")

    await db.execute(
        "UPDATE users SET failed_attempts = 0, locked_until = NULL, last_login = ? WHERE id = ?",
        (datetime.now(timezone.utc).isoformat(), user["id"]),
    )
    await db.commit()

    sid = None
    if user["role"] == "child" and settings.single_device_login:
        sid = uuid.uuid4().hex
        r = get_redis()
        await r.set(f"child_sid:{user['id']}", sid)
    access = create_access_token(user["id"], user["role"], sid=sid)
    refresh = create_refresh_token(user["id"], sid=sid)
    return {
        "access_token": access,
        "refresh_token": refresh,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "username": user["username"],
            "nickname": user.get("nickname") or "",
            "role": user["role"],
            "status": user["status"],
        },
    }


@router.post("/refresh")
async def refresh(body: RefreshBody):
    try:
        payload = decode_token(body.refresh_token)
    except Exception:
        raise HTTPException(status_code=401, detail="refresh token 无效或已过期")
    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="token 类型错误")
    user_id = int(payload.get("sub"))
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="用户不存在")
    user = dict(row)
    if user["status"] != "active":
        raise HTTPException(status_code=403, detail="账号不可用")
    sid = payload.get("sid")
    if sid:
        r = get_redis()
        current = await r.get(f"child_sid:{user_id}")
        if current != sid:
            raise HTTPException(status_code=401, detail="已在其他设备登录，请重新登录")
    return {
        "access_token": create_access_token(user["id"], user["role"], sid=sid),
        "token_type": "bearer",
    }


@router.post("/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    # JWT 无状态，登出由客户端丢弃 token 即可
    return {"status": "ok"}


class ProfileBody(BaseModel):
    nickname: str | None = None


@router.get("/me")
async def me(current_user: dict = Depends(get_current_user)):
    return {
        "id": current_user["id"],
        "username": current_user["username"],
        "nickname": current_user.get("nickname") or "",
        "role": current_user["role"],
        "email": current_user["email"],
        "phone": current_user["phone"],
        "status": current_user["status"],
        "family_id": current_user["family_id"],
    }


@router.put("/me")
async def update_me(
    body: ProfileBody,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db),
):
    """更新个人资料（昵称等）。"""
    fields = {}
    if body.nickname is not None:
        fields["nickname"] = body.nickname.strip()
    if fields:
        sets = ", ".join(f"{k} = ?" for k in fields)
        vals = list(fields.values()) + [current_user["id"]]
        await db.execute(f"UPDATE users SET {sets} WHERE id = ?", vals)
        await db.commit()
    return {"status": "ok"}


@router.post("/change-password")
async def change_password(
    body: ChangePasswordBody,
    current_user: dict = Depends(get_current_user),
    db=Depends(get_db),
):
    if not verify_password(body.old_password, current_user["password_hash"]):
        raise HTTPException(status_code=400, detail="原密码错误")
    if len(body.new_password) < 6:
        raise HTTPException(status_code=400, detail="新密码至少 6 位")
    await db.execute(
        "UPDATE users SET password_hash = ? WHERE id = ?",
        (hash_password(body.new_password), current_user["id"]),
    )
    await db.commit()
    return {"status": "ok"}
