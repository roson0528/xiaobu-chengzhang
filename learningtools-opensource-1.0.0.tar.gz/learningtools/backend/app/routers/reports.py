import os
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.report_service import report_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/reports", tags=["报告"])


def _previous_iso_week() -> str:
    d = date.today() - timedelta(days=7)
    iso = d.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


@router.get("/{child_id}/celebration")
async def celebration(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    """孩子端「本周成长回顾」：返回上周周报是否已生成及摘要。"""
    await get_child(child_id, current_user, db)
    last_week = _previous_iso_week()
    report = await webdav_service.read_json(f"{child_id}/reports/weekly_{last_week}.json", {})
    has = bool(report)
    return {
        "has_report": has,
        "week": last_week,
        "summary": report.get("summary", {}) if has else {},
    }


@router.get("/{child_id}/weekly/{week}")
async def get_weekly_report(child_id: str, week: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    report = await webdav_service.read_json(
        f"{child_id}/reports/weekly_{week}.json", {}
    )
    if not report:
        report = await report_service.generate_weekly_report(child_id, week)
    return report


@router.get("/{child_id}/monthly/{month}")
async def get_monthly_report(child_id: str, month: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    report = await webdav_service.read_json(
        f"{child_id}/reports/monthly_{month}.json", {}
    )
    if not report:
        report = await report_service.generate_monthly_report(child_id, month)
    return report


@router.post("/{child_id}/generate")
async def generate_report(
    child_id: str,
    week: str | None = None,
    month: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    if week:
        return await report_service.generate_weekly_report(child_id, week)
    if month:
        return await report_service.generate_monthly_report(child_id, month)
    raise HTTPException(status_code=400, detail="需指定 week 或 month")


@router.get("/{child_id}/export/pdf")
async def export_pdf(
    child_id: str,
    week: str | None = None,
    month: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    if week:
        report = await report_service.generate_weekly_report(child_id, week)
    elif month:
        report = await report_service.generate_monthly_report(child_id, month)
    else:
        raise HTTPException(status_code=400, detail="需指定 week 或 month")
    pdf_path = await report_service.export_pdf(child_id, report)
    return FileResponse(pdf_path, media_type="application/pdf", filename=os.path.basename(pdf_path))
