from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_current_user, get_db, require_role
from app.core.security import hash_password
from app.database import add_audit_log

router = APIRouter(prefix="/api/v1/users", tags=["用户管理"])


class UpdateUserBody(BaseModel):
    email: str | None = None
    phone: str | None = None
    family_id: str | None = None


class RoleBody(BaseModel):
    role: str


class QuotaBody(BaseModel):
    quota_gb: int


def _admin_dep():
    return require_role("super_admin", "family_admin")


@router.get("")
async def list_users(db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("SELECT * FROM users ORDER BY id")
    rows = await cur.fetchall()
    users = []
    for r in rows:
        u = dict(r)
        u.pop("password_hash", None)
        users.append(u)
    return users


@router.get("/{user_id}")
async def get_user(user_id: int, db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    row = await cur.fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="用户不存在")
    u = dict(row)
    u.pop("password_hash", None)
    return u


@router.put("/{user_id}")
async def update_user(
    user_id: int, body: UpdateUserBody, db=Depends(get_db), current_user=Depends(_admin_dep())
):
    cur = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    if await cur.fetchone() is None:
        raise HTTPException(status_code=404, detail="用户不存在")
    fields = []
    vals = []
    for k, v in body.dict(exclude_none=True).items():
        fields.append(f"{k} = ?")
        vals.append(v)
    if fields:
        vals.append(user_id)
        await db.execute(f"UPDATE users SET {', '.join(fields)} WHERE id = ?", vals)
        await db.commit()
    return {"status": "ok"}


@router.delete("/{user_id}")
async def delete_user(user_id: int, db=Depends(get_db), current_user=Depends(require_role("super_admin"))):
    if user_id == current_user["id"]:
        raise HTTPException(status_code=400, detail="不能删除自己")
    cur = await db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:delete", str(user_id))
    return {"status": "ok"}


@router.post("/{user_id}/approve")
async def approve_user(user_id: int, db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("UPDATE users SET status = 'active' WHERE id = ?", (user_id,))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:approve", str(user_id))
    return {"status": "ok"}


@router.post("/{user_id}/reject")
async def reject_user(user_id: int, db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("UPDATE users SET status = 'rejected' WHERE id = ?", (user_id,))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:reject", str(user_id))
    return {"status": "ok"}


@router.post("/{user_id}/disable")
async def disable_user(user_id: int, db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("UPDATE users SET status = 'disabled' WHERE id = ?", (user_id,))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:disable", str(user_id))
    return {"status": "ok"}


@router.post("/{user_id}/enable")
async def enable_user(user_id: int, db=Depends(get_db), current_user=Depends(_admin_dep())):
    cur = await db.execute("UPDATE users SET status = 'active' WHERE id = ?", (user_id,))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:enable", str(user_id))
    return {"status": "ok"}


@router.put("/{user_id}/quota")
async def set_user_quota(
    user_id: int,
    body: QuotaBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin")),
):
    """管理员设置家长账号的可用存储空间（单位 GB）。"""
    if body.quota_gb < 0:
        raise HTTPException(status_code=400, detail="存储空间不能为负数")
    cur = await db.execute("UPDATE users SET quota_gb = ? WHERE id = ?", (body.quota_gb, user_id))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:quota", str(user_id), str(body.quota_gb))
    return {"status": "ok", "quota_gb": body.quota_gb}


@router.put("/{user_id}/role")
async def change_role(
    user_id: int,
    body: RoleBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin")),
):
    allowed = {"super_admin", "family_admin", "parent", "child", "guest"}
    if body.role not in allowed:
        raise HTTPException(status_code=400, detail="非法角色")
    cur = await db.execute("UPDATE users SET role = ? WHERE id = ?", (body.role, user_id))
    await db.commit()
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="用户不存在")
    await add_audit_log(str(current_user["id"]), "user:role", str(user_id), body.role)
    return {"status": "ok"}
