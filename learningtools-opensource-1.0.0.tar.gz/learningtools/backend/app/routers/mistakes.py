import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/mistakes", tags=["错题"])


def _month() -> str:
    return datetime.now().strftime("%Y-%m")


class MistakeBody(BaseModel):
    subject: str
    content: str
    photo_path: str | None = None
    answer: str | None = None
    mastery: int = 0


@router.post("/{child_id}")
async def add_mistake(
    child_id: str,
    body: MistakeBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    record = body.dict()
    record["id"] = f"mistake_{uuid.uuid4().hex[:10]}"
    record["created_at"] = datetime.now().isoformat()
    record["last_reviewed"] = None

    def _mutate(data: dict) -> dict:
        data.setdefault("records", [])
        data["records"].append(record)
        return data

    await webdav_service.mutate_json(f"{child_id}/mistakes/{_month()}.json", _mutate, {"records": []})
    return record


@router.get("/{child_id}")
async def list_mistakes(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/mistakes/{_month()}.json", {"records": []})
    return data.get("records", [])


async def _mutate_mistake(child_id: str, mistake_id: str, mutate_fn) -> None:
    data = await webdav_service.read_json(f"{child_id}/mistakes/{_month()}.json", {"records": []})
    found = False
    for r in data.get("records", []):
        if r.get("id") == mistake_id:
            found = True
            mutate_fn(r)
    if not found:
        raise HTTPException(status_code=404, detail="错题不存在")
    await webdav_service.write_json(f"{child_id}/mistakes/{_month()}.json", data)


@router.put("/{mistake_id}")
async def update_mistake(
    mistake_id: str,
    child_id: str,
    body: MistakeBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    updates = {k: v for k, v in body.dict().items() if v is not None}
    await _mutate_mistake(child_id, mistake_id, lambda r: r.update(updates))
    return {"status": "ok"}


@router.delete("/{mistake_id}")
async def delete_mistake(
    mistake_id: str,
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/mistakes/{_month()}.json", {"records": []})
    before = len(data.get("records", []))
    data["records"] = [r for r in data.get("records", []) if r.get("id") != mistake_id]
    if len(data["records"]) == before:
        raise HTTPException(status_code=404, detail="错题不存在")
    await webdav_service.write_json(f"{child_id}/mistakes/{_month()}.json", data)
    return {"status": "ok"}


@router.post("/{mistake_id}/review")
async def review_mistake(
    mistake_id: str,
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    await _mutate_mistake(
        child_id,
        mistake_id,
        lambda r: r.update({"mastery": r.get("mastery", 0) + 1, "last_reviewed": datetime.now().isoformat()}),
    )
    return {"status": "ok"}
