import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/diary", tags=["教育日记"])

_PARENT_ROLES = ("super_admin", "family_admin", "parent")


class DiaryBody(BaseModel):
    date: str  # YYYY-MM-DD
    growth: str = ""  # 成长状态
    homework: str = ""  # 作业完成情况
    problems: str = ""  # 学习问题/不足
    mood: str = ""  # happy / ok / tired
    note: str = ""  # 其他备注


class DiaryUpdateBody(BaseModel):
    date: str | None = None
    growth: str | None = None
    homework: str | None = None
    problems: str | None = None
    mood: str | None = None
    note: str | None = None


async def _load_entries(child_id: str) -> dict:
    return await webdav_service.read_json(f"{child_id}/diary.json", {"entries": []})


@router.post("/{child_id}")
async def create_diary(
    child_id: str,
    body: DiaryBody,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    entry = body.dict()
    entry["id"] = f"diary_{uuid.uuid4().hex[:10]}"
    entry["created_at"] = datetime.now().isoformat()
    entry["updated_at"] = entry["created_at"]

    def _mutate(data: dict) -> dict:
        data.setdefault("entries", []).append(entry)
        return data

    await webdav_service.mutate_json(f"{child_id}/diary.json", _mutate, {"entries": []})
    return entry


@router.get("/{child_id}")
async def list_diary(
    child_id: str,
    month: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    data = await _load_entries(child_id)
    entries = data.get("entries", [])
    if month:
        entries = [e for e in entries if str(e.get("date", "")).startswith(month)]
    entries.sort(key=lambda e: e.get("date", ""), reverse=True)
    return entries


@router.put("/{child_id}/{entry_id}")
async def update_diary(
    child_id: str,
    entry_id: str,
    body: DiaryUpdateBody,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    updates = {k: v for k, v in body.dict().items() if v is not None}
    found = False

    def _mutate(data: dict) -> dict:
        nonlocal found
        for e in data.get("entries", []):
            if e.get("id") == entry_id:
                e.update(updates)
                e["updated_at"] = datetime.now().isoformat()
                found = True
        return data

    await webdav_service.mutate_json(f"{child_id}/diary.json", _mutate, {"entries": []})
    if not found:
        raise HTTPException(status_code=404, detail="日记不存在")
    return {"status": "ok"}


@router.delete("/{child_id}/{entry_id}")
async def delete_diary(
    child_id: str,
    entry_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    found = False

    def _mutate(data: dict) -> dict:
        nonlocal found
        before = len(data.get("entries", []))
        data["entries"] = [e for e in data.get("entries", []) if e.get("id") != entry_id]
        found = len(data["entries"]) != before
        return data

    await webdav_service.mutate_json(f"{child_id}/diary.json", _mutate, {"entries": []})
    if not found:
        raise HTTPException(status_code=404, detail="日记不存在")
    return {"status": "ok"}
