import logging
import os
import uuid
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.redis_client import get_redis
from app.routers.tasks import _find_task as _find_task_in_plans
from app.services.focus_monitor import focus_monitor
from app.services.netcontrol_service import (
    FOCUS_HEARTBEAT_GRACE_MINUTES,
    FOCUS_MAX_MINUTES,
    GRANT_FOCUS,
    netcontrol_service,
)
from app.services.notification_service import notification_service
from app.services.quota_service import quota_service
from app.services.serverchan import serverchan
from app.services.webdav_service import webdav_service

logger = logging.getLogger("learningtools.focus")

router = APIRouter(prefix="/api/v1/focus", tags=["专注"])


async def _grant_focus_net(child_id: str, minutes: int, note: str = "专注模式",
                          task_name: str = "") -> None:
    """专注模式期间放开管控设备的外网权限。

    管控本身是路由器的职责，这里只写「放行窗口」。任何异常都不得影响专注功能本身。
    """
    try:
        await netcontrol_service.add_grant(
            GRANT_FOCUS,
            minutes=minutes if minutes and minutes > 0 else FOCUS_HEARTBEAT_GRACE_MINUTES,
            child_id=child_id,
            note=note,
            cap_minutes=FOCUS_MAX_MINUTES,
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("专注放行写入失败 child=%s: %s", child_id, e)
    # 放行窗口写好了，但设备可能正被「一键断网 / 管控停用」挡着 ——
    # 这种时候孩子的表现只是「网打不开」，光看现象根本找不到原因
    # （2026-10-07 令牌失效、10-08 一键断网，连续两次都卡在这里），所以主动提醒家长。
    await _alert_if_net_blocked(child_id, task_name)


async def _alert_if_net_blocked(child_id: str, task_name: str) -> None:
    """「需要联网」的任务开跑，但设备被挡住时，给家长推一条提醒（10 分钟内只发一次）。"""
    try:
        info = await netcontrol_service.effective_for_child(child_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("查询管控状态失败 child=%s: %s", child_id, e)
        return
    if info.get("action") != "block":
        return
    try:
        r = get_redis()
        if not await r.set(f"throttle:netblocked:{child_id}", "1", nx=True, ex=600):
            return
    except Exception:  # noqa: BLE001
        pass
    name = task_name or "需要联网的任务"
    reason = info.get("reason") or "管控策略"
    content = (
        f"## 孩子正被断网挡住\n\n"
        f"**任务**: {name}\n\n"
        f"**设备**: {info.get('device_name') or '管控设备'}\n\n"
        f"**当前策略**: {reason}（此项优先于专注模式的联网放行）\n\n"
        f"**结果**: 孩子做这个任务时打不开网页/加载不了内容。\n\n"
        f"**处理**: 在家长端「网络管控」里点「恢复正常管控」，或改用限时放行。\n"
    )
    try:
        await notification_service.notify_parents(
            child_id, f"⚠️ {name} 被断网挡住了", content, kind="netcontrol"
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("站内提醒失败 child=%s: %s", child_id, e)
    try:
        await serverchan.send_notification(title=f"⚠️ {name} 被断网挡住了", content=content)
    except Exception as e:  # noqa: BLE001
        logger.warning("微信提醒失败 child=%s: %s", child_id, e)


async def _revoke_focus_net(child_id: str) -> None:
    try:
        await netcontrol_service.clear_grant(GRANT_FOCUS, child_id=child_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("专注放行撤销失败 child=%s: %s", child_id, e)



async def _load_sessions(child_id: str) -> dict:
    return await webdav_service.read_json(f"{child_id}/focus/sessions.json", {"sessions": []})


async def _find_plan_task(child_id: str, task_id: str) -> dict | None:
    """按 task_id 查找任务/作业对象。

    作业（task_type=作业）与普通任务存放在同一份周计划文件里，因此这里一并覆盖。

    注意：**必须在所有周计划文件里找**，不能只看本周和上周 ——
    循环任务（每天/每周）的主记录一直留在它被创建的那一周，
    而孩子端每天点开的仍然是同一个 task_id（例如「英语打卡」创建于 3 周前）。
    只看近两周会找不到任务 → need_network 退化成 False → 平板被断网。
    这里直接复用任务模块的跨周查找 `_find_task`（当前周优先），与其它接口口径一致。
    """
    if not task_id:
        return None
    try:
        return await _find_task_in_plans(child_id, task_id)
    except Exception as e:  # noqa: BLE001
        logger.warning("查找任务失败 child=%s task=%s: %s", child_id, task_id, e)
        return None


def _is_live(session: dict, now: datetime) -> bool:
    """会话是否「还活着」：状态 active 且最近（宽限期内）有过开始/心跳。

    历史遗留的 active 会话（APP 被杀、没走 stop）不能算数 ——
    否则一条老旧的「需要联网」会话会让平板一直联网。
    """
    if session.get("status") != "active":
        return False
    stamp = session.get("last_heartbeat_at") or session.get("started_at")
    if not stamp:
        return False
    try:
        last = datetime.fromisoformat(str(stamp))
    except ValueError:
        return False
    return now - last <= timedelta(minutes=FOCUS_HEARTBEAT_GRACE_MINUTES)


def _task_needs_network(task: dict | None) -> bool:
    """任务/作业是否勾选了「需要联网」。

    默认 False —— 没勾选、找不到任务（自由专注）时，专注期间都不放开外网。
    """
    return bool(task.get("need_network")) if task else False


@router.post("/{child_id}/start")
async def start_focus(
    child_id: str,
    task_id: str = Form(""),
    duration_minutes: int = Form(0),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    task = await _find_plan_task(child_id, task_id)
    need_network = _task_needs_network(task)
    now = datetime.now()
    session = {
        "id": f"focus_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:4]}",
        "child_id": child_id,
        "started_at": datetime.now().isoformat(),
        "ended_at": None,
        "duration": 0,
        "planned_minutes": max(0, duration_minutes),
        "last_heartbeat_at": datetime.now().isoformat(),
        "task_id": task_id,
        "task_name": (task.get("title") if task else None) or "自由任务",
        # 本次专注是否放开外网：由发布任务/作业时的「需要联网」决定
        "need_network": need_network,
        "distraction_count": 0,
        "photo_count": 0,
        "status": "active",
        "events": [],
        "photos": [],
        "videos": [],
    }

    def _mutate(data: dict) -> dict:
        sessions = data.setdefault("sessions", [])
        # 顺手收掉历史遗留的 active 会话（APP 被杀没走 stop），避免状态越积越乱
        for s in sessions:
            if s.get("status") == "active" and not _is_live(s, now):
                s["status"] = "ended"
                s["ended_at"] = s.get("last_heartbeat_at") or s.get("started_at")
        sessions.append(session)
        return data

    await webdav_service.mutate_json(f"{child_id}/focus/sessions.json", _mutate, {"sessions": []})
    if need_network:
        # 任务/作业勾选了「需要联网」→ 专注期间放开管控设备的外网权限
        await _grant_focus_net(
            child_id, duration_minutes, "专注模式", task_name=session["task_name"]
        )
    else:
        # 未勾选 → 专注期间不允许上网，同时清掉可能残留的上一次放行
        await _revoke_focus_net(child_id)
    return session


@router.post("/{child_id}/heartbeat")
async def focus_heartbeat(
    child_id: str,
    session_id: str = Form(""),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """专注会话心跳：维持放行窗口，APP 被杀后窗口会在宽限期后自动失效。"""
    await get_child(child_id, current_user, db)
    now = datetime.now()
    found = {"ok": False, "net": False}

    def _mutate(data: dict) -> dict:
        sessions = data.get("sessions", [])
        for s in sessions:
            if s.get("status") == "active" and (not session_id or s.get("id") == session_id):
                s["last_heartbeat_at"] = now.isoformat()
                found["ok"] = True
                break
        # 只要还有「还活着且需要联网」的专注在进行中，就续期；否则明确收回
        found["net"] = any(_is_live(s, now) and s.get("need_network") for s in sessions)
        return data

    await webdav_service.mutate_json(f"{child_id}/focus/sessions.json", _mutate, {"sessions": []})
    if found["ok"]:
        if found["net"]:
            await _grant_focus_net(child_id, FOCUS_HEARTBEAT_GRACE_MINUTES, "专注模式")
        else:
            await _revoke_focus_net(child_id)
    return {"status": "ok", "active": found["ok"], "network": found["net"]}



@router.post("/{child_id}/stop")
async def stop_focus(
    child_id: str,
    session_id: str = Form(""),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)

    def _mutate(data: dict) -> dict:
        for s in data.get("sessions", []):
            if s.get("status") == "active" and (not session_id or s.get("id") == session_id):
                s["status"] = "ended"
                s["ended_at"] = datetime.now().isoformat()
                try:
                    start = datetime.fromisoformat(s["started_at"])
                    s["duration"] = int((datetime.now() - start).total_seconds())
                except Exception:
                    pass
        return data

    await webdav_service.mutate_json(f"{child_id}/focus/sessions.json", _mutate, {"sessions": []})
    # 专注结束 → 立即撤销放行
    await _revoke_focus_net(child_id)
    return {"status": "ok"}


@router.post("/{child_id}/event")
async def report_event(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
    type: str = Form(...),
    timestamp: str = Form(""),
    session_id: str = Form(""),
):
    child = await get_child(child_id, current_user, db)
    event = {
        "type": type,
        "timestamp": timestamp or datetime.now().isoformat(),
        "session_id": session_id,
    }

    def _mutate(data: dict) -> dict:
        for s in data.get("sessions", []):
            if s.get("id") == session_id:
                s.setdefault("events", []).append(event)
                s["distraction_count"] = len(s.get("events", []))
        return data

    await webdav_service.mutate_json(f"{child_id}/focus/sessions.json", _mutate, {"sessions": []})
    await focus_monitor.process_event(child_id, child.get("name"), event)
    return {"status": "ok"}


@router.post("/upload")
async def upload_focus_photo(
    child_id: str = Form(...),
    file: UploadFile = File(...),
    timestamp: str = Form(""),
    session_id: str = Form(""),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    child = await get_child(child_id, current_user, db)

    raw = await file.read()
    compressed = quota_service.compress_bytes(raw)
    await quota_service.check_and_reserve(child_id, db, len(compressed))

    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = now.strftime("%H-%M-%S") + ".jpg"
    remote_path = f"{child_id}/focus/{date_dir}/{fname}"

    local_tmp = f"/tmp/focus_{uuid.uuid4().hex}.jpg"
    with open(local_tmp, "wb") as f:
        f.write(compressed)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    # 更新会话照片计数与照片列表
    if session_id:
        photo_rel = f"{date_dir}/{fname}"

        def _mutate(data: dict) -> dict:
            for s in data.get("sessions", []):
                if s.get("id") == session_id:
                    s["photo_count"] = s.get("photo_count", 0) + 1
                    s.setdefault("photos", []).append(photo_rel)
            return data
        await webdav_service.mutate_json(
            f"{child_id}/focus/sessions.json", _mutate, {"sessions": []}
        )

    return {"path": remote_path, "size": len(compressed)}


@router.post("/video/upload")
async def upload_focus_video(
    child_id: str = Form(...),
    file: UploadFile = File(...),
    timestamp: str = Form(""),
    session_id: str = Form(""),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """专注模式录像上传：存入孩子 focus 目录，并登记到对应会话的 videos 列表。"""
    await get_child(child_id, current_user, db)

    raw = await file.read()
    await quota_service.check_and_reserve(child_id, db, len(raw))

    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = now.strftime("%H-%M-%S") + ".mp4"
    remote_path = f"{child_id}/focus/{date_dir}/{fname}"

    local_tmp = f"/tmp/focus_video_{uuid.uuid4().hex}.mp4"
    with open(local_tmp, "wb") as f:
        f.write(raw)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    if session_id:
        video_rel = f"{date_dir}/{fname}"

        def _mutate(data: dict) -> dict:
            for s in data.get("sessions", []):
                if s.get("id") == session_id:
                    s.setdefault("videos", []).append(video_rel)
            return data
        await webdav_service.mutate_json(
            f"{child_id}/focus/sessions.json", _mutate, {"sessions": []}
        )

    return {"path": remote_path, "size": len(raw)}


@router.get("/{child_id}/sessions")
async def list_sessions(
    child_id: str,
    date: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """专注会话列表：按日期归档，date 传 YYYY-MM-DD 可查某天会话（缺省查全部）。"""
    await get_child(child_id, current_user, db)
    data = await _load_sessions(child_id)
    sessions = data.get("sessions", [])
    if date:
        sessions = [s for s in sessions if str(s.get("started_at") or "").startswith(date)]
    sessions.sort(key=lambda s: str(s.get("started_at") or ""), reverse=True)
    # 兼容旧会话：缺少 task_name 时按 task_id 补全，便于后台「会话」列显示任务名。
    # 跨周查找有 IO 开销，这里按 task_id 去重缓存，避免同一条任务被反复扫描周计划。
    title_cache: dict[str, str] = {}
    for s in sessions:
        if not s.get("task_name") and s.get("task_id"):
            tid = s["task_id"]
            if tid not in title_cache:
                t = await _find_plan_task(child_id, tid)
                title_cache[tid] = (t.get("title") if t else None) or "自由任务"
            s["task_name"] = title_cache[tid]
    return sessions


_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}


def _is_image(name: str) -> bool:
    return any(name.lower().endswith(ext) for ext in _IMAGE_EXTS)


@router.get("/{child_id}/photos")
async def list_photos(
    child_id: str,
    date: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    if date:
        files = await webdav_service.list_files(f"{child_id}/focus/{date}")
        # 只返回图片文件（date/filename），过滤可能的非图片文件
        return [f"{date}/{f}" for f in files if isinstance(f, str) and _is_image(f)]
    files = await webdav_service.list_files(f"{child_id}/focus")
    # 未选日期时只返回日期子目录（以 / 结尾），隐藏 sessions.json / annotations.json 等数据文件
    return [f for f in files if isinstance(f, str) and f.endswith("/")]


@router.get("/{child_id}/photo")
async def get_photo(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent", "child")),
):
    """查看/下载专注照片（照片路径形如 2026-09-11/09-00-00.jpg）。"""
    await get_child(child_id, current_user, db)
    if ".." in path or path.startswith("/") or "\\" in path:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/focus/{path}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="照片不存在")
    local = f"/tmp/focus_view_{uuid.uuid4().hex}.jpg"
    await webdav_service.download_file(remote, local)
    return FileResponse(local, media_type="image/jpeg")


@router.delete("/photos")
async def delete_photo(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    # path 形如 date/fname，需防目录穿越
    if ".." in path or path.startswith("/") or "\\" in path:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/focus/{path}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="照片不存在")
    size = await webdav_service.get_size(remote)
    await webdav_service.delete(remote)
    if size:
        await quota_service.release(child_id, size / (1024 * 1024))
    return {"status": "ok"}


# ---------------- 专注照片「分心」标注 ----------------

class AnnotateBody(BaseModel):
    path: str
    distracted: bool = True
    note: str | None = None


@router.post("/{child_id}/photo/annotate")
async def annotate_photo(
    child_id: str,
    body: AnnotateBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """家长给专注照片标注「分心」，用于学习报告的分心次数统计。"""
    await get_child(child_id, current_user, db)
    annotation = {
        "path": body.path,
        "distracted": body.distracted,
        "note": body.note or "",
        "marked_at": datetime.now().isoformat(),
        "marked_by": current_user.get("username", ""),
    }

    def _mutate(data: dict) -> dict:
        items = data.setdefault("items", [])
        # 同一张照片覆盖式更新
        items = [a for a in items if a.get("path") != body.path]
        items.append(annotation)
        data["items"] = items
        return data

    await webdav_service.mutate_json(f"{child_id}/focus/annotations.json", _mutate, {"items": []})
    return {"status": "ok"}


@router.get("/{child_id}/annotations")
async def list_annotations(
    child_id: str, db=Depends(get_db), current_user=Depends(require_role("super_admin", "family_admin", "parent"))
):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/focus/annotations.json", {"items": []})
    return data.get("items", [])
