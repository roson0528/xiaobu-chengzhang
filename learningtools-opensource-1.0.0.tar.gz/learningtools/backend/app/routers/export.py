import json
import os
import shutil
import tempfile
import zipfile
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.database import add_audit_log
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/export", tags=["导出"])


class DateRangeBody(BaseModel):
    start: str
    end: str


COLLECTIONS = ["checkins", "fitness", "reading", "mistakes"]

# 参与打包的媒体目录（相对孩子根目录）
MEDIA_DIRS = ["focus", "submissions/photos", "checkins/audio", "videos"]


async def _collect_files(prefix: str) -> list[str]:
    """递归列出 prefix 下所有文件（返回相对 prefix 的路径，含子目录）。"""
    result: list[str] = []

    async def walk(rel: str) -> None:
        remote = f"{prefix}/{rel}" if rel else prefix
        items = await webdav_service.list_files(remote)
        for it in items:
            if not isinstance(it, str) or not it:
                continue
            if it.endswith("/"):
                child = f"{rel}/{it.rstrip('/')}" if rel else it.rstrip("/")
                await walk(child)
            else:
                result.append(f"{rel}/{it}" if rel else it)

    await walk("")
    return result


async def _collect(child_id: str) -> dict:
    result: dict = {"child_id": child_id, "exported_at": datetime.now().isoformat()}
    result["points"] = await webdav_service.read_json(f"{child_id}/rewards/points.json", {})
    result["badges"] = await webdav_service.read_json(f"{child_id}/rewards/badges.json", {})
    result["messages"] = await webdav_service.read_json(f"{child_id}/messages.json", {})
    result["plans"] = {}
    files = await webdav_service.list_files(f"{child_id}/plans")
    for f in files:
        if isinstance(f, str) and f.endswith(".json"):
            name = f.rstrip("/")
            result["plans"][name] = await webdav_service.read_json(f"{child_id}/plans/{name}", {})
    return result


@router.post("/{child_id}/all")
async def export_all(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    data = await _collect(child_id)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"{child_id}/reports/export_{ts}.json"
    await webdav_service.write_json(path, data)
    await add_audit_log(str(current_user["id"]), "export:all", child_id)
    return {"path": path, "data": data}


@router.post("/{child_id}/date-range")
async def export_range(
    child_id: str,
    body: DateRangeBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    data = await _collect(child_id)
    # 按日期范围过滤月度集合（粗过滤：保留文件名在范围内的记录）
    result = {"child_id": child_id, "range": {"start": body.start, "end": body.end}, "data": data}
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = f"{child_id}/reports/export_{ts}_range.json"
    await webdav_service.write_json(path, result)
    return {"path": path}


class ZipBody(BaseModel):
    part_size_mb: int = 0  # 0 = 单个 ZIP；>0 = 按该大小分卷


def _write_zip(staging: str, zip_path: str) -> int:
    """把 staging 目录打包为 zip，返回压缩包字节数。"""
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(staging):
            for name in files:
                full = os.path.join(root, name)
                arc = os.path.relpath(full, staging)
                zf.write(full, arc)
    return os.path.getsize(zip_path)


def _split_staging(staging: str, part_size_bytes: int) -> list[list[str]]:
    """按大小把 staging 下所有文件分成多组，每组 ≤ part_size_bytes。"""
    files = []
    for root, _dirs, names in os.walk(staging):
        for name in names:
            full = os.path.join(root, name)
            files.append((full, os.path.getsize(full)))
    # data.json 固定放第一组
    parts: list[list[str]] = [[]]
    current = 0
    for full, size in files:
        if current + size > part_size_bytes and parts[-1]:
            parts.append([])
            current = 0
        parts[-1].append(full)
        current += size
    return parts


@router.post("/{child_id}/zip")
async def export_zip(
    child_id: str,
    body: ZipBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """数据 + 媒体（录音/视频/照片）打包 ZIP，可选分卷。"""
    await get_child(child_id, current_user, db)
    data = await _collect(child_id)

    media: list[str] = []
    for d in MEDIA_DIRS:
        files = await _collect_files(f"{child_id}/{d}")
        # 排除 focus 根目录的 sessions.json / annotations.json 等数据文件，只打包真实媒体
        files = [f for f in files if not f.lower().endswith((".json", ".bak"))]
        media.extend(f"{d}/{f}" for f in files)
    data["media_files"] = media

    tmpdir = tempfile.mkdtemp(prefix="export_")
    try:
        with open(os.path.join(tmpdir, "data.json"), "w", encoding="utf-8") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=2)
        for rel in media:
            local = os.path.join(tmpdir, "media", rel)
            os.makedirs(os.path.dirname(local), exist_ok=True)
            try:
                await webdav_service.download_file(f"{child_id}/{rel}", local)
            except Exception:
                pass

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        parts: list[str] = []
        if body.part_size_mb <= 0:
            zip_path = os.path.join(tmpdir, f"export_{ts}.zip")
            _write_zip(tmpdir, zip_path)
            remote = f"{child_id}/reports/export_{ts}.zip"
            await webdav_service.upload_file(zip_path, remote)
            parts.append(remote)
        else:
            part_size = body.part_size_mb * 1024 * 1024
            groups = _split_staging(tmpdir, part_size)
            for idx, group in enumerate(groups, start=1):
                part_dir = tempfile.mkdtemp(prefix="part_", dir=tmpdir)
                for full in group:
                    rel = os.path.relpath(full, tmpdir)
                    dest = os.path.join(part_dir, rel)
                    os.makedirs(os.path.dirname(dest), exist_ok=True)
                    shutil.copy2(full, dest)
                part_zip = os.path.join(tmpdir, f"export_{ts}.part{idx:02d}.zip")
                _write_zip(part_dir, part_zip)
                shutil.rmtree(part_dir, ignore_errors=True)
                remote = f"{child_id}/reports/export_{ts}.part{idx:02d}.zip"
                await webdav_service.upload_file(part_zip, remote)
                parts.append(remote)

        await add_audit_log(str(current_user["id"]), "export:zip", child_id)
        return {"parts": parts, "media_count": len(media)}
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


@router.get("/{child_id}/download")
async def download_export(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """下载导出的 ZIP（path 为 reports 下相对路径）。"""
    await get_child(child_id, current_user, db)
    prefix = f"{child_id}/reports/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/reports/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="文件不存在")
    local = f"/tmp/export_{os.path.basename(rel)}"
    await webdav_service.download_file(remote, local)
    return FileResponse(local, media_type="application/zip", filename=os.path.basename(rel))


@router.delete("/{child_id}/all")
async def delete_all(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin")),
):
    await get_child(child_id, current_user, db)
    # 删除 WebDAV 上该孩子的全部数据目录
    await webdav_service.delete(f"{child_id}")
    await add_audit_log(str(current_user["id"]), "export:delete_all", child_id)
    return {"status": "ok"}
