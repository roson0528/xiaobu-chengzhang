import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.quota_service import quota_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/submissions", tags=["提交材料"])


@router.post("/{child_id}/photo")
async def upload_submission_photo(
    child_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """打卡/任务等提交照片专用上传，存储到 {child_id}/submissions/photos/（不进入专注监控）。"""
    child = await get_child(child_id, current_user, db)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="照片内容为空")
    compressed = quota_service.compress_bytes(raw)
    await quota_service.check_and_reserve(child_id, db, len(compressed))

    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = now.strftime("%H-%M-%S") + f"_{uuid.uuid4().hex[:6]}.jpg"
    remote_path = f"{child_id}/submissions/photos/{date_dir}/{fname}"

    local_tmp = f"/tmp/sub_{uuid.uuid4().hex}.jpg"
    with open(local_tmp, "wb") as f:
        f.write(compressed)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    return {"path": remote_path, "size": len(compressed)}


@router.get("/{child_id}/photo")
async def view_submission_photo(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent", "child")),
):
    """查看打卡/任务提交照片（path 可为完整存储路径或相对路径）。"""
    await get_child(child_id, current_user, db)
    prefix = f"{child_id}/submissions/photos/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/submissions/photos/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="照片不存在")
    local = f"/tmp/sub_view_{uuid.uuid4().hex}.jpg"
    await webdav_service.download_file(remote, local)
    return FileResponse(local, media_type="image/jpeg")
