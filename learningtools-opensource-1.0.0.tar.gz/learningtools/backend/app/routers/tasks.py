import uuid
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, get_my_child_id, require_role
from app.services import holiday as holiday_util
from app.services.notification_service import notification_service
from app.services.reward_service import reward_service
from app.services.scoring import ratings_to_score, sanitize_ratings
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/tasks", tags=["任务"])

# 任务难度 → 完成积分（简单 10 / 中等 15 / 困难 20）
DIFFICULTY_POINTS = {"easy": 10, "medium": 15, "hard": 20}
DIFFICULTY_LABELS = {"easy": "简单", "medium": "中等", "hard": "困难"}


def _current_week() -> str:
    iso = datetime.now().isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


async def _weekly_files(child_id: str) -> list[dict]:
    """返回所有周计划文件条目（当前周排在最前），用于跨周查找循环任务。"""
    current = f"weekly_{_current_week()}.json"
    entries = await webdav_service.list_entries(f"{child_id}/plans")
    files = [
        e for e in entries
        if not e.get("is_dir")
        and (e.get("name") or "").startswith("weekly_")
        and (e.get("name") or "").endswith(".json")
    ]
    files.sort(key=lambda e: 0 if (e.get("name") or "") == current else 1)
    return files


async def _find_task_week(child_id: str, task_id: str) -> str | None:
    """在所有周计划文件中查找任务所在的周（循环任务跨周仍可找到）。"""
    for e in await _weekly_files(child_id):
        name = e.get("name") or ""
        plan = await webdav_service.read_json(e.get("path") or "", {"tasks": []})
        if any(t.get("id") == task_id for t in plan.get("tasks", [])):
            return name[len("weekly_"):-len(".json")]
    return None


async def _all_week_tasks(child_id: str) -> list[dict]:
    """收集所有周计划里的任务（按 id 去重，当前周优先）。"""
    seen: dict[str, dict] = {}
    for e in await _weekly_files(child_id):
        plan = await webdav_service.read_json(e.get("path") or "", {"tasks": []})
        for t in plan.get("tasks", []):
            tid = t.get("id")
            if tid:
                seen.setdefault(tid, t)
    return list(seen.values())


async def _find_task(child_id: str, task_id: str) -> dict | None:
    """在最近 2 周计划中查找任务对象（含 difficulty 等字段）。"""
    week = await _find_task_week(child_id, task_id)
    if week is None:
        return None
    plan = await webdav_service.read_json(f"{child_id}/plans/weekly_{week}.json", {"tasks": []})
    for t in plan.get("tasks", []):
        if t.get("id") == task_id:
            return t
    return None


async def _award_approved_task(child_id: str, week: str, task_id: str) -> int:
    """任务审核通过后补发积分（按 rewarded 标记幂等，避免重复奖励）。"""
    plan = await webdav_service.read_json(f"{child_id}/plans/weekly_{week}.json", {"tasks": []})
    task = next((t for t in plan.get("tasks", []) if t.get("id") == task_id), None)
    if (
        task is None
        or task.get("rewarded")
        or task.get("status") != "completed"
        or task.get("review_status") != "approved"
    ):
        return 0

    # 满额积分：课堂作业用独立设置，其余用难度默认或任务覆盖
    if task.get("source") == "classroom":
        full = await reward_service.get_behavior_points(child_id, "homework_classroom")
        reason = "完成课堂作业"
    else:
        difficulty = task.get("difficulty") or "medium"
        override = task.get("reward_points")
        if isinstance(override, int) and override > 0:
            full = override
        else:
            full = await reward_service.get_behavior_points(child_id, f"task_{difficulty}")
        reason = f"完成任务（{DIFFICULTY_LABELS.get(difficulty, difficulty)}）"

    # 优秀/良好打分：优秀全额，良好一半（至少 1 分）
    grade = task.get("grade")
    points = full
    grade_label = ""
    if grade == "good":
        points = max(1, full // 2)
        grade_label = "（良好）"
    elif grade == "excellent":
        grade_label = "（优秀）"

    await reward_service.award_points(child_id, points, f"{reason}{grade_label}")

    def _mark(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                t["rewarded"] = True
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mark, {"tasks": []})
    return 1


class TaskBody(BaseModel):
    title: str
    subject: str | None = None
    task_type: str | None = None
    planned_date: str | None = None
    planned_start: str | None = None
    planned_duration: int | None = None
    priority: int = 0
    difficulty: str = "medium"  # easy / medium / hard
    # 循环模式：{"type": "none"|"daily"|"weekly", "days": [1..7]}（days 仅 weekly 生效，1=周一）
    repeat: dict | None = None
    # 是否需要拍照提交；None 视为默认需要
    photo_required: bool | None = None
    # 超时未完成扣分（0 表示不扣）
    penalty_points: int = 0
    # 完成奖励积分（>0 时覆盖难度默认积分）
    reward_points: int | None = None
    # 是否需要联网：勾选后，该任务开启专注模式期间放开受管控设备的外网权限。
    # 默认 False —— 专注模式默认不允许上网。
    need_network: bool = False
    # 假期作业/假期任务：勾选后该任务在「假期时长」天内持续存在，
    # 假期内任意一天提交都算按时完成，不触发超时扣分。
    holiday: bool = False
    holiday_days: int = 0


class TaskReviewBody(BaseModel):
    status: str  # approved / rejected
    score: int | None = None
    comment: str | None = None
    ratings: dict | None = None  # 维度评分 {completion,diligence,accuracy} 1-5
    grade: str | None = None  # 作业评语打分：excellent（优秀，满分）/ good（良好，一半）


class CompleteBody(BaseModel):
    photo_path: str | None = None
    photo_paths: list[str] | None = None
    completed_at: str | None = None  # 完成时间（客户端附带，缺省用服务器时间）


def _repeat_of(task: dict) -> dict:
    r = task.get("repeat") or {}
    if not isinstance(r, dict):
        return {}
    return r


def _task_matches_today(task: dict, today: str) -> bool:
    """判断任务在指定日期是否应出现（支持循环展开 + 例外：跳过/顺延）。

    传入过去的日期，就是判断「那天有没有这个任务」，历史查询也复用这套口径。
    """
    skip_dates = task.get("skip_dates") or []
    defer_dates = task.get("defer_dates") or []
    if today in skip_dates:
        return False
    repeat = _repeat_of(task)
    rtype = repeat.get("type") or "none"
    start = str(task.get("planned_date") or "")
    # 循环任务从「开始那天」起才算发生，早于它的日期不该出现
    if rtype != "none" and start and today < start:
        return False
    if today in defer_dates:
        return True
    # 假期作业/任务：整个假期区间内每天都算「今天有它」，方便孩子随时提交
    if holiday_util.is_holiday(task):
        return holiday_util.in_window(task, today)
    if rtype == "daily":
        return True
    if rtype == "weekly":
        days = repeat.get("days") or []
        try:
            y, m, d = map(int, today.split("-"))
            weekday = date(y, m, d).isoweekday()
        except Exception:
            weekday = datetime.now().isoweekday()
        return weekday in days
    return start == today


def _fresh_recurring_view(task: dict) -> dict:
    """循环任务的全新今日实例：清除上一轮的所有状态/痕迹，重置为「未完成」。"""
    view = {k: v for k, v in task.items() if k not in (
        "completed_at", "completed_photos", "completed_photo",
        "review_status", "review_comment", "rejected_at",
        "grade", "score", "ratings", "rewarded",
    )}
    view["status"] = "pending"
    return view


def _today_view(task: dict, today: str) -> dict:
    """今日视图：循环任务（daily/weekly）每天是全新实例，昨天（或更早）的状态不延续到今天。

    只返回副本并重置为「未完成」，不修改存储数据（历史状态仍用于审批/归档）。
    - 未完成（pending）本身就是新任务状态，直接返回；
    - 已完成/已驳回/已跳过等状态，仅当发生在「今天」才保留，否则归档并重置为未完成的新任务。
    """
    repeat = _repeat_of(task)
    rtype = repeat.get("type") or "none"
    if rtype not in ("daily", "weekly"):
        return task

    status = task.get("status")
    if status == "completed":
        stamp = str(task.get("completed_at") or "")
    elif task.get("review_status") == "rejected":
        stamp = str(task.get("rejected_at") or task.get("completed_at") or "")
    elif status == "skipped":
        stamp = ""  # 循环任务的跳过只记 skip_dates，不长期保持 skipped
    else:
        return task  # pending（未完成）本身就是新任务

    if stamp and stamp.startswith(today):
        return task

    return _fresh_recurring_view(task)


@router.get("/{child_id}/today")
async def today_tasks(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    today = datetime.now().strftime("%Y-%m-%d")
    tasks = [
        _today_view(t, today)
        for t in await _all_week_tasks(child_id)
        if _task_matches_today(t, today) and not holiday_util.is_archived(t)
    ]
    return {"date": today, "tasks": tasks}


async def _occurrence_dates(task: dict, until: str) -> set[str]:
    """任务在 until（不含）之前实际「发生」的所有日期。

    一次性任务只有 planned_date 一天；循环任务（每天/每周）按规则逐日展开。
    """
    start = str(task.get("planned_date") or "")
    if not start:
        return set()
    if holiday_util.is_holiday(task):
        # 假期作业会横跨好几天（甚至跨周），历史日期要按整个假期展开
        return holiday_util.window_dates(task, until)
    repeat = _repeat_of(task)
    if (repeat.get("type") or "none") == "none":
        return {start} if start < until else set()
    try:
        cur = date(*map(int, start.split("-")))
        end = date(*map(int, until.split("-")))
    except (TypeError, ValueError):
        return set()
    out: set[str] = set()
    while cur < end:
        day = cur.isoformat()
        if _task_matches_today(task, day):
            out.add(day)
        cur += timedelta(days=1)
    return out


@router.get("/{child_id}/history/dates")
async def history_dates(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    """有历史记录的日期（新的在前）。

    注意不能只收集 planned_date：循环任务的主记录一直留在**创建它的那一周**，
    若只看 planned_date，除了创建那周以外，其余每天都会被误判成「没有任务」。
    """
    await get_child(child_id, current_user, db)
    today = datetime.now().strftime("%Y-%m-%d")
    dates: set[str] = set()
    for t in await _all_week_tasks(child_id):
        dates |= await _occurrence_dates(t, today)
    return {"dates": sorted(dates, reverse=True)}


@router.get("/{child_id}/history")
async def history_tasks(
    child_id: str,
    date: str | None = None,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """按日期查那天的任务/作业。

    同样按「那天有没有这个任务」匹配（循环任务逐日展开），并用 ``_today_view``
    还原当天应有的状态：循环任务如果当天没有完成记录，就显示为「未进行」，
    不会拿最新一次的状态冒充历史；当天提交但还没审核的，仍以「待审批」返回，
    家长在历史列表里可以直接继续处理。
    """
    await get_child(child_id, current_user, db)
    all_tasks = await _all_week_tasks(child_id)
    if not date:
        return {"date": date, "tasks": all_tasks}
    tasks = [_today_view(t, date) for t in all_tasks if _task_matches_today(t, date)]
    tasks.sort(key=lambda t: str(t.get("created_at") or ""))
    return {"date": date, "tasks": tasks}


@router.get("/{child_id}/review")
async def review_list(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """列出孩子已提交（待审核/已审核）的任务，供家长/后台审批。

    跨全部周计划扫描：循环任务的主记录留在创建它的那一周，只看本周会让
    「上周提交、还没审核」的任务从审批列表里消失。
    """
    await get_child(child_id, current_user, db)
    seen: dict[str, dict] = {}
    # 仅列当前处于「已提交」状态的任务（驳回后 status 退回 pending，不再列入审批）
    for t in await _all_week_tasks(child_id):
        if t.get("status") == "completed" and t.get("review_status") and t.get("id"):
            seen.setdefault(t["id"], t)
    tasks = sorted(seen.values(), key=lambda t: str(t.get("completed_at") or ""), reverse=True)
    # 待审核的排最前（组内仍按提交时间倒序），方便家长先处理没审的
    tasks.sort(key=lambda t: 0 if str(t.get("review_status")) == "pending" else 1)
    return {"tasks": tasks}


@router.post("/{child_id}")
async def create_task(
    child_id: str,
    body: TaskBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    week = _current_week()
    task = body.dict()
    task["id"] = f"task_{uuid.uuid4().hex[:10]}"
    task.setdefault("status", "pending")
    task.setdefault("planned_date", datetime.now().strftime("%Y-%m-%d"))
    task["repeat"] = body.repeat or {"type": "none", "days": []}
    if task.get("photo_required") is None:
        task["photo_required"] = True

    def _mutate(plan: dict) -> dict:
        plan.setdefault("tasks", [])
        plan["tasks"].append(task)
        plan["week"] = week
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return task


@router.put("/{task_id}")
async def update_task(
    task_id: str,
    body: TaskBody,
    child_id: str,
    today_only: bool = False,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    # child_id 通过 query 传入（任务不直接带 child 归属）
    await get_child(child_id, current_user, db)
    task = await _find_task(child_id, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    # 只更新客户端显式传入的字段（避免把 priority/difficulty/penalty_points 等默认值覆盖回原任务）
    updates = body.model_dump(exclude_unset=True)
    # reward_points 允许清空（None → 回落按难度默认奖励）
    if "reward_points" not in updates:
        updates["reward_points"] = None

    repeat = _repeat_of(task)
    if today_only and (repeat.get("type") or "none") != "none":
        # 循环任务：修改仅对今天有效——克隆为一次性任务，并跳过原循环任务的今天，
        # 原任务本身不动，以后仍按原内容执行。
        today = datetime.now().strftime("%Y-%m-%d")
        new_task = {k: v for k, v in task.items() if k not in (
            "id", "completed_at", "completed_photos", "completed_photo",
            "review_status", "review_comment", "rejected_at",
            "grade", "score", "ratings", "rewarded", "skip_dates", "defer_dates",
        )}
        new_task.update(updates)
        new_task["id"] = f"task_{uuid.uuid4().hex[:10]}"
        new_task["repeat"] = {"type": "none", "days": []}
        new_task["planned_date"] = today
        new_task["status"] = "pending"
        new_task["review_status"] = "pending"
        week = _current_week()

        def _append(plan: dict) -> dict:
            plan.setdefault("tasks", []).append(new_task)
            plan["week"] = week
            return plan

        await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _append, {"tasks": []})
        await _add_task_date_field(child_id, task_id, "skip_dates", today)
        return {"status": "ok", "mode": "today_instance", "task": new_task}

    week = await _find_task_week(child_id, task_id)
    if week is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                t.update(updates)
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return {"status": "ok", "mode": "whole"}


@router.delete("/{task_id}")
async def delete_task(
    task_id: str,
    child_id: str,
    today_only: bool = False,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    task = await _find_task(child_id, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    repeat = _repeat_of(task)
    if today_only and (repeat.get("type") or "none") != "none":
        # 循环任务：删除仅对今天有效（跳过今天），原任务以后仍照常出现。
        today = datetime.now().strftime("%Y-%m-%d")
        await _add_task_date_field(child_id, task_id, "skip_dates", today)
        return {"status": "ok", "mode": "today_instance", "date": today}

    week = await _find_task_week(child_id, task_id)
    if week is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    def _mutate(plan: dict) -> dict:
        plan["tasks"] = [t for t in plan.get("tasks", []) if t.get("id") != task_id]
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return {"status": "ok", "mode": "whole"}


async def _set_task_status(child_id: str, task_id: str, status: str, extra: dict | None = None) -> None:
    week = await _find_task_week(child_id, task_id)
    if week is None:
        raise HTTPException(status_code=404, detail="任务不存在")

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                t["status"] = status
                if status == "completed" and not t.get("completed_at"):
                    t["completed_at"] = datetime.now().isoformat()
                if extra:
                    t.update(extra)
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})


@router.post("/{task_id}/complete")
async def complete_task(
    task_id: str,
    body: CompleteBody,
    child_id: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    if not child_id:
        child_id = await get_my_child_id(current_user, db)
    if not child_id:
        raise HTTPException(status_code=400, detail="未关联孩子档案")
    child = await get_child(child_id, current_user, db)
    task = await _find_task(child_id, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    # 非循环任务审核通过后不可重复提交；循环任务每天是新实例，不受此限制
    repeat = _repeat_of(task)
    if (repeat.get("type") or "none") == "none" and task.get("review_status") == "approved":
        raise HTTPException(status_code=400, detail="该任务已审核通过，不可重复提交")
    photo_paths = [p for p in (body.photo_paths or []) if p]
    if not photo_paths and body.photo_path:
        photo_paths = [body.photo_path]
    # 重新提交后待家长审批；清空上一次驳回的留言/时间，作为一次全新审核
    extra: dict = {"review_status": "pending", "rewarded": False, "review_comment": "", "rejected_at": ""}
    if holiday_util.is_holiday(task):
        # 假期作业：假期里可以「每天交一部分」，照片按天累计，家长审核时能看到每一天交的内容。
        # 只有审核通过才算写完（归档后不能再提交，由上面的 approved 校验挡住）。
        submitted_at = (body.completed_at or "").strip() or datetime.now().isoformat()
        day = submitted_at[:10]
        subs = [s for s in (task.get("submissions") or []) if isinstance(s, dict)]
        # 同一天重复提交只保留当天最新的一条
        subs = [s for s in subs if str(s.get("date") or "") != day]
        subs.append({"date": day, "at": submitted_at, "photos": photo_paths})
        subs.sort(key=lambda s: str(s.get("date") or ""))
        extra["submissions"] = subs
        accumulated: list[str] = []
        for s in subs:
            for p in (s.get("photos") or []):
                if p and p not in accumulated:
                    accumulated.append(p)
        if accumulated:
            extra["completed_photos"] = accumulated
            extra["completed_photo"] = accumulated[0]
        extra["completed_at"] = submitted_at
    else:
        if photo_paths:
            extra["completed_photos"] = photo_paths
            extra["completed_photo"] = photo_paths[0]
        if (body.completed_at or "").strip():
            extra["completed_at"] = body.completed_at
    await _set_task_status(child_id, task_id, "completed", extra)
    # 通知家长：孩子提交了任务/作业，请及时审核
    child_name = child.get("name") or "孩子"
    title = task.get("title") or ""
    is_homework = task.get("task_type") == "作业"
    await notification_service.notify_parents(
        child_id,
        f"📝 {child_name}提交了{'作业' if is_homework else '任务'}",
        f"{child_name} 提交了「{title}」，请及时审核",
        kind="homework" if is_homework else "task",
    )
    # 注意：不再在提交时奖励积分，改为家长审核通过后奖励（见 review_task → _award_approved_task）。
    return {"status": "ok"}


@router.post("/{task_id}/review")
async def review_task(
    task_id: str,
    body: TaskReviewBody,
    child_id: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """家长对已完成任务评分/审核。通过→保留完成；驳回→退回未完成，孩子可重新完成。"""
    if body.status not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="status 需为 approved 或 rejected")
    if not child_id:
        child_id = await get_my_child_id(current_user, db)
    if not child_id:
        raise HTTPException(status_code=400, detail="未关联孩子档案")
    await get_child(child_id, current_user, db)

    if body.status == "approved":
        week = await _find_task_week(child_id, task_id)
        if week is None:
            raise HTTPException(status_code=404, detail="任务不存在")
        extra = {
            "review_status": "approved",
            "review_comment": body.comment,
        }
        if body.grade in ("excellent", "good"):
            extra["grade"] = body.grade
        ratings = sanitize_ratings(body.ratings)
        if ratings:
            extra["ratings"] = ratings
            extra["score"] = ratings_to_score(ratings)
        elif body.score is not None:
            extra["score"] = body.score
        await _set_task_status(child_id, task_id, "completed", extra)
        # 审核通过后奖励积分（幂等：rewarded 标记防重复奖励）
        await _award_approved_task(child_id, week, task_id)
        return {"status": "ok"}

    # 驳回：退回未完成（status=pending），但保留驳回明细（照片/评论/驳回时间）供归档查看，
    # 孩子端列表标记「已驳回」，可点开查看原因并重新提交。
    week = await _find_task_week(child_id, task_id)
    if week is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    task = await _find_task(child_id, task_id)

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                t["status"] = "pending"
                t["review_status"] = "rejected"
                if body.comment:
                    t["review_comment"] = body.comment
                t["rewarded"] = False  # 重新完成后可再次在通过时奖励
                t["rejected_at"] = datetime.now().isoformat()
                t.pop("score", None)
                t.pop("ratings", None)
                t.pop("grade", None)
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})

    # 通知孩子：任务/作业被驳回
    is_homework = bool(task and task.get("task_type") == "作业")
    await notification_service.notify_child(
        child_id,
        f"❌ {'作业' if is_homework else '任务'}被驳回",
        f"「{task.get('title','') if task else ''}」未通过，请查看原因后重新提交",
        kind="homework" if is_homework else "task",
    )
    return {"status": "ok"}


async def _add_task_date_field(child_id: str, task_id: str, field: str, day: str) -> dict | None:
    """给任务的日期列表字段（skip_dates / defer_dates）追加某天，返回更新后的任务。"""
    week = await _find_task_week(child_id, task_id)
    if week is None:
        return None

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                lst = t.setdefault(field, [])
                if not isinstance(lst, list):
                    lst = []
                    t[field] = lst
                if day not in lst:
                    lst.append(day)
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return await _find_task(child_id, task_id)


@router.post("/{task_id}/skip")
async def skip_task(
    task_id: str,
    child_id: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """跳过任务：循环任务只跳过今天（skip_dates），非循环任务整条标记 skipped。"""
    if not child_id:
        child_id = await get_my_child_id(current_user, db)
    if not child_id:
        raise HTTPException(status_code=400, detail="未关联孩子档案")
    child = await get_child(child_id, current_user, db)
    task = await _find_task(child_id, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    if task.get("status") == "completed":
        raise HTTPException(status_code=400, detail="已提交的任务不可跳过")
    repeat = _repeat_of(task)
    if (repeat.get("type") or "none") != "none":
        today = datetime.now().strftime("%Y-%m-%d")
        await _add_task_date_field(child_id, task_id, "skip_dates", today)
        return {"status": "ok", "mode": "instance", "date": today}
    await _set_task_status(child_id, task_id, "skipped")
    return {"status": "ok", "mode": "whole"}


@router.post("/{task_id}/defer")
async def defer_task(
    task_id: str,
    child_id: str | None = None,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """顺延任务：循环任务今天顺延到明天（skip 今天 + defer 明天）；非循环任务 planned_date 顺延一天。"""
    if not child_id:
        child_id = await get_my_child_id(current_user, db)
    if not child_id:
        raise HTTPException(status_code=400, detail="未关联孩子档案")
    child = await get_child(child_id, current_user, db)
    task = await _find_task(child_id, task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    if task.get("status") == "completed":
        raise HTTPException(status_code=400, detail="已提交的任务不可顺延")
    today = datetime.now().strftime("%Y-%m-%d")
    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    repeat = _repeat_of(task)
    if (repeat.get("type") or "none") != "none":
        await _add_task_date_field(child_id, task_id, "skip_dates", today)
        await _add_task_date_field(child_id, task_id, "defer_dates", tomorrow)
        return {"status": "ok", "mode": "instance", "date": tomorrow}
    week = await _find_task_week(child_id, task_id)

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == task_id:
                t["planned_date"] = tomorrow
                if t.get("status") == "skipped":
                    t["status"] = "pending"
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return {"status": "ok", "mode": "whole", "date": tomorrow}
