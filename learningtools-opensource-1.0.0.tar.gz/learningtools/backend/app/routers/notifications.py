from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.deps import get_current_user, get_db, require_role
from app.services.notification_service import notification_service
from app.services.serverchan import serverchan
from app.services.settings_service import set_setting
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/notifications", tags=["通知"])


class TestBody(BaseModel):
    message: str = "这是一条测试消息"


class ServerChanKeyBody(BaseModel):
    key: str = ""


@router.get("")
async def list_notifications(
    unread_only: bool = False,
    date: str | None = None,
    current_user: dict = Depends(get_current_user),
):
    return await notification_service.list_for(current_user["id"], unread_only, date)


@router.get("/serverchan-key")
async def get_serverchan_key(
    current_user: dict = Depends(require_role("super_admin", "family_admin")),
):
    """返回当前生效的 Server酱 SendKey（脱敏）。"""
    key = serverchan.sendkey
    masked = ""
    if key:
        masked = key[:4] + "****" + key[-4:] if len(key) > 10 else key[:2] + "****"
    return {"key": key, "masked": masked, "configured": bool(key)}


@router.post("/serverchan-key")
async def set_serverchan_key(
    body: ServerChanKeyBody,
    current_user: dict = Depends(require_role("super_admin", "family_admin")),
):
    """在线设置 Server酱 SendKey，保存后立即生效（同时持久化到 app_settings）。"""
    key = (body.key or "").strip()
    await set_setting("serverchan_sendkey", key)
    serverchan.set_runtime_sendkey(key)
    return {"status": "ok", "configured": bool(serverchan.sendkey)}


def _truncate(text: str, n: int = 50) -> str:
    import re
    text = re.sub(r"\[sticker:[^\]]*\]", "😊", text or "")
    text = text.strip()
    if not text:
        return "[表情]"
    return text[:n] + ("…" if len(text) > n else "")


@router.get("/chat-unread")
async def chat_unread(
    db=Depends(get_db), current_user: dict = Depends(get_current_user)
):
    """返回当前用户每个会话（群聊/私聊/好友）的最新消息，供 App 轮询做未读提醒。"""
    uid = current_user["id"]
    role = current_user["role"]
    fid = current_user.get("family_id")

    items = []  # [{key, channel, title, latest_id, sender_id, sender_name, preview, created_at}]

    async def push(key: str, channel: str, title: str, msgs):
        if not msgs:
            return
        latest = max(msgs, key=lambda m: (m.get("created_at") or ""))
        items.append({
            "key": key,
            "channel": channel,
            "title": title,
            "latest_id": latest.get("id") or "",
            "sender_id": latest.get("sender_id"),
            "sender_name": latest.get("sender_name") or "",
            "preview": _truncate(latest.get("content") or ""),
            "created_at": latest.get("created_at") or "",
        })

    async def child_name_of(user_id: int) -> str:
        cur = await db.execute("SELECT name FROM children WHERE user_id = ?", (user_id,))
        row = await cur.fetchone()
        return (row["name"] if row and row["name"] else "")

    if fid:
        # 家庭群聊
        g = await webdav_service.read_json(f"{fid}/family_chat.json", {"messages": []})
        await push("family", "family", "家庭群聊", g.get("messages", []))

        # 家庭私聊：与每个其他成员（家长↔家长、家长↔孩子、孩子↔家长）分开一条会话
        cur = await db.execute(
            "SELECT id, username, nickname, role FROM users WHERE family_id = ? ORDER BY id", (fid,)
        )
        for r in await cur.fetchall():
            peer_id = r["id"]
            if peer_id == uid:
                continue
            if r["role"] == "child":
                name = await child_name_of(peer_id)
                title = name or (r["nickname"] or "") or r["username"]
            else:
                title = (r["nickname"] or "").strip() or r["username"]
            lo, hi = sorted((int(uid), int(peer_id)))
            d = await webdav_service.read_json(f"{fid}/p2p/{lo}_{hi}.json", {"messages": []})
            await push(f"p2p:{peer_id}", "p2p", title, d.get("messages", []))

    # 好友私聊（仅孩子账号）
    if role == "child":
        cur = await db.execute("SELECT id FROM children WHERE user_id = ?", (uid,))
        row = await cur.fetchone()
        if row:
            my_child = row["id"]
            links = await webdav_service.read_json("friends/links.json", {"links": []})
            for l in links.get("links", []):
                a, b = l.get("child_a"), l.get("child_b")
                if a == my_child and b:
                    peer = b
                elif b == my_child and a:
                    peer = a
                else:
                    continue
                conv = "__".join(sorted([my_child, peer]))
                d = await webdav_service.read_json(f"friends/messages/{conv}.json", {"messages": []})
                msgs = d.get("messages", [])
                # 好友消息只存 from_child，补充 sender_id=发送方孩子账号的 user_id 供 App 判断是否本人
                for m in msgs:
                    if m.get("sender_id") is None:
                        fc = m.get("from_child")
                        if fc:
                            uc = await db.execute("SELECT user_id FROM children WHERE id = ?", (fc,))
                            urow = await uc.fetchone()
                            if urow and urow["user_id"]:
                                m["sender_id"] = urow["user_id"]
                cur2 = await db.execute("SELECT name FROM children WHERE id = ?", (peer,))
                row2 = await cur2.fetchone()
                title = (row2["name"] if row2 and row2["name"] else "") or peer
                await push(f"friend:{peer}", "friend", title, msgs)

    items.sort(key=lambda x: x["created_at"] or "", reverse=True)
    return {"items": items}


@router.post("/{notification_id}/read")
async def mark_read(notification_id: int, current_user: dict = Depends(get_current_user)):
    ok = await notification_service.mark_read(notification_id, current_user["id"])
    return {"status": "ok" if ok else "not_found"}


@router.post("/test")
async def test_notification(body: TestBody, current_user: dict = Depends(get_current_user)):
    result = await serverchan.send_notification("🔔 测试通知", body.message)
    if result is None:
        return {"status": "skipped", "reason": "Server酱 SendKey 未配置"}
    return {"status": "sent", "result": result}
