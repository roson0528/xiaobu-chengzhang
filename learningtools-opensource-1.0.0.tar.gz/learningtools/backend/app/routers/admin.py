import aiosqlite

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.core.deps import get_current_user, require_role
from app.database import add_audit_log
from app.services.backup_service import backup_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/admin", tags=["管理"])


class RestoreBody(BaseModel):
    backup_id: str


class ConfigBody(BaseModel):
    config: dict


@router.get("/audit-log")
async def audit_log(
    limit: int = 200, current_user=Depends(require_role("super_admin", "family_admin"))
):
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
        rows = await cur.fetchall()
    return [dict(r) for r in rows]


@router.get("/stats")
async def stats(current_user=Depends(require_role("super_admin", "family_admin"))):
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        users = (await (await db.execute("SELECT COUNT(*) c FROM users")).fetchone())["c"]
        pending = (await (await db.execute("SELECT COUNT(*) c FROM users WHERE status='pending'")).fetchone())["c"]
        children = (await (await db.execute("SELECT COUNT(*) c FROM children")).fetchone())["c"]
    return {"users": users, "pending_users": pending, "children": children}


@router.get("/backup")
async def list_backups(current_user=Depends(require_role("super_admin", "family_admin"))):
    return await backup_service.list_backups()


@router.post("/backup")
async def create_backup(current_user=Depends(require_role("super_admin", "family_admin"))):
    result = await backup_service.create_backup()
    await add_audit_log(str(current_user["id"]), "backup:create", result["backup_id"])
    return result


@router.post("/restore")
async def restore(
    body: RestoreBody, current_user=Depends(require_role("super_admin"))
):
    try:
        result = await backup_service.restore(body.backup_id)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="备份不存在")
    await add_audit_log(str(current_user["id"]), "backup:restore", body.backup_id)
    return result


@router.get("/config")
async def get_config(current_user=Depends(require_role("super_admin", "family_admin"))):
    return await webdav_service.read_json("system/config.json", {})


@router.put("/config")
async def put_config(
    body: ConfigBody, current_user=Depends(require_role("super_admin", "family_admin"))
):
    await webdav_service.write_json("system/config.json", body.config)
    await add_audit_log(str(current_user["id"]), "config:update")
    return {"status": "ok"}
