import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/mood", tags=["情绪"])

MOODS = {"happy": "开心", "ok": "一般", "tired": "疲惫"}


def _month() -> str:
    return datetime.now().strftime("%Y-%m")


class MoodBody(BaseModel):
    mood: str  # happy / ok / tired
    note: str | None = None
    date: str | None = None  # YYYY-MM-DD，默认今天


@router.post("/{child_id}")
async def record_mood(
    child_id: str,
    body: MoodBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    if body.mood not in MOODS:
        raise HTTPException(status_code=400, detail="mood 需为 happy / ok / tired")
    day = body.date or datetime.now().strftime("%Y-%m-%d")
    month = day[:7]
    record = {
        "id": f"mood_{uuid.uuid4().hex[:10]}",
        "mood": body.mood,
        "note": body.note,
        "date": day,
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("records", [])
        # 每天一条：同日期覆盖
        data["records"] = [r for r in data["records"] if r.get("date") != day]
        data["records"].append(record)
        return data

    await webdav_service.mutate_json(f"{child_id}/mood/{month}.json", _mutate, {"records": []})
    return record


@router.get("/{child_id}")
async def list_mood(
    child_id: str,
    month: str | None = None,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    m = month or _month()
    data = await webdav_service.read_json(f"{child_id}/mood/{m}.json", {"records": []})
    records = data.get("records", [])
    records.sort(key=lambda r: r.get("date", ""))
    return records
