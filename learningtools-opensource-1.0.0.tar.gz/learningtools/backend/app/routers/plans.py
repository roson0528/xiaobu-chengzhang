import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/plans", tags=["计划"])


def _current_week() -> str:
    iso = datetime.now().isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


class PlanBody(BaseModel):
    tasks: list[dict] = []


@router.get("/{child_id}/weekly/{week}")
async def get_weekly(child_id: str, week: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    return await webdav_service.read_json(
        f"{child_id}/plans/weekly_{week}.json", {"week": week, "tasks": []}
    )


@router.post("/{child_id}/weekly")
async def create_weekly(
    child_id: str,
    body: PlanBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    week = _current_week()
    data = {"week": week, "tasks": body.tasks, "updated_at": datetime.now().isoformat()}
    await webdav_service.write_json(f"{child_id}/plans/weekly_{week}.json", data)
    return data


@router.put("/{child_id}/weekly/{week}")
async def update_weekly(
    child_id: str,
    week: str,
    body: PlanBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    data = {"week": week, "tasks": body.tasks, "updated_at": datetime.now().isoformat()}
    await webdav_service.write_json(f"{child_id}/plans/weekly_{week}.json", data)
    return data


@router.get("/{child_id}/template")
async def get_template(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    return await webdav_service.read_json(
        f"{child_id}/plans/template.json", {"tasks": []}
    )


@router.post("/{child_id}/template")
async def save_template(
    child_id: str,
    body: PlanBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    data = {"tasks": body.tasks, "updated_at": datetime.now().isoformat()}
    await webdav_service.write_json(f"{child_id}/plans/template.json", data)
    return data


@router.post("/{child_id}/apply-template")
async def apply_template(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    template = await webdav_service.read_json(f"{child_id}/plans/template.json", {"tasks": []})
    new_tasks = []
    for t in template.get("tasks", []):
        nt = dict(t)
        nt["id"] = f"task_{uuid.uuid4().hex[:10]}"
        nt.setdefault("status", "pending")
        nt.pop("completed_at", None)
        new_tasks.append(nt)
    week = _current_week()
    data = {"week": week, "tasks": new_tasks, "updated_at": datetime.now().isoformat()}
    await webdav_service.write_json(f"{child_id}/plans/weekly_{week}.json", data)
    return data
