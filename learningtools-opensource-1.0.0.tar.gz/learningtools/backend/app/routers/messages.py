import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db
from app.services.quota_service import quota_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/messages", tags=["消息"])


class AttachmentItem(BaseModel):
    type: str = "file"  # image / audio / video / file
    path: str
    name: str = ""
    size: int = 0


class MessageBody(BaseModel):
    content: str = ""
    attachments: list[AttachmentItem] = []


_IMAGE_EXTS = {"jpg", "jpeg", "png", "gif", "webp", "bmp"}
_AUDIO_EXTS = {"mp3", "wav", "m4a", "aac", "ogg"}
_VIDEO_EXTS = {"mp4", "webm", "mov", "avi", "mkv"}

_MEDIA = {
    "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
    "gif": "image/gif", "webp": "image/webp", "bmp": "image/bmp",
    "mp4": "video/mp4", "webm": "video/webm", "mov": "video/quicktime",
    "mp3": "audio/mpeg", "wav": "audio/wav", "m4a": "audio/mp4", "aac": "audio/aac",
    "pdf": "application/pdf",
}


async def _display_name(user: dict, db) -> str:
    """聊天显示名：家长用昵称（回退用户名），孩子用档案姓名。"""
    if user.get("role") == "child":
        cur = await db.execute("SELECT name FROM children WHERE user_id = ?", (user["id"],))
        row = await cur.fetchone()
        if row and row["name"]:
            return row["name"]
    return (user.get("nickname") or "").strip() or user.get("username", "")


def _ext(name: str) -> str:
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def _type_of(name: str) -> str:
    ext = _ext(name)
    if ext in _IMAGE_EXTS:
        return "image"
    if ext in _AUDIO_EXTS:
        return "audio"
    if ext in _VIDEO_EXTS:
        return "video"
    return "file"


def _media_type(name: str) -> str:
    return _MEDIA.get(_ext(name), "application/octet-stream")


@router.get("/{child_id}")
async def list_messages(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/messages.json", {"messages": []})
    return data.get("messages", [])


@router.post("/{child_id}")
async def send_message(
    child_id: str,
    body: MessageBody,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    msg = {
        "id": f"msg_{uuid.uuid4().hex[:10]}",
        "sender_role": current_user["role"],
        "sender_name": await _display_name(current_user, db),
        "content": body.content,
        "attachments": [a.model_dump() for a in body.attachments],
        "read_at": None,
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(f"{child_id}/messages.json", _mutate, {"messages": []})
    return msg


@router.post("/{child_id}/attachment")
async def upload_attachment(
    child_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """上传聊天附件（照片/文件/作业），存储到 {child_id}/messages/attachments/。"""
    await get_child(child_id, current_user, db)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="文件内容为空")
    if len(raw) > 30 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件超过 30MB 限制")
    await quota_service.check_and_reserve(child_id, db, len(raw))

    safe_name = os.path.basename(file.filename or "file")
    safe_name = safe_name.replace("/", "_").replace("\\", "_") or "file"
    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = f"{now.strftime('%H-%M-%S')}_{uuid.uuid4().hex[:6]}_{safe_name}"
    remote_path = f"{child_id}/messages/attachments/{date_dir}/{fname}"

    local_tmp = f"/tmp/msg_up_{uuid.uuid4().hex}"
    with open(local_tmp, "wb") as f:
        f.write(raw)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    return {"type": _type_of(safe_name), "path": remote_path, "name": safe_name, "size": len(raw)}


@router.get("/{child_id}/attachment")
async def view_attachment(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """查看聊天附件（path 可为完整存储路径或相对路径）。"""
    await get_child(child_id, current_user, db)
    prefix = f"{child_id}/messages/attachments/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/messages/attachments/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="附件不存在")

    local = f"/tmp/msg_view_{uuid.uuid4().hex}"
    await webdav_service.download_file(remote, local)
    media = _media_type(rel)
    if media.startswith("image/"):
        return FileResponse(local, media_type=media)
    return FileResponse(local, media_type=media, filename=os.path.basename(rel))


@router.post("/{child_id}/read_all")
async def mark_all_read(
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """打开消息页时把该孩子所有未读消息批量标记为已读。"""
    await get_child(child_id, current_user, db)

    def _mutate(data: dict) -> dict:
        now = datetime.now().isoformat()
        for m in data.get("messages", []):
            if not m.get("read_at"):
                m["read_at"] = now
        return data

    await webdav_service.mutate_json(f"{child_id}/messages.json", _mutate, {"messages": []})
    return {"status": "ok"}


@router.post("/{message_id}/read")
async def mark_read(
    message_id: str,
    child_id: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    found = False

    def _mutate(data: dict) -> dict:
        nonlocal found
        for m in data.get("messages", []):
            if m.get("id") == message_id:
                m["read_at"] = datetime.now().isoformat()
                found = True
        return data

    await webdav_service.mutate_json(f"{child_id}/messages.json", _mutate, {"messages": []})
    if not found:
        raise HTTPException(status_code=404, detail="消息不存在")
    return {"status": "ok"}
