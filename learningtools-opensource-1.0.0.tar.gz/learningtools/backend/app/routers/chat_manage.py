import aiosqlite

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.core.deps import require_role
from app.database import add_audit_log
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/chat-manage", tags=["聊天记录管理"])

_IMAGE_EXTS = {"jpg", "jpeg", "png", "gif", "webp", "bmp"}
_VIDEO_EXTS = {"mp4", "webm", "mov", "avi", "mkv"}
_AUDIO_EXTS = {"mp3", "wav", "m4a", "aac", "ogg"}

# clear 接口的 scope → 附件分类（与 messages.py 保持一致）
_SCOPE_TYPE = {"images": "image", "videos": "video", "files": "file", "audio": "audio"}
_VALID_SCOPES = {"all", "images", "videos", "files", "audio"}


class ClearBody(BaseModel):
    scope: str = "all"
    child_id: str | None = None


def _ext(name: str) -> str:
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def _type_of(name: str) -> str:
    ext = _ext(name)
    if ext in _IMAGE_EXTS:
        return "image"
    if ext in _VIDEO_EXTS:
        return "video"
    if ext in _AUDIO_EXTS:
        return "audio"
    return "file"


async def _walk_files(remote_dir: str) -> list[dict]:
    """递归返回 remote_dir 下所有文件条目（不含目录本身），目录缺失时返回空列表。"""
    files: list[dict] = []
    for entry in await webdav_service.list_entries(remote_dir):
        if entry["is_dir"]:
            files.extend(await _walk_files(entry["path"]))
        else:
            files.append(entry)
    return files


async def _children_from_db() -> list[dict]:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT id, name FROM children ORDER BY created_at")
        return [dict(r) for r in await cur.fetchall()]


async def _family_ids_from_db() -> list[str]:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            "SELECT DISTINCT family_id FROM users WHERE family_id IS NOT NULL AND family_id != ''"
        )
        return [r["family_id"] for r in await cur.fetchall()]


@router.get("/storage")
async def storage(current_user=Depends(require_role("super_admin", "family_admin"))):
    """扫描 WebDAV 上全部聊天数据，返回按孩子/家庭/好友分类的容量统计。"""
    children_rows = await _children_from_db()
    family_ids = await _family_ids_from_db()

    children = []
    for ch in children_rows:
        child_id = ch["id"]
        messages_bytes = await webdav_service.get_size(f"{child_id}/messages.json")
        stats = {"image": [0, 0], "video": [0, 0], "audio": [0, 0], "file": [0, 0]}
        for f in await _walk_files(f"{child_id}/messages/attachments"):
            t = _type_of(f["name"])
            stats[t][0] += f["size"]
            stats[t][1] += 1
        children.append({
            "child_id": child_id,
            "name": ch["name"],
            "total_bytes": messages_bytes + sum(v[0] for v in stats.values()),
            "messages_bytes": messages_bytes,
            "images_bytes": stats["image"][0],
            "images_count": stats["image"][1],
            "videos_bytes": stats["video"][0],
            "videos_count": stats["video"][1],
            "audio_bytes": stats["audio"][0],
            "audio_count": stats["audio"][1],
            "files_bytes": stats["file"][0],
            "files_count": stats["file"][1],
        })

    families = []
    for fid in family_ids:
        chat_bytes = await webdav_service.get_size(f"{fid}/family_chat.json")
        p2p_files = await _walk_files(f"{fid}/p2p")
        p2p_bytes = sum(f["size"] for f in p2p_files)
        families.append({
            "family_id": fid,
            "total_bytes": chat_bytes + p2p_bytes,
            "chat_bytes": chat_bytes,
            "p2p_bytes": p2p_bytes,
        })

    friends_files = await _walk_files("friends/messages")
    friends_total = sum(f["size"] for f in friends_files)

    grand_total_bytes = (
        sum(c["total_bytes"] for c in children)
        + sum(f["total_bytes"] for f in families)
        + friends_total
    )

    return {
        "children": children,
        "families": families,
        "friends": {"total_bytes": friends_total, "files_count": len(friends_files)},
        "grand_total_bytes": grand_total_bytes,
    }


async def _delete_dir_files(remote_dir: str) -> int:
    """递归删除目录下所有文件（保留目录本身），返回删除的文件数。"""
    files = await _walk_files(remote_dir)
    for f in files:
        await webdav_service.delete(f["path"])
    return len(files)


async def _clear_child_all(child_id: str) -> int:
    """清空某孩子的聊天：messages.json 写回空，附件全部删除。"""
    await webdav_service.write_json(f"{child_id}/messages.json", {"messages": []})
    return await _delete_dir_files(f"{child_id}/messages/attachments")


async def _delete_matching(remote_dir: str, scope: str) -> int:
    """删除 remote_dir 下扩展名匹配 scope 的附件文件，返回删除数。"""
    want = _SCOPE_TYPE[scope]
    deleted = 0
    for f in await _walk_files(remote_dir):
        if _type_of(f["name"]) == want:
            await webdav_service.delete(f["path"])
            deleted += 1
    return deleted


@router.post("/clear")
async def clear(body: ClearBody, current_user=Depends(require_role("super_admin", "family_admin"))):
    """按类型清理聊天数据。scope: all/images/videos/files/audio。"""
    if body.scope not in _VALID_SCOPES:
        raise HTTPException(status_code=400, detail="非法 scope")
    deleted = 0

    if body.scope == "all":
        if body.child_id:
            deleted += await _clear_child_all(body.child_id)
        else:
            for ch in await _children_from_db():
                deleted += await _clear_child_all(ch["id"])
            for fid in await _family_ids_from_db():
                await webdav_service.write_json(f"{fid}/family_chat.json", {"messages": []})
                deleted += await _delete_dir_files(f"{fid}/p2p")
            deleted += await _delete_dir_files("friends/messages")
    else:
        targets: list[str] = []
        if body.child_id:
            targets.append(f"{body.child_id}/messages/attachments")
        else:
            for ch in await _children_from_db():
                targets.append(f"{ch['id']}/messages/attachments")
            # 家庭/私聊若存在附件目录也一并处理（目前业务未使用，做兼容）
            for fid in await _family_ids_from_db():
                targets.append(f"{fid}/p2p/attachments")
                targets.append(f"{fid}/attachments")
        for t in targets:
            deleted += await _delete_matching(t, body.scope)

    await add_audit_log(
        str(current_user["id"]),
        f"chat-manage:clear:{body.scope}",
        body.child_id or "*",
        f"deleted={deleted}",
    )
    return {"status": "ok", "deleted_count": deleted}
