"""上网管控接口。

* ``GET /netcontrol/policy``  —— 软路由代理专用（token 鉴权，不走用户登录）
* ``GET /netcontrol/state``   —— 家长端读取当前策略
* ``POST /netcontrol/mode``   —— 家长端一键断网 / 一键联网 / 恢复正常管控
* ``POST /netcontrol/device`` —— 家长端调整设备绑定（孩子 / 是否启用）
"""

import secrets

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from app.core.deps import get_current_user, require_role
from app.services.netcontrol_service import netcontrol_service

router = APIRouter(prefix="/api/v1/netcontrol", tags=["上网管控"])


class ModeBody(BaseModel):
    mode: str
    minutes: int | None = None      # 仅对 allow_all / block_all 有意义；为空表示永久
    device_id: str | None = None


class DeviceBody(BaseModel):
    device_id: str | None = None
    child_id: str | None = None
    enabled: bool | None = None
    name: str | None = None
    ip: str | None = None
    mac: str | None = None


class NewDeviceBody(BaseModel):
    ip: str
    name: str | None = None
    mac: str | None = None


class ScheduleBody(BaseModel):
    device_id: str | None = None
    enabled: bool = True
    # 每段：{"days": [1,2,3,4,5], "start": "18:00", "end": "21:00"}
    windows: list[dict] = []
    out_action: str = "restricted"     # restricted=限制上网 / block=完全断网


@router.get("/policy")
async def get_policy(token: str = Query("")):
    """软路由代理拉取策略（token 鉴权）。"""
    expected = await netcontrol_service.get_token()
    if not expected or not token or not secrets.compare_digest(token, expected):
        # 记下「代理拿错 token 来拉」，家长端/看门狗据此提示重新同步
        netcontrol_service.note_agent_token_error()
        raise HTTPException(status_code=403, detail="token 无效")
    netcontrol_service.note_agent_poll()
    return await netcontrol_service.agent_policy()


@router.get("/state")
async def get_state(
    device_id: str | None = None,
    current_user=Depends(get_current_user),
):
    return await netcontrol_service.state(device_id)


@router.post("/mode")
async def set_mode(
    body: ModeBody,
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    try:
        return await netcontrol_service.set_mode(
            body.mode, body.device_id, body.minutes
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/devices")
async def add_device(
    body: NewDeviceBody,
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """新增受管控设备：给任意 IP 加上联网管控。"""
    try:
        return await netcontrol_service.add_device(
            body.ip, body.name or "", body.mac or ""
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.delete("/devices/{device_id}")
async def delete_device(
    device_id: str,
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    try:
        return await netcontrol_service.delete_device(device_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/schedule")
async def set_schedule(
    body: ScheduleBody,
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """时间段控制：窗口内可上网，窗口外限制或断网。"""
    try:
        return await netcontrol_service.set_schedule(
            device_id=body.device_id,
            enabled=body.enabled,
            windows=body.windows,
            out_action=body.out_action,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/device")
async def set_device(
    body: DeviceBody,
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    try:
        return await netcontrol_service.set_device(
            device_id=body.device_id,
            child_id=body.child_id if "child_id" in body.model_fields_set else ...,
            enabled=body.enabled,
            name=body.name,
            ip=body.ip,
            mac=body.mac,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
