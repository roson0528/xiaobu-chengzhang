import logging
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.netcontrol_service import GRANT_REWARD, netcontrol_service
from app.services.notification_service import notification_service
from app.services.reward_service import reward_service
from app.services.webdav_service import webdav_service

logger = logging.getLogger("learningtools.rewards")

router = APIRouter(prefix="/api/v1/rewards", tags=["奖励"])


async def _lookup_net_minutes(child_id: str, reward_name: str) -> int:
    """按奖励名称查「附赠上网时长」。"""
    catalog = await webdav_service.read_json(
        f"{child_id}/rewards/catalog.json", {"badges": [], "redeem_items": []}
    )
    for item in catalog.get("redeem_items") or []:
        if item.get("name") == reward_name:
            try:
                return max(0, int(item.get("net_minutes") or 0))
            except (TypeError, ValueError):
                return 0
    return 0


async def _grant_reward_net(child_id: str, reward_name: str) -> None:
    """兑换带上网时长的奖励后，放开管控设备的外网权限。失败不得影响兑换本身。"""
    try:
        minutes = await _lookup_net_minutes(child_id, reward_name)
        if minutes <= 0:
            return
        await netcontrol_service.add_grant(
            GRANT_REWARD,
            minutes=minutes,
            child_id=child_id,
            note=f"兑换：{reward_name}",
        )
        await notification_service.notify_parents(
            child_id,
            "🌐 已开放上网时长",
            f"「{reward_name}」兑换成功，已为管控设备开放 {minutes} 分钟上网",
            kind="netcontrol",
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("奖励附赠上网时长写入失败 child=%s reward=%s: %s", child_id, reward_name, e)


class RedeemBody(BaseModel):
    reward_name: str
    cost: int


def _points_ts(record: dict) -> float:
    """把积分记录时间转成可排序的时间戳。

    时间缺失或格式异常的记录按 0（1970）处理，倒序时自然落到最后，
    不会因为一条脏数据把整页顺序打乱。
    """
    raw = str(record.get("timestamp") or "").strip()
    if not raw:
        return 0.0
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(raw).timestamp()
    except ValueError:
        return 0.0


@router.get("/{child_id}/points")
async def get_points(
    child_id: str,
    # 分页 / 排序均为可选：不传时行为与以前完全一致（返回全部记录、保持存储顺序），
    # 以免影响孩子端「积分记录」等已有调用方。
    page: int | None = Query(None, ge=1, description="页码，从 1 开始；不传则返回全部"),
    page_size: int = Query(30, ge=1, le=200, description="每页条数"),
    order: str = Query("keep", pattern="^(keep|asc|desc)$", description="keep=存储顺序，desc=按时间倒序"),
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(
        f"{child_id}/rewards/points.json", {"records": [], "total": 0}
    )
    records = list(data.get("records") or [])
    if order == "desc":
        records.sort(key=_points_ts, reverse=True)
    elif order == "asc":
        records.sort(key=_points_ts)

    result = dict(data)
    result["record_count"] = len(records)
    if page is None:
        result["records"] = records
        return result

    start = (page - 1) * page_size
    result["records"] = records[start : start + page_size]
    result["page"] = page
    result["page_size"] = page_size
    result["page_count"] = max(1, (len(records) + page_size - 1) // page_size)
    return result


@router.get("/{child_id}/badges")
async def get_badges(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    return await webdav_service.read_json(
        f"{child_id}/rewards/badges.json", {"earned": []}
    )


async def _notify_redeem(child: dict, reward_name: str, cost: int) -> None:
    """兑换成功后，自动把兑换信息发到家庭群聊。"""
    fid = child.get("family_id")
    if not fid:
        return
    msg = {
        "id": f"fm_{uuid.uuid4().hex[:10]}",
        "sender_id": child.get("user_id"),
        "sender_name": child.get("name") or "孩子",
        "sender_role": "child",
        "content": f"我刚刚用 {cost} 积分兑换了「{reward_name}」",
        "attachments": [],
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(f"{fid}/family_chat.json", _mutate, {"messages": []})


@router.post("/{child_id}/redeem")
async def redeem(
    child_id: str,
    body: RedeemBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent", "child")),
):
    child = await get_child(child_id, current_user, db)
    if body.cost <= 0:
        raise HTTPException(status_code=400, detail="积分必须为正数")

    def _mutate(data: dict) -> dict:
        total = data.get("total", 0)
        if total < body.cost:
            raise HTTPException(status_code=400, detail="积分不足")
        data["total"] = total - body.cost
        data.setdefault("records", []).append(
            {
                "points": -body.cost,
                "reason": f"兑换奖励: {body.reward_name}",
                "timestamp": datetime.now().isoformat(),
            }
        )
        return data

    updated = await webdav_service.mutate_json(
        f"{child_id}/rewards/points.json", _mutate, {"records": [], "total": 0}
    )
    await _notify_redeem(child, body.reward_name, body.cost)
    # 带「附赠上网时长」的奖励 → 放开管控设备的外网权限
    await _grant_reward_net(child_id, body.reward_name)
    # 通知家长：孩子兑换了奖励（APP 通知推送）
    await notification_service.notify_parents(
        child_id,
        f"🎁 {child.get('name') or '孩子'}兑换了奖励",
        f"用 {body.cost} 积分兑换了「{body.reward_name}」",
        kind="reward",
    )
    return updated


# ---------------- 手动积分奖惩（正分=奖励，负分=扣分） ----------------

class AdjustBody(BaseModel):
    points: int                      # 正数=奖励，负数=扣分
    reason: str = ""
    notify: bool = True              # 是否把分数与理由发到孩子端聊天框


async def _send_points_chat(
    child_id: str, points: int, reason: str, current_user: dict, db
) -> dict:
    """把奖惩写进孩子端聊天框（家长端与孩子端看到的是同一条消息）。"""
    from app.routers.messages import _display_name

    sign = "+" if points > 0 else ""
    head = "积分奖励" if points > 0 else "积分扣除"
    msg = {
        "id": f"msg_{uuid.uuid4().hex[:10]}",
        "sender_role": current_user.get("role") or "parent",
        "sender_name": await _display_name(current_user, db),
        "content": f"【{head}】{sign}{points} 分\n理由：{reason}",
        "attachments": [],
        "read_at": None,
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(f"{child_id}/messages.json", _mutate, {"messages": []})
    return msg


@router.post("/{child_id}/adjust")
async def adjust_points(
    child_id: str,
    body: AdjustBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    """手动积分奖惩：按正负分奖励或扣分，可填理由，并可同步发到孩子端聊天框。

    与自动积分（完成任务、打卡、超时扣分）走同一套积分流水，所以记录里能一眼看到
    「谁因为什么加/扣了多少分」。
    """
    await get_child(child_id, current_user, db)
    if body.points == 0:
        raise HTTPException(status_code=400, detail="分值不能为 0")
    if abs(body.points) > 1000:
        raise HTTPException(status_code=400, detail="单次奖惩不能超过 1000 分")

    reason = (body.reason or "").strip() or ("手动奖励" if body.points > 0 else "手动扣分")
    updated = await reward_service.award_points(child_id, body.points, reason)

    message = None
    if body.notify:
        try:
            message = await _send_points_chat(child_id, body.points, reason, current_user, db)
        except Exception as e:  # noqa: BLE001
            logger.warning("积分奖惩消息发送失败 child=%s: %s", child_id, e)
    return {"points": updated, "message": message}


# ---------------- 积分奖励设置（每项行为奖励多少积分） ----------------

class PointsSettingsBody(BaseModel):
    points: dict


@router.get("/{child_id}/settings")
async def get_points_settings(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    await get_child(child_id, current_user, db)
    return await reward_service.get_settings(child_id)


@router.put("/{child_id}/settings")
async def update_points_settings(
    child_id: str,
    body: PointsSettingsBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    return await reward_service.update_settings(child_id, body.points)


@router.get("/{child_id}/rank")
async def family_rank(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    child = await get_child(child_id, current_user, db)
    cur = await db.execute("SELECT id, name FROM children WHERE family_id = ?", (child.get("family_id"),))
    rows = await cur.fetchall()
    if not rows:
        # 无 family_id 时仅当前孩子
        rows = [(child_id, child.get("name"))]
    ranking = []
    for r in rows:
        cid, cname = (r["id"], r["name"]) if isinstance(r, dict) else (r[0], r[1])
        pts = await webdav_service.read_json(f"{cid}/rewards/points.json", {"total": 0})
        ranking.append({"child_id": cid, "name": cname, "points": pts.get("total", 0)})
    ranking.sort(key=lambda x: x["points"], reverse=True)
    for i, item in enumerate(ranking, start=1):
        item["rank"] = i
    return ranking


# ---------------- 徽章目录 + 积分兑换目录（家长可配置） ----------------

class BadgeItemBody(BaseModel):
    name: str
    emoji: str = "🏆"
    description: str | None = None


class RedeemItemBody(BaseModel):
    name: str
    emoji: str = "🎁"
    cost: int
    # 附赠上网时长（分钟）。>0 时，兑换后可放开管控设备的外网权限这么久。
    net_minutes: int = 0


async def _load_catalog(child_id: str) -> dict:
    return await webdav_service.read_json(
        f"{child_id}/rewards/catalog.json", {"badges": [], "redeem_items": []}
    )


@router.get("/{child_id}/catalog")
async def get_catalog(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    return await _load_catalog(child_id)


@router.post("/{child_id}/badges")
async def add_badge(
    child_id: str,
    body: BadgeItemBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    item = {"id": f"badge_{uuid.uuid4().hex[:10]}", "name": body.name, "emoji": body.emoji,
            "description": body.description or ""}

    def _mutate(data: dict) -> dict:
        data.setdefault("badges", []).append(item)
        return data

    await webdav_service.mutate_json(f"{child_id}/rewards/catalog.json", _mutate, {"badges": [], "redeem_items": []})
    return item


@router.delete("/{child_id}/badges/{badge_id}")
async def delete_badge(
    child_id: str,
    badge_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)

    def _mutate(data: dict) -> dict:
        data["badges"] = [b for b in data.get("badges", []) if b.get("id") != badge_id]
        return data

    await webdav_service.mutate_json(f"{child_id}/rewards/catalog.json", _mutate, {"badges": [], "redeem_items": []})
    return {"status": "ok"}


@router.post("/{child_id}/redeem_items")
async def add_redeem_item(
    child_id: str,
    body: RedeemItemBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    if body.cost <= 0:
        raise HTTPException(status_code=400, detail="兑换所需积分必须为正数")
    item = {
        "id": f"redeem_{uuid.uuid4().hex[:10]}",
        "name": body.name,
        "emoji": body.emoji,
        "cost": body.cost,
        "net_minutes": max(0, body.net_minutes),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("redeem_items", []).append(item)
        return data

    await webdav_service.mutate_json(f"{child_id}/rewards/catalog.json", _mutate, {"badges": [], "redeem_items": []})
    return item


@router.delete("/{child_id}/redeem_items/{item_id}")
async def delete_redeem_item(
    child_id: str,
    item_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)

    def _mutate(data: dict) -> dict:
        data["redeem_items"] = [i for i in data.get("redeem_items", []) if i.get("id") != item_id]
        return data

    await webdav_service.mutate_json(f"{child_id}/rewards/catalog.json", _mutate, {"badges": [], "redeem_items": []})
    return {"status": "ok"}
