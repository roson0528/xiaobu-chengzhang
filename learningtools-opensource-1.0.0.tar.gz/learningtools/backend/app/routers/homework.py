import uuid
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.routers.family import _display_name as _family_display_name
from app.routers.tasks import _find_task_week, _task_matches_today
from app.services import holiday as holiday_util
from app.services.notification_service import notification_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/homework", tags=["作业"])

_PARENT_ROLES = ("super_admin", "family_admin", "parent")
HOMEWORK_TYPE = "作业"


class HomeworkAttachment(BaseModel):
    type: str = "file"  # image / file
    path: str
    name: str = ""
    size: int = 0


class HomeworkBody(BaseModel):
    title: str
    content: str = ""
    date: str  # YYYY-MM-DD
    attachments: list[HomeworkAttachment] = []
    # 是否需要联网：勾选后，该作业开启专注模式期间放开受管控设备的外网权限。
    # 默认 False —— 专注模式默认不允许上网。
    need_network: bool = False
    # 假期作业：勾选后该作业在「假期时长」天内持续存在，假期内任意一天提交都算按时完成
    holiday: bool = False
    holiday_days: int = 0


class HomeworkUpdateBody(BaseModel):
    title: str | None = None
    content: str | None = None
    date: str | None = None
    attachments: list[HomeworkAttachment] | None = None
    need_network: bool | None = None
    holiday: bool | None = None
    holiday_days: int | None = None


class HomeworkSubmitBody(BaseModel):
    """孩子提交学校布置的课堂作业（拍照上传后提交审核）。"""

    title: str
    content: str = ""
    subject: str | None = None
    photo_paths: list[str] | None = None
    completed_at: str | None = None


def _now_utc() -> str:
    return datetime.now().isoformat()


def _week_of(day: str) -> str:
    try:
        y, m, d = map(int, day.split("-"))
        iso = date(y, m, d).isocalendar()
        return f"{iso.year}-W{iso.week:02d}"
    except Exception:
        iso = datetime.now().isocalendar()
        return f"{iso.year}-W{iso.week:02d}"


async def _all_week_files(child_id: str) -> list[tuple[str, str]]:
    """所有周计划文件 (周名, 路径)，当前周排在最前。

    不能只看近期几周：循环任务的主记录留在创建它的那一周，假期作业也可能落在
    更早或更晚的周文件里，只看近几周会让历史作业查不到、也改不了。
    """
    current = f"weekly_{datetime.now().isocalendar().year}-W{datetime.now().isocalendar().week:02d}.json"
    try:
        entries = await webdav_service.list_entries(f"{child_id}/plans")
    except Exception:  # noqa: BLE001
        return []
    files = [
        (str(e.get("name") or ""), str(e.get("path") or ""))
        for e in entries
        if not e.get("is_dir")
        and str(e.get("name") or "").startswith("weekly_")
        and str(e.get("name") or "").endswith(".json")
    ]
    files.sort(key=lambda x: 0 if x[0] == current else 1)
    return [(n[len("weekly_"):-len(".json")], p) for n, p in files]


async def _collect(child_id: str, only_homework: bool) -> list[dict]:
    items: list[dict] = []
    for w, path in await _all_week_files(child_id):
        plan = await webdav_service.read_json(path, {"tasks": []})
        for t in plan.get("tasks", []):
            if only_homework and t.get("task_type") != HOMEWORK_TYPE:
                continue
            t = dict(t)
            t.setdefault("week", w)
            items.append(t)
    return items


async def _homework_tasks(child_id: str) -> list[dict]:
    """从周计划中收集所有「作业」类型任务。"""
    return await _collect(child_id, only_homework=True)


async def _all_tasks(child_id: str) -> list[dict]:
    """从周计划中收集全部任务（含家长布置的临时任务、课堂作业等）。"""
    return await _collect(child_id, only_homework=False)


def _sort(items: list) -> list:
    return sorted(
        items,
        key=lambda h: (h.get("planned_date", ""), h.get("created_at", "")),
        reverse=True,
    )


@router.post("/{child_id}")
async def create_homework(
    child_id: str,
    body: HomeworkBody,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    """布置作业：直接写入孩子当周计划，作为「作业」任务出现在孩子端「今日任务」。"""
    await get_child(child_id, current_user, db)
    week = _week_of(body.date)
    task = {
        "id": f"task_{uuid.uuid4().hex[:10]}",
        "title": body.title,
        "subject": HOMEWORK_TYPE,
        "task_type": HOMEWORK_TYPE,
        "content": body.content,
        "attachments": [a.model_dump() for a in body.attachments],
        "planned_date": body.date,
        "planned_duration": 0,
        "priority": 0,
        "difficulty": "easy",
        "status": "pending",
        "review_status": "pending",
        "repeat": {"type": "none", "days": []},
        "homework": True,
        "need_network": bool(body.need_network),
        "holiday": bool(body.holiday),
        "holiday_days": holiday_util.holiday_days({"holiday": body.holiday, "holiday_days": body.holiday_days}) if body.holiday else 0,
        "created_at": _now_utc(),
    }

    def _mutate(plan: dict) -> dict:
        plan.setdefault("tasks", [])
        plan["tasks"].append(task)
        plan["week"] = week
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})

    # 通知孩子：家长布置了新作业
    await notification_service.notify_child(
        child_id,
        "📚 家长布置了新作业",
        f"「{body.title}」请按时完成哦",
        kind="homework",
    )
    return task


@router.post("/{child_id}/submit")
async def submit_class_homework(
    child_id: str,
    body: HomeworkSubmitBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """孩子提交老师在学校布置的课堂作业：作为「作业」任务进入家长端作业列表待审核。

    与家长「布置作业」的区别：`source=classroom`（来自课堂作业），家长端不显示「发送到聊天」。
    """
    await get_child(child_id, current_user, db)
    today = datetime.now().strftime("%Y-%m-%d")
    week = _week_of(today)
    photos = [p for p in (body.photo_paths or []) if p]
    task = {
        "id": f"task_{uuid.uuid4().hex[:10]}",
        "title": body.title,
        "subject": (body.subject or "").strip() or HOMEWORK_TYPE,
        "task_type": HOMEWORK_TYPE,
        "content": body.content,
        "planned_date": today,
        "planned_duration": 0,
        "priority": 0,
        "difficulty": "easy",
        "status": "completed",
        "review_status": "pending",
        "repeat": {"type": "none", "days": []},
        "homework": True,
        "source": "classroom",  # 来自课堂作业（区别于家长布置）
        "rewarded": False,
        "created_at": _now_utc(),
        "completed_at": (body.completed_at or "").strip() or _now_utc(),
    }
    if photos:
        task["completed_photos"] = photos
        task["completed_photo"] = photos[0]

    def _mutate(plan: dict) -> dict:
        plan.setdefault("tasks", [])
        plan["tasks"].append(task)
        plan["week"] = week
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})

    # 通知家长：孩子提交了课堂作业
    child = await get_child(child_id, current_user, db)
    child_name = child.get("name") or "孩子"
    await notification_service.notify_parents(
        child_id,
        f"📝 {child_name}提交了作业",
        f"{child_name} 提交了「{body.title}」，请及时审核",
        kind="homework",
    )
    return task


@router.get("/{child_id}")
async def list_homework(
    child_id: str,
    date: str | None = None,
    all_types: bool = False,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    items = await (_all_tasks(child_id) if all_types else _homework_tasks(child_id))
    if date:
        items = [h for h in items if h.get("planned_date") == date]
    return _sort(items)


@router.get("/{child_id}/today")
async def today_homework(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    """孩子端「今日作业」（按今日任务一致性返回）。"""
    await get_child(child_id, current_user, db)
    today = datetime.now().strftime("%Y-%m-%d")
    items = [
        h for h in await _homework_tasks(child_id)
        if _task_matches_today(h, today) and not holiday_util.is_archived(h)
    ]
    return _sort(items)


@router.put("/{child_id}/{item_id}")
async def update_homework(
    child_id: str,
    item_id: str,
    body: HomeworkUpdateBody,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    updates = {k: v for k, v in body.dict().items() if v is not None}
    if "attachments" in updates:
        updates["attachments"] = [a.model_dump() for a in body.attachments]
    # 布尔字段不能走 "非 None" 过滤（False 也是有效值），单独按「是否显式传入」处理
    if "need_network" in body.model_fields_set:
        updates["need_network"] = bool(body.need_network)
    # 请求体字段名是 date，但任务里存的是 planned_date：不转换会写成一个没用的
    # 新字段，日期其实没改成（改「假期开始日期」时就会踩到）
    if "date" in updates:
        updates["planned_date"] = updates.pop("date")
    if "holiday" in body.model_fields_set:
        updates["holiday"] = bool(body.holiday)
    if "holiday_days" in body.model_fields_set:
        updates["holiday_days"] = max(0, int(body.holiday_days or 0))
    # 打开假期开关但没填时长 → 补默认 7 天，避免出现「假期开关生效但只有一天」
    if updates.get("holiday") is True and not updates.get("holiday_days"):
        updates["holiday_days"] = holiday_util.DEFAULT_HOLIDAY_DAYS
    week = await _find_homework_week(child_id, item_id)
    if week is None:
        raise HTTPException(status_code=404, detail="作业不存在")

    def _mutate(plan: dict) -> dict:
        for t in plan.get("tasks", []):
            if t.get("id") == item_id:
                t.update(updates)
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return {"status": "ok"}


async def _find_homework_week(child_id: str, item_id: str) -> str | None:
    """跨全部周计划查找作业所在周（旧作业也能修改/删除）。"""
    return await _find_task_week(child_id, item_id)


@router.delete("/{child_id}/{item_id}")
async def delete_homework(
    child_id: str,
    item_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    await get_child(child_id, current_user, db)
    week = await _find_homework_week(child_id, item_id)
    if week is None:
        raise HTTPException(status_code=404, detail="作业不存在")

    def _mutate(plan: dict) -> dict:
        plan["tasks"] = [t for t in plan.get("tasks", []) if t.get("id") != item_id]
        return plan

    await webdav_service.mutate_json(f"{child_id}/plans/weekly_{week}.json", _mutate, {"tasks": []})
    return {"status": "ok"}


@router.post("/{child_id}/{item_id}/send-to-chat")
async def send_homework_to_chat(
    child_id: str,
    item_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role(*_PARENT_ROLES)),
):
    """把某条作业通过聊天消息发送给孩子。"""
    await get_child(child_id, current_user, db)
    item = next((t for t in await _all_tasks(child_id) if t.get("id") == item_id), None)
    if item is None:
        raise HTTPException(status_code=404, detail="作业不存在")

    lines = [f"📝 今日作业：{item.get('title', '')}"]
    if item.get("content"):
        lines.append(item.get("content", ""))
    content = "\n".join(lines)

    sender_name = await _family_display_name(current_user, db)

    # 优先发到家长↔孩子的家庭私聊（p2p），这样孩子端「爸爸/妈妈」会话与家长端「与孩子聊天」都能看到。
    cur = await db.execute("SELECT user_id, family_id FROM children WHERE id = ?", (child_id,))
    row = await cur.fetchone()
    child_user_id = row["user_id"] if row else None
    child_fid = row["family_id"] if row else None
    fid = current_user.get("family_id")

    if child_user_id and fid and child_fid == fid:
        lo, hi = sorted((int(current_user["id"]), int(child_user_id)))
        key = f"{fid}/p2p/{lo}_{hi}.json"
        msg = {
            "id": f"pm_{uuid.uuid4().hex[:10]}",
            "sender_id": current_user["id"],
            "sender_name": sender_name,
            "sender_role": current_user["role"],
            "content": content,
            "attachments": item.get("attachments", []),
            "created_at": _now_utc(),
        }

        def _mutate(data: dict) -> dict:
            data.setdefault("messages", []).append(msg)
            return data

        await webdav_service.mutate_json(key, _mutate, {"messages": []})
        return msg

    # 兜底：孩子没有账号时，走旧的共享消息通道。
    msg = {
        "id": f"msg_{uuid.uuid4().hex[:10]}",
        "sender_role": current_user["role"],
        "sender_name": sender_name,
        "content": content,
        "attachments": item.get("attachments", []),
        "read_at": None,
        "created_at": _now_utc(),
    }

    def _mutate_legacy(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(f"{child_id}/messages.json", _mutate_legacy, {"messages": []})
    return msg
