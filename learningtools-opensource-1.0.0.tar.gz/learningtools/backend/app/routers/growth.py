import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.quota_service import quota_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/growth", tags=["成长"])

# 类型：award 获奖 / mistake 犯错 / milestone 成长瞬间 / other 其它
_GROWTH_TYPES = {"award", "mistake", "milestone", "other"}


class GrowthBody(BaseModel):
    type: str
    title: str
    content: str | None = None
    photo_path: str | None = None
    photo_paths: list[str] | None = None  # 朋友圈式多图
    happened_at: str | None = None


async def _load_records(child_id: str) -> dict:
    return await webdav_service.read_json(f"{child_id}/growth/records.json", {"records": []})


# 成长树阶段：成长值 = 积分 + 专注总分钟数，随积累长成大树。
GROWTH_STAGES = [
    {"min": 0, "code": "seed", "name": "种子", "emoji": "🌰"},
    {"min": 100, "code": "sprout", "name": "发芽", "emoji": "🌱"},
    {"min": 300, "code": "sapling", "name": "小树苗", "emoji": "🌿"},
    {"min": 800, "code": "tree", "name": "小树", "emoji": "🌳"},
    {"min": 2000, "code": "big_tree", "name": "大树", "emoji": "🌳"},
    {"min": 5000, "code": "lush_tree", "name": "茂盛大树", "emoji": "🌲"},
]


@router.get("/{child_id}/tree")
async def growth_tree(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    """专注成就树：成长值 = 积分 + 专注总分钟数，返回当前阶段与下一阶段进度。"""
    await get_child(child_id, current_user, db)
    points = await webdav_service.read_json(f"{child_id}/rewards/points.json", {"total": 0})
    sessions = await webdav_service.read_json(f"{child_id}/focus/sessions.json", {"sessions": []})
    focus_minutes = sum(
        int(s.get("duration", 0) or 0) for s in sessions.get("sessions", [])
    ) // 60
    total = int(points.get("total", 0) or 0) + focus_minutes

    stage = GROWTH_STAGES[0]
    next_stage = None
    for i, s in enumerate(GROWTH_STAGES):
        if total >= s["min"]:
            stage = s
            next_stage = GROWTH_STAGES[i + 1] if i + 1 < len(GROWTH_STAGES) else None
    progress = None
    if next_stage:
        span = next_stage["min"] - stage["min"]
        progress = round((total - stage["min"]) / span, 4) if span > 0 else 1.0
    return {
        "growth": total,
        "points": int(points.get("total", 0) or 0),
        "focus_minutes": focus_minutes,
        "stage_code": stage["code"],
        "stage_name": stage["name"],
        "stage_emoji": stage["emoji"],
        "next_stage": next_stage["name"] if next_stage else None,
        "next_threshold": next_stage["min"] if next_stage else None,
        "progress": progress if progress is not None else 1.0,
    }


@router.get("/{child_id}")
async def list_growth(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    await get_child(child_id, current_user, db)
    data = await _load_records(child_id)
    records = data.get("records", [])
    records.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return records


@router.post("/{child_id}")
async def create_growth(
    child_id: str,
    body: GrowthBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    if body.type not in _GROWTH_TYPES:
        raise HTTPException(status_code=400, detail="无效的成长类型")
    record = body.dict()
    record["id"] = f"growth_{uuid.uuid4().hex[:10]}"
    record["created_at"] = datetime.now().isoformat()

    def _mutate(data: dict) -> dict:
        data.setdefault("records", [])
        data["records"].append(record)
        return data

    await webdav_service.mutate_json(f"{child_id}/growth/records.json", _mutate, {"records": []})
    return record


@router.put("/{child_id}/{record_id}")
async def update_growth(
    child_id: str,
    record_id: str,
    body: GrowthBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    updates = {k: v for k, v in body.dict().items() if v is not None}
    found = False

    def _mutate(data: dict) -> dict:
        nonlocal found
        for r in data.get("records", []):
            if r.get("id") == record_id:
                found = True
                r.update(updates)
        return data

    await webdav_service.mutate_json(f"{child_id}/growth/records.json", _mutate, {"records": []})
    if not found:
        raise HTTPException(status_code=404, detail="成长记录不存在")
    return {"status": "ok"}


@router.delete("/{child_id}/{record_id}")
async def delete_growth(
    child_id: str,
    record_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    found = False

    def _mutate(data: dict) -> dict:
        nonlocal found
        before = len(data.get("records", []))
        data["records"] = [r for r in data.get("records", []) if r.get("id") != record_id]
        found = len(data["records"]) != before
        return data

    await webdav_service.mutate_json(f"{child_id}/growth/records.json", _mutate, {"records": []})
    if not found:
        raise HTTPException(status_code=404, detail="成长记录不存在")
    return {"status": "ok"}


# ---------------- 成长照片上传/查看（朋友圈式发布） ----------------

@router.post("/{child_id}/photo")
async def upload_growth_photo(
    child_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(require_role("child", "super_admin", "family_admin", "parent")),
):
    """上传成长照片，存储到 {child_id}/growth/photos/。"""
    child = await get_child(child_id, current_user, db)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="照片内容为空")
    compressed = quota_service.compress_bytes(raw)
    await quota_service.check_and_reserve(child_id, db, len(compressed))

    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = now.strftime("%H-%M-%S") + f"_{uuid.uuid4().hex[:6]}.jpg"
    remote_path = f"{child_id}/growth/photos/{date_dir}/{fname}"

    local_tmp = f"/tmp/growth_{uuid.uuid4().hex}.jpg"
    with open(local_tmp, "wb") as f:
        f.write(compressed)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)

    return {"path": remote_path, "size": len(compressed)}


@router.get("/{child_id}/photo")
async def view_growth_photo(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    """查看成长照片（path 可为完整存储路径或相对路径）。"""
    await get_child(child_id, current_user, db)
    prefix = f"{child_id}/growth/photos/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"{child_id}/growth/photos/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="照片不存在")
    local = f"/tmp/growth_view_{uuid.uuid4().hex}.jpg"
    await webdav_service.download_file(remote, local)
    return FileResponse(local, media_type="image/jpeg")
