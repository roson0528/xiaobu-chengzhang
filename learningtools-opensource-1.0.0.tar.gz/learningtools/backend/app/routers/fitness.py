import uuid
from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.services.reward_service import reward_service
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/fitness", tags=["运动"])


def _month() -> str:
    return datetime.now().strftime("%Y-%m")


class FitnessBody(BaseModel):
    exercise_type: str
    duration: int | None = None
    count: int | None = None
    calories: int | None = None
    photo_path: str | None = None


@router.post("/{child_id}")
async def submit_fitness(
    child_id: str,
    body: FitnessBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    record = body.dict()
    record["id"] = f"fit_{uuid.uuid4().hex[:10]}"
    record["created_at"] = datetime.now().isoformat()

    def _mutate(data: dict) -> dict:
        data.setdefault("records", [])
        data["records"].append(record)
        return data

    await webdav_service.mutate_json(f"{child_id}/fitness/{_month()}.json", _mutate, {"records": []})
    points = await reward_service.get_behavior_points(child_id, "fitness")
    await reward_service.award_points(child_id, points, "运动打卡")
    return record


@router.get("/{child_id}")
async def list_fitness(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/fitness/{_month()}.json", {"records": []})
    return data.get("records", [])


@router.get("/{child_id}/stats")
async def fitness_stats(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    data = await webdav_service.read_json(f"{child_id}/fitness/{_month()}.json", {"records": []})
    records = data.get("records", [])
    return {
        "total_count": len(records),
        "total_duration": sum(r.get("duration", 0) or 0 for r in records),
        "total_calories": sum(r.get("calories", 0) or 0 for r in records),
    }
