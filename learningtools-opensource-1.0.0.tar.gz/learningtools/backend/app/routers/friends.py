import os
import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from app.core.deps import get_child, get_current_user, get_db, require_role
from app.routers.messages import AttachmentItem, _media_type, _type_of
from app.services.webdav_service import webdav_service

router = APIRouter(prefix="/api/v1/friends", tags=["好友"])


class RequestBody(BaseModel):
    to_child: str


class FriendMessageBody(BaseModel):
    to_child: str
    content: str
    attachments: list[AttachmentItem] = []


async def _load_links() -> dict:
    return await webdav_service.read_json("friends/links.json", {"links": []})


async def _load_requests() -> dict:
    return await webdav_service.read_json("friends/requests.json", {"requests": []})


async def _child_info(db, child_id: str) -> dict | None:
    cur = await db.execute("SELECT id, name, avatar, grade FROM children WHERE id = ?", (child_id,))
    row = await cur.fetchone()
    if row is None:
        return None
    return {"child_id": row["id"], "name": row["name"], "avatar": row["avatar"], "grade": row["grade"]}


async def _are_friends(a: str, b: str) -> bool:
    data = await _load_links()
    for l in data.get("links", []):
        if {l.get("child_a"), l.get("child_b")} == {a, b}:
            return True
    return False


def _conv(a: str, b: str) -> str:
    return "__".join(sorted([a, b]))


async def _list_friend_ids(child_id: str) -> list[str]:
    data = await _load_links()
    ids = []
    for l in data.get("links", []):
        a, b = l.get("child_a"), l.get("child_b")
        if a == child_id and b:
            ids.append(b)
        elif b == child_id and a:
            ids.append(a)
    return ids


@router.get("/search")
async def search_children(
    name: str,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    """孩子按姓名搜索可添加的好友。"""
    my_child = None
    cur = await db.execute("SELECT id, name, avatar, grade FROM children WHERE user_id = ?", (current_user["id"],))
    row = await cur.fetchone()
    if row:
        my_child = row
    my_id = my_child["id"] if my_child else None
    friend_ids = set(await _list_friend_ids(my_id)) if my_id else set()

    like = f"%{name}%"
    cur = await db.execute(
        "SELECT id, name, avatar, grade FROM children WHERE name LIKE ? AND id != ? LIMIT 20",
        (like, my_id or ""),
    )
    rows = await cur.fetchall()
    result = []
    for r in rows:
        if r["id"] in friend_ids:
            continue
        result.append({"child_id": r["id"], "name": r["name"], "avatar": r["avatar"], "grade": r["grade"]})
    return result


@router.get("/{child_id}")
async def list_friends(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    friends = []
    for fid in await _list_friend_ids(child_id):
        info = await _child_info(db, fid)
        if info:
            friends.append(info)
    return friends


@router.post("/{child_id}/request")
async def send_request(
    child_id: str,
    body: RequestBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    if body.to_child == child_id:
        raise HTTPException(status_code=400, detail="不能添加自己为好友")
    if await _are_friends(child_id, body.to_child):
        raise HTTPException(status_code=400, detail="你们已经是好友了")
    # 目标孩子需存在
    if await _child_info(db, body.to_child) is None:
        raise HTTPException(status_code=404, detail="未找到该孩子")

    # 已存在待处理的请求则直接返回
    reqs = await _load_requests()
    for r in reqs.get("requests", []):
        if r.get("from_child") == child_id and r.get("to_child") == body.to_child and r.get("status") == "pending":
            return r

    request = {
        "id": f"fr_{uuid.uuid4().hex[:10]}",
        "from_child": child_id,
        "to_child": body.to_child,
        "status": "pending",
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("requests", []).append(request)
        return data

    await webdav_service.mutate_json("friends/requests.json", _mutate, {"requests": []})
    return request


@router.get("/{child_id}/requests")
async def list_requests(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    reqs = await _load_requests()
    incoming, outgoing = [], []
    for r in reqs.get("requests", []):
        if r.get("to_child") == child_id:
            item = dict(r)
            from_info = await _child_info(db, r.get("from_child"))
            item["from_name"] = from_info["name"] if from_info else ""
            incoming.append(item)
        elif r.get("from_child") == child_id:
            item = dict(r)
            to_info = await _child_info(db, r.get("to_child"))
            item["to_name"] = to_info["name"] if to_info else ""
            outgoing.append(item)
    return {"incoming": incoming, "outgoing": outgoing}


async def _approve_or_reject(request_id: str, status: str, db, current_user):
    if status not in ("approved", "rejected"):
        raise HTTPException(status_code=400, detail="非法状态")
    reqs = await _load_requests()
    target = None
    for r in reqs.get("requests", []):
        if r.get("id") == request_id:
            target = r
    if target is None:
        raise HTTPException(status_code=404, detail="好友申请不存在")
    # 审批人必须是目标孩子的家长/管理员
    await get_child(target["to_child"], current_user, db)

    def _mutate(data: dict) -> dict:
        for r in data.get("requests", []):
            if r.get("id") == request_id:
                r["status"] = status
        return data

    await webdav_service.mutate_json("friends/requests.json", _mutate, {"requests": []})

    if status == "approved":
        def _link(data: dict) -> dict:
            data.setdefault("links", [])
            if not any({l.get("child_a"), l.get("child_b")} == {target["from_child"], target["to_child"]}
                       for l in data["links"]):
                data["links"].append({
                    "id": f"link_{uuid.uuid4().hex[:10]}",
                    "child_a": target["from_child"],
                    "child_b": target["to_child"],
                    "created_at": datetime.now().isoformat(),
                })
            return data

        await webdav_service.mutate_json("friends/links.json", _link, {"links": []})
    return {"status": "ok"}


@router.post("/requests/{request_id}/approve")
async def approve_request(
    request_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    return await _approve_or_reject(request_id, "approved", db, current_user)


@router.post("/requests/{request_id}/reject")
async def reject_request(
    request_id: str,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    return await _approve_or_reject(request_id, "rejected", db, current_user)


# ---------------- 好友互发消息 ----------------

@router.post("/{child_id}/message")
async def send_friend_message(
    child_id: str,
    body: FriendMessageBody,
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    if not await _are_friends(child_id, body.to_child):
        raise HTTPException(status_code=403, detail="你们还不是好友")
    conv = _conv(child_id, body.to_child)
    msg = {
        "id": f"fm_{uuid.uuid4().hex[:10]}",
        "from_child": child_id,
        "to_child": body.to_child,
        "content": body.content,
        "attachments": [a.model_dump() for a in body.attachments],
        "created_at": datetime.now().isoformat(),
    }

    def _mutate(data: dict) -> dict:
        data.setdefault("messages", []).append(msg)
        return data

    await webdav_service.mutate_json(f"friends/messages/{conv}.json", _mutate, {"messages": []})
    return msg


@router.get("/{child_id}/messages/{friend_child_id}")
async def list_friend_messages(
    child_id: str,
    friend_child_id: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    if not await _are_friends(child_id, friend_child_id):
        raise HTTPException(status_code=403, detail="你们还不是好友")
    conv = _conv(child_id, friend_child_id)
    data = await webdav_service.read_json(f"friends/messages/{conv}.json", {"messages": []})
    return data.get("messages", [])


# ---------------- 好友聊天附件（图片/视频/文件） ----------------

@router.post("/{child_id}/attachment")
async def upload_friend_attachment(
    child_id: str,
    file: UploadFile = File(...),
    db=Depends(get_db),
    current_user=Depends(require_role("child")),
):
    await get_child(child_id, current_user, db)
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=400, detail="文件内容为空")
    if len(raw) > 50 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件超过 50MB 限制")
    safe_name = os.path.basename(file.filename or "file").replace("/", "_").replace("\\", "_") or "file"
    now = datetime.now()
    date_dir = now.strftime("%Y-%m-%d")
    fname = f"{now.strftime('%H-%M-%S')}_{uuid.uuid4().hex[:6]}_{safe_name}"
    remote_path = f"friends/attachments/{date_dir}/{fname}"

    local_tmp = f"/tmp/frnd_up_{uuid.uuid4().hex}"
    with open(local_tmp, "wb") as f:
        f.write(raw)
    try:
        await webdav_service.upload_file(local_tmp, remote_path)
    finally:
        if os.path.exists(local_tmp):
            os.remove(local_tmp)
    return {"type": _type_of(safe_name), "path": remote_path, "name": safe_name, "size": len(raw)}


@router.get("/{child_id}/attachment")
async def view_friend_attachment(
    child_id: str,
    path: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    prefix = "friends/attachments/"
    rel = path[len(prefix):] if path.startswith(prefix) else path
    if ".." in rel or rel.startswith("/") or "\\" in rel:
        raise HTTPException(status_code=400, detail="非法路径")
    remote = f"friends/attachments/{rel}"
    if not await webdav_service.exists(remote):
        raise HTTPException(status_code=404, detail="附件不存在")
    local = f"/tmp/frnd_view_{uuid.uuid4().hex}"
    await webdav_service.download_file(remote, local)
    media = _media_type(rel)
    if media.startswith("image/"):
        return FileResponse(local, media_type=media)
    return FileResponse(local, media_type=media, filename=os.path.basename(rel))


# ---------------- 查看好友成长 ----------------

@router.get("/{child_id}/friend/{friend_child_id}/growth")
async def friend_growth(
    child_id: str,
    friend_child_id: str,
    db=Depends(get_db),
    current_user=Depends(get_current_user),
):
    await get_child(child_id, current_user, db)
    if not await _are_friends(child_id, friend_child_id):
        raise HTTPException(status_code=403, detail="你们还不是好友")
    data = await webdav_service.read_json(f"{friend_child_id}/growth/records.json", {"records": []})
    records = data.get("records", [])
    records.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return records
