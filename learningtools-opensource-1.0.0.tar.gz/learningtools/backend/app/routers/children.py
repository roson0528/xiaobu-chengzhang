import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.config import settings
from app.core.deps import (
    get_child,
    get_current_user,
    get_db,
    list_accessible_children,
    require_role,
)
from app.core.security import hash_password
from app.database import add_audit_log
from app.services.webdav_service import webdav_service
from app.services.quota_service import quota_service

router = APIRouter(prefix="/api/v1/children", tags=["孩子"])


class ChildBody(BaseModel):
    name: str
    grade: int | None = None
    birthday: str | None = None
    avatar: str | None = None
    username: str | None = None
    password: str | None = None


class QuotaBody(BaseModel):
    quota_mb: int


class RetentionBody(BaseModel):
    photo_retention_days: int | None = None
    video_retention_days: int | None = None


@router.get("")
async def list_children(db=Depends(get_db), current_user=Depends(get_current_user)):
    return await list_accessible_children(current_user, db)


@router.post("")
async def create_child(
    body: ChildBody, db=Depends(get_db), current_user=Depends(require_role("super_admin", "family_admin", "parent"))
):
    child_id = f"child_{uuid.uuid4().hex[:8]}"

    user_id = None
    if body.username and body.password:
        if len(body.password) < 6:
            raise HTTPException(status_code=400, detail="孩子账号密码至少 6 位")
        exists = await db.execute("SELECT id FROM users WHERE username = ?", (body.username,))
        if await exists.fetchone():
            raise HTTPException(status_code=400, detail="用户名已存在")
        cur = await db.execute(
            "INSERT INTO users (username, password_hash, role, status, family_id) "
            "VALUES (?, ?, 'child', 'active', ?)",
            (body.username, hash_password(body.password), current_user.get("family_id")),
        )
        await db.commit()
        user_id = cur.lastrowid

    parent_ids = str(current_user["id"])
    if current_user["role"] in ("super_admin", "family_admin"):
        # 管理员创建时可通过已有家长关联，此处默认关联到当前管理员
        parent_ids = str(current_user["id"])

    await db.execute(
        "INSERT INTO children (id, user_id, name, grade, birthday, avatar, parent_ids, family_id, "
        "quota_mb, photo_retention_days, video_retention_days) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            child_id,
            user_id,
            body.name,
            body.grade,
            body.birthday,
            body.avatar,
            parent_ids,
            current_user.get("family_id"),
            settings.default_quota_mb,
            settings.default_photo_retention_days,
            settings.default_video_retention_days,
        ),
    )
    await db.commit()
    # 预置默认徽章目录 + 积分兑换奖品目录
    await webdav_service.write_json(f"{child_id}/rewards/catalog.json", {
        "badges": [
            {"id": "badge_early_bird", "name": "早起鸟", "emoji": "🐦", "description": "连续早起"},
            {"id": "badge_reader", "name": "阅读之星", "emoji": "⭐", "description": "坚持阅读"},
            {"id": "badge_sport", "name": "运动达人", "emoji": "🏅", "description": "爱运动"},
            {"id": "badge_checkin", "name": "坚持打卡", "emoji": "🔥", "description": "每天打卡"},
            {"id": "badge_focus", "name": "专注小达人", "emoji": "🧘", "description": "专注学习"},
        ],
        "redeem_items": [
            {"id": "redeem_game_30", "name": "30分钟游戏时间", "emoji": "🎮", "cost": 100},
            {"id": "redeem_cartoon_30", "name": "看动画30分钟", "emoji": "📺", "cost": 80},
            {"id": "redeem_toy", "name": "买一个小玩具", "emoji": "🧸", "cost": 200},
        ],
    })
    await add_audit_log(str(current_user["id"]), "child:create", child_id, body.name)
    return {"id": child_id, "name": body.name, "user_id": user_id}


@router.get("/{child_id}")
async def get_child_detail(
    child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)
):
    return await get_child(child_id, current_user, db)


@router.put("/{child_id}")
async def update_child(
    child_id: str,
    body: ChildBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    fields = {}
    if body.name is not None:
        fields["name"] = body.name
    if body.grade is not None:
        fields["grade"] = body.grade
    if body.birthday is not None:
        fields["birthday"] = body.birthday
    if body.avatar is not None:
        fields["avatar"] = body.avatar
    if fields:
        sets = ", ".join(f"{k} = ?" for k in fields)
        vals = list(fields.values()) + [child_id]
        await db.execute(f"UPDATE children SET {sets} WHERE id = ?", vals)
        await db.commit()
    return {"status": "ok"}


@router.delete("/{child_id}")
async def delete_child(
    child_id: str, db=Depends(get_db), current_user=Depends(require_role("super_admin", "family_admin"))
):
    child = await get_child(child_id, current_user, db)
    await db.execute("DELETE FROM children WHERE id = ?", (child_id,))
    await db.commit()
    await add_audit_log(str(current_user["id"]), "child:delete", child_id, child.get("name"))
    return {"status": "ok"}


@router.get("/{child_id}/quota")
async def get_quota(child_id: str, db=Depends(get_db), current_user=Depends(get_current_user)):
    await get_child(child_id, current_user, db)
    quota = await quota_service.get_quota(child_id, db)
    used = await quota_service.get_used(child_id)
    return {"child_id": child_id, "quota_mb": quota, "used_mb": used}


@router.put("/{child_id}/quota")
async def set_quota(
    child_id: str,
    body: QuotaBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin")),
):
    await get_child(child_id, current_user, db)
    await db.execute("UPDATE children SET quota_mb = ? WHERE id = ?", (body.quota_mb, child_id))
    await db.commit()
    await add_audit_log(str(current_user["id"]), "child:quota", child_id, str(body.quota_mb))
    return {"status": "ok"}


@router.put("/{child_id}/retention")
async def set_retention(
    child_id: str,
    body: RetentionBody,
    db=Depends(get_db),
    current_user=Depends(require_role("super_admin", "family_admin", "parent")),
):
    await get_child(child_id, current_user, db)
    fields = []
    vals = []
    if body.photo_retention_days is not None:
        fields.append("photo_retention_days = ?")
        vals.append(body.photo_retention_days)
    if body.video_retention_days is not None:
        fields.append("video_retention_days = ?")
        vals.append(body.video_retention_days)
    if fields:
        vals.append(child_id)
        await db.execute(f"UPDATE children SET {', '.join(fields)} WHERE id = ?", vals)
        await db.commit()
    return {"status": "ok"}
