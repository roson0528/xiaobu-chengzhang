import redis.asyncio as aioredis

from app.config import settings

_client = None


def get_redis() -> aioredis.Redis:
    """返回进程级 Redis 异步客户端（每个 gunicorn worker 独立实例）。"""
    global _client
    if _client is None:
        _client = aioredis.from_url(settings.redis_url, decode_responses=True)
    return _client
