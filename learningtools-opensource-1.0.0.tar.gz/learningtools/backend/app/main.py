import logging
from contextlib import asynccontextmanager

import aiosqlite
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.config import settings
from app.core.security import hash_password
from app.database import init_db
from app.services.serverchan import serverchan
from app.tasks import netcontrol_watchdog
from app.routers import (
    admin,
    auth,
    chat_manage,
    checkins,
    children,
    diary,
    export,
    family,
    fitness,
    focus,
    friends,
    growth,
    homework,
    messages,
    mistakes,
    mood,
    netcontrol,
    notifications,
    plans,
    reading,
    reports,
    rewards,
    submissions,
    sync,
    tasks,
    users,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("learningtools")


async def ensure_admin() -> None:
    async with aiosqlite.connect(settings.sqlite_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute("SELECT COUNT(*) AS c FROM users WHERE role = 'super_admin'")
        count = (await cur.fetchone())["c"]
        if count == 0:
            await db.execute(
                "INSERT OR IGNORE INTO users (username, password_hash, role, status) "
                "VALUES (?, ?, 'super_admin', 'active')",
                (settings.admin_username, hash_password(settings.admin_password)),
            )
            await db.commit()
            if settings.admin_password == "admin123456":
                logger.warning(
                    "已创建默认管理员 %s，密码为默认值，请尽快修改！", settings.admin_username
                )
            else:
                logger.info("已创建管理员 %s", settings.admin_username)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    await ensure_admin()
    await serverchan.load_runtime_sendkey()
    watchdog = netcontrol_watchdog.start()
    try:
        yield
    finally:
        watchdog.cancel()


app = FastAPI(title="小步成长 API", version="2.0.0", lifespan=lifespan)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ROUTERS = [
    auth, users, children, plans, tasks, checkins, focus, fitness,
    reading, mistakes, rewards, reports, messages, notifications,
    admin, export, sync, growth, friends, submissions, mood,
    homework, diary, family, chat_manage, netcontrol,
]
for r in ROUTERS:
    app.include_router(r.router)


@app.get("/api/v1/app/latest")
async def app_latest_version():
    """孩子端 App「检查升级」：返回最新版本号与 APK 下载路径。"""
    return {
        "version": settings.app_version,
        "download_url": settings.app_apk_path,
        "tablet_download_url": settings.app_tablet_apk_path,
        "changelog": "",
    }


@app.get("/api/v1/app/parent/latest")
async def parent_app_latest_version():
    """家长/管理端 App「检查升级」：返回家长端版本 + 孩子端下载信息。"""
    return {
        "version": settings.app_parent_version,
        "download_url": settings.app_parent_apk_path,
        "child_app": {
            "version": settings.app_version,
            "download_url": settings.app_apk_path,
            "tablet_download_url": settings.app_tablet_apk_path,
        },
        "changelog": "",
    }


@app.get("/health")
async def health():
    status = {"api": "ok", "webdav": "unknown", "redis": "unknown"}
    try:
        from app.services.webdav_service import webdav_service

        await webdav_service.list_files("system")
        status["webdav"] = "ok"
    except Exception as e:  # noqa: BLE001
        status["webdav"] = f"error: {e}"
    try:
        from app.redis_client import get_redis

        await get_redis().ping()
        status["redis"] = "ok"
    except Exception as e:  # noqa: BLE001
        status["redis"] = f"error: {e}"
    return status
