# 学习工具项目 —— 开发前部署分析与项目理解

> 分析对象：《学习工具最终版完整部署方案（全功能版）》
> 目标：在动手写代码之前，先厘清「要做什么 / 怎么部署 / 有哪些坑 / 该怎么改」，并给出可执行的关键建议。

---

## 1. 项目理解（一页版）

### 1.1 产品定位

面向 6–12 岁小学生的**学习时间规划 + 习惯养成 + 家长监督**工具，三个端：

| 端 | 形态 | 用户 | 核心职责 |
|---|---|---|---|
| 孩子端 | Flutter Android 平板 APP | 小学生 | 看今日任务、执行打卡、进入专注模式（屏幕常亮+定时拍照+后台切换检测）、运动/阅读打卡、错题本、积分 |
| 家长端 | Vue 3 Web 后台 | 家长 | 排计划、审打卡、看专注照片/视频、配置告警、看数据看板、发消息、导出数据 |
| 管理员端 | Vue 3 Web 后台 | 系统管理员 | 账号审批、配额分配、全局配置、备份恢复、审计日志 |

### 1.2 核心链路

```text
孩子平板 ──HTTPS──▶ Nginx(:51666) ──/api──▶ FastAPI(:8000)
                                              │  Redis(会话/限流/配额)
                                              │  SQLite(本地元数据)
                                              └─HTTP─▶ WebDAV(NAS YOUR_NAS_IP:5005，唯一业务数据存储)
                                                              ▲
                                          Server酱(微信告警) ─ 家长
```

关键设计意图（文档明确声明的）：
- **后端是 WebDAV 的唯一写入方**，孩子端不直连 WebDAV，避免并发冲突。
- **孩子端离线优先**：本地 SQLite 暂存，联网后经 `/api/sync/*` 同步。
- **专注监控**：每 5 分钟前台拍照上传，检测切换后台/失焦，频繁分心则 Server酱 推微信。

### 1.3 总体评价

**优点**：覆盖面完整（RBAC、合规、备份、监控、加固都想到了）；分层清晰；有明确的端口/IP/凭证规划；孩子端对 Android 前台服务/电池优化/通知权限等"坑"有意识（第 20 章注意事项）。

**主要问题**：这是一份"方案文档"，但里面混入了大量**实现级代码**，而这些代码与文档声明之间存在**多处自相矛盾或不可落地的缺陷**（双数据源、多进程内存状态、5 分钟 WorkManager、非原子 JSON 写入等）。直接照此开发会踩坑。详见第 3 章问题清单。

---

## 2. 部署方案评估

### 2.1 网络与入口

| 项 | 方案 | 评估 |
|---|---|---|
| 公网入口 | `https://YOUR_DOMAIN:51666`，光猫+路由器两层 51666 端口映射 | ✅ 可行。**51666 是唯一暴露端口，攻击面收敛做得好** |
| 域名解析 | A 记录 `ai` → 公网 IP | ✅ 正确；⚠️ 家庭宽带公网 IP 多为**动态 IP**，文档未提 DDNS，IP 变化后 A 记录失效 |
| 静态 IP | Ubuntu YOUR_SERVER_IP，DHCP IP-MAC 绑定 | ✅ 正确 |
| UPnP/ACL | 禁用 UPnP，仅放行 51666 入站 | ✅ 正确 |
| WebDAV | 仅局域网 `YOUR_NAS_IP:5005`，明文 HTTP | ⚠️ 见 2.2 |

**建议补充**：如果公网 IP 是动态的，需要 DDNS（或用 Cloudflare Tunnel / FRP 替代端口暴露）。端口直连家庭宽带还需确认 ISP 是否封了 80/443/高端口，以及是否有 CGNAT（无公网 IP 时 51666 映射根本不通——这是**上线前必须最先验证**的事）。

### 2.2 存储（WebDAV）

- 用 NAS 的 WebDAV 作为唯一业务数据存储，后端统一读写，**方向是对的**（规避了对象存储成本、也满足"数据本地化"的合规诉求）。
- ⚠️ **问题点**：
  1. WebDAV 走明文 HTTP（LAN 内可接受，但文档第 17 章又说"传输加密"，存在口径不一致）。
  2. **JSON 文件作为业务主存储 + 读改写非原子**（见 P0-4）。
  3. **凭证明文硬编码**在 `init_webdav_dirs.sh`、检查清单等多处（见 P0-5）；密码含 `+` 号，curl/URL 需转义。
  4. 备份脚本（§15.2）依赖一个**从未配置说明的本地挂载点** `/mnt/webdav/learningtools`（应是 davfs2 挂载），且 rsync 直接对着"活数据"跑，存在**备份不一致**风险。

### 2.3 后端与运行态

- FastAPI + Gunicorn(UvicornWorker) + Redis + SQLite，标准组合，✅。
- ⚠️ 但方案存在三类**运行态硬伤**，都会在 `workers=5` 多进程下出问题（见 P0-2/3）。

### 2.4 安全与合规

- 安全加固章节（JWT/bcrypt/限流/CORS/HSTS/ufw/fail2ban）**很完整**，值得保留。
- 合规章节（§17）对《儿童个人信息网络保护规定》《未成年人网络保护条例》的映射是加分项。
- ⚠️ 但要落实：**AES 加密的密钥管理**、**监控功能的家长显式授权**、**最小化采集**目前只停留在"表"里，缺实现设计（见开放问题）。

---

## 3. 关键问题清单（按严重程度）

### P0 —— 阻塞项，开发前必须定案

#### P0-1：SQLite 与 WebDAV JSON 双数据源边界不清（§4 vs §6）

- 架构图写"SQLite = 本地元数据"；但 §6 的 SQLite 建表却包含 `tasks / checkins / focus_sessions / points / messages` 等**完整业务数据**；而 §4 又把 WebDAV 的 `plans/ logs/ fitness/ rewards/ ...` 定义成业务主存储。
- **两套结构同时存在且字段不一致**（如：§6 `children.quota_mb` vs §8.3 配额读 Redis `quota:{child_id}`；§6 `points` 表 vs §4 `rewards/points.json`）。
- **影响**：写代码时每个实体都要纠结"读写哪边、哪边是真相源、如何一致"，是最大的返工源。
- **建议**：开工前定死一张"数据归属表"。推荐：
  - **SQLite 只存**：账号/审批/家庭关系/本地队列/审计（小、强一致、要事务）。
  - **WebDAV 只存**：孩子业务数据 + 大文件（照片/视频）。
  - **Redis 只做**：缓存/会话/限流/分布式锁/计数器，**不是持久真相源**。
  - 每个实体明确"唯一真相源"，其余位置只做缓存或冗余。

#### P0-2：APScheduler 会在 5 个 worker 里各起一套 → 定时任务重复执行（§5.5 + §8.2）

- `start_scheduler()` 挂在 `@app.on_event("startup")`；Gunicorn `workers=5` 下每个 worker 进程都会执行 startup，**清理/日报/备份会各跑 5 遍**（重复发 Server酱、重复 rsync、重复删除）。
- **建议**：定时任务与 API 进程**解耦**：
  - 方案 A（推荐）：调度器独立进程/独立 systemd 服务（如 `learning-scheduler.service` 单独跑 `python -m app.tasks.scheduler`）。
  - 方案 B：用 `--preload` + `worker_id==0` 才启动（脆弱，不推荐）。
  - 方案 C：改用 systemd timer + cron 调 CLI，最稳。

#### P0-3：内存态状态在多 worker 下失效（§8.4 + §13.2）

- `FocusMonitor.child_records`（defaultdict）与 `ServerChanService.last_sent` 都是**进程内内存**。
- 5 个 worker 下，"5 分钟内第 3 次分心才告警""5 分钟节流"会因请求落在不同 worker 而**统计不准确/重复推送**。
- **建议**：分心计数与节流窗口全部下沉到 **Redis**（INCR + EXPIRE 或 Sorted Set 滑窗），跨进程共享。

#### P0-4：WebDAV JSON 的"读-改-写"非原子 → 并发丢更新（§4.3 + §8.7）

- `read_json → 内存改 → write_json`（如 `points.json`、`badges.json`、`weekly_*.json`）没有锁。同一孩子并发提交打卡/并发发奖励时，**后写覆盖先写**，积分/徽章会丢。
- **建议**：
  1. 用 **Redis 分布式锁**（`SET lock:child_id NX EX`）包住每个"读改写"事务；
  2. 或把易变数据改为**追加型文件/单条记录文件**，避免整文件重写；
  3. 保留 §4.3 已有的 `.bak` 备份，但备份不能替代锁。

#### P0-5：WebDAV 密码明文硬编码 + 特殊字符（§4.4、§19、检查清单）

- 文档一边强调"密码走环境变量、不硬编码"，一边在 `init_webdav_dirs.sh`、curl 命令、检查清单里**明文写死 `your-webdav-password`**。
- `+` 在 URL 里表示空格，curl 需要 `--data-urlencode`/引号正确转义，否则认证失败。
- **建议**：脚本统一从环境变量/`.env`（权限 600）读取；文档脱敏；上线后**立即轮换密码与 JWT_SECRET**（文档已泄露，必须视为已泄露）。

---

### P1 —— 高风险，开发早期必须解决

#### P1-1：5 分钟定时拍照低于 WorkManager 15 分钟下限（§10.3）

- Android `PeriodicWorkRequest` **最小周期是 15 分钟**，`registerPeriodicTask(frequency: Duration(minutes: 5))` 实际会退化为 15 分钟（甚至更久，取决于系统）。
- **建议**：专注期间改用**前台服务内的 `Timer`/`Handler` 自循环**实现精确 5 分钟拍照（前台服务不受 WorkManager 下限约束）；WorkManager 只用于兜底/非专注期的周期任务。

#### P1-2：`CameraDescription` 硬编码实例化不正确（§10.3）

- `CameraDescription(name:'front', sensorOrientation:270, ...)` 是错误用法；应通过 `availableCameras()` 枚举后选择 `lensDirection == front` 的实例，`sensorOrientation` 由设备返回，不能写死 270。
- **建议**：封装 `CameraService`：初始化时 `availableCameras()` 缓存前置摄像头；处理平板横竖屏旋转与照片方向。

#### P1-3：后台"强制拉回前台"受 Android 10+ 限制（§10.3）

- `AppLifecycleState.paused → forceReturnToForeground()` 依赖后台启动 Activity，**Android 10+ 默认禁止**，无 `SYSTEM_ALERT_WINDOW` 授权或"允许后台弹出界面"白名单会失效。
- **建议**：弱化"强制拉回"，改为**上报分心事件 + 前台服务通知常驻提醒**；确需"锁屏式专注"再评估悬浮窗方案（需家长显式授权，见 §20-4 已意识到这一点，保持一致）。

#### P1-4：80 端口 301 重定向与 ACME 验证冲突（§5.7）

- `listen 80 → return 301 https://...:51666` 会干扰 certbot 的 HTTP-01 续期验证（`.well-known/acme-challenge` 被重定向）。
- **建议**：在 80 端口 server 里**放行 `.well-known/acme-challenge` 静态路径**（webroot）再对其余请求 301；或干脆用 **DNS-01**（文档已列作方式二，更稳，还能应对"ISP 封 80"）。

#### P1-5：API 版本前缀自相矛盾（§8.1/§9 vs §20-20）

- 全部路由是 `/api/...`，无版本；但注意事项第 20 条又要求 `/api/v1/`。
- **建议**：**现在**就统一为 `/api/v1/`（改起来成本最低），并让 Nginx `location /api/` 保留路径转发。

#### P1-6：`/api/sync/pull` 缺失（§10.4 引用，§9 未定义）

- 孩子端 `SyncService.pullLatestData()` 调用 `/api/sync/pull`，但 §9 API 清单里没有同步相关接口。
- **建议**：补齐同步接口设计（pull 增量拉取、push 批量上报、`last_sync` 游标、幂等键），这是离线优先的命脉。

#### P1-7：配额数据源不一致（§8.3 Redis vs §6 SQLite `children.quota_mb`）

- `QuotaService.get_quota` 读 Redis `quota:{child_id}`，却没有任何地方写入它；真正的配额字段在 SQLite `children.quota_mb`。
- **建议**：配额以 SQLite `children.quota_mb` 为真相源，Redis 只缓存；"已用量"用 Redis 计数器 + 落库对账，重启后从 WebDAV 实际大小校准。

#### P1-8：ISO 周解析错误（§8.6）

- `datetime.strptime(f"{year}-W{w}-1", "%Y-W%W-%w")` 有误：`%W` 是"周一为起始、第 0 周"的纪年法，与 ISO 8601 的 `%V` 不一致；且年份应用 ISO 年 `%G` 而非日历年 `%Y`。跨年周（如 W01/W52）会算错日期。
- **建议**：统一用 `datetime.strptime(f"{year}-W{week:02d}-1", "%G-W%V-%u")`；全项目周标识统一为 ISO `YYYY-Wnn`。

#### P1-9：AI 分析接口复用 OCR 端点（§8.5 疑似 copy-paste）

- `analyze_focus_photo()` 判断的是 `if not self.ocr_endpoint`、却 POST 到 `f"{self.ocr_endpoint}/analyze"`；人脸/低头分析应有**独立的 `VISION_ENDPOINT`**。
- **建议**：把 `ocr_endpoint / asr_endpoint / vision_endpoint` 三个配置拆开，各自判空、各自超时、各自降级。

#### P1-10：家长端"实时查看专注状态"无实时通道（§11.2 vs 全 REST）

- §11.2 要求"实时查看专注状态/历史分心记录"，但后端全是 REST 轮询，无 WebSocket/SSE。
- **建议**：明确是"轮询(5–10s)"还是"WebSocket/SSE"；若真需要实时，加 `/api/v1/focus/{child_id}/stream`（SSE 更省心，Nginx 需 `proxy_buffering off`）。

---

### P2 —— 中风险，规划好再实现

| # | 问题 | 位置 | 建议 |
|---|---|---|---|
| P2-1 | 子 location（`/api/focus/upload`、`/api/auth/login`、`/api/export/`）未继承 `proxy_set_header`（因为它们与 `/api/` 是平级而非嵌套） | §5.7 | 抽出公共 `include proxy.conf` 或逐条补齐，否则丢失 X-Real-IP / X-Forwarded-Proto |
| P2-2 | `@app.on_event("startup")` 已弃用，且 §8.1 主入口没挂 `health` 路由（§18.3 却写了 `routers/health.py`） | §8.1/§18.3 | 改用 lifespan；统一健康检查入口 |
| P2-3 | `python-jose[cryptography]`、`passlib[bcrypt]` 维护停滞，passlib 与 bcrypt>=4 有兼容告警 | §5.3 | 建议换 **PyJWT**（JWT）+ **bcrypt 直接调用** 或 `pwdlib` |
| P2-4 | `apt install python3.11` 在 Ubuntu 22.04 默认源不存在，需 deadsnakes PPA | §5.1 | 明确目标 Ubuntu 版本，或锁定 22.04 + deadsnakes / 24.04 自带 |
| P2-5 | 备份依赖未说明的 `/mnt/webdav` 挂载 + rsync 直接对活数据 | §15.2/15.3 | 用 `davfs2` 显式挂载，或让备份走后端 WebDAV 客户端；备份前短暂静默或快照 |
| P2-6 | 离线同步无冲突解决策略（last-write-wins？服务端时间 vs 设备时间？） | §10.4 | 定义并发冲突策略 + 每条记录唯一幂等键 |
| P2-7 | 敏感文件 AES 加密的**密钥管理**未定义（密钥存哪、怎么轮换） | §16.3/§17 | 定义 KMS/主密钥方案；密钥与数据分离存放 |
| P2-8 | "SQLite 本地元数据"也要纳入备份，但 §15 只备了 WebDAV 数据 | §20-13 已提到 | 把 SQLite 文件（含 WAL）一并纳入备份与恢复演练 |

---

### P3 / 开放问题（需与业务方确认）

1. **公网可达性前置验证**：ISP 是否 CGNAT？有无公网 IP？80/443/51666 是否被封？→ 先测通，再决定"端口直连"还是"隧道/内网穿透"方案。
2. **儿童监控的伦理与合规**：§17 已意识到，但要形成**家长显式授权流程**（功能清单 + 同意）和**孩子可见的"正在被记录"提示**，并默认保守的保留期（照片 30 天/视频 15 天）。
3. **Server酱 免费额度**（5 条/天）与告警频率的矛盾：明确是自建 Webhook 还是购买 Turbo，或改企业微信/钉钉/飞书机器人。
4. **AI 能力是否在 MVP 内**：OCR/ASR/人脸/姿态均为"可选、未配置端点"，需定 MVP 是否包含；否则先做规则版（拍照异常/后台切换）就够。
5. **单点故障与规模**：单 Ubuntu + 单 NAS，家庭场景可接受；明确"无 HA、允许短暂中断"的 SLO。
6. **多孩子扩展**：`child_01/child_02` 目录是硬编码示例，孩子需**动态生成目录/ID**，并做路径安全校验（防目录穿越）。
7. **测试与 CI**：文档无测试/CI 章节；至少为"周解析、RBAC 矩阵、配额、同步幂等"补单元测试。
8. **APK 侧载分发**：家庭自用可 adb 侧载；若要给其他家庭用，需考虑签名、应用商店合规、后台隔离（目前"家庭"概念 vs 全局超级管理员的关系要厘清）。

---

## 4. 关键建议（优先级排序）

### 建议 1（最高优先）：开工前定稿"数据归属 + 进程模型"两张表

- **数据归属表**：每个实体唯一真相源（SQLite / WebDAV / Redis），消除 §4 与 §6 的冲突。
- **进程模型**：API(Gunicorn 5 worker) + Scheduler(独立进程) + 定时任务(systemd timer)，把 P0-2/3 从根上解决。

### 建议 2：MVP 裁剪，先跑通主链路

首版建议只保留闭环：**注册/审批 → 孩子档案 → 周计划/今日任务 → 打卡(照片) → 家长审核 → 专注模式(前台服务+拍照+后台切换告警) → 积分/徽章 → 周报**。OCR/ASR/姿态分析、邮件、Webhook、Excel 导出等一律二期。

### 建议 3：先验证外部依赖，再写代码

按 §19.2 检查清单，但**提前**做四件事：
1. 公网 IP / CGNAT / 端口封禁验证；
2. WebDAV PROPFIND 连通性 + 目录初始化（改环境变量取密码）；
3. Android 14 真机验证：前台服务 dataSync、POST_NOTIFICATIONS、电池优化白名单、定时拍照；
4. Server酱 真机收到告警。

### 建议 4：把"实时/一致性"类需求在方案期定死

- 实时专注状态：轮询还是 SSE；
- 同步冲突策略；
- WebDAV JSON 并发写：分布式锁还是追加型存储。

### 建议 5：安全口径统一

- 脱敏所有明文凭证、轮换已泄露的 WebDAV 密码与 JWT_SECRET；
- 统一"环境变量注入 + 600 权限"；
- 补齐 AES 密钥管理与备份加密。

---

## 5. 建议的开发落地顺序（供参考）

1. **阶段 0（本次）**：定稿数据归属表、进程模型、API 版本前缀 → 生成《技术设计定稿》替代本方案中的实现代码。
2. **阶段 1**：后端骨架（FastAPI + 分层 + RBAC + 认证 + WebDAV 封装含锁）+ SQLite 迁移框架 + 单测（周解析/RBAC/配额）。
3. **阶段 2**：孩子端 MVP（任务/打卡/专注模式）+ 同步队列。
4. **阶段 3**：家长/管理员后台（计划编排、审核、专注照片、数据看板）。
5. **阶段 4**：告警(Server酱)、备份恢复、合规授权流程、安全加固联调。
6. **阶段 5**：真机联调 + §19.2 全量检查清单 + 恢复演练（备份→还原→验证）。

---

*本文件为开发前分析，用于对齐认知与排雷；具体技术定稿应在阶段 0 产出并取代方案文档中的实现级代码。*
